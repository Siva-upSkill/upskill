package constants;

public interface Device {
	String NOKIA7="NOKIA7";
	String IPADAIR="IPADAIR";
	String HUAWEIMATE30="HUAWEIMATE30";
	String Testmobilemi = "Testmobilemi";
	String Samsung="Samsung";


}
