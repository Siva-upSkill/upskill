package actions;

import base.Keywords;
import exceptions.ApplicationException;
import io.appium.java_client.MobileElement;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class Type extends Keywords{

    private static Logger log=Logger.getLogger(Type.class);

    public void data(String locatorKey,String value) throws ApplicationException {
        log.info("Type the value ["+value+"] into element ["+locatorKey+"]");
        get.elementBy(locatorKey).clear();
        get.elementBy(locatorKey).sendKeys(value);
       // keyboard.hideIOS();
        log.info("Type Successful!");
    }

    public void data1(String locatorKey,String value) throws ApplicationException
    {
        log.info("Type the value ["+value+"] into element ["+locatorKey+"]");
        //driver.findElements(By.id("com.unionbankph.online.qat:id/text_pin"));
        get.elementBy(locatorKey);
        Actions action = new Actions(driver);
        action.sendKeys(value).build().perform();
        log.info("Type Successful!");
    }

    public void clearandType(String locatorKey,String value) throws ApplicationException
    {
        log.info("Type the value ["+value+"] into element ["+locatorKey+"]");
        get.elementBy(locatorKey);
        get.elementBy(locatorKey).clear();
        get.elementBy(locatorKey).sendKeys(Keys.chord(Keys.CONTROL,"a",Keys.DELETE));
        Actions action = new Actions(driver);
        action.sendKeys(value).perform();
        log.info("Type Successful!");
    }

    public void sensitiveData(String locatorKey,String value) throws ApplicationException {
        log.info("Type the value ["+value.substring(0,2)+"*****] into element ["+locatorKey+"]");
        get.elementBy(locatorKey).sendKeys(value);
       // keyboard.hideIOS();
        log.info("Type Successful!");
    }

    public void data(By locator, String value) throws ApplicationException {
        log.info("Type the value ["+value+"] into element ["+locator+"]");
        get.elementBy(locator).sendKeys(value);
       // keyboard.hideIOS();
        log.info("Type Successful!");
    }

    public void sensitiveData(By locator,String value) throws ApplicationException {
        log.info("Type the value ["+value.substring(0,2)+"*****] into element ["+locator+"]");
        get.elementBy(locator).sendKeys(value);
      //  keyboard.hideIOS();
        log.info("Type Successful!");
    }

    public void data(String locatorKey,String value,boolean hideKeyboard) throws ApplicationException {
        log.info("Type the value ["+value+"] into element ["+locatorKey+"]");
        get.elementBy(locatorKey).sendKeys(value);
        if(hideKeyboard){
            keyboard.hide();
        }
        log.info("Type Successful!");
    }

    public void sensitiveData(String locatorKey,String value,boolean hideKeyboard) throws ApplicationException {
        log.info("Type the value ["+value.substring(0,2)+"*****] into element ["+locatorKey+"]");
        get.elementBy(locatorKey).sendKeys(value);
        if(hideKeyboard){
            keyboard.hide();
        }
        log.info("Type Successful!");
    }

    public void data(By locator, String value,boolean hideKeyboard) throws ApplicationException {
        log.info("Type the value ["+value+"] into element ["+locator+"]");
        get.elementBy(locator).sendKeys(value);
        if(hideKeyboard){
            keyboard.hide();
        }
        log.info("Type Successful!");
    }

    public void sensitiveData(By locator,String value,boolean hideKeyboard) throws ApplicationException {
        log.info("Type the value ["+value.substring(0,2)+"*****] into element ["+locator+"]");
        get.elementBy(locator).sendKeys(value);
        if(hideKeyboard){
            keyboard.hide();
        }
        log.info("Type Successful!");
    }

//    public void clearvalue(String locatorKey,String value) throws ApplicationException)
//    {
//        log.info("Type the value ["+value+"] into element ["+locatorKey+"]");
//        get.elementBy(locatorKey);
//        get.elementBy(locatorKey).clear();
//        get.elementBy(locatorKey).sendKeys(Keys.chord(Keys.CONTROL,"a",Keys.DELETE));
//        Actions action = new Actions(driver);
//        action.sendKeys(value).perform();
//        log.info("Type Successful!");
//    }
}