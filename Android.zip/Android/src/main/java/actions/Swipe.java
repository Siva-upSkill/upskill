package actions;

import base.Keywords;
import base.Test;
import constants.Keys;
import constants.OS;
import exceptions.ApplicationException;
import io.appium.java_client.MobileBy;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

import java.time.Duration;

import org.apache.log4j.Logger;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriverException;

import java.util.HashMap;

public class Swipe extends Keywords {

    private static Logger log=Logger.getLogger(Swipe.class);


 /*   public void scrollDownToText() throws ApplicationException {
        if(Test.attributes.get(Keys.OS).equalsIgnoreCase(OS.ANDROID)) {
            try{

                driver.findElement(MobileBy.AndroidUIAutomator(
                        "new UiScrollable(new UiSelector()).scrollIntoView(new UiSelector().text(\""+searchText +"\"));"

            }catch (WebDriverException e) {
                driver.findElement(MobileBy.AndroidUIAutomator(
                        "new UiScrollable(new UiSelector()).scrollIntoView(new UiSelector().text(\""+searchText +"\"));"

            }catch (Throwable e) {
                throw new ApplicationException("Element not found!");
            }
        }else {
            try{
            }catch (Throwable ex){
                throw new ApplicationException("Element not found!");
            }
        }
    }*/

    public void swipeVertical(int divideScreenInto,double startPointPercentage,double endPointPercentage) throws ApplicationException {
        try {
            Dimension size = driver.manage().window().getSize();
            int x = size.width/divideScreenInto;
            int startPoint = (int) (size.height * startPointPercentage);
            int endPoint = (int) (size.height * endPointPercentage);
            //new TouchAction(ResourceBase.driver).press(x, startPoint).moveTo(x, endPoint).release().perform();
            new TouchAction(driver).press(PointOption.point(x, startPoint)).moveTo(PointOption.point(x, endPoint)).release().perform();
        }catch(Exception e) {
            log.info("Failed to Swipe " + e.getMessage());
            throw new ApplicationException(e.getMessage());
        }
    }
    public void swipeVertical(int divideScreenInto,double startPointPercentage,double endPointPercentage,int slowDownDurationInSeconds) throws ApplicationException {
        try {
            Dimension size = driver.manage().window().getSize();
            int x = size.width/divideScreenInto;
            int startPoint = (int) (size.height * startPointPercentage);
            int endPoint = (int) (size.height * endPointPercentage);
            new TouchAction(driver).press(PointOption.point(x, startPoint)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(slowDownDurationInSeconds))).moveTo(PointOption.point(x, endPoint)).release().perform();
            //new TouchAction(ResourceBase.driver).press(x, startPoint).waitAction(Duration.ofMillis(slowDownDurationInSeconds)).moveTo(x, endPoint).release().perform();
        }catch(Exception e) {
            log.info("Failed to Swipe " + e.getMessage());
            throw new ApplicationException(e.getMessage());
        }
    }

    public void swipeHorizontal(int divideScreenInto,double startPointPercentage,double endPointPercentage,int slowDownDurationInSeconds) throws ApplicationException  {
        try {
            Dimension size = driver.manage().window().getSize();
            int y = size.height/divideScreenInto;
            int startPoint = (int) (size.width * startPointPercentage);
            int endPoint = (int) (size.width * endPointPercentage);
            new TouchAction(driver).press(PointOption.point(startPoint, y)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(slowDownDurationInSeconds))).moveTo(PointOption.point(endPoint, y)).release().perform();
            //new TouchAction(ResourceBase.driver).press(x, startPoint).waitAction(Duration.ofMillis(slowDownDurationInSeconds)).moveTo(x, endPoint).release().perform();
        }catch(Exception e) {
            log.info("Failed to Swipe " + e.getMessage());
            throw new ApplicationException(e.getMessage());
        }
    }

    public void androidScrollToAnElementByText(String text) {
        try {
            ((AndroidDriver)driver).findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().text(\"" + text + "\").instance(0))");
        } catch (Exception e) {
            throw new NoSuchElementException("No element" + e);
        }
    }
    public void scrollDownToTextandClick(String searchText) throws ApplicationException {
        searchText = searchText.trim();
        if (Test.attributes.get(Keys.OS).equalsIgnoreCase(OS.ANDROID)) {
            try {
                driver.findElement(MobileBy.AndroidUIAutomator(
                        "new UiScrollable(new UiSelector()).scrollIntoView(new UiSelector().text(\"" + searchText + "\"));"
                )).click();
            } catch (WebDriverException e) {
                driver.findElement(MobileBy.AndroidUIAutomator(
                        "new UiScrollable(new UiSelector()).scrollIntoView(new UiSelector().text(\"" + searchText + "\"));"
                )).click();
            } catch (Throwable ex) {
                log.error(ex.getMessage());
                throw new ApplicationException("Element not found!" + ex.getMessage());
            }
            log.info("Scrolled to the element matching the text --> " + searchText);
        }
        else
        {
            {
                try {
                    boolean found = false;
                    JavascriptExecutor js = driver;
                    HashMap scrollObject = new HashMap<>();
                    scrollObject.put("predicateString", "value == '" + searchText + "'");
                    scrollObject.put("direction", "down");
                    int toleranceTime = 50;
                    int i = 0;
                    js.executeScript("mobile: scroll", scrollObject);
                    while (!( driver.findElement(MobileBy.AccessibilityId(searchText)).isDisplayed() )) {
                        i += 1;
                        js.executeScript("mobile: scroll", scrollObject);
                        if (i > toleranceTime) {
                            break;
                        }
                        if (driver.findElement(MobileBy.AccessibilityId(searchText)).isDisplayed()) {
                            driver.findElement(MobileBy.AccessibilityId(searchText)).click();
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        log.error("Element matching the text " + searchText + " is not found");
                        throw new ApplicationException("Element matching the text " + searchText + " is not found");
                    }
                    log.info("Scrolled to the element matching the text --> " + searchText);
                    //driver.findElement(MobileBy.AccessibilityId("Done")).click();

                } catch (Throwable ex) {
                    log.error(ex.getMessage());
                    ex.printStackTrace();

                }
            }
        }
    }

    public void scrollDownToClickBookVisitIOS(String searchText) throws ApplicationException {
        boolean found = false;
        JavascriptExecutor js = driver;
        HashMap scrollObject = new HashMap<>();
        scrollObject.put("predicateString", "value == '" + searchText + "'");
        scrollObject.put("direction", "down");
        int toleranceTime = 50;
        int i = 0;
        Wait.forSeconds(20);
        js.executeScript("mobile: scroll", scrollObject);

       /* while (!( driver.findElement(MobileBy.AccessibilityId(searchText)).isDisplayed() )) {
            i += 1;
            js.executeScript("mobile: scroll", scrollObject);
            if (i > toleranceTime) {
                break;
            }
            if (driver.findElement(MobileBy.AccessibilityId(searchText)).isDisplayed()) {
                driver.findElement(MobileBy.AccessibilityId(searchText)).click();
                found = true;
                break;
            }
        }*/

        while (!( driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"UnionBank\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell[6]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton").isDisplayed() )) {

            i += 1;
            js.executeScript("mobile: scroll", scrollObject);
            if (i > toleranceTime) {
                break;
            }
            if (driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"UnionBank\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell[6]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton").isDisplayed()) {
                driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"UnionBank\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell[6]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton").click();
                found = true;
                break;
            }
        }
    }

    public void scrollDownToTextandClickIOS(String searchText) throws ApplicationException {

        try {
            boolean found = false;
            JavascriptExecutor js = driver;
            HashMap scrollObject = new HashMap<>();
            scrollObject.put("predicateString", "value == '" + searchText + "'");
            scrollObject.put("direction", "down");
            int toleranceTime = 50;
            int i = 0;
            Wait.forSeconds(10);
            js.executeScript("mobile: scroll", scrollObject);


            if (!found) {
                log.error("Element matching the text " + searchText + " is not found");
                throw new ApplicationException("Element matching the text " + searchText + " is not found");
            }
            log.info("Scrolled to the element matching the text --> " + searchText);
            //driver.findElement(MobileBy.AccessibilityId("Done")).click();

        } catch (Throwable ex) {
            log.error(ex.getMessage());
            ex.printStackTrace();

        }
    }

    public void scrollDownToTextandVerify(String searchText, String yesorno) throws ApplicationException {
        boolean found = false;
        String result=null;
        searchText = searchText.trim();
        if (Test.attributes.get(Keys.OS).equalsIgnoreCase(OS.ANDROID)) {
            // boolean found = false;
            try {
                driver.findElement(MobileBy.AndroidUIAutomator(
                        "new UiScrollable(new UiSelector()).scrollIntoView(new UiSelector().text(\"" + searchText + "\"));"
                )).isDisplayed();
                found=true;

            } catch (Throwable ex) {
                //log.error(ex.getMessage());
                //throw new ApplicationException("Element not found!" + ex.getMessage());

            }
            log.info("Scrolled to the element matching the text --> " + searchText);
        }

        if(found)
        {
            result = "yes";
        }
        else
        {
            result = "no";
        }
        if (result.equalsIgnoreCase(yesorno)){
            log.info("Successfully Verified");
        }
        else{}
        log.error("Successfully not Verified");

    }

}
