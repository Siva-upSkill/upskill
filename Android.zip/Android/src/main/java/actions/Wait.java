package actions;

import helper.PropertyReader;
import io.appium.java_client.AppiumDriver;
import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import base.Keywords;

import java.time.Duration;

public class Wait extends Keywords {

    private static Logger log=Logger.getLogger(Wait.class);

    public static void forSeconds(int seconds) {
        try{
            Thread.sleep(seconds*1000);
        }catch (InterruptedException e){
            log.warn("Failed to execute thread.sleep()");
        }
    }
    public static void waituntillElementVisibleMob(String locatorKey, int waitSeconds)  {
        try {
            WebDriverWait wait1 = new WebDriverWait(driver, waitSeconds);
            wait1.until(ExpectedConditions.presenceOfElementLocated(PropertyReader.locatorOf(locatorKey)));
            log.info("Waited for "+waitSeconds+" seconds");
        }catch(Exception e){
            log.warn("Failed to execute WaitUntill Element Visible Method.");
        }
    }

    public void forSecondsUsingFluentWAIT(int seconds,String elementType) {
        try{
            FluentWait<AppiumDriver> fluentwait = new FluentWait<AppiumDriver>(driver)
                    .withTimeout(Duration.ofSeconds(seconds))
                    .pollingEvery(Duration.ofSeconds(3))
                    .ignoring(NoSuchElementException.class);
            fluentwait.until(ExpectedConditions.presenceOfElementLocated(PropertyReader.locatorOf(elementType)));
            log.info("Waited for "+seconds+" seconds");
        }catch (Exception e){
            log.warn("Failed to execute fluent wait");
        }
    }

}
