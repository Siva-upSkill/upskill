package actions;

import base.Keywords;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.time.Duration;

public class Touch extends Keywords {


    private static Logger log = Logger.getLogger(Swipe.class);



    public static void touchLongPress(int xstrat, int ystart, int xend, int yend) {

          try {
              TouchAction touchAction = new TouchAction(driver);
        //      touchAction.longPress(xstrat).waitAction(3000).moveTo(yend).perform().release();
              touchAction.longPress(PointOption.point(xstrat, ystart)).waitAction(WaitOptions.waitOptions(Duration.parse("3000"))).moveTo(PointOption.point(xend, yend)).release().perform();
              //touchAction.longPress(PointOption.point(50,250)).moveTo(PointOption.point(50,1000)).release().perform();
              Wait.forSeconds(3);
              log.info("Successfully press in the screen");

          }
          catch(Exception e){
              log.info("Failed to touch " + e.getMessage());
              e.printStackTrace();
          }
    }

    public static void pressByCoordinates (int x, int y, long seconds) {

        try {
        TouchAction touchAction = new TouchAction(driver);
                touchAction.tap(PointOption.point(x,y)).release().perform();
                Wait.forSeconds(3);
        log.info("Successfully press in the screen");
    }
        catch(Exception e){
        log.info("Failed to press " + e.getMessage());
        e.printStackTrace();
        }
    }

    public static void getTextByCoordinates (int x, int y, long seconds) {

        try {
            TouchAction touchAction = new TouchAction(driver);
            //touchAction.tap(PointOption.point(x,y)).release().perform();
            touchAction.toString();
            Wait.forSeconds(3);
            log.info("Successfully press in the screen");
        }
        catch(Exception e){
            log.info("Failed to press " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void touch( WebElement e)
    {
        AndroidTouchAction touch = new AndroidTouchAction(driver);

        touch.tap (TapOptions.tapOptions ()
                .withElement (ElementOption.element (e)))
                .perform ();
    }


/*
        public static void dragAndDrop(int xa,int ya,int xb,int yb)

        {
        //AndroidElement a = (AndroidElement) driver.findElementByXPath("//*[contains(@text,'Barcelona')]");
        //AndroidElement b = (AndroidElement) driver.findElement(By.id("dragdrop.stufflex.com.dragdrop:id/answer"));


action.longPress(PointOption.point(a.getLocation().x, a.getLocation().y)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(b.getLocation().x, b.getLocation().y)).release().perform();
            try {
                TouchAction touchAction = new TouchAction(driver);
                touchAction.longPress(PointOption.point(xstrat, ystart)).moveTo(PointOption.point(xend, yend)).release().perform();
                //touchAction.longPress(PointOption.point(50,250)).moveTo(PointOption.point(50,1000)).release().perform();
                Wait.forSeconds(3);
                log.info("Successfully press in the screen");

            }
            catch(Exception e){
                log.info("Failed to touch " + e.getMessage());
                e.printStackTrace();
            }

    }

 */
}


