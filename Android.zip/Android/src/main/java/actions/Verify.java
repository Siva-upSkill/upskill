package actions;

import base.Keywords;
import base.Test;
import exceptions.ApplicationException;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;

import java.util.List;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class Verify extends Keywords{

	private static Logger log=Logger.getLogger(Verify.class);

	public void elementIsPresent(String locatorKey) throws ApplicationException {
		log.info("Verify element ["+locatorKey+"] is present");
		get.elementBy(locatorKey);
		log.info("Element is present!");
	}



	public void elementIsPresent(By locator) throws ApplicationException {
		log.info("Verify element ["+locator+"] is present");
		get.elementBy(locator);
		log.info("Element is present!");
	}

	public void elementTextMatching(String locatorKey,String expectedValue) throws ApplicationException {
		log.info("Verify element ["+locatorKey+"] text is matching with ["+expectedValue+"]");
		//Wait.forSeconds(8);
		String actualValue=Test.tools.REMOVE_MULTIPLE_SPACES_AND_NEW_LINES(get.elementBy(locatorKey).getText().trim());
		actualValue=actualValue.toLowerCase();
		expectedValue=expectedValue.toLowerCase();
		//String actualValue=get.elementBy(locatorKey).getText().trim();
		//String actualValue = driver.findElement(By.xpath("//*[@text='EVENLY']")).getText();
		try{
			isMatching(expectedValue,actualValue);
		}catch (Exception ex){
			log.error(ex);
			throw new ApplicationException(ex.getMessage());
		}
		log.info("Condition verified!");
	}

	public boolean elementTextMatchingboolean(String locatorKey,String expectedValue) throws ApplicationException {
		boolean test=false;
		log.info("Verify element ["+locatorKey+"] text is matching with ["+expectedValue+"]");
		//Wait.forSeconds(8);
		String actualValue=Test.tools.REMOVE_MULTIPLE_SPACES_AND_NEW_LINES(get.elementBy(locatorKey).getText().trim());
		actualValue=actualValue.toLowerCase();
		expectedValue=expectedValue.toLowerCase();
		//String actualValue=get.elementBy(locatorKey).getText().trim();
		//String actualValue = driver.findElement(By.xpath("//*[@text='EVENLY']")).getText();
		try{
			isMatching(expectedValue,actualValue);
			test=true;
		}catch (Exception ex){


		}
		log.info("Condition verified!");
		return test;
	}


	public void elementTextContains(String locatorKey,String expectedValue) throws ApplicationException {
		log.info("Verify element ["+locatorKey+"] text is matching with ["+expectedValue+"]");
		String actualValue=Test.tools.REMOVE_MULTIPLE_SPACES_AND_NEW_LINES(get.elementBy(locatorKey).getText().trim());
		try{
			Assert.assertTrue(actualValue.contains(expectedValue.trim()),"Condition failed!, actual value doesn't contains the expected value");
		}catch (Exception ex){
			log.error(ex);
			throw new ApplicationException(ex.getMessage());
		}
		log.info("Condition verified!");
	}

	public void elementTextMatching(By locator,String expectedValue) throws ApplicationException {
		log.info("Verify element ["+locator+"] text is matching with ["+expectedValue+"]");
		String actualValue=Test.tools.REMOVE_MULTIPLE_SPACES_AND_NEW_LINES(get.elementBy(locator).getText().trim());
		try{
			isMatching(expectedValue,actualValue);
		}catch (Exception ex){
			log.error(ex);
			throw new ApplicationException(ex.getMessage());
		}
		log.info("Condition verified!");
	}

	public void elementTextContains(By locator,String expectedValue) throws ApplicationException {
		log.info("Verify element ["+locator+"] text is matching with ["+expectedValue+"]");
		String actualValue=Test.tools.REMOVE_MULTIPLE_SPACES_AND_NEW_LINES(get.elementBy(locator).getText().trim());
		try{
			Assert.assertTrue(actualValue.contains(expectedValue.trim()),"Condition failed!, actual value doesn't contains the expected value");
		}catch (Exception ex){
			log.error(ex);
			throw new ApplicationException(ex.getMessage());
		}
		log.info("Condition verified!");
	}

	public void elementtrimTextContains(String locatorKey,String expectedValue) throws ApplicationException {
		log.info("Verify element ["+locatorKey+"] text is matching with ["+expectedValue+"]");
		String actualValue=Test.tools.REMOVE_MULTIPLE_SPACES_AND_NEW_LINES(get.elementBy(locatorKey).getText().trim());
		actualValue=actualValue.replace(",","");
		try{
			Assert.assertTrue(actualValue.contains(expectedValue.trim()),"Condition failed!, actual value doesn't contains the expected value");
		}catch (Exception ex){
			log.error(ex);
			throw new ApplicationException(ex.getMessage());
		}
		log.info("Condition verified!");
	}


	public void isMatching(String expected,String actual){
		Assert.assertTrue(actual.equalsIgnoreCase(expected.trim()),"Condition failed!, actual value[ "+actual+" ]doesn't match with expected value[ "+expected+" ]");
	}


	public void elementIsEnabled(String locatorKey) throws ApplicationException {
		log.info("Verify element ["+locatorKey+"] is Enabled");
		try{
			Boolean enable=get.elementBy(locatorKey).isEnabled();
			Assert.assertTrue(enable.booleanValue());
			//Assert.assertTrue( get.elementBy(locatorKey).isEnabled());
			log.info("Element is Enabled!");
		}catch(Exception e){
			throw new ApplicationException(e.getMessage());
		}
	}

	public void elementIsEnabled(By locator) throws ApplicationException {
		log.info("Verify element ["+locator+"] is Enabled");
		try{
			Assert.assertTrue( get.elementBy(locator).isEnabled());
			log.info("Element is Enabled!");
		}catch(Exception e){
			throw new ApplicationException(e.getMessage());
		}
	}

	public void elementIsDisabled(String locatorKey) throws ApplicationException {
		log.info("Verify element ["+locatorKey+"] is Disabled");
		try{
			/////
			Boolean enable=get.elementBy(locatorKey).isEnabled();
			Assert.assertFalse(enable.booleanValue());
			//Assert.assertFalse(!get.elementBy(locatorKey).isEnabled());
			log.info("Verification success, Element " + locatorKey + " is disabled");
		}catch(Exception e){
			throw new ApplicationException(e.getMessage());
		}

	}


	public void elementTextMatching(String locatorKey,int whichElement,String expectedValue) throws ApplicationException {
		log.info("Verify element ["+locatorKey+"] text is matching with ["+expectedValue+"]");
		String actualValue=Test.tools.REMOVE_MULTIPLE_SPACES_AND_NEW_LINES(get.elementBy(locatorKey,whichElement).getText().trim());
		try{
			isMatching(expectedValue,actualValue);
			log.info("Condition verified!");
		}catch (Exception ex){
			log.error(ex);
			throw new ApplicationException(ex.getMessage());
		}

	}

	public void IfElementExists(By locator) throws ApplicationException {
		try{
			get.elementBy(locator);
			log.info("ApplicationException success, Element " + locator + " exists in the page");
		}catch(Exception e){
			throw new ApplicationException(e.getMessage());
		}
	}




	public void IfElementExists(String locatorKey) throws ApplicationException {
		try{
			get.elementBy(locatorKey);

			log.info("Verification success, Element " + locatorKey + " exists in the page");
		}catch(Exception e){
			throw new ApplicationException(e.getMessage());
		}
	}


	public boolean IfElementExistsboolean(String locatorKey) throws ApplicationException {
		boolean test=false;
		try{
			test=get.elementBy(locatorKey).isDisplayed();


			log.info("Verification success, Element " + locatorKey + " exists in the page");
			//test=true;
		}catch(Exception e){

		}
		return test;
	}

	public void IfElementNotExists(String locatorKey) throws ApplicationException {
		try{
			get.elementBy(locatorKey);
			throw new ApplicationException("Element " + locatorKey + " exists in the page");
		}catch(ApplicationException e){
			log.info("Verification success, Element " + locatorKey + " not exist in the page");
		}
	}

	public void ElementTextByAttribute(String locatorKey,String expectedValue,String whichAttribute) throws ApplicationException {
		try{
			String actualValue = get.elementBy(locatorKey).getAttribute(whichAttribute.trim());
			Assert.assertEquals(expectedValue.trim(),actualValue.trim());
			log.info("Verification success, Expected value " + expectedValue + " matching with Actual text " + actualValue);
		}catch(Exception e){
			throw new ApplicationException(e.getMessage());
		}
	}

	public boolean elementText(String locatorKey,String ivalue) throws ApplicationException {

		boolean val=false;
		try{
			//attachScreenshot("Click_"+ locatorKey.replace(".","_"));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(locatorKey)));
			List<WebElement> a=driver.findElements(By.id(locatorKey));
			for (int i = 0; i <a.size(); i++) {
				if((a.get(i).getText().trim()).contentEquals(ivalue.trim()))
				{
					val=true;
					break;
				}

			}

		}catch(Exception e){
			throw new ApplicationException(e.getMessage());
		}

		return val;
	}

	public void verifyTransactionDate(String tyear,String tmonth,String tday) throws ApplicationException
	{
		int year=Integer.parseInt(tyear);
		String month=tmonth.substring(0,3).trim();
		//int date=Integer.parseInt(tday);
		String formatdate=tday+" "+tmonth+" "+tyear;
		String imonth;
		//for loop iteration
		int loopcount=10;
		String iyear;

		iyear=driver.findElement(By.id("com.unionbankph.online.qat:id/mdtp_date_picker_year")).getText();
		if(year==Integer.parseInt(iyear.trim()))
		{

			for (int l = 0; l < loopcount; l++) {
				imonth=driver.findElement(By.id("com.unionbankph.online.qat:id/mdtp_date_picker_day")).getText().substring(5,8);
				if(month.contains(imonth))
				{
					try {
						driver.findElementByAccessibilityId(formatdate).getAttribute("selected");
						driver.findElementByAccessibilityId(formatdate).click();
						driver.findElementByAccessibilityId(formatdate).getAttribute("selected");

					}
					catch (Exception e)
					{
						// TODO: handle exception
						driver.findElementByAccessibilityId(formatdate+" selected").getAttribute("selected");
					}
					try {
						String evalue;
						try {
							evalue=driver.findElementByAccessibilityId(formatdate).getAttribute("selected");
						}
						catch (Exception e)
						{
							// TODO: handle exception
							evalue=driver.findElementByAccessibilityId(formatdate+" selected").getAttribute("selected");
						}
						if(evalue.contentEquals("true"))
						{
							log.info("Verification success, Expected Date " + formatdate + " is a present or future date and it is in enable mode");
						}
						else
						{
							log.info("Verification success, Expected Date " + formatdate + " is a past date and it is in disable mode");
						}

						break;

					}
					catch (Exception e)
					{
						// TODO: handle exception
						throw new ApplicationException(e.getMessage());
					}
				}
				else
				{
					//swipe horizontal for choosing the Month
					swipe.swipeHorizontal(2,0.85,0.35,1);
					click.elementBy(By.xpath("(//android.view.View)[6]"));
				}
			}

		}
		else
		{
			driver.findElement(By.id("com.unionbankph.online.qat:id/mdtp_date_picker_year")).click();
			for (int i = 0; i < loopcount; i++)
			{
				if(verify.elementText("com.unionbankph.online.qat:id/mdtp_month_text_view",Integer.toString(year)))
				{
					click.elementBy("com.unionbankph.online.qat:id/mdtp_month_text_view",Integer.toString(year));
					break;
				}
				else
				{
					//swipe vertical for choosing the year
					swipe.swipeVertical(2, 0.7, 0.5,1);
				}
			}
			for (int z = 0; z < loopcount; z++) {
				try {

					if(driver.findElementByAccessibilityId(formatdate).isDisplayed())
					{
						try {
							driver.findElementByAccessibilityId(formatdate).getAttribute("selected");
							driver.findElementByAccessibilityId(formatdate).click();
							driver.findElementByAccessibilityId(formatdate).getAttribute("selected");
						}
						catch (Exception e)
						{
							// TODO: handle exception
							driver.findElementByAccessibilityId(formatdate+" selected").getAttribute("selected");
						}
						try {
							String evalue;
							try {
								evalue=driver.findElementByAccessibilityId(formatdate).getAttribute("selected");
							} catch (Exception e) {
								// TODO: handle exception
								evalue=driver.findElementByAccessibilityId(formatdate+" selected").getAttribute("selected");
							}
							if(evalue.contentEquals("true"))
							{
								log.info("Verification success, Expected Date " + formatdate + " is a present or future date and it is in enable mode");
							}
							else
							{
								log.info("Verification success, Expected Date " + formatdate + " is a past date and it is in disable mode");
							}

						} catch (Exception e) {
							// TODO: handle exception
							throw new ApplicationException(e.getMessage());
						}

						break;
					}
				}
				catch(Exception e)
				{
					//swipe horizontal for choosing the Month
					swipe.swipeHorizontal(2,0.85,0.35,1);
					click.elementBy(By.xpath("(//android.view.View)[6]"));
				}
			}
		}
	}




}