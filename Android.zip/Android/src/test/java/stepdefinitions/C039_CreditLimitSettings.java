package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.*;

public class C039_CreditLimitSettings {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();

    CreditLimitSettings_Page CreditLimitSettings_Page = new CreditLimitSettings_Page();

    @When("^user select a credit card from dashboard to increase the limit$")
    public void userSelectACreditCardFromDashboardToIncreaseTheLimit() throws Throwable {
        CreditLimitSettings_Page.click_CreditCardAccount();

    }
    @And("^user click to card settings in account details page$")
    public void userClickToCardSettingsInAccountDetailsPage() throws Throwable {
        CreditLimitSettings_Page.click_CardSettings();
    }
    @And("^user click to supplementary or activate supplementary in  card settings page$")
    public void userClickToSupplementaryOrActivateSupplementaryInCardSettingsPage() throws Throwable {
        CreditLimitSettings_Page.click_Supplementary();
    }

    @And("^user to click amount edit button$")
    public void userToClickAmountEditButton() throws Throwable {
        CreditLimitSettings_Page.click_Editbtn();
    }

    @And("^Enter the limit for credit limit$")
    public void enterTheLimitForCreditLimit() throws Throwable {
        CreditLimitSettings_Page.EnterAmount();
    }

    @Then("^check if the user is able to click save$")
    public void checkIfTheUserIsAbleToClickSave() throws Throwable {
        CreditLimitSettings_Page.click_Savebtn();
    }

    @Then("^verify the success message for credit limit update$")
    public void verifyTheSuccessMessageForCreditLimitUpdate() throws Throwable {
        CreditLimitSettings_Page.verify_Sucessmsg();
    }

    @And("^user to click go back to dashboard$")
    public void userToClickGoBackToDashboard() throws Throwable {
        CreditLimitSettings_Page.click_Dashboard();
    }

    @And("^Enter the limit for credit limit not a increments of (\\d+)$")
    public void enterTheLimitForCreditLimitNotAIncrementsOf(int arg0) throws Throwable {
        CreditLimitSettings_Page.Enter_NonIncrementsAmount();

    }

    @Then("^verify the inline message when user entered is not a increments of (\\d+)$")
    public void verifyTheInlineMessageWhenUserEnteredIsNotAIncrementsOf(int arg0) throws Throwable {
        CreditLimitSettings_Page.verify_IncrementErrormsg();

    }

    @And("^Enter the limit for credit limit less than minimum amount$")
    public void enterTheLimitForCreditLimitLessThanMinimumAmount() throws Throwable {
        CreditLimitSettings_Page.EnterAmount();

    }

    @Then("^verify the inline message when user enters less than Min amount$")
    public void verifyTheInlineMessageWhenUserEntersLessThanMinAmount() throws Throwable {
        CreditLimitSettings_Page.verify_MinimumErrorMsg();

    }
    @Then("^verify the inline message when user enters more than Maximum amount$")
    public void verifyTheInlineMessageWhenUserEntersMoreThanMaximumAmount() throws Throwable {
        CreditLimitSettings_Page.verify_MaximumErrorMsg();
    }
    @Then("^verify the save button is disabled$")
    public void verifyTheSaveButtonIsDisabled() throws Throwable {
        CreditLimitSettings_Page.verify_SaveBtn();

    }
    @And("^click to don't set credit limit$")
    public void clickToDonTSetCreditLimit() throws Throwable {
        CreditLimitSettings_Page.click_DontSave();

    }

    @Then("^user navigates back to card settings page$")
    public void userNavigatesBackToCardSettingsPage() throws Throwable {
        CreditLimitSettings_Page.click_Backbtn();
    }

    @And("^click to save new card limit$")
    public void clickToSaveNewCardLimit() throws Throwable {
        CreditLimitSettings_Page.click_SavenewCredit();
    }

    @Then("^I verify the Invalid OTP error message$")
    public void iVerifyTheInvalidOTPErrorMessage() {

    }
}
