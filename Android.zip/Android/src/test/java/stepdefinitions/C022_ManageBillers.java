package stepdefinitions;

import actions.Wait;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverManager;
import helper.PropertyReader;
import pages.*;

public class C022_ManageBillers {

    private LoginPage login = new LoginPage();
    private PayBillsPage PayBills = new PayBillsPage();
    private OTPPage otp = new OTPPage();
    private ReviewandTransferPage ReviewandTransfer = new ReviewandTransferPage();
    private TransferDetailsPage otherdetailpage = new TransferDetailsPage();




    @When("^I click Pay Bills in Dashboard(\\d+)$")
    public void iClickPayBillsInDashboard(int arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @And("^I click the managebillers link$")
    public void iClickTheManagebillersLink() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        PayBills.clickManageBillersInPayBills();
    }

    @And("^I Click on add button to add new billers$")
    public void iClickOnAddButtonToAddNewBillers() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        PayBills.clickAddiconManageBillersInPayBills();
    }

    @And("^I Select the biller and save as favourite$")
    public void iSelectTheBillerAndSaveAsFavourite() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        PayBills.SelectBillersandSaveInPayBills("test","123412341234");
    }

    @And("^I Click the existing Biller in billerlist$")
    public void iClickTheExistingfavouriteBillerInBillerlist() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        PayBills.selectfavouritebiller();
    }

    @And("^I Select the biller and save as unfavourite$")
    public void iSelectTheBillerAndSaveAsUnfavourite() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       PayBills.selectunfavouritebilleranssave();
    }

    @And("^I Click the existing Biller in billerlist not in favourite$")
    public void iClickTheExistingBillerInBillerlistNotInFavourite() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        PayBills.Editbillerinmanagebiller();
    }

    @And("^I Change the Billername and save$")
    public void iChangeTheBillernameAndSave() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       PayBills.Changebillernameandsave();
    }

    @And("^I Click the Delete Biller in billerlist$")
    public void iClickTheDeleteBillerInBillerlist() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        PayBills.Deletetbillerinmanagebiller();
    }
}
