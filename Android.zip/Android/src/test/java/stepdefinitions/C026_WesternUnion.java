package stepdefinitions;

import actions.Wait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverManager;
import helper.PropertyReader;
import pages.*;
import runners.ConvergentTestRunner;

public class C026_WesternUnion {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private UITFPage uitfPage = new UITFPage();
    private WesternUnionPage westernUnionPage = new WesternUnionPage();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();
    WelcomePage welcomepage = new WelcomePage();


    @Given("^I'm on login page of UB online banking application with user \"([^\"]*)\" otp \"([^\"]*)\"$")
    public void i_m_on_login_page_of_UB_online_banking_application_with_user_otp(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(arg1);
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(arg2);
            home.clickSubscribeToAppOtpNotNow();
            home.clickContinue();
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(4);
            home.verifyIfDashboardIsDisplayed("Dashboard");

        }
    }

    @When("^I am on the western union page$")
    public void i_am_on_the_western_union_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        westernUnionPage.clickWesternUnion();
    }

    @Then("^I verify the western union header$")
    public void i_verify_the_western_union_header() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        westernUnionPage.verifyHeader();
    }

    @Then("^I enter mtcn code as \"([^\"]*)\"$")
    public void i_enter_mtcn_code_as(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        westernUnionPage.enterMTCNCode(arg1);
    }

    @Then("^I verify mtcn code as \"([^\"]*)\"$")
    public void i_verify_mtcn_code_as(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        westernUnionPage.verifyMTCNCode(arg1);
    }

    @Then("^I verify error message for entering less than (\\d+) digits$")
    public void i_verify_error_message_for_entering_less_than_digits(int arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        westernUnionPage.verifyErrMsg_Lessthan10Digits();
    }

    @Then("^I enter mtcn amount as \"([^\"]*)\"$")
    public void i_enter_mtcn_amount_as(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        westernUnionPage.enterMTCNAmt(arg1);
    }

    @Then("^I verify invalid amount error message$")
    public void i_verify_invalid_amount_error_message() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        westernUnionPage.verifyInvalidAmtErrMsg();
    }


    @Then("^I enter the other details$")
    public void i_enter_the_other_details() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        westernUnionPage.enterOtherDetails_WU();
    }

    @Then("^I click the goals next button$")
    public void i_click_the_goals_next_button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        uitfPage.clickNextBtn();
    }

    @Then("^I verify invalid code error message$")
    public void i_verify_invalid_code_error_message() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        uitfPage.verifyErrMsgAndOk();
    }


    @Then("^I verify mtcn code already claimed error message$")
    public void iVerifyMtcnCodeAlreadyClaimedErrorMessage() throws Throwable {
        uitfPage.verifyErrMsgAndOk();
    }

    @Then("^I verify Send/Receive option displays on Dashboard Footer Section$")
    public void iVerifySendReceiveOptionDisplaysOnDashboardFooterSection() throws Throwable {
        westernUnionPage.verifySendReceive();
    }
}
