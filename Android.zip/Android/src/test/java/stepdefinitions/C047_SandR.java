package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.SandR_Page;


public class C047_SandR {
    SandR_Page sandRPage=new SandR_Page();
    @When("^User click a card on dashboard$")
    public void userClickACardOnDashboard() throws Throwable {
        sandRPage.ClickSandRCard();

    }
    @Then("^User click on redeem button$")
    public void userClickOnRedeemButton() throws Throwable{
        sandRPage.ClickRedeemBtn();
    }

    @Then("^user click S&R member shopping option available in redeem rewards page$")
    public void userClickSRMemberShoppingOptionAvailableInRedeemRewardsPage() throws Throwable{
        sandRPage.ClickMemberShoppingBtn();
    }

    @And("^click to the voucher that you want to redeem$")
    public void clickToTheVoucherThatYouWantToRedeem() throws Throwable{
        sandRPage.ClickToVoucher();
    }

    @Then("^User click to continue$")
    public void userClickToContinue() throws Throwable{
        sandRPage.ClickContinue();
    }

    @And("^user click proceed with redemption$")
    public void userClickProceedWithRedemption() throws Throwable {
        sandRPage.ClickProccedWithRedeem();
    }

    @Then("^user verify the successful message and click back to dashboard$")
    public void userVerifyTheSuccessfulMessageAndClickBackToDashboard() throws Throwable {
        sandRPage.VerifySuccessMsg();
    }

    @And("^user click to view voucher wallet in dashboard page$")
    public void userClickToViewVoucherWalletInDashboardPage() throws Throwable {
        sandRPage.VoucherWalletInDashBoard();
    }

    @Then("^click down arrow and press to open gift$")
    public void clickDownArrowAndPressToOpenGift() throws Throwable {
        sandRPage.ClickToDownArrowAndPressOpenGift();
    }

    @And("^verify the congratulations message and verify terms and conditions$")
    public void verifyTheCongratulationsMessageAndVerifyTermsAndConditions() throws Throwable {
        sandRPage.VerifyCongratulationsMessageAndTermsAndConditions();
    }

//    @Then("^close the reward redeem section$")
//    public void closeTheRewardRedeemSection() throws Throwable {
//        sandRPage.CloseBtn();
//    }

    @Then("^user click add icon to increase the redeem points$")
    public void userClickAddIconToIncreaseTheRedeemPoints() throws Throwable {
        sandRPage.ClickAddIcon();
    }

    @Then("^user edit the quantity text box to increase the quantity$")
    public void userEditTheQuantityTextBoxToIncreaseTheQuantity() throws Throwable {
        sandRPage.EnterQuantity();
    }

    @Then("^user click to cancel$")
    public void userClickToCancel() throws Throwable {
        sandRPage.ClickCancelBtn();
    }

    @Then("^user click to edit$")
    public void userClickToEdit() throws Throwable {
        sandRPage.ClickEditBtn();
    }
}
