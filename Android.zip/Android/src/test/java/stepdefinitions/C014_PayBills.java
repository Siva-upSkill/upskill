package stepdefinitions;

import actions.Wait;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;
import driver.DriverManager;
import exceptions.ApplicationException;
import gherkin.lexer.Pa;
import helper.PropertyReader;
import pages.*;

public class C014_PayBills {

    private LoginPage login = new LoginPage();
    private PayBillsPage PayBills = new PayBillsPage();
    private OTPPage otp = new OTPPage();
    private ReviewandTransferPage ReviewandTransfer = new ReviewandTransferPage();
    private TransferDetailsPage otherdetailpage = new TransferDetailsPage();


    @When ("^I click Pay Bills in Dashboard$")
    public void I_click_Pay_Bills_in_Dashboard () throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.clickPayBillsInDashBoard();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.clickPayBillsInDashBoard();
        }
    }

    @And ("^I navigate to \"([^\"]*)\" screen on clicking Pay bills in Dashboard$")
    public void I_navigate_to_PayBills_screen_on_clicking_pay_bills_in_Dashboard (String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.verifyPayBillsPageTitle(arg1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.verifyPayBillsPageTitle(arg1);
        }
    }

    @And ("^I navigate to \"([^\"]*)\" on clicking Select Biller in \"([^\"]*)\" screen$")
    public void I_navigate_to_selectBiller_on_clicking_Select_Biller_in_PayBills_screen (String arg1, String arg2) throws Throwable{
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.clickSelectBillerBtnInPayBills();
            PayBills.verifySelectBillerPageTitle("Select Biller");
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(15);
            PayBills.clickSelectBillerBtnInPayBills();
            PayBills.verifySelectBillerPageTitle(arg1);
        }
    }

    @Then ("^I should navigate back to \"([^\"]*)\" screen on clicking back button in paybills page$")
    public void I_should_navigate_back_to_paybills_screen_on_clicking_back_button_ib_paybills_page (String agr1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.clickBackBtnInPayBills();
            PayBills.verifyPayBillsPageTitle(agr1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.clickBackBtnInPayBills();
            PayBills.verifyPayBillsPageTitle(agr1);
        }
    }

    @Then ("^I choose \"([^\"]*)\" tab and search billers \"([^\"]*)\" in Select Biller screen$")
    public void  I_choose_myBillers_tab_and_search_billers_in_select_biller_screen (String arg1, String arg2) throws Throwable{
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.clickMyBillersTabinSelectBiller();
            PayBills.clickSelectBillerBtnInPayBillsAndroid();
            PayBills.verifyBillerNameInBillerInformation(arg2);
            //PayBills.clickCloseBtnInBillerInformation();

        }

        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.clickMyBillersTabinSelectBiller();
            PayBills.clickSearchBtnSelectBiller();
            PayBills.enterSearchtextboxInSelectBiller(arg2);
            Wait.forSeconds(5);
            PayBills.verifySearchBiller(arg2);
        }
    }

    @Then ("^I choose \"([^\"]*)\" tab and search favorites \"([^\"]*)\" in Select Biller screen$")
    public void I_choose_favorites_tab_and_search_favorites_in_select_biller_screen (String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

            PayBills.clickSelectBillerBtnInPayBills();
            PayBills.clickFavoritesTabinSelectBiller();
            PayBills.clickSelectBillerBtnInPayBillsAndroid();
            PayBills.verifyBillerNameInBillerInformation(arg2);
            PayBills.clickCloseBtnInBillerInformation();

            //====Old=====//
            //PayBills.clickBackBtnInPayBills();
//            PayBills.clickManageBillersInPayBills();
//            PayBills.clickSearchbtnInManageBills();
//            PayBills.enterSearchtxtInManageBillsAndroid(arg2);
//            PayBills.clickFavoritesbtnInManageBills();
//            PayBills.clickFavoritesTabinSelectBiller();
//            PayBills.clickCloseSearchInManageBills();
//            PayBills.clickBackSearchInManageBills();
//            PayBills.clickBackInManageBills();
//            PayBills.clickSearchbtnInManageBills();
//            PayBills.enterSearchtxtInManageBillsAndroid(arg2);
//
//            PayBills.verifySearchFavorites(arg2);
            ///PayBills.enterSearchtextboxInSelectBillerAndroid(arg2);

        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.clickFavoritesTabinSelectBiller();
            //PayBills.clickSearchBtnSelectBiller();
            PayBills.enterSearchtextboxInSelectBiller(arg2);
            Wait.forSeconds(7);
            PayBills.verifySearchFavorites(arg2);
        }
    }

    @Then ("^I choose \"([^\"]*)\" tab and search favorite \"([^\"]*)\" in Select Biller screen$")
    public void I_choose_favorites_tab_and_search_favorite_in_select_biller_screen (String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            PayBills.clickCloseBtnInBillerInformation();
//            PayBills.clickManageBillersInPayBills();
//            PayBills.clickSearchbtnInManageBills();
//            PayBills.enterSearchtxtInManageBillsAndroid1(arg2);
//            PayBills.clickFavoritesbtnInManageBills();
//            PayBills.clickFavoritesTabinSelectBiller();
//            PayBills.clickCloseSearchInManageBills();
//            PayBills.clickBackSearchInManageBills();
//            PayBills.clickBackInManageBills();
//            PayBills.clickSelectBillerBtnInPayBills();
//
//            PayBills.clickFavoritesTabinSelectBiller();
//            PayBills.clickSearchbtnInManageBills();
//            PayBills.enterSearchtxtInManageBillsAndroid1(arg2);
//            PayBills.verifySearchFavorites(arg2);
            PayBills.clickFavoritesTabinSelectBiller();

        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.clickFavoritesTabinSelectBiller();
            PayBills.clickSearchBtnSelectBiller();
            PayBills.enterSearchtextboxInSelectBiller(arg2);
            Wait.forSeconds(7);
            PayBills.verifySearchFavorites(arg2);
        }
    }

    @Then ("^I choose \"([^\"]*)\" tab and search Biller list \"([^\"]*)\" in Select Biller screen$")
    public void I_choose_favorites_tab_and_search_biller_list_in_select_biller_screen(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID"))
        {
            PayBills.clickSelectBillerBtnInPayBills();
            PayBills.clickBillerListTabinSelectBiller();
            Wait.forSeconds(5);
            //PayBills.enterSearchtxtInManageBillsAndroid(arg2);
            //PayBills.verifySearchBillerList1(arg2);
            PayBills.clickSearchBillerList1();
            Wait.forSeconds(5);
        }

        else if(DriverManager.OS.equalsIgnoreCase("IOS"))
        {
           try {
               PayBills.clickBillerListTabinSelectBiller();
               //PayBills.clickSearchBtnSelectBiller();
               Wait.forSeconds(25);
//               PayBills.enterSearchtextboxInSelectBiller(arg2);
//               Wait.forSeconds(20);
//               PayBills.verifySearchBillerList(arg2);
               //PayBills.selectBillerin_BillerList();
               actions.Touch.pressByCoordinates(201, 190, 5);
               Wait.forSeconds(15);

           }
           catch (Exception e)

           {

               //XCUIElementTypeStaticText[@name="UNIONBANK VISA"]

           }
        }
    }

    @Then ("^I choose \"([^\"]*)\" tab and search Billerlist tab \"([^\"]*)\" in Select Biller screen$")
    public void I_choose_favorites_tab_and_search_billerlist_tab_in_select_biller_screen (String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

            PayBills.clickBillerListTabinSelectBiller();
            Wait.forSeconds(15);
            PayBills.clickSearchbtnInManageBills();
            PayBills.enterSearchtxtInManageBillsAndroid1(arg2);
            Wait.forSeconds(20);
            //PayBills.verifySearchFavorites(arg2);

        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.clickBillerListTabinSelectBiller();
            PayBills.clickSearchBtnSelectBiller();
            Wait.forSeconds(15);
            PayBills.enterSearchtextboxInSelectBiller(arg2);
            Wait.forSeconds(20);
            PayBills.verifySearchBillerList(arg2);
        }
    }

    @Then ("^I choose \"([^\"]*)\" tab and search biller \"([^\"]*)\" in Select Biller screen$")
    public void I_choose_myBillers_tab_and_search_biller_in_select_biller_screen (String arg1, String arg2) throws Throwable{
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.clickMyBillersTabinSelectBiller();
            //PayBills.clickSelectBillerBtnInPayBillsAndroid1();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.clickMyBillersTabinSelectBiller();
            PayBills.clickSearchBtnSelectBiller();
            PayBills.enterSearchtextboxInSelectBiller(arg2);
            Wait.forSeconds(5);
        }
    }

    @And ("^I choose \"([^\"]*)\" in Select Biller screen then \"([^\"]*)\" screen display$")
    public void I_choose_in_select_biller_screen_then_screen_display (String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(4);
            PayBills.chooseBillerAndroid();
            //PayBills.clickSelectBillerBtnInPayBillsAndroid1();
            Wait.forSeconds(5);
            PayBills.verifyBillerInformationPageTitle("Enter biller information");
            PayBills.enterBillerBillerInformation();
            PayBills.clickNext();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.chooseBiller();
            PayBills.verifyBillerInformationPageTitle(arg2);
            PayBills.clickNext();
        }
    }

    @And ("^I choose \"([^\"]*)\" in Select Billers screen then \"([^\"]*)\" screen display$")
    public void I_choose_in_select_billers_screen_then_screen_display (String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(2);
            PayBills.chooseBillerAndroid();
            PayBills.verifyBillerInformationPageTitle("Enter biller information");
            Wait.forSeconds(2);
            PayBills.enterBillerNumberInBillerInformation("82028711016");
            PayBills.clickNext();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.chooseBiller();
            PayBills.verifyBillerInformationPageTitle(arg2);
            PayBills.clickNext();
        }
    }

    @And ("^I choose account in \"([^\"]*)\" screen$")
    public void I_choose_account_in_screen (String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID"))
        {
            PayBills.verifyPayFromAccountPageTitle(arg1);
            Wait.forSeconds(8);
            PayBills.chooseAccount();
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.verifyPayFromAccountPageTitle(arg1);
            Wait.forSeconds(5);
            PayBills.chooseAccount();
        }
    }

    @Then ("^On successful enter amount \"([^\"]*)\" in \"([^\"]*)\" screen \"([^\"]*)\" screen will display$")
    public void On_successful_enter_amount_in_screen_will_display(String arg1, String arg2, String arg3) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.verifyPaymentDetailsPageTitle(arg2);
            PayBills.enterAmountInPaymentDetails(arg1);
            Wait.forSeconds(8);
            PayBills.clickNext();
            ///PayBills.verifyReviewAndPayPageTitle(arg3);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.verifyPaymentDetailsPageTitle(arg2);
            PayBills.enterAmountInPaymentDetails(arg1);
            PayBills.clickNext();
            PayBills.verifyReviewAndPayPageTitle(arg3);
        }
    }

    @Then ("^I should see the \"([^\"]*)\" message after clicking Pay button in \"([^\"]*)\" screen$")
    public void I_should_see_the_success_message_after_clicking_pay_button_in_ReviewandPay_screen (String arg1, String arg2) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            ReviewandTransfer.clickGotitButton();
            Wait.forSeconds(10);
            PayBills.clickPaybuttonInReviewAndPayAndroid();
            Wait.forSeconds(10);
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(20);
            PayBills.verifyPaymentSuccessfulPageTitle(arg1);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(15);
            ReviewandTransfer.clickGotitButton();
            PayBills.clickPaybuttonInReviewAndPay();
            Wait.forSeconds(20);
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(20);
            PayBills.verifyPaymentSuccessfulPageTitle(arg1);
        }
    }

    @Then ("^i should unfavorites \"([^\"]*)\" in \"([^\"]*)\" screen$")
    public void i_should_unfavorites_in_Manage_Billers_screen(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.clickGoToDashboardInPaymentSuccessful();
            Wait.forSeconds(2);
            PayBills.clickPayBillsInDashBoard();
            PayBills.clickManageBillersInPayBills();
            PayBills.clickSearchbtnInManageBills();
            PayBills.enterSearchtxtInManageBillsAndroid1(arg2);
            PayBills.clickFavoritesbtnInManageBills();
            PayBills.clickFavoritesTabinSelectBiller();
            PayBills.clickCloseSearchInManageBills();
            PayBills.clickBackSearchInManageBills();
            PayBills.clickBackInManageBills();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

        }
    }

    @Then ("^I should see the error message \"([^\"]*)\" in amount field when user enter amount \"([^\"]*)\" more than the current balance$")
    public void I_should_see_the_error_message_in_amount_field_when_user_enter_amount_more_than_the_current_balance (String arg1, String arg2)throws Throwable{
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.enterAmountInPaymentDetails(arg2);
            //PayBills.clickCalender();
            //PayBills.clickTodayCalender();
            //PayBills.clickDoneCalender();
            //PayBills.chooseFutureDate();
            Wait.forSeconds(5);
            //PayBills.clickRepeatSwitch();
            PayBills.verifyAmountgreatererrormessageAndroid("Amount exceeds available balance.");
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.enterAmountInPaymentDetails(arg2);
            PayBills.clickRepeatSwitch();
            PayBills.verifyAmountgreatererrormessage(arg1);
        }
    }

    @Then ("^I should able to select future date in \"([^\"]*)\" screen and \"([^\"]*)\" date$")
    public void I_should_able_to_select_future_date_in_Paymentdetails_screen(String arg1,String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.verifyPaymentDetailsPageTitle(arg1);
            PayBills.enterAmountInPaymentDetails("10");
            PayBills.clickTodayCalender();
            //PayBills.clickTodayCalender();
            //PayBills.clickCalenderAndroid();
            otherdetailpage.choosefuturetransctiondate(arg2);
            otherdetailpage.clickDatePickerOkBtn();
            //TransferDetailsPage.
            //PayBills.chooseFutureDate(arg2);
            Wait.forSeconds(5);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.verifyPaymentDetailsPageTitle(arg1);
            PayBills.enterAmountInPaymentDetails("10");
            PayBills.clickCalender();
            PayBills.chooseFutureDate(arg2);
            Wait.forSeconds(5);
        }
    }

    @Then ("^On successful clicking cancel button in \"([^\"]*)\" screen for \"([^\"]*)\" screen will display$")
    public void on_successful_clicking_cancel_button_in_reviewandpay_screen_for_paybills_screen_will_display (String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            ReviewandTransfer.clickGotitButton();
            //PayBills.clickCloseInReviewAndPay();
            PayBills.clickCloseInReviewAndPayAndroid();
            PayBills.clickCancelPaymentInHandOn();
            PayBills.verifyPayBillsPageTitle(arg2);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            ReviewandTransfer.clickGotitButton();
            PayBills.clickCloseInReviewAndPay();
            PayBills.clickCancelPaymentInHandOn();
            PayBills.verifyPayBillsPageTitle(arg2);
        }
    }

    @And ("^On successful clicking account edit button in \"([^\"]*)\" screen \"([^\"]*)\" screen should display$")
    public void on_successful_clicking_account_edit_button_in_reviewandpay_screen_pay_from_which_account_screen_should_display (String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            ReviewandTransfer.clickGotitButton();
            PayBills.clickAccountEditAndroid();
            //PayBills.verifyPayFromAccountPageTitle(arg2);
            Wait.forSeconds(5);
            //PayBills.chooseAccount();
            PayBills.clickDone();

        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            ReviewandTransfer.clickGotitButton();
            PayBills.clickAccountEdit();
            PayBills.verifyPayFromAccountPageTitle(arg2);
            Wait.forSeconds(5);
            PayBills.chooseAccountedit();
        }
    }

    @And ("^On successful clicking Biller edit button in \"([^\"]*)\" screen \"([^\"]*)\" screen should display$")
    public void on_successful_clicking_account_edit_button_in_reviewandpay_screen_Biller_information_screen_should_display (String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            ReviewandTransfer.clickGotitButton();
            PayBills.clickBillerEdit();
            PayBills.verifyBillerInformationPageTitle(arg2);
            PayBills.clickDone();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            ReviewandTransfer.clickGotitButton();
            PayBills.clickBillerEdit();
            PayBills.verifyBillerInformationPageTitle(arg2);
            PayBills.clickDone();
        }
    }

    @And ("^On successful clicking Amount edit button in \"([^\"]*)\" screen \"([^\"]*)\" screen should display and user able to edit \"([^\"]*)\" amount$")
    public void on_successful_clicking_account_edit_button_in_reviewandpay_screen_payment_details_screen_should_display_and_user_able_to_edit_amount (String arg1, String arg2, String arg3) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            ReviewandTransfer.clickGotitButton();
            PayBills.clickAmountEditAndroid();
            PayBills.verifyPaymentDetailsPageTitle(arg2);
            PayBills.enterAmountEditInPaymentDetails(arg3);
            PayBills.clickDone();
            ReviewandTransfer.clickGotitButton();

        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            ReviewandTransfer.clickGotitButton();
            PayBills.clickAmountEdit();
            PayBills.verifyPaymentDetailsPageTitle(arg2);
            PayBills.enterAmountEditInPaymentDetails(arg3);
            PayBills.clickDone();
            ReviewandTransfer.clickGotitButton();
        }
    }

    @Then ("^I should be able to masked and unmasked on clicking account and card number in \"([^\"]*)\" screen$")
    public void i_should_be_able_to_masked_and_unmasked_on_clicking_account_and_card_number_in_review_and_pay_screen (String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            ReviewandTransfer.clickGotitButton();
            PayBills.clickUnMaskedAccountAndroid();
            PayBills.verifyMaskedAccount("1022 2002 1750");
            PayBills.clickMaskedAccount();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            ReviewandTransfer.clickGotitButton();
            PayBills.clickMaskedAccount();
            //PayBills.clickUnMaskedAccount();
           PayBills.verifyunMaskedAccount("1022 2002 1750");
            //PayBills.clickMaskedAccount();
        }
    }

    @And ("^I click Biller edit button in \"([^\"]*)\" screen \"([^\"]*)\" screen should display$")
    public void i_click_biller_edit_button_in_review_and_ay_screen_biller_information_screen_should_display (String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            ReviewandTransfer.clickGotitButton();
            PayBills.clickBillerEditAndroid();
            PayBills.verifyBillerInformationPageTitle(arg2);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            ReviewandTransfer.clickGotitButton();
            PayBills.clickBillerEdit();
            PayBills.verifyBillerInformationPageTitle(arg2);
        }
    }

    @Then ("^On successful click back button in \"([^\"]*)\" screen \"([^\"]*)\" screen should display$")
    public void on_successful_click_back_button_in_biller_information_screen_review_and_pay_screen_should_display(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(5);
            PayBills.clickDoneBtnInBillerInformationAndroid();
            Wait.forSeconds(5);
            ReviewandTransfer.clickGotitButton();
            Wait.forSeconds(5);
            PayBills.verifyReviewAndPayPageTitle(arg2);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.clickCloseBtnInBillerInformation();
            PayBills.verifyReviewAndPayPageTitle(arg2);
        }
    }

    @Then ("^I validate \"([^\"]*)\" and \"([^\"]*)\" fields are displayed after user check the Repeat checkbox$")
    public void i_validate_fields_are_displayed_after_user_check_the_repeat_checkbox (String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.enterAmountEditInPaymentDetails("1");
            //PayBills.clickTodayCalender();
            //PayBills.clickDoneCalender();
            PayBills.clickRepeatSwitch();
            PayBills.verifyFrequencyInPaymentDetails();
            PayBills.verifyEndDateInPaymentDetails();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            //PayBills.enterAmountInPaymentDetails(arg2);
            PayBills.clickRepeatSwitch();
            PayBills.verifyFrequencyInPaymentDetails();
            PayBills.verifyEndDateInPaymentDetails();
        }
    }

    @Then ("^I validate Biller information fields are blank \"([^\"]*)\" error message$")
    public void i_validate_biller_information_fields_are_blank_error_message(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            ///PayBills.chooseBiller();
            //PayBills.clickBillerListTabinSelectBiller();
            //Wait.forSeconds(20);
            ///PayBills.clickSearchbtnInManageBills();
            ///PayBills.enterSearchtxtInManageBillsAndroid1("VECO UNINON BANK OF PHILIPPINES");
            Wait.forSeconds(20);
            PayBills.clickSelectBillerBtnInPayBillsAndroid1();
            PayBills.verifyBillererrormessageAndroid("Account ID is required");
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS"))
        {
            PayBills.chooseBiller();
            PayBills.verifyBillererrormessage(arg1);
        }
    }

    @Then ("^I validate Payment details fields are blank \"([^\"]*)\" error message$")
    public void i_validate_payment_details_fields_are_blank_error_message(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.clickAmountInPaymentDetails();
            ///PayBills.clickRepeatSwitch();
            PayBills.clickTodayCalender();
            PayBills.verifyAmountInPaymentDetailserrormessageAndroid("Amount is required.");
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.clickAmountInPaymentDetails();
            PayBills.clickRepeatSwitch();
            PayBills.verifyAmountInPaymentDetailserrormessage(arg1);
        }
    }

    @Then ("^I validate next button is disabled by default in \"([^\"]*)\" screen when fields are empty$")
    public void i_validate_next_button_is_disabled_by_default_when_fields_are_empty(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //PayBills.chooseBiller();
            //PayBills.clickBillerListTabinSelectBiller();
            Wait.forSeconds(10);
            PayBills.clickSelectBillerBtnInPayBillsAndroid1();
            PayBills.verifyNextBtnIsDisabled1();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.chooseBiller();
            PayBills.verifyNextBtnIsDisabled();
        }
    }

    @Then ("^I validate next button is disabled by default in \"([^\"]*)\" screen when field is empty$")
    public void i_validate_next_button_is_disabled_by_default_when_field_is_empty(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.verifyNextBtnIsDisabledInPaymentDetails();
            PayBills.verifyPaymentDetailsPageTitle(arg1);
            PayBills.enterAmountInPaymentDetails("10");
            PayBills.clickNext();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.verifyNextBtnIsDisabledInPaymentDetails();
            PayBills.verifyPaymentDetailsPageTitle(arg1);
            PayBills.enterAmountInPaymentDetails("10");
            PayBills.clickNext();
        }
    }

    @Then ("^I validate Biller information field when user enter invalid card number \"([^\"]*)\" error message$")
    public void i_validate_biller_information_field_when_user_enter_invalid_card_number_error_message(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.verifyInvalidCardNumberBillererrormessage(arg1);
        }
    }

    @Then ("^I validate Biller information field when user enter any text characters \"([^\"]*)\" error message$")
    public void i_validate_biller_information_field_when_user_any_text_characters_error_message(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.verifyInvalidCharacterBillererrormessage(arg1);
        }
    }

    @Then ("^I validate current date \"([^\"]*)\" is displayed by default in Date field$")
    public void i_validate_current_date_is_displayed_by_default_in_date_field(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.verifyCurrentDateInPaymentDetails(arg1);
            Wait.forSeconds(4);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.verifyCurrentDateInPaymentDetails(arg1);
            Wait.forSeconds(4);
        }
    }

    @Then ("^I validate account number \"([^\"]*)\" should be unmasked when user click account number and card number in \"([^\"]*)\" screen$")
    public void i_validate_account_number_should_be_unmasked_when_click_account_number_and_card_number_in_payment_successful_screen(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.clickUnMaskedAccountInPaymentSuccessful();
            Wait.forSeconds(5);
            PayBills.verifyMaskedAccountInPaymentSuccessful(arg1);
            Wait.forSeconds(2);
            PayBills.clickUnMaskedAccountInPaymentSuccessful();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.clickUnMaskedAccountInPaymentSuccessful();
            Wait.forSeconds(5);
            PayBills.verifyMaskedAccountInPaymentSuccessful(arg1);
            Wait.forSeconds(2);
            PayBills.clickMaskedAccountInPaymentSuccessful();
        }
    }

    @Then ("^On successful click \"([^\"]*)\" button in \"([^\"]*)\" screen \"([^\"]*)\" screen will display$")
    public void on_successful_click_new_payment_button_in_payment_successful_screen_pay_bills_screen_will_display(String arg1, String arg2, String arg3) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.clickNewPaymentInPaymentSuccessful();
            PayBills.verifyPayBillsPageTitle(arg3);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.clickNewPaymentInPaymentSuccessful();
            PayBills.verifyPayBillsPageTitle(arg3);
        }
    }

    @Then ("^I validate account number \"([^\"]*)\" should be unmasked when user click account number in \"([^\"]*)\" screen$")
    public void i_validate_account_number_should_be_unmasked_when_user_click_account_number_in_notification_screen(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            PayBills.clickGoToDashboardInPaymentSuccessful();
            Wait.forSeconds(15);
            PayBills.clickMailInDashboard();
            Wait.forSeconds(8);
            //PayBills.verifyNotificationsPageTitle(arg2);
            Wait.forSeconds(4);
            PayBills.clickTransationsTab();
            Wait.forSeconds(7);
            PayBills.choosePaymentTransactionsNotificationsIOS();
            Wait.forSeconds(4);
            PayBills.clickUnMaskedAccountInNotifications();
            Wait.forSeconds(5);
            PayBills.verifyMaskedAccountInNotifications(arg1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            PayBills.clickGoToDashboardInPaymentSuccessful();
            Wait.forSeconds(15);
            PayBills.clickMailInDashboard();
            Wait.forSeconds(8);
            //PayBills.verifyNotificationsPageTitle(arg2);
            Wait.forSeconds(4);
            PayBills.clickTransationsTab();
            Wait.forSeconds(10);
            PayBills.choosePaymentTransactionsNotificationsIOS();
            Wait.forSeconds(4);
            PayBills.clickUnMaskedAccountInNotifications();
            Wait.forSeconds(5);
            PayBills.verifyMaskedAccountInNotifications(arg1);
        }
    }


    @And("^Enter the unionbank visa \"([^\"]*)\" card number and click next button$")
    public void enterTheUnionbankVisaCardNumberAndClickNewxButton(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(15);
        PayBills.entercarnumber(arg0);
        PayBills.clickNext();
    }

    @Then("^I enter paymentReferenceNo as \"([^\"]*)\" PayorsName as \"([^\"]*)\" and PolicyNo as \"([^\"]*)\"$")
    public void i_enter_paymentReferenceNo_as_PayorsName_as_and_PolicyNo_as(String arg1, String arg2, String arg3) throws Throwable {
        PayBills.enterBillerBillerInformation();
    }

    @Then("^I click the Next Button$")
    public void i_click_the_Next_Button() throws Throwable {
        PayBills.clickNext_CC();
    }

    @Then("^I Select the CreditCards Pay from account$")
    public void i_Select_the_CreditCards_Pay_from_account() throws Throwable {
        PayBills.selectCreditCard();
    }

    @Then("^I Select Pay from account option$")
    public void I_Select_Pay_from_account_option() throws Throwable {
        PayBills.selectAcountOption();
    }
    @Then("^I enter the amount field as \"([^\"]*)\"$")
    public void i_enter_the_amount_field_as(String arg1) throws Throwable {
        PayBills.enterAmount_CC();
    }

    @Then("^I click the Pay Bills php button$")
    public void i_click_the_Pay_Bills_php_button() throws Throwable {
        PayBills.clickPayBillsBtn();
    }

    @Then("^I click the GotIt button if displayed$")
    public void i_click_the_GotIt_button_if_displayed() throws Throwable {
        PayBills.clickGotItBtn();
    }

    @Then("^I Enter the OTP \"([^\"]*)\" in OTP Page$")
    public void i_Enter_the_OTP_in_OTP_Page(String arg1) throws Throwable {
        otp.enterOTP(arg1);
    }

    @Then("^I verify Payment Request successful message$")
    public void i_verify_Payment_Request_successful_message() throws Throwable {
        PayBills.verifyPaymentRequestSucessMessage();
    }


    @When("^I navigate to \"([^\"]*)\" on clicking Select Biller in \"([^\"]*)\" screen for CC$")
    public void i_navigate_to_on_clicking_Select_Biller_in_screen_for_CC(String arg1, String arg2) throws Throwable {
        PayBills.clickSelectBillerBtnInPayBills();
    }

    @Then("^I choose \"([^\"]*)\" tab and search Biller list \"([^\"]*)\" in Select Biller screen for CC$")
    public void i_choose_tab_and_search_Biller_list_in_Select_Biller_screen_for_CC(String arg1, String arg2) throws Throwable {
        PayBills.clickBillerListTabinSelectBiller();
        PayBills.clickSearchbtnInManageBills();
        PayBills.enterSearchtxtInManageBills(arg2);
        PayBills.SelectFirstBiller();

    }

    @And ("^I choose \"([^\"]*)\" in Select Biller screen then \"([^\"]*)\" screen display for Cc$")
    public void I_choose_in_select_biller_screen_then_screen_display_for_CC(String arg1, String arg2) throws Throwable {
            Wait.forSeconds(4);
            //PayBills.chooseBillerAndroid();
            //PayBills.clickSelectBillerBtnInPayBillsAndroid1();
            Wait.forSeconds(5);
            PayBills.verifyBillerInformationPageTitle("Enter biller information");
            PayBills.enterBillerBillerInformation();
            PayBills.clickNext();
    }


    @Then("^Enter the unionbank visa \"([^\"]*)\" card number for CC and click next button$")
    public void enter_the_unionbank_visa_card_number_for_CC_and_click_next_button(String arg1) throws Throwable {
        Wait.forSeconds(15);
        PayBills.entercarnumber_CC(arg1);
        PayBills.clickNext();
    }

    @Then("^I verify review page error message as \"Sorry, none of your accounts are eligible for this feature$")
    public void i_verify_review_page_error_message_as_Sorry_none_of_your_accounts_are_eligible_for_this_feature() throws Throwable {

        PayBills.VerifyErrorMsg();
    }

    @When("^I choose \"([^\"]*)\" in Select Biller screen then \"([^\"]*)\" screen display under Ewallet$")
    public void iChooseInSelectBillerScreenThenScreenDisplayUnderEwallet(String arg0, String arg1) throws Throwable {
        Wait.forSeconds(5);
        PayBills.enterBillerBillerInformation_Ewallet();
        PayBills.clickNext();
    }


    @Then("^I choose \"([^\"]*)\" tab and search Biller list \"([^\"]*)\" in Select Biller screen Ewallet$")
    public void iChooseTabAndSearchBillerListInSelectBillerScreenEwallet(String arg0, String arg1) throws Throwable {

        PayBills.clickBillerListTabinSelectBiller();
        PayBills.clickSearchbtnInManageBills();
        PayBills.enterSearchtxtInManageBills(arg1);
        PayBills.SelectFirstBiller();
    }

    @Then("^verify the remaining fund transfer limit to e-wallets Paybills$")
    public void verifyTheRemainingFundTransferLimitToEWalletsPaybills() throws ApplicationException {
        PayBills.verifyRemainingLimit();
        
    }

    @And("^verify the Daily transaction limit to e-wallets Paybills$")
    public void verifyTheDailyTransactionLimitToEWalletsPaybills() throws ApplicationException {
        PayBills.verifyLimitReminder();
    }

    @Then("^Verify the error message the maximum limit per transaction via Paybills$")
    public void verifyTheErrorMessageTheMaximumLimitPerTransactionViaPaybills() throws Throwable {
        PayBills.VerifyDailyTransactionLimitAmountErrorMsg();
    }

    @And("^On successful enter amount \"([^\"]*)\" in \"([^\"]*)\" screen$")
    public void onSuccessfulEnterAmountInScreen(String arg0, String arg1) throws Throwable {

            PayBills.enterAmountInPaymentDetails(arg0);

    }

    @Then("^i should see the \"([^\"]*)\" and click got it button\\.$")
    public void iShouldSeeTheAndClickGotItButton(String arg0) throws Throwable {
       PayBills.verifyRemainderPopUp();

    }

    @And("^I verify the \"([^\"]*)\",\"([^\"]*)\" tabs on Select Biller Screen$")
    public void iVerifyTheTabsOnSelectBillerScreen(String arg0, String arg1) throws Throwable {
        PayBills.verifyTabs();
    }

    @And("^I verify\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" on paymentDetails Screen$")
    public void iVerifyOnPaymentDetailsScreen(String arg0, String arg1, String arg2) throws Throwable {
        PayBills.verifyPaymentDetailsScreen();
    }

    @And("^I verify \"([^\"]*)\",\"([^\"]*)\" option once toggleon Repeat Option$")
    public void iVerifyOptionOnceToggleonRepeatOption(String arg0, String arg1) throws Throwable {
        PayBills.verifyToggleOn();
    }

    @And("^I verify application displays the list of accounts once click on \"([^\"]*)\"$")
    public void iVerifyApplicationDisplaysTheListOfAccountsOnceClickOn(String arg0) throws Throwable {
        PayBills.verifyListAccounts();
    }

    @And("^I verify \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" on \"([^\"]*)\" screen$")
    public void iVerifyOnScreen(String arg0, String arg1, String arg2, String arg3) throws Throwable {
        PayBills.verifyReviewandPay();
    }

    @And("^I verify the \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" options in \"([^\"]*)\" Screen$")
    public void iVerifyTheOptionsInScreen(String arg0, String arg1, String arg2, String arg3) throws Throwable {
        PayBills.verifyPayBillsPage();
    }

    @And("^i click \"([^\"]*)\" under Manage Section$")
    public void iClickUnderManageSection(String arg0) throws Throwable {
        PayBills.clickScheduledPayment();
    }

    @And("^I click \"([^\"]*)\" Icon on \"([^\"]*)\" Tab and choose any Billers to add$")
    public void iClickIconOnTabAndChooseAnyBillersToAdd(String arg0, String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }


    @And("^I choose any One Scheduled Payments$")
    public void iChooseAnyOneScheduledPayments() throws Throwable {
        PayBills.clickAnyoneScheduledPayment();
    }

    @And("^I verify the \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
    public void iVerifyThe(String arg0, String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws Throwable {
        PayBills.verifyScheduledPayments();
    }
}
