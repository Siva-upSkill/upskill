package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import pages.VirtualCardPage;

public class C043_VirtualCards {

    VirtualCardPage VirtualCards = new VirtualCardPage();

    @Then("^Check user able to click the linked card$")
    public void checkUserAbleToClickTheLinkedCard() throws Throwable {
        VirtualCards.ClickCard();
    }

    @Then("^I verify application navigates to account detail page$")
    public void iVerifyApplicationNavigatesToAccountDetailPage() throws Throwable {
        VirtualCards.VerifyAccountDetailPage();
    }

    @And("^check whether user able to click card settings$")
    public void checkWhetherUserAbleToClickCardSettings() throws Throwable {
        VirtualCards.ClickCardSettings();
    }

    @Then("^I verify the card number$")
    public void iVerifyTheCardNumber() throws Throwable {
        VirtualCards.VerifyCardNumber();
    }

    @And("^I verify valid through details$")
    public void iVerifyValidThroughDetails() throws Throwable {
        VirtualCards.VerifyValidThruDetails();
    }

    @Then("^I verify CVV details$")
    public void iVerifyCVVDetails() throws Throwable {
        VirtualCards.VerifyCVVDetails();
    }

}
