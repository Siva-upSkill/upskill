package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import exceptions.ApplicationException;
import pages.QuickLoan_Page;

public class C051_QuickLoan {
    
    QuickLoan_Page quickLoanPage=new QuickLoan_Page();
    
    @And("^I verify the Application displays \"([^\"]*)\" Option in Dashboard page$")
    public void iVerifyTheApplicationDisplaysOptionInDashboardPage(String arg0) throws Throwable {
        quickLoanPage.verify_QuickLoan();
        
    }
    @And("^I click Quick Loan$")
    public void iClickQuickLoan() throws Throwable {
        quickLoanPage.click_QuickLoan();
    }

    @Then("^I Verify application displays \"([^\"]*)\" ,\"([^\"]*)\",\"([^\"]*)\"$")
    public void iVerifyApplicationDisplays(String arg0, String arg1, String arg2) throws Throwable {
        quickLoanPage.verify_Headers();
       
    }

    @And("^I verify the Inline Error Msg \"([^\"]*)\" once clicking on \"([^\"]*)\" field$")
    public void iVerifyTheInlineErrorMsgOnceClickingOnField(String arg0, String arg1) throws Throwable {
        quickLoanPage.Verify_InlineErrormsg();
    }

    @And("^I choose \"([^\"]*)\" Amount from the Drop down on clicking Select Amount Field$")
    public void iChooseAmountFromTheDropDownOnClickingSelectAmountField(String arg0) throws Throwable {
        quickLoanPage.click_SelectAmount();
    }

    @And("^I choose \"([^\"]*)\" from the Select Purpose drop down$")
    public void iChooseFromTheSelectPurposeDropDown(String arg0) throws Throwable {
        quickLoanPage.click_SelectPurpose();
    }
    

    @And("^I verify the \"([^\"]*)\" Header once entered the amount and purpose$")
    public void iVerifyTheHeaderOnceEnteredTheAmountAndPurpose(String arg0) throws Throwable {
        quickLoanPage.verify_LoanPaymentHeader();
    }

    @And("^I should see the \"([^\"]*)\" on clicking Next Button$")
    public void iShouldSeeTheOnClickingNextButton(String arg0) throws Throwable {
        quickLoanPage.VerifyPopUp();
        
    }

    @And("^I click Continue Button$")
    public void iClickContinueButton() throws Throwable {
        quickLoanPage.click_Continue();
    }

    @And("^I verify the application displays the \"([^\"]*)\" Header$")
    public void iVerifyTheApplicationDisplaysTheHeader(String arg0) throws Throwable {
        quickLoanPage.verify_CustomerInformationHeader();
    }

    @And("^I verify the Headers \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" in customer Information Page$")
    public void iVerifyTheHeadersInCustomerInformationPage(String arg0, String arg1, String arg2, String arg3) throws Throwable {
        quickLoanPage.verfy_FieldsHeader();
    }

    @And("^I should Fill the \"([^\"]*)\" , \"([^\"]*)\" in Your Profile once clicking on Edit button$")
    public void iShouldFillTheInYourProfileOnceClickingOnEditButton(String arg0, String arg1) throws Throwable {
        quickLoanPage.click_Edit1();
    }

    @And("^I should Fill the \"([^\"]*)\" once clicking on Civil status Drop down on clicking edit button$")
    public void iShouldFillTheOnceClickingOnCivilStatusDropDownOnClickingEditButton(String arg0) throws Throwable {
        quickLoanPage.click_Edit2();
    }

    @And("^I should Fill the \"([^\"]*)\" and enter the \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" on clicking edit button$")
    public void iShouldFillTheAndEnterTheOnClickingEditButton(String arg0, String arg1, String arg2, String arg3, String arg4) throws Throwable {
        quickLoanPage.click_Edit3();
    }

    @And("^I click the Checkboxes available On customer Information Screen$")
    public void iClickTheCheckboxesAvailableOnCustomerInformationScreen() throws ApplicationException {
       quickLoanPage.click_chekboxes();
    }

    @And("^I verify the \"([^\"]*)\" and \"([^\"]*)\" on Loan Summary page$")
    public void iVerifyTheAndOnLoanSummaryPage(String arg0, String arg1) throws Throwable {
      quickLoanPage.verify_LoanDetailsPage();
    }

    @And("^I click \"([^\"]*)\" , \"([^\"]*)\" Checkboxes$")
    public void iClickCheckboxes(String arg0, String arg1) throws Throwable {
        quickLoanPage.click_LoansummaryCheckBox();
    }

    @And("^I Click Edit option on Loan Summary Page$")
    public void iClickEditOptionOnLoanSummaryPage() throws Throwable {
        quickLoanPage.Click_EditLoanSummary();
    }

    @And("^I click \"([^\"]*)\" option$")
    public void iClickOption(String arg0) throws Throwable {
        quickLoanPage.clickCancel();
    }

    @Then("^I should see the Loan Details Page$")
    public void iShouldSeeTheLoanDetailsPage() throws Throwable {
        quickLoanPage.verify_LoanDetailsPage();
    }

    @And("^I should Fill the \"([^\"]*)\" Details$")
    public void iShouldFillTheDetails(String arg0) throws Throwable {
        quickLoanPage.click_Edit4();

    }
}
