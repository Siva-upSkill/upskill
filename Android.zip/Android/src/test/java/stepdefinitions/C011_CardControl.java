package stepdefinitions;


import actions.Wait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;
import driver.DriverManager;

import helper.PropertyReader;
import pages.*;

public class C011_CardControl {

    private HomePage home = new HomePage();
    private AccountDetailsPage accountdetails = new AccountDetailsPage();
    private TransactionControlsPage transactionControls = new TransactionControlsPage();
    private OnlinePage online = new OnlinePage();


    @When("^I choose CreditCard from the list in \"([^\"]*)\"$")
    public void i_choose_from_the_list_in(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            home.verifyIfDashboardIsDisplayed(arg1);
            Wait.forSeconds(15);
            home.clickCreditCard(PropertyReader.testDataOf("Credit_Card"));
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(15);
            home.verifyIfDashboardIsDisplayed(arg1);
            home.clickCreditCardIOS(PropertyReader.testDataOf("Credit_Card"));
        }
    }

    @Then("^I should see \"([^\"]*)\" under Transaction Control in \"([^\"]*)\" screen$")
    public void i_should_see_under_Transaction_Control_in_screen(String arg1, String arg2) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            accountdetails.verifyAccountDetailsPageTitle(arg2);
            Wait.forSeconds(6);
            accountdetails.verifyCardStatus(arg1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(15);
            accountdetails.verifyAccountDetailsPageTitle(arg2);

            accountdetails.verifyCardStatusIOS(arg1);
        }
    }

//    @When("^I navigate \"([^\"]*)\" screen on clicking Transaction Controls in \"([^\"]*)\" screen$")
//    public void i_navigate_screen_on_clicking_Transaction_Controls_in_screen(String arg1, String arg2) throws Throwable {
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            accountdetails.verifyAccountDetailsPageTitle(arg2);
//            Wait.forSeconds(15);
//            accountdetails.clickTransactionControls();
//            Wait.forSeconds(5);
//            transactionControls.verifyTransactionControlsPageTitle(arg1);
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            accountdetails.verifyAccountDetailsPageTitle(arg2);
//            accountdetails.clickTransactionControls();
//            transactionControls.verifyTransactionControlsPageTitleIOS(arg1);
//        }
//    }
//
//
//    @Then("^I should navigate back to \"([^\"]*)\" screen on clicking back button$")
//    public void i_should_navigate_back_to_screen_on_clicking_back_button(String arg1) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            accountdetails.clickBackButton();
//            accountdetails.verifyAccountDetailsPageTitle(arg1);
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            accountdetails.clickBackButton();
//            accountdetails.verifyAccountDetailsPageTitle(arg1);
//        }    }
//
//
//    @When("^I navigate \"([^\"]*)\" screen on clicking CreditCard from the list in \"([^\"]*)\"$")
//    public void i_navigate_screen_on_clicking_I_choose_CreditCard_from_the_list_in(String arg1, String arg2) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            home.verifyIfDashboardIsDisplayed(arg2);
//            home.clickCreditCard(PropertyReader.testDataOf("Credit_Card"));
//            accountdetails.verifyAccountDetailsPageTitle(arg1);
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            //home.verifyIfDashboardIsDisplayed(arg1);
//            home.clickCreditCardIOS(PropertyReader.testDataOf("Credit_Card"));
//            accountdetails.verifyAccountDetailsPageTitle(arg1);
//        }
//    }
//
//    @Then("^I should navigate back to \"([^\"]*)\" screen on clicking back button in \"([^\"]*)\" screen$")
//    public void i_should_navigate_back_to_screen_on_clicking_back_button(String arg1, String arg2) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            accountdetails.verifyAccountDetailsPageTitle(arg2);
//            accountdetails.clickBackButton();
//            home.verifyIfDashboardIsDisplayed(arg1);
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            accountdetails.verifyAccountDetailsPageTitle(arg2);
//            accountdetails.clickBackButton();
//            Wait.forSeconds(5);
//            home.verifyIfDashboardIsDisplayed(arg1);
//            Wait.forSeconds(5);
//        }
//    }
//
//    @Then("^I should see \"([^\"]*)\" under Lock and Unlock in \"([^\"]*)\" screen$")
//    public void i_should_see_under_Lock_Unlock_in_Transaction_control_screen(String arg1, String arg2) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            accountdetails.clickTransactionControls();
//            Wait.forSeconds(15);
//            //transactionControls.verifyTransactionControlsPageTitle(arg2);
//            accountdetails.verifyCardStatusInTransactionControl(arg1);
//
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            accountdetails.clickTransactionControls();
//            transactionControls.verifyTransactionControlsPageTitleIOS(arg2);
//            accountdetails.verifyCardStatusInTransactionControlLocalIOS(arg1);
//        }
//    }
//
//    @Then("^I should see all transactions are disabled for credit card whose \"([^\"]*)\" under Lock and Unlock in \"([^\"]*)\" screen$")
//    public void i_should_see_all_transactions_are_disabled(String arg1, String arg2) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            accountdetails.verifyCardStatusForDisabledTransactions(arg1, arg2);
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            accountdetails.verifyCardStatusForDisabledTransactionsIOS(arg1, arg2);
//        }
//    }
//
//    @Then("^I should see all transactions are enabled for credit card whose \"([^\"]*)\" under Lock and Unlock in \"([^\"]*)\" screen$")
//    public void i_should_see_all_transactions_are_enabled(String arg1, String arg2) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            accountdetails.verifyCardStatusForaEnabledTransactions(arg1, arg2);
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            accountdetails.verifyCardStatusForaEnabledTransactionsIOS(arg1, arg2);
//        }
//    }
//
//    @Then("^I should see \"([^\"]*)\" under Lock and Unlock in \"([^\"]*)\" screens$")
//    public void i_should_see_under_Lock_Unlock_in_Transaction_control_screens(String arg1, String arg2) throws Throwable {
//        transactionControls.verifyTransactionControlsPageTitle(arg2);
//        accountdetails.verifyCardStatusInTransactionControl(arg1);
//    }
//
//    @Then("^I check \"([^\"]*)\" under Online transactions in \"([^\"]*)\" screens$")
//    public void i_check_Online_transactions_are_declined(String arg1, String arg2) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            accountdetails.clickTransactionControls();
//            transactionControls.verifyTransactionControlsPageTitle(arg2);
//            transactionControls.VerifyOnlineTransactionStatus(arg1, arg2);
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            accountdetails.clickTransactionControls();
//            transactionControls.verifyTransactionControlsPageTitleIOS(arg2);
//            transactionControls.VerifyOnlineTransactionStatusIOS(arg1, arg2);
//        }
//    }
//
//    @Then("^I check \"([^\"]*)\" under International transactions in \"([^\"]*)\" screens$")
//    public void i_check_international_transactions_are_declined(String arg1, String arg2) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            transactionControls.verifyTransactionControlsPageTitle(arg2);
//            transactionControls.VerifyInternationalTransactionStatus(arg1, arg2);
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            transactionControls.verifyTransactionControlsPageTitleIOS(arg2);
//            transactionControls.VerifyInternationalTransactionStatusIOS(arg1, arg2);
//        }
//    }
//
//
//
//    @Then("^I check \"([^\"]*)\" under Local transactions in \"([^\"]*)\" screens$")
//    public void i_check_local_transactions_are_declined(String arg1, String arg2) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            transactionControls.verifyTransactionControlsPageTitle(arg2);
//            transactionControls.VerifyLocalTransactionStatus(arg1, arg2);
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            transactionControls.verifyTransactionControlsPageTitleIOS(arg2);
//            transactionControls.VerifyLocalTransactionStatusIOS(arg1, arg2);
//        }
//    }
//
//    @Then("^I check \"([^\"]*)\" Online International Local transactions are blocked$")
//    public void i_verify_all_transactions_are_blocked(String arg1) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            transactionControls.verifyOnlineDeclinedStatus(arg1);
//            transactionControls.verifyInternationalDeclinedStatus(arg1);
//            transactionControls.verifyLocalDeclinedStatus(arg1);
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            transactionControls.verifyOnlineTransactionDeclinedStatusIOS(arg1);
//            transactionControls.verifyInternationalTransactionDeclinedStatusIOS(arg1);
//            transactionControls.verifyLocalTransactionDeclinedStatusIOS(arg1);
//        }
//    }
//
//
//    @When("^I enter spend limit greater than CreditLimit in Online screen for \"([^\"]*)\" under lock and unlock in \"([^\"]*)\" screens$")
//    public void i_enter_spend_limit_in_Online_screen(String arg2, String arg3) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            Wait.forSeconds(25);
//            accountdetails.clickTransactionControls();
//            transactionControls.verifyTransactionControlsPageTitle(arg3);
//            transactionControls.verifyCardStatusInTransactionControl(arg2);
//            Wait.forSeconds(5);
//            transactionControls.enterGreaterSpendLimitInOnline();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            accountdetails.clickTransactionControls();
//            transactionControls.verifyTransactionControlsPageTitleIOS(arg3);
//            transactionControls.verifyCardStatusInTransactionControlIOS(arg2);
//            transactionControls.enterGreaterSpendLimitInOnlineIOS();
//
//
//
//        }
//    }
//
//    @Then("^I should see error msg \"([^\"]*)\" in \"([^\"]*)\" Screen$")
//    public void i_should_see_error_msg_in_Screen(String arg1, String arg2) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            online.verifyOnlinePagetitle(arg2);
//            online.spendLimitErrorMsg(arg1);
//            Wait.forSeconds(5);
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            //online.verifyOnlinePagetitle(arg2);
//            online.spendLimitErrorMsg(arg1);
//        }
//    }
//
//    @Then("^I should see save button is enabled in \"([^\"]*)\" Screen$")
//    public void i_should_see_save_button_is_enabled_in_Screen(String arg1) throws Throwable {
//
//    }
//
//    @When("^I enter spend limit lower than credit limit in Online screen for \"([^\"]*)\" under lock and unlock in \"([^\"]*)\" screens$")
//    public void i_enter_spend_limit_in_Online_screen_lower_credit_limit(String arg2, String arg3) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            Wait.forSeconds(8);
//            accountdetails.clickBackButton();
//            transactionControls.verifyTransactionControlsPageTitle(arg3);
//            transactionControls.verifyCardStatusInTransactionControl(arg2);
//            transactionControls.enterLowerCreditLimitInOnline();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            accountdetails.clickBackButtonIOS();
//            transactionControls.verifyTransactionControlsPageTitleIOS(arg3);
//            transactionControls.verifyCardStatusInTransactionControlIOS(arg2);
//            transactionControls.enterLowerCreditLimitInOnlineIOS();
//        }
//    }
//
//    @When("^I enter spend limit equal to credit limit in Online screen for \"([^\"]*)\" under lock and unlock in \"([^\"]*)\" screens$")
//    public void i_enter_spend_limit_in_Online_screen_equal_to_credit_limit(String arg2, String arg3) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            transactionControls.verifyTransactionControlsPageTitle(arg3);
//            transactionControls.verifyCardStatusInTransactionControl(arg2);
//            transactionControls.enterEqualCreditLimitInOnline();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            transactionControls.verifyTransactionControlsPageTitleIOS(arg3);
//            transactionControls.verifyCardStatusInTransactionControlIOS(arg2);
//            transactionControls.enterEqualCreditLimitInOnlineIOS();
//        }
//    }
//
//    @When("^I enter spend limit greater than CreditLimit in International screen for \"([^\"]*)\" under lock and unlock in \"([^\"]*)\" screens$")
//    public void i_enter_spend_limit_in_international_screen(String arg2, String arg3) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            accountdetails.clickTransactionControls();
//            transactionControls.verifyTransactionControlsPageTitle(arg3);
//            transactionControls.verifyCardStatusInTransactionControl(arg2);
//            transactionControls.enterGreaterSpendLimitInInternational();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            accountdetails.clickTransactionControls();
//            transactionControls.verifyTransactionControlsPageTitleIOS(arg3);
//            //transactionControls.verifyCardStatusInTransactionControlIOS(arg2);
//            transactionControls.enterGreaterSpendLimitInInternationalIOS();
//        }
//    }
//
//    @When("^I enter spend limit lower than credit limit in International screen for \"([^\"]*)\" under lock and unlock in \"([^\"]*)\" screens$")
//    public void i_enter_spend_limit_in_international_screen_lower_credit_limit(String arg2, String arg3) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            accountdetails.clickBackButton();
//            transactionControls.verifyTransactionControlsPageTitle(arg3);
//            transactionControls.verifyCardStatusInTransactionControl(arg2);
//            transactionControls.enterLowerCreditLimitInInternational();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            accountdetails.clickBackButtonIOS();
//            transactionControls.verifyTransactionControlsPageTitleIOS(arg3);
//            transactionControls.verifyCardStatusInTransactionControlIOS(arg2);
//            transactionControls.enterLowerCreditLimitInInternationalIOS();
//        }
//    }
//
//    @When("^I enter spend limit equal to credit limit in International screen for \"([^\"]*)\" under lock and unlock in \"([^\"]*)\" screens$")
//    public void i_enter_spend_limit_in_international_screen_equal_to_credit_limit(String arg2, String arg3) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            Wait.forSeconds(10);
//            transactionControls.verifyTransactionControlsPageTitle(arg3);
//            transactionControls.verifyCardStatusInTransactionControl(arg2);
//            transactionControls.enterEqualCreditLimitInInternational();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            transactionControls.verifyTransactionControlsPageTitleIOS(arg3);
//            transactionControls.verifyCardStatusInTransactionControlIOS(arg2);
//            transactionControls.enterEqualCreditLimitInInternationalIOS();
//        }
//    }
//
//    @When("^I enter spend limit greater than CreditLimit in Local screen for \"([^\"]*)\" under lock and unlock in \"([^\"]*)\" screens$")
//    public void i_enter_spend_limit_in_local_screen(String arg2, String arg3) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            accountdetails.clickTransactionControls();
//            transactionControls.verifyTransactionControlsPageTitle(arg3);
//            transactionControls.verifyCardStatusInTransactionControl(arg2);
//            transactionControls.enterGreaterSpendLimitInLocal();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            accountdetails.clickTransactionControls();
//            transactionControls.verifyTransactionControlsPageTitleIOS(arg3);
//            transactionControls.verifyCardStatusInTransactionControlIOS(arg2);
//            transactionControls.enterGreaterSpendLimitInLocalIOS();
//        }
//    }
//
//    @When("^I enter spend limit lower than credit limit in Local screen for \"([^\"]*)\" under lock and unlock in \"([^\"]*)\" screens$")
//    public void i_enter_spend_limit_in_local_screen_lower_credit_limit(String arg2, String arg3) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            accountdetails.clickBackButton();
//            transactionControls.verifyTransactionControlsPageTitle(arg3);
//            transactionControls.verifyCardStatusInTransactionControl(arg2);
//            transactionControls.enterLowerCreditLimitInLocal();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            accountdetails.clickBackButtonIOS();
//            transactionControls.verifyTransactionControlsPageTitleIOS(arg3);
//            transactionControls.enterLowerCreditLimitInLocalIOS();
//        }
//    }
//
//    @When("^I enter spend limit equal to credit limit in Local screen for \"([^\"]*)\" under lock and unlock in \"([^\"]*)\" screens$")
//    public void i_enter_spend_limit_in_local_screen_equal_to_credit_limit(String arg2, String arg3) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            Wait.forSeconds(10);
//            transactionControls.verifyTransactionControlsPageTitle(arg3);
//            transactionControls.verifyCardStatusInTransactionControl(arg2);
//            transactionControls.enterEqualCreditLimitInLocal();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            transactionControls.verifyTransactionControlsPageTitleIOS(arg3);
//            transactionControls.enterEqualCreditLimitInLocalIOS();
//        }
//    }
//
//    @And("^I navigate to Online Transaction Screen and i enable decline online purchase toggle button$")
//    public void i_navigate_to_Online_Transaction_Screen() throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            transactionControls.clickOnlineTransaction();
//            transactionControls.selectDeclineOnlinePurchaseToggleBtn();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            transactionControls.clickOnlineTransaction();
//            transactionControls.selectDeclineOnlinePurchaseToggleBtnIOS();
//        }
//    }
//
//    @And("^I navigate to International Transaction Screen and i enable decline international purchase toggle button$")
//    public void i_navigate_to_International_Transaction_Screen() throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            transactionControls.clickInternationalTransaction();
//            transactionControls.selectDeclineInternationalPurchaseToggleBtn();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            transactionControls.clickInternationalTransaction();
//            transactionControls.selectDeclineOnlinePurchaseToggleBtnIOS();
//        }
//    }
//
//    @And("^I navigate to Local Transaction Screen and i enable decline local purchase toggle button$")
//    public void i_navigate_to_Local_Transaction_Screen() throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            transactionControls.clickLocalTransaction();
//            transactionControls.selectDeclineLocalPurchaseToggleBtn();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            transactionControls.clickLocalTransaction();
//            transactionControls.selectDeclineOnlinePurchaseToggleBtnIOS();
//        }
//    }
//
//    @Then("^On successful transfer entries save button should be enabled$")
//    public void on_successful_transfer_entries_save_button_should_be_enabled() throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            transactionControls.verifySavebtnIsEnabled();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            transactionControls.verifySavebtnIsEnabled();
//        }
//    }
//
//    @Then("^I enable spend limit toggle button and i enter amount \"([^\"]*)\" as spend limit$")
//    public void i_enable_spend_limit_toggle_button_and_i_enter_amount_as_spend_limit(String arg1) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            transactionControls.selectSpendLimitToggleBtn(arg1);
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            transactionControls.selectSpendLimitToggleBtnInternationalIOS(arg1);
//        }
//    }
//
//    @When("^I leave spend limit amount field blank$")
//    public void i_leave_spend_limit_amount_field_blank() throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            transactionControls.verifyAmountFiled();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            transactionControls.verifyAmountFiledIOS();
//        }
//    }
//
//    @And("^I enable Set Time toggle button in \"([^\"]*)\" screen$")
//    public void i_enable_Set_Time_toggle_button_in_screen(String arg1) throws Throwable {
//
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            transactionControls.verifyOnlinePagetitle(arg1);
//            transactionControls.selectSetTimeToggleBtn();
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            transactionControls.verifyOnlinePagetitle(arg1);
//            transactionControls.selectSetTimeToggleBtn();
//        }
//    }

    @Then("^I leave From and To time field blank Save button should be disabled$")
    public void i_leave_From_and_To_time_field_blank_Save_button_should_be_disabled() throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            transactionControls.verifySavebtnIsDisabled();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            transactionControls.verifySavebtnIsDisabled();
        }
    }


    @When("^I click the Reportcard credit card listed in dashboard$")
    public void iClickTheReportcardCreditCardListedInDashboard() throws Throwable {
        transactionControls.clickCreditCard();
    }

    @Then("^Verify the lockunlock option is displayed$")
    public void verifyTheLockunlockOptionIsDisplayed() throws Throwable {
        transactionControls.verifyLockUnlockOption();
    }

    @And("^toggle on the lockunlock option$")
    public void toggleOnTheLockunlockOption() throws Throwable {
        transactionControls.clickToggleOnBtn();
    }

    @Then("^user verify the lock card header$")
    public void userVerifyTheLockCardHeader() throws Throwable {
        transactionControls.verifyLockcardHeader();
    }

    @And("^user verify the lock card prohibitions$")
    public void userVerifyTheLockCardProhibitions() throws Throwable {
        transactionControls.verifyProhibitionMsg();
    }

    @And("^user click to lock my card$")
    public void userClickToLockMyCard() throws Throwable {
        transactionControls.clickLockCard();
    }

    @Then("^user click to unlock my card option$")
    public void userClickToUnlockMyCardOption() throws Throwable {
        transactionControls.clickUnlockCard();
    }
    @Then("^user click may be later$")
    public void userClickMayBeLater() throws Throwable {
        transactionControls.clickMayBelater();
    }
}

