package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.AutoDebitPage;

public class C034_AutoDebit {

    AutoDebitPage AutoDebit = new AutoDebitPage();


    @When("^User clicks an Account Details screen by clicking card screen$")
    public void userClicksAnAccountDetailsScreenByClickingCardScreen() throws Throwable {
        AutoDebit.clickOnPlatinumCredit();
    }
    @When("^User clicking AutoDebit ViewCard screen$")
    public void userClickingAutoDebitViewCardScreen() throws Throwable {
        AutoDebit.clickOnPlatinumCredit_View();
    }
    @Then("^Verify application displays pay option in Account details$")
    public void verifyApplicationDisplaysPayOptionInAccountDetails() throws Throwable {
        AutoDebit.verifyPayButton();
    }
    @When("^User able to click on pay option$")
    public void userAbleToClickOnPayOption() throws Throwable {
        AutoDebit.clickOnPayButton();
    }
    @Then("^Verify application navigates to Payment Details screen$")
    public void verifyApplicationNavigatesToPaymentDetailsScreen() throws Throwable {
        AutoDebit.verifyPaymentDetails();
    }
    @Then("^Verify application navigates to Which amount do you want to pay screen$")
    public void verifyApplicationNavigatesToWhichAmountDoYouWantToPayScreen()throws Throwable {
        AutoDebit.verifyAmountPayScreen();
    }
    @When("^User able to click on Set up Auto-debit$")
    public void userAbleToClickOnSetUpAutoDebit() throws Throwable {
        AutoDebit.clickOnSetupAutoDebit();
    }
    @Then("^Verify that next button is disabled$")
    public void verifyThatNextButtonIsDisabled() throws Throwable {
        AutoDebit.verifyNextButton();
    }
    @When("^User able to click Minimum Amount Due option$")
    public void userAbleToClickMinimumAmountDueOption() throws Throwable {
        AutoDebit.clickOnMinimumAmountDue();
    }
    @Then("^Verify application navigates to Review and Request screen$")
    public void verifyApplicationNavigatesToReviewAndRequestScreen() throws Throwable {
        AutoDebit.verifyReviewandRequestPage();
    }
    @And("^Verify that SET UP AUTO-DEBIT ARRANGEMENT button is disabled$")
    public void verifyThatSETUPAUTODEBITARRANGEMENTButtonIsDisabled() throws Throwable {
        AutoDebit.verifySetupAutoDebitArrangementButton();
    }
    @When("^User able to click on Accept And Continue$")
    public void userAbleToClickOnAcceptAndContinue() throws Throwable {
        AutoDebit.clickOnAcceptAndContinue();
    }
    @When("^User able to click SET UP AUTO-DEBIT ARRANGEMENT button$")
    public void userAbleToClickSETUPAUTODEBITARRANGEMENTButton() throws Throwable {
        AutoDebit.clickOnSetupAutoDebitArrangementButton();
    }
    @Then("^Verify if application navigates to OTP screen$")
    public void verifyIfApplicationNavigatesToOTPScreen() throws Throwable {
        AutoDebit.verifyOtpScreen();
    }
    @Then("^Verify Set up Auto Debit option is changed to View Auto-Debit screen$")
    public void verifySetUpAutoDebitOptionIsChangedToViewAutoDebitScreen() throws Throwable {
        AutoDebit.verifyViewAutoDebit();
    }
    @When("^user able to select View Auto-Debit$")
    public void userAbleToSelectViewAutoDebit() throws Throwable {
        AutoDebit.clickViewAutoDebit();
    }
    @Then("^Verify application navigate to Auto-Debit Details screen when user click on View Auto-Debit$")
    public void verifyApplicationNavigateToAutoDebitDetailsScreenWhenUserClickOnViewAutoDebit() throws Throwable {
        AutoDebit.verifyAutoDebitDetailsPage();
    }

    @Then("^Verify that next button is disabled in Payment details section$")
    public void verifyThatNextButtonIsDisabledInPaymentDetailsSection() throws Throwable {
        AutoDebit.verifyNextButton();
    }

    @And("^I click the next button in Payment details section$")
    public void iClickTheNextButtonInPaymentDetailsSection() throws Throwable {
        AutoDebit.ClickNextButton();
    }

    @And("^User select Pay from which account$")
    public void userSelectPayFromWhichAccount() throws Throwable {
        AutoDebit.clickOnPayFromAccount();

    }
}
