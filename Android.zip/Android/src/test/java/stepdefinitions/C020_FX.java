package stepdefinitions;

import actions.Swipe;
import actions.Wait;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverManager;
import pages.*;
import runners.ConvergentTestRunner;

public class C020_FX {
    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private SendRequestPage sendrequest = new SendRequestPage();
    private PesonetPage pesonet = new PesonetPage();
    private TransferDetailsPage transferDetailsPage = new TransferDetailsPage();
    private TransferToPage transferToPage = new TransferToPage();
    private TransferSuccessfulPage ownsuccesspage = new TransferSuccessfulPage();
    private ReviewandTransferPage otherreviewpage = new ReviewandTransferPage();
    private TransferFromPage otherfrompage = new TransferFromPage();
    private TransferToPage othertopage = new TransferToPage();
    private TransferDetailsPage otherdetailpage = new TransferDetailsPage();
    private AccountDetailsPage accountdetailspage = new AccountDetailsPage();
    private TransferFromPage pesonetfrompage = new TransferFromPage();
    private ReviewandTransferPage pesonetreviewpage = new ReviewandTransferPage();
    private ManageReceipentPage mangerecepent = new ManageReceipentPage();
    private ForeignExchange fxpage = new ForeignExchange();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();
    public static Swipe swipe=new Swipe();
    private String updatedamount;

    @When("^I choose Click the FX link from the footer section in welcome page$")
    public void iChooseClickTheFXLinkFromTheFooterSectionInWelcomePage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(4);
        swipe.swipeVertical(2, 0.8, .4, 2);
        swipe.swipeVertical(2, 0.8, .4, 2);
        swipe.swipeVertical(2, 0.8, .4, 2);
        //swipe.swipeVertical(2, 0.8, .4, 2);
        //swipe.swipeVertical(2, 0.8, .4, 2);
        //swipe.swipeVertical(2, 0.8, .4, 2);
        fxpage.clickforeinexchange();
        Wait.forSeconds(5);
    }

    @Then("^I should see the \"([^\"]*)\" title in FX page$")
    public void iShouldSeeTheTitleInFXPage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        fxpage.verifyFXtitle();
    }

    @And("^I click the Buy USD option in the Foreign Exchange$")
    public void iClickTheBuyUSDOptionInTheForeignExchange() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        fxpage.clickbuyusd();
    }



    @And("^I enter the \"([^\"]*)\" usd amount to exchange$")
    public void iEnterTheUsdAmountToExchange(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        fxpage.enterUSDamounttotransfer(arg0);
    }

    @And("^I draw the sign in sigaturepad$")
    public void iDrawTheSignInSigaturepad() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        fxpage.signinsignaturepad();
    }

    @And("^click next button in Foreign Exchange$")
    public void clickNextButtonInForeignExchange() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        fxpage.clicknext();
    }

    @And("^I click the Sell USD option in the Foreign Exchange$")
    public void iClickTheSellUSDOptionInTheForeignExchange() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        fxpage.clicksellusd();
    }


    @And("^I select transfer account by using tap to select account option$")
    public void iSelectTransferAccountByUsingTapToSelectAccountOption() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        fxpage.selectfromaccount();
    }

    @Then("^I should see the \"([^\"]*)\" message in FX page$")
    public void iShouldSeeTheMessageInFXPage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
      fxpage.verifyMessagecontent(arg0);
    }

    @Then("^I should see the \"([^\"]*)\" Amount exceed message in FX page$")
    public void iShouldSeeTheAmountExceedMessageInFXPage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        fxpage.verifyMessageamountexceed(arg0);
    }

    @Then("^I should see the \"([^\"]*)\" dont have enough fund validation message in FX page$")
    public void iShouldSeeTheDontHaveEnoughFundValidationMessageInFXPage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        fxpage.verifyMessageenoughamount(arg0);
    }


    @Then("^user verify BUYUSD and SELLUSD$")
    public void userVerifyBUYUSDAndSELLUSD() throws Throwable {
        fxpage.verifyUsd();
    }

    @Then("^I verify Add Account and Cancel buttons by clicking SELLUSD button$")
    public void iVerifyAddAccountAndCancelButtonsByClickingSELLUSDButton() {
    }

    @Then("^I verify Add Account and Cancel buttons by clicking BUYUSD button$")
    public void iVerifyAddAccountAndCancelButtonsByClickingBUYUSDButton() {
    }

    @And("^I select account and enter exceeded USD amount$")
    public void iSelectAccountAndEnterExceededUSDAmount() throws Throwable {
        fxpage.clickTapToSelect();
    }
    @Then("^I verify the amount exceeds error message$")
    public void iVerifyTheAmountExceedsErrorMessage() throws Throwable {
        fxpage.verifyLimitExceeds();
    }
    @And("^click Buy USD Button$")
    public void clickBuyUSDButton() throws Throwable {
        fxpage.clickBuyusd();
    }

    @Then("^I verify the Deal Received Title message$")
    public void iVerifyTheDealReceivedTitleMessage() throws Throwable {
        fxpage.verifyDealReceivedmsg();
    }
    @And("^I verify the DealSuccess message$")
    public void iVerifyTheDealSuccessMessage() throws Throwable {
        fxpage.verifyDealDescription();
    }

    @And("^click Sell USD Button$")
    public void clickSellUSDButton() throws Throwable {
        fxpage.clickSellUSD();
    }

    @Then("^I click to edit option in review and convert page$")
    public void iClickToEditOptionInReviewAndConvertPage() {
    }

    @And("^click to update button$")
    public void clickToUpdateButton() {
    }

    @And("^verify the rate,buying,settlement amount,From acc, claim method, purpose and signature$")
    public void verifyTheRateBuyingSettlementAmountFromAccClaimMethodPurposeAndSignature() {
    }

    @And("^verify the rate,selling,settlement amount,From acc, claim method, purpose and signature$")
    public void verifyTheRateSellingSettlementAmountFromAccClaimMethodPurposeAndSignature() {
    }

    @And("^I click the Next Button in signature verification page$")
    public void iClickTheNextButtonInSignatureVerificationPage() {
    }

    @Then("^I click edit option in signature$")
    public void iClickEditOptionInSignature() {
    }

    @Given("^I'm on login page of UB online banking application with FX user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithFXUser() {
    }

    @When("^I click on Foreign Exchange button in dashboard$")
    public void iClickOnForeignExchangeButtonInDashboard() {
    }

    @And("^user verify recent transaction and foreign exchange rate section$")
    public void userVerifyRecentTransactionAndForeignExchangeRateSection() {
    }

    @And("^user enter invalid amount beyond limit$")
    public void userEnterInvalidAmountBeyondLimit() {
    }

    @Then("^user verify the amount exceed inline message$")
    public void userVerifyTheAmountExceedInlineMessage() {
    }

    @And("^user enter invalid amount beyond limit for SELL USD$")
    public void userEnterInvalidAmountBeyondLimitForSELLUSD() {
    }
}
