package stepdefinitions;

import java.time.ZonedDateTime;
import java.time.format.TextStyle;
import java.util.Locale;


import actions.Wait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverManager;
import helper.PropertyReader;
import pages.*;
import runners.ConvergentTestRunner;

public class C006_FundTransfer_OwnAccount {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private SendRequestPage sendrequest = new SendRequestPage();
    private TransferFromPage ownfrompage = new TransferFromPage();
    private TransferToPage owntopage = new TransferToPage();
    private TransferDetailsPage owndetailpage = new TransferDetailsPage();
    private ReviewandTransferPage ownreviewpage = new ReviewandTransferPage();
    private TransferSuccessfulPage ownsuccesspage = new TransferSuccessfulPage();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();


    //Test data for verification
    private String transferamount;
    private String remarkmsg;
    private String frequency;
    private String date = "Today";
    private String repeat = "Never";
    private String updatedamount;
    private String refernenceno;

    /////
    static String day;
    static ZonedDateTime zdt = ZonedDateTime.now();
    static String year = Integer.toString(zdt.getYear());
    static String monthName = zdt.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
    static String dayOfMonth = Integer.toString(zdt.getDayOfMonth());

    static String pastdate = Integer.toString(zdt.minusDays(1).getDayOfMonth());

    static {
        if (dayOfMonth.length() == 1) {
            day = "0" + dayOfMonth;
        } else {
            day = dayOfMonth;

        }

    }


    /*static
    {
    if(!day.contentEquals("01"))
    {
    pastdate=Integer.toString(Integer.parseInt(day)-1);
    }
    pastdate=Integer.toString(zdt.minusDays(Integer.parseInt(day)).getDayOfMonth());
    }
    */
    private static String transactiondate = monthName + " " + day + ", " + year;
    /////


    @Given("^I'am on \"([^\"]*)\" page of union bank mobile application$")
    public void i_am_on_page_of_union_bank_mobile_application(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        welcome.clickGotITBtn_Biometrics();
        welcome.clickNext();
        welcome.clickNext();
        welcome.clickNext();
        if(Devicename.currentdevicename.equalsIgnoreCase("Samsung")) {
            welcome.clickNext();
        }
        welcome.clickGetStarted();
        welcome.clickLogin();
        login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
        login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
        login.clickLogin();
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        home.clickContinue();
        home.clickNotNowtoSubscribe();
        home.clickNotNowToTurnOnNotification();
        home.clickNotNowToTurnOnNotification();
        home.clickGotoDashBoard();
        home.gotoSendRequestTab();
        sendrequest.verifySendRequestTitle(arg1);

    }

    @Given("^I'am on \"([^\"]*)\" page of union bank mobile application for user having two accounts$")
    public void i_am_on_page_of_union_bank_mobile_application_for_user_having_two_accounts(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        welcome.clickGotITBtn_Biometrics();
        welcome.clickNext();
        welcome.clickNext();
        welcome.clickNext();
        if (Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            welcome.clickNext();
        }
        welcome.clickGetStarted();
        welcome.clickLogin();
        login.enterUsername(PropertyReader.testDataOf("Account4_UserID"));
        login.enterPassword(PropertyReader.testDataOf("Account4_Password"));
        login.clickLogin();
        otp.enterOTP(PropertyReader.testDataOf("Account4_OTP"));
        Thread.sleep(15000);
        //home.closeRegisterDevicePopup();
        home.clickContinue();
        home.clickNotNowtoSubscribe();
          home.clickNotNowToTurnOnNotification();
        if(Devicename.currentdevicename.equalsIgnoreCase("ABC")) {
            home.clickNotNowToTurnOnNotification();
        }
        home.clickGotoDashBoard();
        Thread.sleep(10000);
//        home.clickNotNowfingerprintNotification();
//        home.clickNotNowfingerprintNotification();
        home.verifyIfDashboardIsDisplayed("Dashboard");
        home.gotoSendRequestTab();
        Thread.sleep(10000);
        //sendrequest.verifySendRequestTitle(arg1);

    }


    @When("^I click on \"([^\"]*)\" fund transfer option from the Send/Request page$")
    public void i_click_on_fund_transfer_option_from_the_Send_Request_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.verifyOWNAccountLink(arg1);
        sendrequest.clickOWNAccountLink();
        Wait.forSeconds(10);
    }

    @When("^choose the \"([^\"]*)\" from the list of source accounts in Transfer from\\? page$")
    public void choose_the_from_the_list_of_source_accounts_in_Transfer_from_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg1));
    }

    @Then("^I should see \"([^\"]*)\" page with facility to choose transfer to account details$")
    public void i_should_see_page_with_facility_to_choose_transfer_to_account_details(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owntopage.verifyTransferToPageTitle(arg1);
    }

    @When("^choose the \"([^\"]*)\" and \"([^\"]*)\" from the list of availabel accounts$")
    public void choose_the_and_from_the_list_of_availabel_accounts(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg1));
        owntopage.chooseTranferToAccount(PropertyReader.testDataOf(arg1));
    }

    @Then("^I should see \"([^\"]*)\" page$")
    public void i_should_see_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.verifyTransferDetailsPageTile(arg1);
    }


    @Given("^I'm on \"([^\"]*)\" Fund Transfer from\\? page$")
    public void i_m_on_Fund_Transfer_from_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.clickNext();
            welcome.clickNext();
            welcome.clickNext();
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                welcome.clickNext();
            }
            welcome.clickGetStarted();
            welcome.clickLogin();
            login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(2);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(2);
            //home.closeRegisterDevicePopup();
            home.clickContinue();
            Wait.forSeconds(2);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(2);
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            home.verifyIfDashboardIsDisplayed("Dashboard");
            home.gotoSendRequestTab();
            Thread.sleep(30000);

            sendrequest.verifyOWNAccountLink(arg1);
            sendrequest.clickOWNAccountLink();

        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(15);
            home.gotoSendRequestTabIOS();
            Wait.forSeconds(20);
            arg1=arg1+"s";
            sendrequest.verifyOWNAccountLink(arg1);
            sendrequest.clickOWNAccountLink();
        }


    }

    @Given("^I'm on \"([^\"]*)\" Send_Request page if customer have one account$")
    public void i_m_on_Send_Request_page_if_customer_have_one_account(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.clickNext();
            welcome.clickNext();
            welcome.clickNext();
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                welcome.clickNext();
            }
            welcome.clickGetStarted();
            welcome.clickLogin();
            login.enterUsername(PropertyReader.testDataOf("Account3_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account3_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account3_OTP"));
            Thread.sleep(35000);
            //home.closeRegisterDevicePopup();
            home.clickContinue();
            home.clickNotNowtoSubscribe();
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung"))
            {
                home.clickNotNowToTurnOnNotification();
            }
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            home.verifyIfDashboardIsDisplayed("Dashboard");
            home.gotoSendRequestTab();
            Wait.forSeconds(30);
        }

       else if(DriverManager.OS.equalsIgnoreCase("IOS")) {


        }

    }

    @When("^I choose \"([^\"]*)\" and \"([^\"]*)\" informations$")
    public void i_enter_and_informations(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(3);
            ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg1));
            Wait.forSeconds(3);
            owntopage.chooseTranferToAccount(PropertyReader.testDataOf(arg2));
            Wait.forSeconds(3);
            owntopage.clickOKBtn();
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            ownfrompage.chooseTranferFromAccountios();
            Thread.sleep(3000);
            ownfrompage.chooseTranferToAccountios();

        }


    }

    @When("^I try to enter non-numeric characters \"([^\"]*)\" in amount field of \"([^\"]*)\" page$")
    public void i_try_to_enter_non_numeric_characters_in_amount_field_of_page(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.verifyTransferDetailsPageTile(arg2);
        owndetailpage.enterTransferAmt(arg1);

    }

    @Then("^the application should not allow to user to keyin the non-numeric characters in amount field section$")
    public void the_application_should_not_allow_to_user_to_keyin_the_non_numeric_characters_in_amount_field_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.checkDefaultTransferAmtval();
    }

    @Then("^I should not see \"([^\"]*)\" link in the \"([^\"]*)\" page$")
    public void i_should_not_see_link_in_the_page(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.verifySendRequestTitle(arg2);
        sendrequest.verifyOWNAccountLinkNotDisplayed(arg1);

    }

    @Then("^I should see a \"([^\"]*)\" link in the \"([^\"]*)\" page$")
    public void i_should_see_a_link_in_the_page(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.verifySendRequestTitle(arg2);
        sendrequest.verifyOWNAccountLink(arg1);

    }


    @Then("^Own Account \"([^\"]*)\" page should be displayed$")
    public void own_Account_page_should_be_displayed(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.verifyTransferDetailsPageTile(arg1);
    }

    @When("^I enter an amount PHP \"([^\"]*)\" greater than the account balance in amount field$")
    public void i_enter_an_amount_PHP_greater_than_the_account_balance_in_amount_field(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.enterTransferAmt(arg1);
        owndetailpage.clickRepeatMsgbox();
    }

    @Then("^I should see an error message \"([^\"]*)\" below the amount field$")
    public void i_should_see_an_error_message_below_the_amount_field(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.verifyAmtErrorMsg(arg1);
    }

    @When("^I enter transaction amount \"([^\"]*)\" PHP in amount field in Own Account fund transfer details page$")
    public void i_enter_transaction_amount_PHP_in_amount_field_in_Own_Account_fund_transfer_details_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferamount = "PHP " + arg1;
        owndetailpage.enterTransferAmt(arg1);
    }

    @When("^Turn on the repeat toggle button$")
    public void turn_on_the_repeat_toggle_button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       Wait.forSeconds(15);
        owndetailpage.turnONToggleBtn();
    }

    @Then("^I should see a option to provide \"([^\"]*)\" and \"([^\"]*)\" functionality in Own Account fund transfer details page$")
    public void i_should_see_a_option_to_provide_and_functionality_in_Own_Account_fund_transfer_details_page(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.verifyFrequencyElement(arg1);
        owndetailpage.verifyEndRepeatElement(arg2);
    }

    @When("^Not choosing any freqency interval from the Repeat section$")
    public void not_choosing_any_freqency_interval_from_the_Repeat_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.turnONToggleBtn();
        owndetailpage.turnONToggleBtn();
    }

    @Then("^The Next button should be in disabled mode$")
    public void the_Next_button_should_be_in_disabled_mode() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.checkNextButtonDisabled();
    }
//    @And("^Turn on repeat toggle button$")
//    public void turn_on_repeat_toggle_button() throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        owndetailpage.turnONToggleBtn();
//    }
    @When("^I choose \"([^\"]*)\" as a repeat option from select frequency in Own Account fund transfer details page$")
    public void i_choose_as_a_repeat_option_from_select_frequency_in_Own_Account_fund_transfer_details_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
         if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

            frequency = arg1;
            owndetailpage.clickFrequencyElement();
            owndetailpage.chooseSelectFrequency();
        }

          else if(DriverManager.OS.equalsIgnoreCase("IOS"))  {


             //C004_FundTransfer_EONAccount.turn_on_repeat_toggle_button();
             owndetailpage.clickFrequencyElement();
             owndetailpage.chooseSelectFrequencyios(arg1);
             owndetailpage.clickTransferfrequencydone();
             Wait.forSeconds(10);
        }


    }

    @When("^click next button in Own Account fund transfer details page$")
    public void click_next_button_in_Own_Account_fund_transfer_details_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.clickNextBtn();
        Thread.sleep(5000);
        ownreviewpage.clickGotitButton();


    }

    @Then("^I should see Own Account \"([^\"]*)\" page$")
    public void i_should_see_Own_Account_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Thread.sleep(2000);
        ownreviewpage.verifyReviewandTransfertitle(arg1);
    }

    @Given("^I'm on the landing page of union bank with \"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_m_on_the_landing_page_of_union_bank_with_and(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        welcome.clickGotITBtn_Biometrics();
        welcome.clickNext();
        welcome.clickNext();
        welcome.clickNext();
        if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            welcome.clickNext();
        }
        welcome.clickGetStarted();
        welcome.clickLogin();
        login.enterUsername(PropertyReader.testDataOf(arg1));
        login.enterPassword(PropertyReader.testDataOf(arg2));
        login.clickLogin();
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        //home.closeRegisterDevicePopup();
        home.clickContinue();
        home.clickNotNowtoSubscribe();
        home.clickNotNowToTurnOnNotification();
        if(Devicename.currentdevicename.equalsIgnoreCase("ABC") || Devicename.currentdevicename.equalsIgnoreCase("ABC")) {
            home.clickNotNowToTurnOnNotification();
        }
        home.clickGotoDashBoard();
        home.verifyIfDashboardIsDisplayed("Dashboard");
    }


    @When("^I enter remark message with text \"([^\"]*)\" in own account transfer detail page$")
    public void i_enter_remark_message_with_text_in_own_account_transfer_detail_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.enterRemarkMessageText(PropertyReader.testDataOf(arg1));
    }

    @Then("^I should see the entered remark message in own account transfer detail page$")
    public void i_should_see_the_entered_remark_message_in_own_account_transfer_detail_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.verifyRemarkMessageText(PropertyReader.testDataOf("less_than_256_characters"));
    }

    @Then("^I should see the entered remark message with only (\\d+) characters in own account transfer detail page$")
    public void i_should_see_the_entered_remark_message_with_only_characters_in_own_account_transfer_detail_page(int arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.verifyRemarkMessageText(PropertyReader.testDataOf("equal_to_256_characters"));
    }

    @Then("^I should see the remark message with only (\\d+) characters in own account transfer detail page$")
    public void i_should_see_the_remark_message_with_only_characters_in_own_account_transfer_detail_page(int arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //owndetailpage.verifyRemarkMessageText(PropertyReader.testDataOf("greater_than_256_characters").substring(0, 256));
    }

    @When("^I enter remark message as \"([^\"]*)\" in Own Account detail page$")
    public void i_enter_remark_message_as_in_Own_Account_detail_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        remarkmsg = arg1;
        owndetailpage.enterRemarkMessageText(arg1);
    }

    @Then("^I should see Own Account \"([^\"]*)\" page with \"([^\"]*)\",\"([^\"]*)\",transaction \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and remark \"([^\"]*)\" details$")
    public void i_should_see_Own_Account_page_with_transaction_and_remark_details(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ownreviewpage.verifyReviewandTransfertitle(arg1);
        ownreviewpage.verifyReviewPagelabel(arg2);
        ownreviewpage.verifyReviewPagelabel(arg3);
        ownreviewpage.verifyReviewPagelabel(arg4);
        ownreviewpage.verifyReviewPagelabel(arg5);
        ownreviewpage.verifyReviewPagelabel(arg6);
        ownreviewpage.verifyReviewPagelabel(arg7);
        ownreviewpage.verifyReviewPagelabel(arg8);

        //////few hard coded refer string declaration
        ownreviewpage.verifyReviewPagedetails(PropertyReader.testDataOf("OWN_Source_Name"), PropertyReader.testDataOf("OWN_Recipient_Name"), PropertyReader.testDataOf("OWN_Source_Account"), PropertyReader.testDataOf("OWN_Recipient_Account"), transferamount, date, frequency, repeat, remarkmsg);

        //ownreviewpage.clickTransfer();
    }

    @Given("^I'm on \"([^\"]*)\" \"([^\"]*)\" page with the \"([^\"]*)\",\"([^\"]*)\" and an amount PHP \"([^\"]*)\"$")
    public void verifyOWNAccountLinki_m_on_page_with_the_and_an_amount_PHP(String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.clickNext();
            welcome.clickNext();
            welcome.clickNext();
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                welcome.clickNext();
            }
            welcome.clickGetStarted();
            welcome.clickLogin();
            login.enterUsername(PropertyReader.testDataOf("Account4_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            Wait.forSeconds(5);
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(2);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(2);
            home.clickContinue();
            Wait.forSeconds(2);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(2);
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            //home.clickSendRequestTab();
            Wait.forSeconds(5);
            home.gotoSendRequestTab();
            Wait.forSeconds(3);
            sendrequest.verifyOWNAccountLink(arg1);
            Wait.forSeconds(3);
            sendrequest.clickOWNAccountLink();
            //actions.Wait.forSeconds(5);
            ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg3));
            Wait.forSeconds(3);
            owntopage.chooseTranferToAccount(PropertyReader.testDataOf(arg4));
            Wait.forSeconds(3);
            owntopage.clickOKBtn();
            Wait.forSeconds(3);
            owndetailpage.enterTransferAmt(arg5);
            Wait.forSeconds(3);
            owndetailpage.clickNextBtn();
            ownreviewpage.clickGotitButton();
            //Thread.sleep(3000);
            //ownreviewpage.verifyReviewandTransfertitle(arg2);
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(25);
            home.gotoSendRequestTabIOS();
            Thread.sleep(30000);
            arg1=arg1+"s";
            sendrequest.verifyOWNAccountLink(arg1);
            sendrequest.clickOWNAccountLink();
            ownfrompage.chooseTranferFromAccountios();
            Thread.sleep(10000);
            ownfrompage.chooseTranferToAccountios();
            Thread.sleep(10000);
            owndetailpage.enterTransferAmt(arg5);
            Thread.sleep(3000);
            owntopage.clickNextBtn();
            ownreviewpage.clickGotitButton();

        }


    }

    @When("^I click Edit link present in the From account section of Own Account review and transfer page$")
    public void i_click_Edit_link_present_in_the_From_account_section_of_Own_Account_review_and_transfer_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            ownreviewpage.clickEditlinkFromAccount();
//            if(Devicename.currentdevicename.equalsIgnoreCase("NOKIA7") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
//                Wait.forSeconds(20);
//                Touch.touchLongPress(950, 350, 950, 350);
//
//            }
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            ownreviewpage.clickEditlinkFromAccountios();
        }
    }

    @Then("^I should see Own Account \"([^\"]*)\" page with an option to change source account$")
    public void i_should_see_Own_Account_page_with_an_option_to_change_source_account(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Thread.sleep(2000);
        //ownreviewpage.clickGotitButton();
        ownfrompage.verifyTransferFromPageTitle(arg1);
    }

    @When("^I choose \"([^\"]*)\" from the list in Own Account page$")
    public void i_choose_from_the_list_in_Own_Account_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg1));
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            ownfrompage.chooseTranferFromAccountios();
        }

    }

    @When("^I choose \"([^\"]*)\" from the list in edit Own Account page$")
    public void i_choose_from_the_list_in_edit_Own_Account_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg1));
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            ownfrompage.chooseTranferFromeditAccountios();
        }

    }



    @Then("^I should see Own Account \"([^\"]*)\" page with updated source account$")
    public void i_should_see_Own_Account_page_with_updated_source_account(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //Keywords.refreshPage();
        //ownreviewpage.verifyReviewandTransfertitle(arg1);
        //ownreviewpage.verifyReviewandTransfertitle(arg1);
        //ownreviewpage.verificationafterfromaccounteditlink(PropertyReader.testDataOf("OWN_Another_Source_Name"),PropertyReader.testDataOf("OWN_Another_Source_Account"));
    }

    @When("^I click Edit link present in the To account section of Own Account review and transfer page$")
    public void i_click_Edit_link_present_in_the_To_account_section_of_Own_Account_review_and_transfer_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            ownreviewpage.clickEditlinkToAccount();
//            if(Devicename.currentdevicename.equalsIgnoreCase("NOKIA7") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
//                Wait.forSeconds(15);
//                Touch.touchLongPress(950, 540, 950, 540);
//            }
            //Touch.touchLongPress(950,650,950,650);
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            ownreviewpage.clickEditlinkToAccountios();
        }
    }

    @Then("^I should see Own Account \"([^\"]*)\" page with an option to change recipient account$")
    public void i_should_see_Own_Account_page_with_an_option_to_change_recipient_account(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Thread.sleep(3000);
        owntopage.verifyTransferToPageTitle(arg1);
    }

    @When("^I change the recipient account to \"([^\"]*)\" in Own Account transfer to\\? page$")
    public void i_change_the_recipient_account_to_in_Own_Account_transfer_to_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //owntopage.chooseTranferToAccount(PropertyReader.testDataOf("OWN_Another_Source_two_Account"));
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Thread.sleep(5000);
            owntopage.chooseTranferToAccount(PropertyReader.testDataOf(arg1));
            Thread.sleep(5000);
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            ownfrompage.chooseTranferToAccountios();

        }

    }

    @Then("^I should see Own Account \"([^\"]*)\" page with updated recipient account$")
    public void i_should_see_Own_Account_page_with_updated_recipient_account(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Thread.sleep(5000);
        ownreviewpage.verifyReviewandTransfertitle(arg1);
        //ownreviewpage.verificationaftertoaccounteditlink(PropertyReader.testDataOf("OWN_Another_Recipient_Name"), PropertyReader.testDataOf("OWN_Another_Recipient_Account"));
    }

    @When("^I click Edit link present in the Amount section of Own Account review and transfer page$")
    public void i_click_Edit_link_present_in_the_Amount_section_of_Own_Account_review_and_transfer_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            if(Devicename.currentdevicename.equalsIgnoreCase("NOKIA7") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
//                Wait.forSeconds(15);
//                Touch.pressByCoordinates(950, 875, 5);
//            }
            //Touch.pressByCoordinates(950,750,5);
            //Touch.touchLongPress(950,730,950,730);
            ownreviewpage.clickEditlinkAmount();
        }
        else if (DriverManager.OS.equalsIgnoreCase("IOS")) {

            ownreviewpage.clickEditlinkamountios();
        }

    }

    @Then("^I should see Own Account \"([^\"]*)\" page with option to change transfer amount details$")
    public void i_should_see_Own_Account_page_with_option_to_change_transfer_amount_details(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.verifyTransferDetailsPageTile(arg1);
    }

    @When("^I change the transfer amount to PHP \"([^\"]*)\" in Own Account transfer details page$")
    public void i_change_the_transfer_amount_to_PHP_in_Own_Account_transfer_details_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

            updatedamount = "PHP " + arg1;
            owndetailpage.enterTransferAmt(arg1);
            Wait.forSeconds(5);
            owndetailpage.clickDoneBtn();
            Wait.forSeconds(3);
            ownreviewpage.clickGotitButton();

        }

        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            updatedamount = "PHP " + arg1;
            owndetailpage.entereditTransferAmt(arg1);
            //owndetailpage.enterTransferAmt(arg1);
            //owndetailpage.clickDoneBtn();
            owndetailpage.clickDoneBtn();


        }

    }

    @Then("^I should see Own Account \"([^\"]*)\" page with updated transfer account$")
    public void i_should_see_Own_Account_page_with_updated_transfer_account(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(8);
        ownreviewpage.verifyReviewandTransfertitle(arg1);
        //ownreviewpage.verificationafteramounteditlink(updatedamount);
    }


    @When("^I click on \"([^\"]*)\" button in Own Account review and transfer page$")
    public void i_click_on_button_in_Own_Account_review_and_transfer_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(10);
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")){
//            if(Devicename.currentdevicename.equalsIgnoreCase("NOKIA7") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
//                Touch.touchLongPress(500, 1075, 500, 1075);
//                Touch.touchLongPress(500, 1200, 500, 1200);
//                Touch.touchLongPress(500, 1325, 500, 1325);
//                Touch.touchLongPress(500, 1475, 500, 1475);
//                Touch.touchLongPress(500, 1650, 500, 1650);
//            }
        //ownreviewpage.verifyTransferBtn(arg1);
        //Keywords.refreshPage();
        ownreviewpage.clickTransfer();
         }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            ownreviewpage.clickTransfer();
        }

    }

    @Then("^I should see a \"([^\"]*)\" page to enter OTP during Own account transfer scenario$")
    public void i_should_see_a_page_to_enter_OTP_during_Own_account_transfer_scenario(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otp.verifyPageTitle(arg1);
    }

    @When("^I enter Valid OTP \"([^\"]*)\" for Own account transfer scenario$")
    public void i_enter_Valid_OTP_for_Own_account_transfer_scenario(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otp.enterOTP(PropertyReader.testDataOf(arg1));
        Wait.forSeconds(15);
    }

    @Then("^I should see \"([^\"]*)\" screen for Own account transfer scenario$")
    public void i_should_see_screen_for_Own_account_transfer_scenario(String arg1) throws Throwable {
        Wait.forSeconds(20);
        ownsuccesspage.verifyTransferSuccessfultitle(arg1);
    }

    @When("^I enter invalid OTP \"([^\"]*)\" for Own account transfer scenario$")
    public void i_enter_invalid_OTP_for_Own_account_transfer_scenario(String arg1) throws Throwable {
        otp.enterOTP(PropertyReader.testDataOf(arg1));
    }

    @Then("^I should see a pop-up with an error message \"([^\"]*)\" for Own account transfer scenario$")
    public void i_should_see_a_pop_up_with_an_error_message_for_Own_account_transfer_scenario(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otp.verifyOTPAlertMsg(arg1);
    }

    @Given("^I'm on \"([^\"]*)\" \"([^\"]*)\" page with the \"([^\"]*)\",\"([^\"]*)\",amount as PHP \"([^\"]*)\",frequency as \"([^\"]*)\" and remark as \"([^\"]*)\"$")
    public void i_m_on_page_with_the_amount_as_PHP_frequency_as_and_remark_as(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferamount = "PHP " + arg5;
        frequency = arg6;
        remarkmsg = arg7;
        welcome.clickGotITBtn_Biometrics();
        welcome.clickNext();
        welcome.clickNext();
        welcome.clickNext();
        if(Devicename.currentdevicename.equalsIgnoreCase("ABC") || Devicename.currentdevicename.equalsIgnoreCase("ABC")) {
            welcome.clickNext();
        }
        welcome.clickGetStarted();
        welcome.clickLogin();
        login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
        login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
        login.clickLogin();
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        home.clickContinue();
        home.clickNotNowtoSubscribe();
        if(Devicename.currentdevicename.equalsIgnoreCase("ABC") || Devicename.currentdevicename.equalsIgnoreCase("ABC")) {
            home.clickNotNowToTurnOnNotification();
        }
        home.clickNotNowToTurnOnNotification();
        home.clickGotoDashBoard();
        //home.clickSendRequestTab();
        home.gotoSendRequestTab();
        sendrequest.verifyOWNAccountLink(arg1);
        sendrequest.clickOWNAccountLink();
        ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg3));
        owntopage.chooseTranferToAccount(PropertyReader.testDataOf(arg4));
        owntopage.clickNextBtn();
        owndetailpage.enterTransferAmt(arg5);
        owndetailpage.turnONToggleBtn();
        owndetailpage.clickFrequencyElement();
        owndetailpage.chooseSelectFrequency();
        owndetailpage.enterRemarkMessageText(arg7);
        owndetailpage.clickNextBtn();
        ownreviewpage.verifyReviewandTransfertitle(arg2);

        ownreviewpage.verifyReviewPagedetails(PropertyReader.testDataOf("OWN_Source_Name"),
                PropertyReader.testDataOf("OWN_Recipient_Name"), PropertyReader.testDataOf(arg3),
                PropertyReader.testDataOf(arg4), transferamount, "Today", frequency, repeat, remarkmsg);
    }

    @Then("^I should see \"([^\"]*)\" screen with my transaction details for Own account transfer scenario$")
    public void i_should_see_screen_with_my_transaction_details_for_Own_account_transfer_scenario(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ownsuccesspage.verifyTransferSuccessfultitle(arg1);

        ownsuccesspage.verifyTransferSuccessfulfieldlabels
                ("Reference Number", "Transaction Date", "From Account", "To Account", "Amount", "Date");

        ownsuccesspage.verifyTransferSuccessfulPageBasicDetails(PropertyReader.testDataOf("OWN_Source_Name"),
                PropertyReader.testDataOf("OWN_Recipient_Name"), PropertyReader.testDataOf("OWN_Source_Account"),
                PropertyReader.testDataOf("OWN_Recipient_Account"), transferamount, transactiondate, frequency, repeat, remarkmsg);

        ownsuccesspage.verifyTransferSuccessfulpagebuttons();
    }

    @Given("^I'm on \"([^\"]*)\" Fund \"([^\"]*)\" page to send funds from OWN account$")
    public void i_m_on_Fund_page_to_send_funds_from_OWN_account(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.clickNext();
            welcome.clickNext();
            welcome.clickNext();
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                welcome.clickNext();
            }
            welcome.clickGetStarted();
            welcome.clickLogin();
            login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(2);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(2);
            home.clickContinue();
            Wait.forSeconds(2);
//            home.clickNotNowtoSubscribe();
             home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(2);
              home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            home.gotoSendRequestTab();
            Wait.forSeconds(8);
            sendrequest.verifyOWNAccountLink(arg1);
            sendrequest.clickOWNAccountLink();
            Wait.forSeconds(8);
           // ownfrompage.verifyTransferFromPageTitle(arg2);
        }

        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(25);
            home.gotoSendRequestTabIOS();
            Thread.sleep(30000);
            arg1=arg1+"s";
            sendrequest.verifyOWNAccountLink(arg1);
            sendrequest.clickOWNAccountLink();
            ownfrompage.verifyTransferFromPageTitle(arg2);


        }


    }

    @When("^I click on back button in Own account fund Transfer from\\? page$")
    public void i_click_on_back_button_in_Own_account_fund_Transfer_from_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            ownfrompage.clickBackBtn();
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")){
            ownreviewpage.clickClosetrnsferfrom();
        }

    }

    @Then("^I should navigate back to the \"([^\"]*)\" page from Own Account Transfer from\\? page$")
    public void i_should_navigate_back_to_the_page_from_Own_Account_Transfer_from_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.verifySendRequestTitle(arg1);
    }

    @When("^I'm navigate to  \"([^\"]*)\" Fund \"([^\"]*)\" page from Own Account Transfer from\\?$")
    public void i_m_navigate_to_Fund_page_from_Own_Account_Transfer_from(String arg1, String arg2) throws Throwable {


        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            sendrequest.clickOWNAccountLink();
            ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg1));
            owntopage.verifyTransferToPageTitle(arg2);
//            ownfrompage.verifyTransferFromPageTitle(arg2);
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")){

            sendrequest.clickOWNAccountLink();
            ownfrompage.chooseTranferFromAccountios();
            Wait.forSeconds(3);
            ownfrompage.verifyTransferToPageTitle(arg2);
        }

    }


    @Given("^I'm on \"([^\"]*)\" Fund \"([^\"]*)\" page after choosing \"([^\"]*)\"$")
    public void i_m_on_Fund_page_after_choosing(String arg1, String arg2, String arg3) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        welcome.clickGotITBtn_Biometrics();
        welcome.clickNext();
        welcome.clickNext();
        welcome.clickNext();
        if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            welcome.clickNext();
        }
        welcome.clickGetStarted();
        welcome.clickLogin();
        login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
        login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
        login.clickLogin();
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        home.clickContinue();
        home.clickNotNowtoSubscribe();
        home.clickNotNowToTurnOnNotification();
        if(Devicename.currentdevicename.equalsIgnoreCase("ABC") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            home.clickNotNowToTurnOnNotification();
        }
        home.clickGotoDashBoard();
        home.gotoSendRequestTab();
        Thread.sleep(4000);
        sendrequest.verifyOWNAccountLink(arg1);
        sendrequest.clickOWNAccountLink();
        Thread.sleep(4000);
        ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg3));
        Thread.sleep(4000);
        owntopage.verifyTransferToPageTitle(arg2);
    }

    @When("^I click on back button in Own account fund Transfer to\\? page$")
    public void i_click_on_back_button_in_Own_account_fund_Transfer_to_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owntopage.clickBackBtn();
    }

    @Then("^I should navigate back to Own Account \"([^\"]*)\" page from Transfer to\\? page$")
    public void i_should_navigate_back_to_Own_Account_page_from_Transfer_to_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ownfrompage.verifyTransferFromPageTitle(arg1);
    }
	
	/*
	@Then("^I should navigate back to the \"([^\"]*)\" page from Own Account Transfer to page$")
	public void i_should_navigate_back_to_the_page_from_Own_Account_Transfer_to_page(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}
	*/

    @Given("^I'm on \"([^\"]*)\" Fund \"([^\"]*)\" after choosing \"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_m_on_Fund_after_choosing_and(String arg1, String arg2, String arg3, String arg4) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.clickNext();
            welcome.clickNext();
            welcome.clickNext();
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                welcome.clickNext();
            }
            welcome.clickGetStarted();
            welcome.clickLogin();
            login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            home.clickSubscribeToAppOtpNotNow();
            home.clickContinue();
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            home.gotoSendRequestTab();
            Wait.forSeconds(4);
            sendrequest.verifyOWNAccountLink(arg1);
            sendrequest.clickOWNAccountLink();

            ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg3));
            owntopage.chooseTranferToAccount(PropertyReader.testDataOf(arg4));
            Wait.forSeconds(5);
            owndetailpage.verifyTransferDetailsPageTile(arg2);
        }

        else if(DriverManager.OS.equalsIgnoreCase("IOS")){

            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(20);
            home.gotoSendRequestTabIOS();
            Thread.sleep(30000);
            arg1=arg1+"s";
            sendrequest.verifyOWNAccountLink(arg1);
            sendrequest.clickOWNAccountLink();
            ownfrompage.chooseTranferFromAccountios();
            Thread.sleep(3000);
            ownfrompage.chooseTranferToAccountios();


        }

    }

    //	@Given("^I'm on Dashboard page$")
//	public void i_m_on_Dashboard_page() throws Throwable {
//		// Write code here that turns the phrase above into concrete actions
//
//		welcome.clickNext();
//		welcome.clickNext();
//		welcome.clickNext();
//		welcome.clickNext();
//		welcome.clickGetStarted();
//		welcome.clickLogin();
//		login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
//		login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
//		login.clickLogin();
//		otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
//		home.clickContinue();
//		home.clickNotNowtoSubscribe();
//		home.clickNotNowToTurnOnNotification();
//		home.clickNotNowToTurnOnNotification();
//		home.clickGotoDashBoard();
//
//	}
    @When("^I click on back button in Own account fund Transfer details page$")
    public void i_click_on_back_button_in_Own_account_fund_Transfer_details_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.clickBackBtn();
    }

    @Then("^I should navigate back to the \"([^\"]*)\" page from Own Account Transfer details page$")
    public void i_should_navigate_back_to_the_page_from_Own_Account_Transfer_details_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owntopage.verifyTransferToPageTitle(arg1);
    }

    @When("^I click on next button with an amount of PHP \"([^\"]*)\" in the Own Account \"([^\"]*)\" page$")
    public void i_click_on_next_button_with_an_amount_of_PHP_in_the_Own_Account_page(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.verifyTransferDetailsPageTile(arg2);
        owndetailpage.enterTransferAmt(arg1);
        owndetailpage.clickNextBtn();
    }

    @When("^I click on close button in the Own account Review and Transfer page$")
    public void i_click_on_close_button_in_the_Own_account_Review_and_Transfer_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions


        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            // Keywords.refreshPage();
            ownreviewpage.clickClose();
//            if(Devicename.currentdevicename.equalsIgnoreCase("NOKIA7") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
//                Wait.forSeconds(10);
//                Touch.touchLongPress(75, 170, 75, 170);
//            }

        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            ownreviewpage.clickClose();
        }



    }

    @Then("^I should see a \"([^\"]*)\" pop-up window with \"([^\"]*)\" and \"([^\"]*)\" button during own account fund transfer$")
    public void i_should_see_a_pop_up_window_with_and_button_during_own_account_fund_transfer(String arg1, String arg2, String arg3) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ownreviewpage.verifypopup(arg1, arg2, arg3);
    }

    @When("^I click on CANCEL TRANSFER button to cancel own account fund transfer$")
    public void i_click_on_CANCEL_TRANSFER_button_to_cancel_own_account_fund_transfer() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ownreviewpage.clickpopupcanceltransferbtn();
    }

    @Then("^I should navigate back to \"([^\"]*)\" page from Own Account review and transfer page$")
    public void i_should_navigate_back_to_page_from_Own_Account_review_and_transfer_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.verifySendRequestTitle(arg1);
    }

    @Then("^I should see a \"([^\"]*)\" page with facility to enter OTP, \"([^\"]*)\" button and back button during fund tranfer from Own account$")
    public void i_should_see_a_page_with_facility_to_enter_OTP_button_and_back_button_during_fund_tranfer_from_Own_account(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otp.verifyPageTitle(arg1);
        otp.verifyOTPPageElements(arg2);
    }


    @When("^I click on \"([^\"]*)\" button in the Own account fund Transfer Successful page$")
    public void i_click_on_button_in_the_Own_account_fund_Transfer_Successful_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ownsuccesspage.clickGoToDashboard();
    }

    @Then("^I should see \"([^\"]*)\" page of union bank navigated from Own account transfer Successful page$")
    public void i_should_see_page_of_union_bank_navigated_from_Own_account_transfer_Successful_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        home.verifyIfDashboardIsDisplayed(arg1);
    }

    @When("^I click on \"([^\"]*)\" button in the Own account fund Transfer Successful screen$")
    public void i_click_on_button_in_the_Own_account_fund_Transfer_Successful_screen(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ownsuccesspage.clickNewTransaction();
    }

    @Then("^I should see \"([^\"]*)\" page for initiating a new fund transfer$")
    public void i_should_see_page_for_initiating_a_new_fund_transfer(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.verifySendRequestTitle(arg1);
    }


    @When("^I click on trasanction date with an amount PHP \"([^\"]*)\" in the own account transfer details page$")
    public void i_click_on_trasanction_date_with_an_amount_PHP_in_the_own_account_transfer_details_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.enterTransferAmt(arg1);
        owndetailpage.clickTransactionDate();
    }

    @Then("^I should see a date picker for choosing the transaction date with the past date in disable mode$")
    public void i_should_see_a_date_picker_for_choosing_the_transaction_date_with_the_past_date_in_disable_mode() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.verifyDatePicker();
        owndetailpage.choosetransactiondate(date);

    }

    @Then("^I should see a date picker for choosing the transaction date with present and future dates are in enable mode$")
    public void i_should_see_a_date_picker_for_choosing_the_transaction_date_with_present_and_future_dates_are_in_enable_mode() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.verifyDatePicker();
        owndetailpage.choosetransactiondate(date);

    }

    @When("^I choose future date as \"([^\"]*)\"$")
    public void i_choose_future_date_as(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String data[] = arg1.split(" ");
        owndetailpage.choosetransactiondate(date);
    }

    @When("^Click \"([^\"]*)\" button in the datepicker of own account fund transfer details page$")
    public void click_button_in_the_datepicker_of_own_account_fund_transfer_details_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.clickDatePickerOkBtn();
    }

    @Then("^The selected date \"([^\"]*)\" should be displayed in the transaction date field in the own account fund transfer details page$")
    public void the_selected_date_should_be_displayed_in_the_transaction_date_field_in_the_own_account_fund_transfer_details_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String data[] = arg1.split(" ");

        String evalue = data[0] + " " + data[1] + ", " + data[2];
        owndetailpage.verifyTransactionDate(evalue);
    }


    @When("^I click the account \"([^\"]*)\" in dashboard and store the value$")
    public void iClickTheAccountInDashboardAndStoreTheValue(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(10);
        owndetailpage.storetheEndbalance();
    }

    @Then("^I store the Transfer Reference number$")
    public void iStoreTheTransferAmountAndReferenceNumber() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ownsuccesspage.storetheTransferRefNo();
    }

    @And("^I Click the new transaction button$")
    public void iClickTheNewTransactionButton() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ownsuccesspage.clickNewTransaction();
    }

    @Then("^I'm on \"([^\"]*)\" \"([^\"]*)\" page by selecting \"([^\"]*)\",\"([^\"]*)\" and an amount PHP \"([^\"]*)\"$")
    public void iMOnPageBySelectingAndAnAmountPHP(String arg0, String arg1, String arg2, String arg3, String arg4) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        home.gotoSendRequestTab();
        sendrequest.clickOWNAccountLink();
        ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg2));
        owntopage.chooseTranferToAccount(PropertyReader.testDataOf(arg3));
        owntopage.clickOKBtn();
        owndetailpage.enterTransferAmt(arg4);
        owndetailpage.clickNextBtn();
        //ownreviewpage.clickGotitButton();
        //ownreviewpage.verifyReviewandTransfertitle(arg1);

    }

    @Then("^I Click goto dashboard link$")
    public void iClickGotoDashboardLink() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ownsuccesspage.clickGoToDashboard();

    }

    @Then("^I do calculation for the transation \"([^\"]*)\" for \"([^\"]*)\" and \"([^\"]*)\" verify in the transaction history$")
    public void iDoCalculationForTheTransationAndVerifyInTheTransactionHistory(double arg0, String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        owndetailpage.verifyinTxnhistory(arg0, arg2);
    }

    @Given("^I'm on \"([^\"]*)\" \"([^\"]*)\" page with the \"([^\"]*)\",\"([^\"]*)\" dormanttarget and an amount PHP \"([^\"]*)\"$")
    public void iMOnPageWithTheDormantAndAnAmountPHP(String arg0, String arg1, String arg2, String arg3, String arg4) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.clickNext();
            welcome.clickNext();
            welcome.clickNext();
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                welcome.clickNext();
            }
            welcome.clickGetStarted();
            welcome.clickLogin();
            login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Thread.sleep(3000);
            home.clickContinue();
            home.clickNotNowtoSubscribe();
                home.clickNotNowToTurnOnNotification();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            home.clickGotoDashBoard();
            //home.clickSendRequestTab();
            Thread.sleep(3000);
            home.gotoSendRequestTab();
            Thread.sleep(30000);
            sendrequest.verifyOWNAccountLink(arg0);
            Thread.sleep(4000);
            sendrequest.clickOWNAccountLink();
            //actions.Wait.forSeconds(5);
            ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg2));
            Thread.sleep(3000);
            owntopage.chooseTranferToAccount(PropertyReader.testDataOf(arg3));
            Thread.sleep(3000);
            owntopage.clickOKBtn();
            Thread.sleep(3000);
            owndetailpage.enterTransferAmt(arg4);
            Thread.sleep(3000);
            owndetailpage.clickNextBtn();
            //ownreviewpage.clickGotitButton();
            //Thread.sleep(3000);
            //ownreviewpage.verifyReviewandTransfertitle(arg2);
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(15);
            home.gotoSendRequestTabIOS();
            Wait.forSeconds(30);
            arg0=arg0+"s";
            sendrequest.verifyOWNAccountLink(arg0);
            sendrequest.clickOWNAccountLink();
            ownfrompage.chooseTranferFromAccountios();
            Thread.sleep(3000);
            ownfrompage.chooseTranferDormantToAccountios();
            owndetailpage.enterTransferAmt(arg4);
            Thread.sleep(3000);
            owntopage.clickNextBtn();

        }

    }

    @Given("^I'm on \"([^\"]*)\" \"([^\"]*)\" page with the \"([^\"]*)\",\"([^\"]*)\" dormantfrom and an amount PHP \"([^\"]*)\"$")
    public void iMOnPageWithTheDormantfromAndAnAmountPHP(String arg0, String arg1, String arg2, String arg3, String arg4) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.clickNext();
            welcome.clickNext();
            welcome.clickNext();
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                welcome.clickNext();
            }
            welcome.clickGetStarted();
            welcome.clickLogin();
            login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Thread.sleep(3000);
            home.clickContinue();
            home.clickNotNowtoSubscribe();
                home.clickNotNowToTurnOnNotification();
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            //home.clickSendRequestTab();
            Thread.sleep(3000);
            home.gotoSendRequestTab();
            Thread.sleep(30000);
            sendrequest.verifyOWNAccountLink(arg0);
            Thread.sleep(4000);
            sendrequest.clickOWNAccountLink();
            //actions.Wait.forSeconds(5);
            ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg2));
            Thread.sleep(3000);
            owntopage.chooseTranferToAccount(PropertyReader.testDataOf(arg3));
            Thread.sleep(3000);
            owntopage.clickOKBtn();
            Thread.sleep(3000);
            owndetailpage.enterTransferAmt(arg4);
            Thread.sleep(3000);
            owndetailpage.clickNextBtn();
            //ownreviewpage.clickGotitButton();
            //Thread.sleep(3000);
            //ownreviewpage.verifyReviewandTransfertitle(arg2);
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(10);
            home.gotoSendRequestTabIOS();
            Thread.sleep(30000);
            arg0=arg0+"s";
            sendrequest.verifyOWNAccountLink(arg0);
            sendrequest.clickOWNAccountLink();
            ownfrompage.chooseTranferDormantToAccountios();
            Thread.sleep(3000);
            //ownfrompage.chooseTranferFromAccountios();
            ownfrompage.chooseTranferToAccountios();
            owndetailpage.enterTransferAmt(arg4);
            Thread.sleep(3000);
            owntopage.clickNextBtn();

        }
    }

    @And("^I Enter the InvalidOTP in OTP Page$")
    public void iEnterTheInvalidOTPInOTPPage() {

    }
}
