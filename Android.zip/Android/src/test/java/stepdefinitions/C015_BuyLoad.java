package stepdefinitions;


import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import exceptions.ApplicationException;
import pages.BuyloadPage;
import pages.Dashboard_Home_Page;
import pages.LoginPage;

public class C015_BuyLoad {
    private Dashboard_Home_Page dashboard = new Dashboard_Home_Page();
    private LoginPage login = new LoginPage();

    private BuyloadPage Buyload= new BuyloadPage();

    @Then("^I click the from account number for Buyload$")
    public void i_click_the_from_account_number_for_Buyload() throws Throwable {
        Buyload.fromAccount_Buyload();

    }

    @Then("^I click select contact in the buyload page$")
    public void iClickSelectContactInTheBuyloadPage() throws Throwable {
        Buyload.clickselectcontact();
    }

    @And("^I verify the mobile number is exist$")
    public void iVerifyTheMobileNumberIsExist() throws Throwable {
        Buyload.verifyelementisexist();
    }

    @And("^I select the value in buy load screen$")
    public void iSelectTheValueInBuyLoadScreen() throws Throwable {
        Buyload.selectvaluefromthetext();
    }

    @And("^I click the search result$")
    public void iClickTheSearchResult() throws Throwable {
        Buyload.clickSearchresult();
    }

    @And("^I click the select from list$")
    public void iClickTheSelectFromList() throws Throwable {
        Buyload.clickSelectfromlist();
    }

    @And("^I verify transfer successful displayed$")
    public void iVerifyTransferSuccessfulDisplayed() throws Throwable {
        Buyload.verifypurchasesuccessful();
    }

//    @And("^I Verify the buyload details$")
//    public void iVerifyTheBuyloadDetails() throws Throwable {
//           Buyload.verifySuccessfulscreenvalidations();
//    }

    @And("^I enter the name in search field$")
    public void iEnterTheNameInSerachField() throws Throwable {
        Buyload.enterSearchcontact();
    }
    @And("^I enter the LowBalance ContactName in search field$")
    public void iEnterTheLowBalanceContactNameInSearchField() throws Throwable {
        Buyload.enterSearchcontactLowBalance();
    }
//    @And("^I enter the phonenumber in search field$")
//    public void iEnterThePhonenumberInSearchField() throws Throwable {
//        Buyload.enterSearchPhone();
//    }
    @And("^I enter the mobilenumber low balance$")
    public void iEnterTheMobilenumberLowBalance() throws Throwable {
        Buyload.enterLowBalancePhonenumber();
    }
    @And("^I enter the Invalid mobilenumber$")
    public void iEnterTheInvalidMobilenumber() throws Throwable {
        Buyload.enterInvalidPhonenumber();
    }

    @And("^I click purchaseload button$")
    public void iClickPurchaseloadButton() throws Throwable {
        Buyload.clickPurchaseload();
    }

//    @And("^I click the favourite link$")
//    public void iClickTheFavouriteLink() throws Throwable {
//        Buyload.clickLnkfavourites();
//    }
//
    @And("^I click the from account number low balance$")
    public void iClickTheFromAccountNumberLowBalance() throws Throwable {
        Buyload.clickkeyaccountnumber();
    }

    @And("^I verify the error message low balance account$")
    public void iVerifyTheErrorMessageLowBalanceAccount() throws Throwable {
        Buyload.verifyInvalidPHNumber();
    }

    @And("^I click the Submit Button in buyload$")
    public void iClickTheSubmitButtonInBuyload() throws Throwable {
        Buyload.clickSubmit();
    }

    @And("^I verify the new purchase link$")
    public void iVerifyTheNewPurchaseLink() throws Throwable {
        Buyload.clickNewpurchase();
    }

    @And("^I verify the select contact is exist$")
    public void iVerifyTheSelectContactIsExist() throws Throwable {
        Buyload.verifySelectcontactisexist();
    }

    @And("^I Verify the Dashboard page is displayed$")
    public void iVerifyTheDashboardPageIsDisplayed() throws Throwable {
        Buyload.verifyKeyDashboardisexist();
    }

    @And("^I click the cancel purchase button$")
    public void iClickTheCancelPurchaseButton() throws Throwable {
        Buyload.clickBuyloadcancelpurchase();
    }

    @And("^I click the fromaccount edit button$")
    public void iClickTheFromaccountEditButton() throws Throwable {
        Buyload.clickBuyloadfromaccountedit();
    }

    @And("^I click the mobilenumber edit button$")
    public void iClickTheMobilenumberEditButton() throws Throwable {
        Buyload.clickBuyloadmobilenumberedit();
    }

    @And("^I click the amount edit button$")
    public void iClickTheAmountEditButton() throws Throwable {
        Buyload.clickBuyloadamountedit();
    }

    @And("^I Verify the next button is enabled$")
    public void iVerifyTheNextButtonIsEnabled() throws Throwable {
//        Ownaccount.VerifyNextisenabled();
    }
    @And("^I enter the name in my contacts$")
    public void iEnterTheNameInMyContacts() throws Throwable {
        Buyload.entertheSearchname();
    }
    @And("^I enter the name in my contacts1$")
    public void iEnterTheNameInMyContacts1() throws Throwable {
        Buyload.entertheSearchname1();
    }
    @And("^I click the search icon in buyload$")
    public void iClickTheSearchIconInBuyload() throws Throwable {
        Buyload.clickSearchicon();
    }

    @And("^I click the favourite link in buyload$")
    public void iClickTheFavouriteLinkInBuyload() throws Throwable {
//        OtherUBaccount.clickfavourite();
    }

    @And("^I click the addcontact in buyload$")
    public void iClickTheAddcontactInBuyload() throws Throwable {
        Buyload.clickAddcontact();
    }

//    @And("^I enter the name and mobile in add contact details$")
//    public void iEnterTheNameAndMobileInAddContactDetails() throws Throwable {
//        Buyload.enterContactNameandMobile();
//    }
//    @And("^I enter the blank name and mobile number in add contact details$")
//    public void iEnterTheBlankNameAndMobileNumberInAddContactDetails() throws Throwable {
//        Buyload.enterBlankNameandMobile();
//    }
//    @And("^I enter the alreadyname and mobile in add contact details$")
//    public void iEnterTheAlreadynameAndMobileInAddContactDetails() throws Throwable {
//        Buyload.enterAlreadyaddedNameandMobile();
//    }
//    @And("^I enter the name favorites in add contact details$")
//    public void iEnterTheNameFavoritesInAddContactDetails() throws Throwable {
//        Buyload.enterContactNameandMobile_favorites();
//    }
//    @And("^I click the save button in manage contact$")
//    public void iClickTheSaveButtonInManageContact() throws Throwable {
//        Buyload.clickSave();
//    }
//
//    @And("^I click the search result link$")
//    public void iClickTheSearchResultLink() throws Throwable {
//        Buyload.clickSearchfirstresult();
//    }

    @And("^I click the edit button in manage contact$")
    public void iClickTheEditButtonInManageContact() throws Throwable {
        Buyload.clickEdit();
    }
//    @And("^I change the buyload contact name$")
//    public void iChangeTheBuyloadContactName() throws Throwable {
//        Buyload.changeContactNameandMobile();
//    }
//    @And("^I verify the search results in addcontact$")
//    public void iVerifyTheSearchResultsInAddcontact() throws Throwable {
//        Buyload.verifyTheSearchResultsInAddcontact();
//    }
//    @And("^I verify the search results in changeContactName$")
//    public void iVerifyTheSearchResultsInChangeContactName() throws Throwable {
//        Buyload.verifyTheSearchResultsInChangeContactName();
//    }

//    @And("^I verify the search results in favorite$")
//    public void iVerifyTheSearchResultsInFavorite() throws ApplicationException {
//        Buyload.verifyTheSearchResultsInChangeContactName_Favorite();
//    }
//    @And("^I verify the search results in favorites$")
//    public void iVerifyTheSearchResultsInFavorites() throws Throwable {
//        Buyload.verifyTheSearchResultsInFavorites();
//     }
//    @And("^I change the buyload contact name favoritesnew$")
//    public void iChangeTheBuyloadContactNameFavoritesnew() throws ApplicationException {
//        Buyload.changeContactNameandMobile_favorites();
//    }
    @And("^I click the delete button in manage contact$")
    public void iClickTheDeleteButtonInManageContact() throws Throwable {
        Buyload.clickDelete();
    }
//    @And("^I verify No enrolled contacts found$")
//    public void iVerifyNoEnrolledContactsFound() throws Throwable {
//        Buyload.verifySearcresultNoenrolledcontactsfound();
//    }
//
//    @And("^I click the favorite button$")
//    public void iClickTheFavoriteButton() throws Throwable {
//        Buyload.clickfavouritebutton();
//    }
//
//    @And("^I verify the validation error message in add contact$")
//    public void iVerifyTheValidationErrorMessageInAddContact() throws Throwable {
//        Buyload.verifyValidationinaddcontact();
//    }


    @Then("^click to telco provider Globe$")
    public void clickToTelcoProviderGlobe() throws Throwable {
        Buyload.ClickProviderGlobe();
    }

    @And("^Check if the application allows the users to select a denomination$")
    public void checkIfTheApplicationAllowsTheUsersToSelectADenomination() throws Throwable {
        Buyload.SelectDenomination();
    }

    @And("^user click on contact icon$")
    public void userClickOnContactIcon() throws Throwable {
        Buyload.ClickContactIcon();
    }

    @Then("^user click purchase from account details and select the account$")
    public void userClickPurchaseFromAccountDetailsAndSelectTheAccount() throws Throwable {
        Buyload.ClickPurchaseFromAccount();
    }

    @Then("^verify user able to click buyload button$")
    public void verifyUserAbleToClickBuyloadButton() throws Throwable {
        Buyload.ClickBuyLoadBtn();
    }

    @And("^I verify the purchase successful message$")
    public void iVerifyThePurchaseSuccessfulMessage() throws Throwable {
        Buyload.VerifyPurchaseSuccessMessage();
    }

    @Then("^click to telco provider Smart$")
    public void clickToTelcoProviderSmart() throws Throwable {
        Buyload.SelectProviderSmart();
    }

    @Then("^click to telco provider TM$")
    public void clickToTelcoProviderTM() throws Throwable {
        Buyload.SelectProviderTM();

    }

    @Then("^click to telco provider TNT$")
    public void clickToTelcoProviderTNT() throws Throwable {
        Buyload.SelectProviderTNT();
    }
    @Then("^user click edit option in buyload from account$")
    public void userClickEditOptionInBuyloadFromAccount() throws Throwable {
        Buyload.ClickFromAccountEdit();

    }

    @Then("^user click account updation select new account$")
    public void userClickAccountUpdationSelectNewAccount() throws Throwable {
        Buyload.ClickAccountUpdation();
    }

    @When("^I click the BuyLoad link in the send request page$")
    public void iClickTheBuyLoadLinkInTheSendRequestPage() throws Throwable {
        Buyload.clickBuyload();
    }

    @And("^I Click the New Purchase button Link$")
    public void iClickTheNewPurchaseButtonLink() throws Throwable {
        Buyload.clickNewpurchase();
    }

    @And("^User enter the mobile number$")
    public void userEnterTheMobileNumber() throws Throwable {
        Buyload.enterMobilenumber();
    }


    @And("^I Click the New Transaction button Link$")
    public void iClickTheNewTransactionButtonLink() throws Throwable {
        Buyload.clickNewTransaction();
    }

    @And("^user select new denomination and click to update button$")
    public void userSelectNewDenominationAndClickToUpdateButton() throws Throwable {
       Buyload.ClickEditOptionInDenomination();
    }

    @Then("^user click account updation select new account and click update$")
    public void userClickAccountUpdationSelectNewAccountAndClickUpdate() throws Throwable {
        Buyload.ClickAccountUpdation();
    }

    @And("^User enter number not staring with (\\d+)$")
    public void userEnterNumberNotStaringWith(int arg0) throws Throwable {
       Buyload.enterMobileNumberStartsZero();
    }

    @Then("^user verify the inline message Mobile number should start with (\\d+) \\(e\\.g\\. (\\d+)\\)$")
    public void userVerifyTheInlineMessageMobileNumberShouldStartWithEG(int arg0, int arg1) throws Throwable {
        Buyload.verifyMobileStartsErrorMsg();
    }

    @And("^User enter Mobile Number less that (\\d+) digit$")
    public void userEnterMobileNumberLessThatDigit(int arg0) throws Throwable {
        Buyload.EnterMobileNumber();
    }

    @Then("^user verify the inline Mobile Number should be (\\d+) digits long$")
    public void userVerifyTheInlineMobileNumberShouldBeDigitsLong(int arg0) throws Throwable {
        Buyload.verifyMobileLessErrorMsg();
    }

    @And("^User enter the mobile numberThen user click purchase from account details and select the account$")
    public void userEnterTheMobileNumberThenUserClickPurchaseFromAccountDetailsAndSelectTheAccount() throws Throwable {
       Buyload.clickTaptoselectAccount();
    }

    @When("^User Click \"([^\"]*)\" From BuyLoad Page$")
    public void userClickFromBuyLoadPage(String arg0) throws Throwable {
        Buyload.clickManageContacts();
    }

    @And("^I Search the contact Name in \"([^\"]*)\" Screen$")
    public void iSearchTheContactNameInScreen(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Buyload.enterSearchcontactManageContacts();
    }

    @Then("^Verify User to view Edit, Delete Option after clicking dots in \"([^\"]*)\" Screen$")
    public void verifyUserToViewEditDeleteOptionAfterClickingDotsInScreen(String arg0) throws Throwable {
        Buyload.verifyOptions();
    }

    @When("^User able to click Edit Button on \"([^\"]*)\" Screen$")
    public void userAbleToClickEditButtonOnScreen(String arg0) throws Throwable{
        Buyload.clickEdit();
    }

    @Then("^Verify The Default Inline Error Message Presents Once Clicking on Edit Contact option$")
    public void verifyTheDefaultInlineErrorMessagePresentsOnceClickingOnEditContactOption() throws Throwable {
        Buyload.verifyInlineErrormsgEditContactScreen();
    }

    @And("^User able to Enter The FirstName and MobileNumber on TextBoxes and Click Save Button\\.$")
    public void userAbleToEnterTheFirstNameAndMobileNumberOnTextBoxesAndClickSaveButton() throws Throwable {
        Buyload.enterEditContactDetails();
    }

    @When("^User able to Click Delete Button on \"([^\"]*)\" screen$")
    public void userAbleToClickDeleteButtonOnScreen(String arg0) throws Throwable {
      Buyload.clickDelete();
    }

    @Then("^verify the Pop Up Message Displays and having Delete Contact , Keep contact Options$")
    public void verifyThePopUpMessageDisplaysAndHavingDeleteContactKeepContactOptions() throws Throwable {
        Buyload.verifyDeletepopup();
    }

    @When("^User able to click Plus Icon on \"([^\"]*)\" Screen$")
    public void userAbleToClickPlusIconOnScreen(String arg0) throws Throwable {
        Buyload.clickAddButton();
    }

    @And("^User able to input the details of \"([^\"]*)\" and click add contact button$")
    public void userAbleToInputTheDetailsOfAndClickAddContactButton(String arg0) throws Throwable {
        Buyload. EnterDetailsAddContactsScreen();

    }

    @Then("^user click edit option in buyload denomination and select new denomination$")
    public void userClickEditOptionInBuyloadDenominationAndSelectNewDenomination() throws Throwable {
        Buyload.ClickEditOptionInDenomination();
    }

    @And("^Verify application navigates to \"([^\"]*)\" Screen$")
    public void verifyApplicationNavigatesToScreen(String arg0) throws Throwable {
        Buyload.verifyEditContactHeader();

    }
}
