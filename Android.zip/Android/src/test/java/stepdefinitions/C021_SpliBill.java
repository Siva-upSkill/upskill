package stepdefinitions;


import actions.Swipe;
import actions.Wait;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverManager;
import helper.PropertyReader;
import helper.Tools;
import pages.*;
import runners.ConvergentTestRunner;

public class C021_SpliBill {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private SendRequestPage sendrequest = new SendRequestPage();
    private RequestPaymentPage requestPayment = new RequestPaymentPage();
    private RequestTab requestTab = new RequestTab();
    private SelectRecipient add_participant = new SelectRecipient();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();

    @Given("^I'm on Splitbiils page in Convergent mobile application$")
    public void iMOnSplitbillsPageInConvergentMobileApplication() throws Throwable {
        welcome.clickGotITBtn_Biometrics();
        welcome.closeWelcomeMessages();
        login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
        login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
        login.clickLogin();
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        Thread.sleep(35000);
        home.clickContinue();
        home.clickNotNowtoSubscribe();
        home.clickNotNowToTurnOnNotification();
        home.clickGotoDashBoard();
        Wait.forSeconds(4);
        home.gotoSendRequestTab();
        Wait.forSeconds(8);
        sendrequest.gotoRequestTab();
    }

    @When("^I click Split Bills screen$")
    public void iClickSplitBillsScreen() throws Throwable {
        Wait.forSeconds(5);
        sendrequest.clickOtherUBPAccountLink();
        requestPayment.clickSplitBills();
    }

    @Given("^I'm on Splitbills Payment screen in Convergent mobile application$")
    public void iMOnSplitbillsPaymentScreenInConvergentMobileApplication() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            iMOnSplitbillsPageInConvergentMobileApplication();
            Wait.forSeconds(10);
            iClickSplitBillsScreen();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(25);
            home.gotoSendRequestTabIOS();
            home.clickRequestTabIOS();
            home.clickRequestPaymentLinkIOS();
        }
    }

    @And("^I enter payment amount \"([^\"]*)\" in your portion$")
    public void iEnterPaymentAmountInYourPortion(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        requestPayment.enterAmountinportion(arg0);
    }
}

