package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.*;
import runners.ConvergentTestRunner;

public class C030_FAQ {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();

    private FAQPage FAQPage = new FAQPage();


    ConvergentTestRunner Devicename=new ConvergentTestRunner();


    @When("^I click the Send/Receive Money$")
    public void i_click_the_Send_Receive_Money() throws Throwable {
        home.gotoSendRequestTab();
    }

    @And("^I click the FAQ link$")
    public void iClickTheFAQLink() throws Throwable {
        FAQPage.clickFAQ();
    }

    @Then("^Check if application allows user to view the list of FAQ's in the FAQ screen$")
    public void checkIfApplicationAllowsUserToViewTheListOfFAQSInTheFAQScreen() throws Throwable {
        FAQPage.viewFQAListScreen();
    }

    @And("^Check if application allows user to view the search bar$")
    public void checkIfApplicationAllowsUserToViewTheSearchBar() throws Throwable {
        FAQPage.viewSearchBar();
    }

    @And("^Check if application allows user to enter the characters \"([^\"]*)\" in the search bar$")
    public void checkIfApplicationAllowsUserToEnterTheCharactersInTheSearchBar(String arg0) throws Throwable {
        FAQPage.enterCharacterSearchbar(arg0);
    }

    @And("^Check if application allows user to view the list of FAQ related to search bar$")
    public void checkIfApplicationAllowsUserToViewTheListOfFAQRelatedToSearchBar() throws Throwable {
        FAQPage.viewRelatedFAQList();
    }

    @And("^Check if application allows user to view the FAQ description by clicking on particular FAQ$")
    public void checkIfApplicationAllowsUserToViewTheFAQDescriptionByClickingOnParticularFAQ() throws Throwable {
        FAQPage.viewFAQDescription();
    }

}
