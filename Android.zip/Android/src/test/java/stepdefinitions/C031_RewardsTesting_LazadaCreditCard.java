package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.*;
import runners.ConvergentTestRunner;

public class C031_RewardsTesting_LazadaCreditCard {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private LazadaCreditCardPages lazadaCreditCardPages = new LazadaCreditCardPages();

    ConvergentTestRunner Devicename=new ConvergentTestRunner();

    @When("^I selects the Lazada credit card$")
    public void i_selects_the_Lazada_credit_card() throws Throwable {
        lazadaCreditCardPages.selectCard();
    }

    @When("^I check if the application displays Account details of the card$")
    public void i_check_if_the_application_displays_Account_details_of_the_card() throws Throwable {
        lazadaCreditCardPages.verify_AccountDetails();
    }

    @When("^I click the Transfer Credit for the Lazada card$")
    public void i_click_the_Transfer_Credit_for_the_Lazada_card() throws Throwable {
        lazadaCreditCardPages.click_TransferCredit();
    }

    @When("^I click the next button in Before you procced page$")
    public void i_click_the_next_button_in_Before_you_procced_page() throws Throwable {
        lazadaCreditCardPages.click_Next_proceedPage();
    }

    @When("^I verify mobile number as \"([^\"]*)\"$")
    public void i_verify_mobile_number_as(String arg1) throws Throwable {
        lazadaCreditCardPages.verify_mobileNumber(arg1);
    }

    @When("^I enter valid OTP \"([^\"]*)\" for Rewards testing$")
    public void i_enter_valid_OTP_for_Rewards_testing(String arg1) throws Throwable {
        lazadaCreditCardPages.enter_OTP();
    }

    @Then("^I verify \"([^\"]*)\" page$")
    public void i_verify_page(String pagename) throws Throwable {

        if(pagename.equalsIgnoreCase("Verify Details")) {
            lazadaCreditCardPages.verifyPage_VerifyDetails(pagename);
        }
        else if(pagename.equalsIgnoreCase("Transfer Lazada Credits"))
        {
            lazadaCreditCardPages.verifyPage_TransferLazadaCredits(pagename);

        }
        else if(pagename.equalsIgnoreCase("Review and Request"))
        {
            lazadaCreditCardPages.verifyPage_ReviewAndRequest(pagename);
        }

    }


    @Then("^I enter amount as \"([^\"]*)\" for Credits to transfer$")
    public void i_enter_amount_as_for_Credits_to_transfer(String amount) throws Throwable {
            lazadaCreditCardPages.enterAmount(amount);
    }

    @Then("^I verify \"([^\"]*)\" error message$")
    public void i_verify_error_message(String message) throws Throwable {
        if(message.equalsIgnoreCase("Amount is greater than your available credits"))
        {
          lazadaCreditCardPages.verify_AmountGreater_ErrMessgae(message);
        }
        else if(message.equalsIgnoreCase("Minimum amount is PHP 100"))
        {
            lazadaCreditCardPages.verify_MimAmount(message);
        }
       else if(message.equalsIgnoreCase("Please enter an amount in increments of 100"))
        {
            lazadaCreditCardPages.verify_Increment_Message(message);
        }

    }


    @Then("^I click next button in Transfer Lazada credits page$")
    public void i_click_next_button_in_Transfer_Lazada_credits_page() throws Throwable {
        lazadaCreditCardPages.click_Nextbutton_TrasferCreditsPage();
    }

    @Then("^I verify success message as \"([^\"]*)\" along with text$")
    public void i_verify_success_message_as_along_with_text(String arg1) throws Throwable {
        lazadaCreditCardPages.verify_SuccessMessage();
        lazadaCreditCardPages.verify_SuccessText();
    }

    @Then("^I verify the dashboad page$")
    public void i_verify_the_dashboad_page() throws Throwable {
        lazadaCreditCardPages.verify_DashboardPage();
    }

    @Then("^I click BACK TO DASHBOARD button$")
    public void i_click_BACK_TO_DASHBOARD_button() throws Throwable {
      lazadaCreditCardPages.click_BackToDashboard();
    }

    @Then("^I click YES THESE ARE CORRECT button$")
    public void i_click_YES_THESE_ARE_CORRECT_button() throws Throwable {
       lazadaCreditCardPages.click_YESButton();
    }

    @Then("^I click REQUEST TRANSFER FOR button$")
    public void i_click_REQUEST_TRANSFER_FOR_button() throws Throwable {
        lazadaCreditCardPages.click_RequestTransfer_button();
    }


    @Then("^I click back button and come back to Lazada credits page$")
    public void i_click_back_button_and_come_back_to_Lazada_credits_page() throws Throwable {
        lazadaCreditCardPages.click_BackButton();
        lazadaCreditCardPages.click_YESButton();
    }
}
