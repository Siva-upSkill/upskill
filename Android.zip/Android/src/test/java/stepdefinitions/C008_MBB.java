package stepdefinitions;


import actions.Wait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverManager;
import helper.PropertyReader;

import pages.*;
import runners.ConvergentTestRunner;

import static base.Keywords.swipe;


public class C008_MBB {
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private WelcomePage welcome = new WelcomePage();
    private RequestPaymentPage requestPayment = new RequestPaymentPage();
    private ReviewandTransferPage reviewandTransfer = new ReviewandTransferPage();
    private BookVisitInAdvancePage bookvisit = new BookVisitInAdvancePage();
    private TransferFromPage MBBaccountpage = new TransferFromPage();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();
    private PesonetPage pesonet = new PesonetPage();
    private String date = helper.Tools.getDateInFormatforMBB(1)+" selected";
    private String futuredate = helper.Tools.getDateInFormatforMBB(1);
    private String currentdate = helper.Tools.getDateInFormatforMBB(0);
//    private String date = "13 January 2020 selected";
//    private String futuredate = "14 January 2020";
//    private String currentdate = "13 January 2020";

    @Given("^I'm on landing page in Convergent mobile application$")
    public void i_m_on_landing_page_in_Convergent_mobile_application() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            home.clickContinue();
            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            home.clickGotoDashBoard();
            //home.clickNotNowfingerprintNotification();
            //home.clickNotNowfingerprintNotification();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(15);
            //home.verifyDashBoardPageTitleIOS("Dashboard");
        }
    }

    @When("^I choose dashboard tab from the footer section of union bank$")
    public void i_choose_dashboard_tab_from_footer_section_of_union_bank() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            home.verifyIfDashboardIsDisplayed("Dashboard");
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            // home.clickGotoDashBoardIOS();
            //home.verifyDashBoardPageTitleIOS("Dashboard");
        }
    }

    @And("^I should see to branch visit section in dashboard of union bank$")
    public void i_should_navigate_to_mbb_screen_from_mbb_section() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.clickMbbCard();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.clickMbbCardIOS("Book VISIT");
            //bookvisit.clickATMNotNowBtnIOS();
            Wait.forSeconds(4);
        }
    }

    @Then("^I should see \"([^\"]*)\" page on clicking mbb card$")
    public void i_should_see_book_visit_in_advance_page(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifyPageTitle(arg1);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.verifyBookVisitInAdvancePageTitle(arg1);
        }
    }

    @When("^I navigate to Branch Visit section in dashboard to click MBB card$")
    public void i_navigate_to_Branch_Visit_section_in_dashboard_to_click_MBB_card() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.clickMbbCard();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
           // bookvisit.clickMbbCardIOS1("Book VISIT");
            bookvisit.clickMbbCardIOS("Book VISIT");
        }
    }

    @Then("^I should able to book visit for cash deposit for current date by entering valid \"([^\"]*)\" and \"([^\"]*)\" in cash deposit trasaction$")
    public void i_should_able_to_book_visit_for_current_date(String arg1, String arg2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(10);
            bookvisit.chooseVisitDate(date);
            bookvisit.clickOkBtn();
            //bookvisit.selectCashDeposit();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
            Wait.forSeconds(4);
            bookvisit.clickNext();
            Wait.forSeconds(4);
            bookvisit.clickBookVisit(PropertyReader.testDataOf("Book_Visit"));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            //bookvisit.chooseVisitDate(date);
            bookvisit.chooseVisitCalenderDoneIOS();  // Future date chooseVisitCalenderFutureDateIOS
            bookvisit.selectCashDeposit();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
            Wait.forSeconds(2);
            bookvisit.clickNext();
            Wait.forSeconds(4);
            bookvisit.clickBookVisitIOS(PropertyReader.testDataOf("Book_Visit"));
        }
    }

    @Then("^I should able to book visit for cash deposit for date by entering valid \"([^\"]*)\" and \"([^\"]*)\" in cash deposit transaction$")
    public void i_should_able_to_book_visit_for_current_dat(String arg1, String arg2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(3);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(3);
            bookvisit.chooseVisitDate(date);
            bookvisit.clickOkBtn();
            Wait.forSeconds(3);
            bookvisit.selectCashDeposit();
            Wait.forSeconds(3);
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
            Wait.forSeconds(2);
            bookvisit.clickNext();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(5);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(3);
            //bookvisit.chooseVisitDate(date);
            bookvisit.chooseVisitCalenderDoneIOS();
            bookvisit.selectCashDeposit();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
            Wait.forSeconds(2);
            bookvisit.clickNext();
            Wait.forSeconds(4);
        }
    }

    @Then("^I should able to book visit for cash deposit for date by entering valid \"([^\"]*)\" and \"([^\"]*)\" in cash deposit trasaction$")
    public void i_should_able_to_book_visit_for_date(String arg1, String arg2) throws Throwable {
        bookvisit.clickBookVisitBtn();
        Wait.forSeconds(3);
        bookvisit.chooseVisitDate(date);
        bookvisit.clickOkBtn();
        bookvisit.selectCashDeposit();
        bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
        bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
        Wait.forSeconds(3);
        bookvisit.clickNext();
        //bookvisit.clickBookVisit(PropertyReader.testDataOf("Book_Visit"));
        //bookvisit.clickViewVisit();

    }

    @Then("^The System should display confirmation message \"([^\"]*)\"$")
    public void systemShouldDisplayConfirmationText(String arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(30);
            bookvisit.verifyConfirmationMessage(arg0.trim());
            bookvisit.clickViewVisit();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(30);
            bookvisit.verifyConfirmationMessage(arg0.trim());
            bookvisit.clickViewVisit();
        }
    }


    @Then("^The System should display confirmation message \"([^\"]*)\" and click Goto Dashboard$")
    public void systemShouldDisplayConfirmationText_Goto_Dashboard(String arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(10);
            bookvisit.verifyConfirmationMessage(arg0.trim());
            bookvisit.clickGoTODashboard();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(10);
            bookvisit.verifyConfirmationMessage(arg0.trim());
            bookvisit.clickGoTODashboard();
        }
    }

    @Then("^I should see visit is booked for current date in \"([^\"]*)\" page$")
    public void i_should_see_visit_booked_for_current_date(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifyPageTitle(arg1);
            Wait.forSeconds(15);
            bookvisit.cancelTodayVisit(PropertyReader.testDataOf("Cancel_Visit"));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.verifyBookVisitInAdvancePageTitle(arg1);
            Wait.forSeconds(8);
            bookvisit.cancelTodayVisitIfPresentIOS(PropertyReader.testDataOf("Cancel_Visit"));
        }
    }

    @Then("^I navigate to View Visit tab to \"([^\"]*)\" in \"([^\"]*)\" screen$")
    public void i_choose_transaction_from_visit_details_screen_to_cancel(String arg1, String arg2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.VerifyVisitPresent(arg1);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.VerifyVisitPresent(arg1);
        }
    }

    @Then("^I should navigate to \"([^\"]*)\" in \"([^\"]*)\" screen$")
    public void i_should_navigate_to(String arg1, String arg2) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifyCurrentDayVisit(arg1, arg2);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            //bookvisit.verifyCurrentDayVisit(arg1, arg2);
            bookvisit.swipeupandClickMBBCardIOS("BookVisit");
            bookvisit.clickCancelVisitIOS1();
            Wait.forSeconds(4);
            bookvisit.clickYesBtnIOS();
            Wait.forSeconds(7);
        }
    }

    @Then("^I navigate to Dashboard to \"([^\"]*)\" in \"([^\"]*)\" screen$")
    public void i_choose_transaction_from_visit_details_screen_from_dashboard(String arg0, String arg1) throws Throwable {
        bookvisit.cancelTodayVisitIfPresent(arg0);
        //bookvisit.cancelTodayVisit(PropertyReader.testDataOf("Cancel_Visit"));
    }

    @Then("^I should see error message \"([^\"]*)\" below Account number fields$")
    public void i_should_see_error_message_below_Account_number_fields(String arg1) throws Throwable {
        bookvisit.verifyAccountNumberIsRequiredErrorMsg(arg1);
    }

    @Then("^I should able to click back button to cancel the visit from \"([^\"]*)\" screen$")
    public void i_should_able_to_cancel_visit_from_review_screen(String arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifyPageTitle(arg0);
            requestPayment.clickBackBtn();
            bookvisit.clickYesBtn();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.verifyReviewAbdBookVisitPageTitle(arg0);
            //requestPayment.clickBackBtn();
            // bookvisit.clickYesBtn();
        }
    }

    @When("^I leave \"([^\"]*)\" and \"([^\"]*)\" fields blank$")
    public void i_leave_and_fields_blank(String arg1, String arg2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(10);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(10);
            //bookvisit.chooseVisitDate(futuredate);
            bookvisit.clickOkBtn();
            Wait.forSeconds(10);
            bookvisit.selectCashDeposit();
            bookvisit.clickAccountNumber();
            bookvisit.clickAmount("0.00");
            bookvisit.clickAccountNumber();
            bookvisit.enterAmount("0");
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            //bookvisit.chooseVisitDate(date);
            bookvisit.chooseVisitCalenderFutureDateIOS();
            //bookvisit.chooseVisitDate(futuredate); //work around should be done to select future date
            bookvisit.chooseVisitCalenderDoneIOS();
            bookvisit.selectCashDeposit();
            bookvisit.clickAccountNumber();
            bookvisit.clickAmountIOS();
            //bookvisit.clickAmount("0.00");
            bookvisit.clickAccountNumber();
        }
    }

    @Then("^I should see error message \"([^\"]*)\" below Account Number and \"([^\"]*)\" below Amount field$")
    public void i_should_see_error_message_below_Account_Number_and_below_Amount_field(String arg1, String arg2) throws Throwable {


        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifyAccountNumberIsRequiredErrorMsg(arg1);
            bookvisit.verifyAmountIsRequiredErrorMsg(arg2);
            requestPayment.clickBackBtn();
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(10);
            //bookvisit.chooseVisitDate(currentdate);
            bookvisit.clickOkBtn();
            Wait.forSeconds(10);
            bookvisit.selectCashDeposit();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.verifyAccountNumberIsRequiredErrorMsg(arg1);
            bookvisit.verifyAmountIsRequiredErrorMsg(arg2);
            requestPayment.clickCashDepositBackBtnIOS();
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            //bookvisit.chooseVisitDate(currentdate);
            bookvisit.chooseVisitCalenderDoneIOS();
            bookvisit.selectCashDeposit();
        }
    }

    @When("^I enter \"([^\"]*)\" and \"([^\"]*)\" in cash deposit trasanction$")
    public void i_enter_invalid_and_in_cash_deposit_trasanction(String arg1, String arg2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
            bookvisit.clickAccountNumber();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            //bookvisit.enterAmountInvalidIOS("....");
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
            bookvisit.clickAccountNumber();
        }
    }

    @Then("^I should see \"([^\"]*)\" below Account Number field and \"([^\"]*)\" below Amount field$")
    public void i_should_see_below_Account_Number_field_and_below_Amount_field(String arg1, String arg2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifyTargentAmountErrorMsg(arg2);
            bookvisit.verifyInvalidAccountErrorMsg(arg1);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.verifyTargentAmountErrorMsg(arg2);
            bookvisit.verifyInvalidAccountErrorMsg(arg1);
        }
    }

    @Then("^I should able to book visit for cash deposit for current day by entering valid \"([^\"]*)\" and \"([^\"]*)\" in cash deposit trasaction$")
    public void i_should_able_to_book_visit_for_current_day(String arg1, String arg2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(15);
            bookvisit.chooseVisitDate(date);
            Wait.forSeconds(10);
            bookvisit.clickOkBtn();
            bookvisit.selectCashDeposit();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
            Wait.forSeconds(2);
            bookvisit.clickNext();
            Wait.forSeconds(4);
            bookvisit.clickBookVisit(PropertyReader.testDataOf("Book_Visit"));
            Wait.forSeconds(8);
            bookvisit.clickGoTODashboard();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            //bookvisit.chooseVisitDate(date);
            bookvisit.chooseVisitCalenderDoneIOS();
            bookvisit.selectCashDeposit();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
            bookvisit.clickNext();
            Wait.forSeconds(4);
            bookvisit.clickBookVisitIOS(PropertyReader.testDataOf("Book_Visit"));
            Wait.forSeconds(8);
            bookvisit.clickGoTODashboard();
        }
    }

    @Then("^I should see visit is booked for cash deposit in \"([^\"]*)\" branch in \"([^\"]*)\" screen$")
    public void i_should_see_visit_booked_for_cash_deposit_in(String arg0, String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifyPageTitle(arg1);
            bookvisit.verifyBranchName(arg0);
            bookvisit.clickBranchTxtBox();
            bookvisit.clickCancelVisit(PropertyReader.testDataOf("Cancel_Visit"));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.verifyPageTitle(arg1);
            bookvisit.verifyBranchName(arg0);
            bookvisit.clickBranchTxtBox();
            bookvisit.clickCancelVisit(PropertyReader.testDataOf("Cancel_Visit"));
        }
    }

    @Then("^I should see \"([^\"]*)\" popup error message in HangOn$")
    public void i_should_see_hang_on_popup_error_message(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.clickMbbCard();
            Wait.forSeconds(6);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            bookvisit.chooseVisitDate(date);
            bookvisit.clickOkBtn();
            bookvisit.verifyHangOnPageTitle(arg1);
            bookvisit.verifyHangOnErrorMsg();
            bookvisit.clickYesBtn();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.clickMbbCardIOS1("Book VISIT");
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            //bookvisit.chooseVisitDate(date);
            bookvisit.chooseVisitCalenderDoneIOS();
            Wait.forSeconds(4);
            bookvisit.verifyHangOnPageTitle(arg1);
            //bookvisit.verifyHangOnErrorMsg();
            bookvisit.clickBtnYes();
        }
    }

    @Then("^I should see \"([^\"]*)\" popup error message$")
    public void i_should_see_hang_on_popup_error_messages(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.clickMbbCard();
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            bookvisit.chooseVisitDate(date);
            bookvisit.clickOkBtn();
            Wait.forSeconds(6);
            bookvisit.verifyHangOnPageTitle(arg1);
            bookvisit.verifyHangOnErrorMsg();
            bookvisit.clickBtnNo();
            Wait.forSeconds(2);
            bookvisit.goToViewVisitTab();

            Wait.forSeconds(3);
            bookvisit.cancelTodayVisit(PropertyReader.testDataOf("Cancel_Visit"));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            //bookvisit.clickMbbCardIOS1("Book Visit");
            bookvisit.clickMbbCardIOS("Book Visit");
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            //bookvisit.chooseVisitDate(date);
            bookvisit.chooseVisitCalenderDoneIOS();
            Wait.forSeconds(4);
            bookvisit.verifyHangOnPageTitle(arg1);
            //bookvisit.verifyHangOnErrorMsg();
            bookvisit.clickBtnNo();
            Wait.forSeconds(6);
            bookvisit.goToViewVisitTabIOS(); //need to look in to this function
            bookvisit.verifyBookedVisitsIOS();
            Wait.forSeconds(3);
            bookvisit.cancelTodayVisitIfPresentIOS(PropertyReader.testDataOf("Cancel_Visit"));
        }
    }

    @When("^I enter Account Numbers in account field next button should be enabled$")
    public void i_enter_acc_num() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.enterAccountNumber(PropertyReader.testDataOf("Account_Numbers"));
            bookvisit.verifyNextButtonIsEnabled();
            bookvisit.clickNext();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.enterAccountNumber(PropertyReader.testDataOf("Account_Numbers"));
            bookvisit.verifyNextButtonIsEnabled();
            bookvisit.clickNext();
        }
    }

    @Then("^I click Update Visit button in \"([^\"]*)\" screen to schedule a visit for current day$")
    public void i_click_update_visit_button(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifyPageTitle(arg1);
            bookvisit.clickUpdateVisit();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.verifyReviewAbdBookVisitPageTitle(arg1);
            bookvisit.clickUpdateVisitIOS();
        }
    }

    @Then("^I click add transaction to add more \"([^\"]*)\" and account select and \"([^\"]*)\" from side bar for check deposit$")
    public void i_click_add_transaction_to_add_more_check_deposit(String arg0, String arg1) throws Throwable {
        Wait.forSeconds(10);
        bookvisit.clickAddTransaction();
        bookvisit.selectCheckDeposit();
        bookvisit.clickCheckNumber2("Check Number");
        bookvisit.enterCheckNumber1(PropertyReader.testDataOf(arg1).trim());
        bookvisit.selectAccount();
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
            actions.Touch.pressByCoordinates(361, 1080, 5);//for samsung galaxy J7
        }
        else {
            Wait.forSeconds(5);
            bookvisit.selectAccountaccountnumber();
        }
        //MBBaccountpage.chooseTranferFromAccount("0016 9000 1280");
        // pesonet.selectAccountFromList1(PropertyReader.testDataOf("Depositto"));
        bookvisit.clickAmount("0.00");
        bookvisit.enterAmount1(PropertyReader.testDataOf(arg0).trim());
        bookvisit.verifyNextButtonIsEnabled();
        bookvisit.clickNext();

    }

    @Then("^I click add transaction to add more \"([^\"]*)\" and account select from side bar for cash deposit$")
    public void i_click_add_transaction_to_add_more_cash_deposit(String arg0) throws Throwable {
        bookvisit.clickAddTransaction();
        bookvisit.selectCashDeposit();
        bookvisit.selectAccount();
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
            actions.Touch.pressByCoordinates(339, 830, 5);//for samsung galaxy J7
        }
        else {
            Wait.forSeconds(10);
            bookvisit.selectAccountaccountnumber();

        }
        Wait.forSeconds(4);
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
            actions.Touch.pressByCoordinates(357, 1191, 5);//for samsung galaxy J7
        }
        else {
            Wait.forSeconds(10);
            bookvisit.selectAccountaccountnumber();

        }
        Wait.forSeconds(2);
        bookvisit.clickAmount("0.00");
        Wait.forSeconds(2);
        bookvisit.enterAmount2(PropertyReader.testDataOf(arg0).trim());
        Wait.forSeconds(4);
        //bookvisit.verifyNextButtonIsEnabled();
        bookvisit.clickNext();

    }

    @Then("^I click add transaction to add more \"([^\"]*)\" and account select from side bar for cash withdrawal$")
    public void i_click_add_transaction_to_add_more_cash_withdrawal(String arg0) throws Throwable {

        bookvisit.clickAddTransaction();
        bookvisit.selectCashWithdrawal();
        bookvisit.selectAccount();
        //pesonet.selectAccountFromList1(PropertyReader.testDataOf("Depositto"));
        //bookvisit.enterAccountNumber1(PropertyReader.testDataOf("Depositto"));
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
            actions.Touch.pressByCoordinates(361, 1080, 5);//for samsung galaxy J7
        }
        else{
            bookvisit.selectAccountaccountnumber();

        }
       // MBBaccountpage.chooseTranferFromAccount("");
        //pesonet.selectAccountFromList1(PropertyReader.testDataOf("Depositto"));
        //actions.Touch.pressByCoordinates(308, 1216, 5);
        //bookvisit.enterAmount(PropertyReader.testDataOf(arg0).trim());
        Wait.forSeconds(4);
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
            actions.Touch.pressByCoordinates(361, 1080, 5);//for samsung galaxy J7
        }
        else{
            bookvisit.selectAccountaccountnumber();

        }
        bookvisit.clickAmount("0.00");
        bookvisit.enterAmount2(PropertyReader.testDataOf(arg0).trim());
        Wait.forSeconds(3);
        bookvisit.verifyNextButtonIsEnabled();
        Wait.forSeconds(3);
        bookvisit.clickNext();
    }

    @Then("^I click book visit button in \"([^\"]*)\" screen$")
    public void i_click_book_visit_button(String arg0) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //bookvisit.verifyPageTitle(arg0);
            bookvisit.clickBookVisit(PropertyReader.testDataOf("Book_Visit"));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.verifyReviewAbdBookVisitPageTitle(arg0);
            bookvisit.clickBookVisitIOS(PropertyReader.testDataOf("Book_Visit"));
        }
    }

    @Then("^I should able to book visit for cash deposit for date by entering valid \"([^\"]*)\" and \"([^\"]*)\" for cash deposit trasaction$")
    public void i_should_able_to_book_visit_for_dates(String arg1, String arg2) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            bookvisit.chooseVisitDate(futuredate);
            bookvisit.clickOkBtn();
            Wait.forSeconds(6);
            bookvisit.selectCashDeposit();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            //bookvisit.chooseVisitDate(date);
            bookvisit.chooseVisitCalenderFutureDateIOS();  // Future date chooseVisitCalenderFutureDateIOS
            bookvisit.chooseVisitCalenderDoneIOS();
            bookvisit.selectCashDeposit();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
        }
    }

    @Then("^I should able to book visit for cash withdrawal for date by entering valid \"([^\"]*)\" and \"([^\"]*)\" for cash withdrawal trasaction$")
    public void i_should_able_to_book_visit_for_cash_withdrawal_dates(String arg1, String arg2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(30);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(35);
            //bookvisit.chooseVisitDate(futuredate);
            bookvisit.clickOkBtn();
            Wait.forSeconds(6);
            bookvisit.selectCashWithdrawal();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            //bookvisit.chooseVisitDate(date);
            bookvisit.chooseVisitCalenderFutureDateIOS();  // Future date chooseVisitCalenderFutureDateIOS
            bookvisit.chooseVisitCalenderDoneIOS();
            bookvisit.selectCashDeposit();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
        }
    }

    @Then("^I should able to book visit for Check deposit for date by entering valid \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" for check deposit trasaction$")
    public void i_should_able_to_book_visit_for_check_deposit_dates(String arg0, String arg1, String arg2) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(15);
           // bookvisit.chooseVisitDate(futuredate);
            bookvisit.clickOkBtn();
            Wait.forSeconds(8);
            bookvisit.selectCheckDeposit();
            bookvisit.enterCheckNumber(PropertyReader.testDataOf(arg2).trim());
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg0).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg1).trim());
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            //bookvisit.chooseVisitDate(date);
            bookvisit.chooseVisitCalenderFutureDateIOS();  // Future date chooseVisitCalenderFutureDateIOS
            bookvisit.chooseVisitCalenderDoneIOS();
            bookvisit.selectCheckDeposit();
            bookvisit.enterCheckNumber(PropertyReader.testDataOf(arg0).trim());
            bookvisit.enterAccountNumberCheckDepositIOS(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmountCheckDepositIOS(PropertyReader.testDataOf(arg2).trim());
        }
    }

    @Given("^I'm on landing page in Convergent mobile applications$")
    public void i_m_on_landing_page_in_Convergent_mobile_applications() throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Account5_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account5_OTP"));
            home.clickContinue();
            home.clickNotNowtoSubscribe();
                home.clickNotNowToTurnOnNotification();
            home.clickGotoDashBoard();
            home.verifyIfDashboardIsDisplayed("Dashboard");
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(10);
            //home.verifyDashBoardPageTitleIOS("Dashboard");
        }
    }

    @And("^I navigate to View Visit tab in \"([^\"]*)\" screen$")
    public void i_navigate_to_view_visit_tab(String arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifyPageTitle(arg0);
            bookvisit.goToViewVisitTab();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.verifyBookVisitInAdvancePageTitle(arg0);
            bookvisit.goToViewVisitTabIOS();
        }
    }

    @Then("^I should see No visit found below Today and No upcoming visits found below Upcoming and No visit found below History$")
    public void i_should_see_no_visits_for_today_upcoming_history() throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifyNoTodayVisit();
            bookvisit.verifyNoUpcomingVisit();
            bookvisit.verifyNoHistoryVisit();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.verifyNoTodayVisit();
            bookvisit.verifyNoUpcomingVisit();
            //bookvisit.verifyNoHistoryVisit();
        }

    }

    @Then("^I click Edit link present in \"([^\"]*)\" screen$")
    public void i_click_edit_link_present_in(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifyPageTitle(arg1);
            Wait.forSeconds(5);
            reviewandTransfer.clickEditLink();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.verifyReviewAbdBookVisitPageTitle(arg1);
            reviewandTransfer.clickEditLink();
        }
    }

    @Then("^I click book visit button \"([^\"]*)\" Screen$")
    public void i_click_book_visit_buttons(String arg0) throws Throwable {
        Wait.forSeconds(15);
        bookvisit.verifyPageTitle(arg0);
        bookvisit.clickBookVisitAddTransaction(PropertyReader.testDataOf("Book_Visit"));
    }

    @And("^I choose \"([^\"]*)\" From the list displayed$")
    public void i_choose_branch(String arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(5);
            bookvisit.clickBranchTxtBox();
            Wait.forSeconds(4);
            bookvisit.searchBranch(PropertyReader.testDataOf(arg0).trim());
            bookvisit.selectBranch();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(5);
            bookvisit.clickBranchTxtBoxCashDepositIOS();
            Wait.forSeconds(4);
            bookvisit.clicksearcselectLocationbtnIOS();
            bookvisit.searchBranchcashdepositIOS(PropertyReader.testDataOf(arg0).trim());
            bookvisit.selectBranchCashDepositIOS();
        }
    }

    @When("^I choose date as Another_date$")
    public void i_choose_date_as() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.selectDate();
            Wait.forSeconds(6);
            //bookvisit.chooseVisitDate(futuredate);
            bookvisit.clickOkBtn();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.selectCalenderCashDepositIOS();
            Wait.forSeconds(6);
            //bookvisit.chooseVisitDate(PropertyReader.testDataOf(arg0).trim());
            //bookvisit.clickOkBtn();
            bookvisit.chooseVisitCalenderFutureDateIOS();
            bookvisit.chooseVisitCalenderDoneIOS();
        }
    }

    @And("^I enter \"([^\"]*)\" in Account number$")
    public void i_enter_aacount_number(String arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.enterAccountNumber(arg0);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg0).trim());
        }
    }

    @And("^I change the transfer \"([^\"]*)\" in Amount$")
    public void i_change_transfer_amount(String arg0) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.enterAmount(PropertyReader.testDataOf(arg0).trim());
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.enterAmount(PropertyReader.testDataOf(arg0).trim());
        }
    }

    @Then("^On successful transfer entries next button should be enabled in Transaction screen$")
    public void on_successful_transfer_entries_Next_button_should_be_enabled() throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifyNextButtonIsEnabled();
            bookvisit.clickNext();
            bookvisit.clickBookVisit(PropertyReader.testDataOf("Book_Visit"));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.verifyNextButtonIsEnabled();
            bookvisit.clickNext();
            //bookvisit.verifyDoneButtonIsEnabledIOS();
            //bookvisit.clickDonebtnCashDepositIOS();
            bookvisit.clickBookVisitIOS(PropertyReader.testDataOf("Book_Visit"));
        }
    }

    @Then("^I should see visit is booked for date in \"([^\"]*)\" page$")
    public void i_should_see_visit_booked_for_date(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifyPageTitle(arg1);
            bookvisit.cancelTodayVisits(PropertyReader.testDataOf("Cancel_Visit"));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.verifyBookVisitInAdvancePageTitle(arg1);
            bookvisit.cancelTodayVisitIfPresent(PropertyReader.testDataOf("Cancel_Visit"));
        }
    }

    @When("^I click Check Deposit to navigate to transaction screen$")
    public void i_click_Check_Deposit_to_navigate_to_transaction_screen() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            bookvisit.chooseVisitDate(date);
            bookvisit.clickOkBtn();
            Wait.forSeconds(8);
            bookvisit.selectCheckDeposit();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            //bookvisit.chooseVisitDate(date);
            bookvisit.chooseVisitCalenderDoneIOS();
            bookvisit.selectCheckDeposit();
        }
    }

    @When("^I try to enter \"([^\"]*)\" in Check Number field valid \"([^\"]*)\" and \"([^\"]*)\" in transaction screen$")
    public void i_try_to_enter_in_Check_Number_field(String arg0, String arg1, String arg2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.enterCheckNumber(PropertyReader.testDataOf(arg0).trim());
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.enterCheckNumber(PropertyReader.testDataOf(arg0).trim());
            bookvisit.enterAccountNumberCheckDepositIOS(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmountCheckDepositIOS(PropertyReader.testDataOf(arg2).trim());
        }
    }

    @Then("^I should get error message \"([^\"]*)\"$")
    public void i_should_get_error_message_and_next_button_should_be_disabled(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.clickCheckNumber1();
            bookvisit.verifyCheckNumberErrorMsg(arg1.trim());
            //bookvisit.verifyNextButtonIsDisabled();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.clickCheckNumber1();
            bookvisit.verifyCheckNumberErrorMsg(arg1.trim());
        }
    }

    @Then("^I select branch as \"([^\"]*)\" in search branch screen$")
    public void i_select_branch_as_ark(String arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.clickBranchSearchBtn();
            Wait.forSeconds(1);
            bookvisit.searchBranch(arg0);
            Wait.forSeconds(4);
            bookvisit.selectBranch();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(5);
            bookvisit.clickSearchbtnInSearchBranchIOS();
            Wait.forSeconds(4);
            bookvisit.clickSearchbtnInSearchBranchIOS();
            Wait.forSeconds(4);
            bookvisit.searchTextInSearchBranchIOS("Dasmar");
            Wait.forSeconds(2);
            bookvisit.selectBranchInSearchBranchIOS();
        }
    }

    @Then("^I should see current day Visit for \"([^\"]*)\" branch in \"([^\"]*)\" screen$")
    public void i_should_see_current_day_ark_visit_details(String arg0, String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            home.verifyIfDashboardIsDisplayed(arg1);
            bookvisit.clickMbbCard();
            Wait.forSeconds(15);
            //bookvisit.clickBookVisitBtn();
            Wait.forSeconds(10);
            bookvisit.clickBranchSearchBtn();
            Wait.forSeconds(1);
            bookvisit.searchBranch(arg0);
            bookvisit.selectBranch();
            Wait.forSeconds(15);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            bookvisit.chooseVisitDate(date);
            bookvisit.clickOkBtn();
            bookvisit.selectCashDeposit();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf("Account_Numbers"));
            bookvisit.enterAmount(PropertyReader.testDataOf("Amount"));
            Wait.forSeconds(4);
            bookvisit.clickNext();
            bookvisit.clickBookVisit(PropertyReader.testDataOf("Book_Visit"));
            bookvisit.clickGoTODashboard();

        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.clickMbbCardIOS1("Book VISIT");
            bookvisit.clickSearchbtnInSearchBranchIOS();
            Wait.forSeconds(4);
            bookvisit.clickSearchbtnInSearchBranchIOS();
            Wait.forSeconds(4);
            bookvisit.searchTextInSearchBranchIOS("Dasmar");
            Wait.forSeconds(2);
            bookvisit.selectBranchInSearchBranchIOS();
            //bookvisit.clicksearcselectLocationbtnIOS();
            //bookvisit.searchBranchcashdepositIOS(PropertyReader.testDataOf(arg0).trim());
            //bookvisit.selectBranchCashDepositIOS();
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            //bookvisit.chooseVisitDate(date);
            bookvisit.chooseVisitCalenderDoneIOS();
            bookvisit.selectCashDeposit();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf("Account_Numbers"));
            bookvisit.enterAmount(PropertyReader.testDataOf("Amount"));
            Wait.forSeconds(2);
            bookvisit.clickNext();
            Wait.forSeconds(4);
            bookvisit.clickBookVisitIOS(PropertyReader.testDataOf("Book_Visit"));
            Wait.forSeconds(8);
            bookvisit.clickGoTODashboard();
        }
    }

    @When("^I click current day visit in \"([^\"]*)\" screen$")
    public void i_click_current_day_visit_in(String arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            home.verifyIfDashboardIsDisplayed(arg0);
            bookvisit.cancelTodayVisit(PropertyReader.testDataOf("Cancel_Visit"));

        }
	           else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
               // home.verifyIfDashboardIsDisplayedIOS(arg0);
            }
        }


    @Then("^I should navigate to View Visit tab to \"([^\"]*)\" in \"([^\"]*)\" screen$")
    public void i_should_navigate_to_view_visit_tab(String arg1, String arg2) throws Throwable {
        bookvisit.verifyCurrentDayVisit(arg1, arg2);
    }

    @And("^I navigate to Cash Deposit link$")
    public void i_navigate_to_Cash_Deposit_link() throws Throwable {
        Wait.forSeconds(8);
        bookvisit.clickBookVisitBtn();
        Wait.forSeconds(8);
        bookvisit.chooseVisitDate(date);
        bookvisit.clickOkBtn();
        Wait.forSeconds(4);
        bookvisit.selectCashDeposit();
    }

    @Given("^I enter \"([^\"]*)\"$")
    public void i_enter(String arg1) throws Throwable {
        bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
        bookvisit.clickAmount1();
    }

    @Then("^I should see error message \"([^\"]*)\" below Account number field$")
    public void i_should_see_error_message_below_Account_number_field(String arg1) throws Throwable {
        bookvisit.verifyAccountErrorMsg(arg1);
    }

    @When("^I leave Account number field blank$")
    public void i_leave_Account_number_field_blank() throws Throwable {
        bookvisit.clickAccountNumber();
        bookvisit.clickAmount1();
    }

    @Then("^I navigate to Check Deposit link$")
    public void i_navigate_to_Check_Deposit_link() throws Throwable {
        bookvisit.selectCheckDeposit();
    }


    @Then("^I navigate to Cash Withdrawal link$")
    public void i_navigate_to_Cash_Withdrawal_link() throws Throwable {
        bookvisit.selectCashWithdrawal();
    }

    @And("^I navigate back to selection transaction page$")
    public void i_click_back_button() throws Throwable {
        requestPayment.clickBackBtn();
        Wait.forSeconds(6);
        bookvisit.clickBookVisitBtn();
        Wait.forSeconds(8);
        bookvisit.chooseVisitDate(date);
        bookvisit.clickOkBtn();

    }

    @Given("^I navigate to search branch$")
    public void i_navigate_to_search_branch() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.clickBranchSearchBtn();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.clickSearchbtnInSearchBranchIOS();
            Wait.forSeconds(4);
            bookvisit.clickSearchbtnInSearchBranchIOS();
            Wait.forSeconds(4);
        }
    }

    @When("^I add \"([^\"]*)\" branch to favourites$")
    public void i_add_branch_to_favourites(String arg1) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.searchBranchAndfavourite(arg1);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.searchTextInSearchBranchIOS("Dasmar");
            Wait.forSeconds(2);
            bookvisit.selectBranchFavouritesIOS();
            //bookvisit.selectBranchInSearchBranchIOS();
            bookvisit.clickBackBtnInSearchBranchIOS();
        }
    }

    @Then("^I should see \"([^\"]*)\" branch appears first in search branch$")
    public void i_should_see_branch_appears_first_in_search_branch(String arg1) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifytheBranchAddAsFavourite(arg1);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.clickSearchbtnInSearchBranchIOS();
            Wait.forSeconds(4);
            bookvisit.clickSearchbtnInSearchBranchIOS();
            Wait.forSeconds(4);
            //bookvisit.verifytheBranchAddAsFavouriteIOS("Dasmariñas GACU");
            bookvisit.clickBackBtnInSearchBranchIOS();
        }
    }

    @When("^I add \"([^\"]*)\" branch back to unfavourites$")
    public void i_add_branch_to_unfavourites(String arg1) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.searchBranchAndUnfavourite(arg1);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.clickSearchbtnInSearchBranchIOS();
            Wait.forSeconds(4);
            bookvisit.clickSearchbtnInSearchBranchIOS();
            Wait.forSeconds(4);
            bookvisit.searchTextInSearchBranchIOS("Dasmar");
            Wait.forSeconds(2);
            bookvisit.selectBranchUnFavouritesIOS();
            bookvisit.selectBranchInSearchBranchIOS();
            bookvisit.clickBackBtnInSearchBranchIOS();
        }
    }

    @Then("^I should see \"([^\"]*)\" branch appears second in search branch$")
    public void i_should_see_branch_appears_second_in_search_branch(String arg1) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifytheBranchAddAsFavourite(arg1);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.clickSearchbtnInSearchBranchIOS();
            Wait.forSeconds(4);
            bookvisit.clickSearchbtnInSearchBranchIOS();
            Wait.forSeconds(4);
            bookvisit.verifytheBranchAddAsFavouriteIOS("Dasmariñas GACU");
            bookvisit.clickBackBtnInSearchBranchIOS();
        }
    }

    @And("^I should able to book visit for cash deposit check deposit cash withdrawal for date by entering valid \"([^\"]*)\" and \"([^\"]*)\" in transaction screen$")
    public void i_should_able_to_book_visit_for_valid_date(String arg1, String arg2) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(9);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(3);
            bookvisit.choosefuturetransactiondate(futuredate);
            bookvisit.clickOkBtn();
            Wait.forSeconds(6);
            bookvisit.selectCashDeposit();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
            bookvisit.clickAddTransaction();
            Wait.forSeconds(6);
            bookvisit.selectCheckDeposit();
            Wait.forSeconds(3);
            bookvisit.clickCheckNumberMutlipleTransactions("Check Number");
            bookvisit.enterCheckNumber(PropertyReader.testDataOf("Check_Number"));
            Wait.forSeconds(2);
            bookvisit.selectAccountForMultipleTransaction();

            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(620, 999, 5); //J7
            }
            Wait.forSeconds(4);

            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(338, 482, 5); //J7
            }
            // pesonet.selectAccountFromList1(PropertyReader.testDataOf("Depositto"));
            bookvisit.clickAmount("0.00");
            bookvisit.enterAmount1(PropertyReader.testDataOf(arg2).trim());
            bookvisit.clickAddTransaction();
            Wait.forSeconds(6);
            bookvisit.selectCashWithdrawal();
            //swipe.swipeVertical(2, 0.3, 0.8, 5);
            bookvisit.selectAccountForMultipleTransaction();

            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(620, 999, 5); //J7
            }
            Wait.forSeconds(4);

            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(338, 482, 5); //J7
            }
            bookvisit.clickAmount("0.00");
            bookvisit.enterAmount2(PropertyReader.testDataOf(arg2).trim());
            //bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            //bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
            bookvisit.clickNext();
            bookvisit.clickBookVisit(PropertyReader.testDataOf("Book_Visit"));

        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            //bookvisit.chooseVisitDate(date);
            bookvisit.chooseVisitCalenderFutureDateIOS();  // Future date chooseVisitCalenderFutureDateIOS
            bookvisit.chooseVisitCalenderDoneIOS();
            bookvisit.selectCashDeposit();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
            bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
            bookvisit.clickAddTransaction();

            bookvisit.selectCheckDeposit();
            //bookvisit.swipeupMBBCardIOS("Check Number");
            bookvisit.enterCheckNumber("Check Number");
            //bookvisit.swipeupMBBCardIOS("Check Number");
            bookvisit.enterAccountNumberCheckDepositIOS("123456789");
            //bookvisit.swipeupMBBCardIOS("Check Number");
            bookvisit.enterAmountCheckDepositIOS(PropertyReader.testDataOf(arg2).trim());
            Wait.forSeconds(3);
            bookvisit.clickAddTransaction();
            bookvisit.selectCashWithdrawal();
            bookvisit.swipeupMBBCardIOS("Cash Withdrawal");
            bookvisit.enterAccountNumberCashWithdrawalIOS("100590250442");
            bookvisit.enterAmountCashWithdrawalIOS("5");
            bookvisit.clickNext();
            bookvisit.clickBookVisitIOS(PropertyReader.testDataOf("Book_Visit"));
        }
    }

    @And("^I should able to book visit for cash deposit check deposit cash withdrawal for Current date by entering valid \"([^\"]*)\" and \"([^\"]*)\" in transaction screen$")
    public void i_should_able_to_book_visit_for_valid_Current_date(String arg1, String arg2) throws Throwable {
        Wait.forSeconds(9);
        bookvisit.clickBookVisitBtn();
        Wait.forSeconds(3);
        bookvisit.choosefuturetransactiondate(date);
        bookvisit.clickOkBtn();
        Wait.forSeconds(6);
        bookvisit.selectCashDeposit();
        bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
        bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
        bookvisit.clickAddTransaction();
        Wait.forSeconds(6);
        bookvisit.selectCheckDeposit();
        Wait.forSeconds(3);
        bookvisit.clickCheckNumberMutlipleTransactions("Check Number");
        bookvisit.enterCheckNumber(PropertyReader.testDataOf("Check_Number"));
        Wait.forSeconds(2);
        bookvisit.selectAccountForMultipleTransaction();
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
            actions.Touch.pressByCoordinates(620, 999, 5); //J7
        }
        Wait.forSeconds(4);
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
            actions.Touch.pressByCoordinates(338, 482, 5); //J7
        }
        // pesonet.selectAccountFromList1(PropertyReader.testDataOf("Depositto"));
        bookvisit.clickAmount("0.00");
        bookvisit.enterAmount1(PropertyReader.testDataOf(arg2).trim());
        bookvisit.clickAddTransaction();
        Wait.forSeconds(6);
        bookvisit.selectCashWithdrawal();
        //swipe.swipeVertical(2, 0.3, 0.8, 5);
        bookvisit.selectAccountForMultipleTransaction();
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
            actions.Touch.pressByCoordinates(620, 999, 5); //J7
        }
        Wait.forSeconds(4);
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
            actions.Touch.pressByCoordinates(338, 482, 5); //J7
        }
        bookvisit.clickAmount("0.00");
        bookvisit.enterAmount2(PropertyReader.testDataOf(arg2).trim());
        //bookvisit.enterAccountNumber(PropertyReader.testDataOf(arg1).trim());
        //bookvisit.enterAmount(PropertyReader.testDataOf(arg2).trim());
        bookvisit.clickNext();
        bookvisit.clickBookVisit(PropertyReader.testDataOf("Book_Visit"));
    }


    @And("^I navigate to upcoming page via \"([^\"]*)\" page$")
    public void i_navigate_to_upcoming_page_via_book_visit_in_advance() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.clickViewVisit();
            //bookvisit.clickviewmoreButton()
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.clickViewVisit();
        }
    }


    @Then("^I see \"([^\"]*)\" in Upcomming vist page$")
    public void i_see_multiple_transaction_in_upcoming_visit(String arg1) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.verifymultipleTransactionInUpcoming(arg1);
            bookvisit.verifyUpcomingBookedVisits("CANCEL VISIT");
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.searchTextInSearchBranchIOS("Ooooooo");
        }
    }

    @Then("^I see \"([^\"]*)\" in dashboard page$")
    public void i_see_multiple_transaction_in_dashboard(String arg1) throws Throwable {
        bookvisit.verifymultipleTransactionInDashboard(arg1);
        bookvisit.verifyDashboardVisits("CANCEL VISIT");
    }

    @And("^I enter \"([^\"]*)\" in branch search text box$")
    public void i_enter_invalid_branch_name(String arg1) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.searchBranch(PropertyReader.testDataOf("Invalid_Branch_Name"));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.searchTextInSearchBranchIOS("Ooooooo");
        }
    }

    @Then("^I should see error message \"([^\"]*)\"$")
    public void i_should_see_error_msg(String arg1) throws Throwable {
        bookvisit.verifyBranchErrorMsg(arg1);
    }

    @Then("^The System should display correct \"([^\"]*)\"$")
    public void the_system_should_display_correct(String arg1) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(9);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(5);
            bookvisit.chooseVisitDate(futuredate);
            bookvisit.clickOkBtn();
            bookvisit.selectCashWithdrawal();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf("Account_Numbers"));
            bookvisit.enterAmount(PropertyReader.testDataOf("Amount"));
            Wait.forSeconds(4);
            bookvisit.clickNext();
            bookvisit.verifyBranchAddress(PropertyReader.testDataOf("Dasmarinas_GACU_Branch_Address"));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(8);
            bookvisit.clickBookVisitBtn();
            Wait.forSeconds(8);
            //bookvisit.chooseVisitDate(date);
            bookvisit.chooseVisitCalenderDoneIOS();  // Future date chooseVisitCalenderFutureDateIOS
            bookvisit.selectCashDeposit();
            bookvisit.enterAccountNumber(PropertyReader.testDataOf("Account_Numbers"));
            bookvisit.enterAmount(PropertyReader.testDataOf("Amount"));
            Wait.forSeconds(2);
            bookvisit.clickNext();
            Wait.forSeconds(4);
            bookvisit.clickBookVisitIOS(PropertyReader.testDataOf("Book_Visit"));
        }
    }

    @Then("^I check viewmore button is not displayed in upcoming and History section when visits in that section are less than 3$")
    public void i_navigate_to_view_visit_tabs() throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            bookvisit.goToViewVisitTab();
            bookvisit.verifyForViewMoreBtnInUpcoming();
            bookvisit.verifyForViewMoreBtnInHistory();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            bookvisit.goToViewVisitTabIOS();
            bookvisit.verifyNoTodayVisit();
            bookvisit.verifyNoUpcomingVisit();
            //bookvisit.verifyNoHistoryVisit();
        }
    }

    @And("^User able to click View all option on Dashboard screen and click ATM & Branch Locator option$")
    public void userAbleToClickViewAllOptionOnDashboardScreenAndClickATMBranchLocatorOption() throws Throwable {
       bookvisit.clickViewAll();
    }

//    @And("^check if the user able to  verify \"([^\"]*)\" text$")
//    public void checkIfTheUserAbleToVerifyText(String arg0) throws Throwable {
//
//    }

//    @And("^check if the user able to verify the \"([^\"]*)\" and \"([^\"]*)\" options displays on pop up screen$")
//    public void checkIfTheUserAbleToVerifyTheAndOptionsDisplaysOnPopUpScreen(String arg0, String arg1) throws Throwable {
//
//    }

    @And("^check if the user able to verify the \"([^\"]*)\" and \"([^\"]*)\" Tabs on ATM & Branch Locator Screen$")
    public void checkIfTheUserAbleToVerifyTheAndTabsOnATMBranchLocatorScreen(String arg0, String arg1) throws Throwable {
        bookvisit.verifyTabOnATMScreen();
    }

    @And("^check if the application allows user to search Branch on clicking \"([^\"]*)\" Option$")
    public void checkIfTheApplicationAllowsUserToSearchBranchOnClickingOption(String arg0) throws Throwable {
        bookvisit.BranchSearchIcon();
    }

    @And("^user able to search for location of Branch$")
    public void userAbleToSearchForLocationOfBranch() throws Throwable {
        bookvisit.verifyBranchATMScreen();
    }


    @Then("^user able to search for location of ATM$")
    public void userAbleToSearchForLocationOfATM() throws Throwable {
        bookvisit.ATMsSearchIcon();
    }

    @Then("^check if the application displays the Results on \"([^\"]*)\" in ATM &Branch Locator Screen$")
    public void checkIfTheApplicationDisplaysTheResultsOnInATMBranchLocatorScreen(String arg0) throws Throwable {
        bookvisit.verifyATMLocation();

    }

    @Then("^verify if the application displays the Results  on \"([^\"]*)\" in ATM &Branch Locator Screen$")
    public void verifyIfTheApplicationDisplaysTheResultsOnInATMBranchLocatorScreen(String arg0) throws Throwable {
        bookvisit.verifyBranchLocation();

    }
}



