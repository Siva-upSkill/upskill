package stepdefinitions;


import actions.Wait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import helper.PropertyReader;
import pages.HomePage;
import pages.LoginPage;
import pages.OTPPage;
import pages.SendRequestPage;
import pages.*;
import runners.ConvergentTestRunner;
public class C001_Login {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private SendRequestPage sendrequest = new SendRequestPage();
    private PesonetPage pesonet = new PesonetPage();
    private TransferFromPage ownfrompage = new TransferFromPage();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();

    @And("^Login screen should contain \"([^\"]*)\" button$")
    public void loginScreenShouldContainButton(String arg0) throws Throwable {

    }

    @Given("^I'm on welcome page of convergent banking mobile application$")
    public void iMOnWelcomePageOfConvergentBankingMobileApplication() throws Throwable {
        welcome.clickGotITBtn_Biometrics();
        welcome.clickNext();
        welcome.clickNext();
        welcome.clickNext();
//        welcome.clickGetStarted();
    }

    @When("^I click Get started & Login$")
    public void iClickGetStartedLogin() throws Throwable {
        welcome.clickGotITBtn_Biometrics();
        welcome.clickGetStarted();
        Thread.sleep(8000);
        welcome.clickLogin();
    }

    @And("^Login screen should contain Username , Password text box fields$")
    public void loginScreenShouldContainUsernamePasswordTextBoxFields() throws Throwable {
        login.checkIfUsernameTextboxExists();
        login.checkIfPasswordTextboxExists();
    }

    @And("^Login screen should contain back button$")
    public void loginScreenShouldContainBackButton() throws Throwable {
        login.checkIfBackButtonExists();
    }

    @And("^Login screen should contain \"([^\"]*)\" link$")
    public void loginScreenShouldContainLink(String arg0) throws Throwable {
        login.checkIfForgotPasswordLinkExists();
    }

    @And("^Password field should contain Password Visibility toggle button$")
    public void passwordFieldShouldContainPasswordVisibilityToggleButton() throws Throwable {
        login.checkIfPasswordVisibilityToggleExists();
    }

    @Then("^Login screen should be displayed with app version \"([^\"]*)\"$")
    public void loginScreenShouldBeDisplayedWithAppVersion(String arg0) throws Throwable {
        login.verifyPageTitle("Log in");
        login.checkIfAppVersionIsDisplayed(arg0);
    }

    @Given("^I'm on login page of convergent banking mobile application$")
    public void iMOnLoginPageOfConvergentBankingMobileApplication() throws Throwable {
        welcome.clickGotITBtn_Biometrics();
        welcome.clickNext();
        welcome.clickNext();
        welcome.clickNext();
        if (Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30") ) {
            welcome.clickNext();
        }
        welcome.clickGetStarted();
        welcome.clickLogin();

    }

    @Then("^Login button should not be enabled$")
    public void loginButtonShouldNotBeEnabled() throws Throwable {
        login.checkIfLoginIsDisabled();
    }

    @Then("^System should throw a error message \"([^\"]*)\"$")
    public void systemShouldThrowAErrorMessage(String arg0) throws Throwable {
        login.verifyInvalidLoginErrorMessage(arg0);
    }

    @When("^I leave User name BLANK & Enter a Valid Password \"([^\"]*)\"$")
    public void iLeaveUserNameBLANKEnterAValidPassword(String arg0) throws Throwable {
        login.enterPassword(PropertyReader.testDataOf(arg0));
    }

    @When("^I enter invalid Username \"([^\"]*)\" & a Valid Password \"([^\"]*)\"$")
    public void iEnterUserNameAValidPassword(String arg0, String arg1) throws Throwable {
        login.enterUsername(arg0.trim());
        login.enterPassword(PropertyReader.testDataOf(arg1).trim());
        login.enterPassword(PropertyReader.testDataOf(arg1).trim());
        login.clickLogin();
    }

    @When("^I enter valid Username \"([^\"]*)\" & a Invalid Password \"([^\"]*)\"$")
    public void iEnterValidUsernameAInvalidPassword(String arg0, String arg1) throws Throwable {
        login.enterUsername(PropertyReader.testDataOf(arg0).trim());
        login.enterPassword(arg1.trim());
        login.clickLogin();
    }

    @When("^I enter a valid username \"([^\"]*)\" & leave the password BLANK$")
    public void iEnterAValidUsernameLeaveThePasswordBLANK(String arg0) throws Throwable {
       login.enterUsername(PropertyReader.testDataOf(arg0).trim());
    }

    @When("^I enter Valid Username \"([^\"]*)\" & Valid Password \"([^\"]*)\"$")
    public void iEnterValidUsernameValidPassword(String arg0, String arg1) throws Throwable {
        login.enterUsername(PropertyReader.testDataOf(arg0).trim());
        login.enterPassword(PropertyReader.testDataOf(arg1).trim());
        login.clickLogin();
        Wait.forSeconds(5);
    }

    @Then("^OTP screen should be displayed asking OTP$")
    public void otpScreenShouldBeDisplayedAskingOTP() throws Throwable {
        Wait.forSeconds(5);
        //otp.verifyPageTitle("One-Time Password");
    }

    @Then("^I should see my account home page$")

    public void iShouldSeeMyAccountHomePage() throws Throwable {
        home.verifyIfDashboardIsDisplayed("Dashboard");
    }

    @When("^I enter Valid OTP \"([^\"]*)\"$")
    public void iEnterValidOTP(String arg0) throws Throwable {
//        Wait.forSeconds(2);
        otp.enterOTP(PropertyReader.testDataOf(arg0).trim());
//        Wait.forSeconds(2);
        home.clickSubscribeToAppOtpNotNow();
//        Wait.forSeconds(2);
        home.clickContinue();
//        Wait.forSeconds(2);
//        home.clickNotNowtoSubscribe();
        home.clickNotNowToTurnOnNotification();
//        Wait.forSeconds(5);
        home.clickGotoDashBoard();
//        home.clickNotNowfingerprintNotification();
//        home.clickNotNowfingerprintNotification();
    }

    @When("^I enter valid Username \"([^\"]*)\" & a Password \"([^\"]*)\" in lower case$")
    public void iEnterValidUsernameAPasswordInLowerCase(String arg0, String arg1) throws Throwable {
        login.enterUsername(PropertyReader.testDataOf(arg0).trim());
        login.enterPassword(PropertyReader.testDataOf(arg1).trim().toLowerCase());
        login.clickLogin();
    }

    @When("^I enter valid Username \"([^\"]*)\" & a Password \"([^\"]*)\" in upper case$")
    public void iEnterValidUsernameAPasswordInUpperCase(String arg0, String arg1) throws Throwable {
        login.enterUsername(PropertyReader.testDataOf(arg0).trim());
        login.enterPassword(PropertyReader.testDataOf(arg1).trim().toUpperCase());
        login.clickLogin();
    }

    @When("^I enter valid Username \"([^\"]*)\" in upper case & a Password \"([^\"]*)\"$")
    public void iEnterValidUsernameInUpperCaseAPassword(String arg0, String arg1) throws Throwable {
        login.enterUsername(PropertyReader.testDataOf(arg0).trim().toUpperCase());
        login.enterPassword(PropertyReader.testDataOf(arg1).trim());
        login.clickLogin();
    }

    @When("^I enter valid Username \"([^\"]*)\" in lower case & a Password \"([^\"]*)\"$")
    public void iEnterValidUsernameInLowerCaseAPassword(String arg0, String arg1) throws Throwable {
        login.enterUsername(PropertyReader.testDataOf(arg0).trim().toLowerCase());
        login.enterPassword(PropertyReader.testDataOf(arg1).trim());
        login.clickLogin();
    }

    @When("^I close the error message$")
    public void iCloseTheErrorMessage() throws Throwable {
        login.closeErrorMessage();
    }

    @When("^I enter Valid Username \"([^\"]*)\" & invalid password for (\\d+) times$")
    public void iEnterValidUsernameInvalidPasswordForTimes(String arg0, int arg1) throws Throwable {
        login.enterUsername(PropertyReader.testDataOf(arg0).trim());
        login.enterPassword("Invalid_Password");
        login.clickLogin();
        login.verifyInvalidLoginErrorMessage("Please enter a valid user id or password");
        login.closeErrorMessage();
        login.enterPassword("Invalid_Password");
        login.clickLogin();
        login.verifyInvalidLoginErrorMessage("Please enter a valid user id or password");
        login.closeErrorMessage();
        login.enterPassword("Invalid_Password");
        login.clickLogin();
    }

    @When("^I close the error message & enter Valid Username \"([^\"]*)\" & Valid Password \"([^\"]*)\"$")
    public void iCloseTheErrorMessageEnterValidUsernameValidPassword(String arg0, String arg1) throws Throwable {
        login.closeErrorMessage();
        login.enterUsername(PropertyReader.testDataOf(arg0).trim());
        login.enterPassword(PropertyReader.testDataOf(arg1).trim());
        login.clickLogin();
    }

    @Then("^System should throw a ACCOUNT IS BLOCKED error message \"([^\"]*)\"$")
    public void system_should_throw_a_ACCOUNT_IS_BLOCKED_error_message(String arg1) throws Throwable {
        login.verifyAccountBlockedErrorMessage(arg1);
    }

    @When("^I launch the application$")
    public void iLaunchTheApplication() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        login.launchnewapplication();

    }

    @Then("^I exit from the applicaton$")
    public void iExitFromTheApplicaton() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        login.closeloggedapplication();
    }

    @Then("^I click the the fundtransfer and verify \"([^\"]*)\" is not displaying in fund transfer to$")
    public void iClickTheTheFundtransferAndVerifyUnionBankOfThePhilipinesIsNotDisplayingInFundTransferTo(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        home.gotoSendRequestTab();
        sendrequest.clickOtherBanks();
        pesonet.selectPesonet();
        ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf("Another_Source_Account"));
        pesonet.clickBankInstapay();
        Wait.forSeconds(5);
        login.veriftheBanknameisnotExist(arg0 , "no");


    }
}
