package stepdefinitions;

import actions.Swipe;
import actions.Touch;
import actions.Wait;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import helper.*;
import pages.*;
import driver.DriverManager;
import constants.Device;
import runners.ConvergentTestRunner;
import base.Keywords;



public class C013_ManageTransfers {


    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private SendRequestPage sendrequest = new SendRequestPage();
    private RequestPaymentPage requestPayment = new RequestPaymentPage();
    private RequestTab requestTab = new RequestTab();
    private SelectRecipient add_participant = new SelectRecipient();
    private TransferFromPage ownfrompage = new TransferFromPage();
    public String Refnumber;
    public static String participantname;
    public static String participantnumber;
    public static String Requestpaymentmessage;
    public static String Requestpaymentamount;
    private TransferSuccessfulPage ownsuccesspage = new TransferSuccessfulPage();
    private ManageReceipentPage mangerecepent = new ManageReceipentPage();
    //private ManageTransfers mangetransfer = new C013_ManageTransfers();
    private ManageTransfers mangetransfer = new ManageTransfers();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();


    @Then("^I Click Request Payment \"([^\"]*)\"  details and submit$")
    public void iClickRequestPaymentDetailsAndSubmit(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        requestTab.clickRequestPayment();
        requestPayment.clickAmount();
        Wait.forSeconds(5);
        requestPayment.enterAmount("50");
        requestPayment.clickRequestTheAmountOfSaveBtn();
        //Touch.touchLongPress(0,250,0,1000);
        Swipe.swipe.swipeVertical(2,0.8,0.2,5);
        Swipe.swipe.swipeVertical(2,0.2,0.8,5);
        requestPayment.clickRequestFrom();
        requestPayment.enteraddtonewcontactName("jaya");
        requestPayment.clickCheckBox();
        requestPayment.clickAddButton();
        Wait.forSeconds(5);
        requestPayment.clickMessage();
        requestPayment.enterMessage("test");
        requestPayment.clickRequestTheAmountOfSaveBtn();
        //Swipe.swipe.swipeVertical(2,0.8,0.2,5);
        //Swipe.swipe.swipeVertical(2,0.2,0.8,5);
        requestPayment.clickDepositTo();
        ownfrompage.chooseTranferFromAccount(PropertyReader.testDataOf("Depositto"));
        //requestPayment.
        requestPayment.clickNext();
        requestPayment.verifyPageTitle("Review and Request");
        requestPayment.verifyReviewAndRequestAmount1("PHP 50.00");
        requestPayment.verifyPageTitle("Review and Request");
    }


    @And("^I save the reference number in the Transfer Successful screen$")
    public void iSaveTheReferenceNumberInTheTransferSuccessfulScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(10);
        ownsuccesspage.storetheTransferRefNo();
    }

    @Then("^I verify the value in the request and transfer page$")
    public void iVerifyTheValueInTheRequestAndTransferPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        requestPayment.verifyReviewAndRequestAmount1("10.00");
    }

    @Then("^I click the manage transfer link in send/request page$")
    public void iClickTheManageTransferLinkInSendRequestPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.clickmanagetransfers();
    }

    @And("^I verify the \"([^\"]*)\" and \"([^\"]*)\" transfer details in the manage transfer screen$")
    public void iVerifyTheTransferDetailsInTheManageTransferScreen(String arg0,String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
         mangetransfer.verifyManagetransfer(arg0,arg1);
    }

    @And("^I enter the reference number into manage transfer search filed$")
    public void iEnterTheReferenceNumberIntoManageTransferSearchFiled() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //Wait.forSeconds(5);
        mangerecepent.clickSearchicon();
        mangerecepent.enterinSearchtextfield(TransferDetailsPage.ReferenceNo);

    }




    @And("^I enter the participantname into manage transfer search field$")
    public void iEnterTheparticipanrnameIntoManageTransferSearchFiled() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(5);
        mangerecepent.clickSearchicon();
        mangerecepent.enterinSearchtextfield(participantname);

    }
    @And("^I enter the message into manage transfer search field$")
    public void iEnterThemessageIntoManageTransferSearchFiled() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(5);
        mangerecepent.clickSearchicon();
        mangerecepent.enterinSearchtextfield(Requestpaymentmessage);

    }
    @And("^I Click the Requests tab in the manage transfer screen$")
    public void iClickTheRequestsTabInTheManageTransferScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(20);
        mangetransfer.clickmanagetransferrequests();
        Wait.forSeconds(30);
    }

    @And("^I click back in request payment page$")
    public void iClickBackInRequestPaymentPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(8);
        requestPayment.clickBackBtn();
    }

    @And("^I click the enter in keyboard$")
    public void iClickTheEnterInKeyboard() throws Throwable {
        // Write code here that turns the phrase above into concrete actions


        if(Devicename.currentdevicename.equalsIgnoreCase("IPADAIR")) {
            mangetransfer.clickenterbutton();
            Wait.forSeconds(30);
        }
    }

    @Then("^I click Buyload tab in homepage$")
    public void iClickBuyloadTabInHomepage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ///throw new PendingException();
        mangetransfer.clickbuyloadlink();
    }

    @And("^I click the Managecontact in buyload page$")
    public void iClickTheManagecontactInBuyloadPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangetransfer.clickbuyloadmanagecontact();
    }

    @Then("^Verify the participantname and mobile number in the search result$")
    public void verifyTheParticipantnameAndMobileNumberInTheSearchResult() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        mangetransfer.verifypaticipantdetails(participantname,participantnumber);

    }

    @Then("^I store the totalamount tobe transfered$")
    public void iStoreTheTotalamountTobeTransfered() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        Requestpaymentamount=mangetransfer.getRequestpaymanetamount();
    }

    @Then("^verify the Requestpayment amount and reference message$")
    public void verifyTheRequestpaymnetAmountAndReferenceMessage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        Wait.forSeconds(30);
        mangetransfer.verifyrequestpaymentdetails(Requestpaymentmessage,Requestpaymentamount);
    }

    @And("^I click the requested result in the managetransfer request page$")
    public void iClickTheRequestedResultInTheManagetransferRequestPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @And("^I click the resendallrequest button in Requestpayment details page$")
    public void iClickTheResendallrequestButtonInRequestpaymentDetailsPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangetransfer.clickresendallrequest();
    }

    @Then("^I click yes button in the popup window$")
    public void iClickYesButtonInThePopupWindow() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangetransfer.clickyes();
    }

    @And("^I click the cancelallrequest button in Requestpayment details page$")
    public void iClickTheCancelallrequestButtonInRequestpaymentDetailsPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangetransfer.clickcancelallrequest();
    }
}


