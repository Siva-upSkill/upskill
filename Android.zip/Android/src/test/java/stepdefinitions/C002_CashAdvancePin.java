package stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import exceptions.ApplicationException;
import pages.CashAdvancePinPage;

public class C002_CashAdvancePin {
    CashAdvancePinPage CAPinPage= new CashAdvancePinPage();

    @When("^user click on the listed accounts from Setcash advancedPin$")
    public void userClickOnTheListedAccounts() throws Throwable {
        CAPinPage.click_CardAccount();

    }

    @Then("^I Verify whether application displays Set Cash Advance Pin option$")
    public void iVerifyWhetherApplicationDisplaysOption() throws Throwable {
        CAPinPage.verifySetCashAdvancedPin();

    }

    @And("^I Enter the Pin in OTP Page$")
    public void iEnterThePinInOTPPage() throws Throwable {
        CAPinPage.SetOTP();

    }
    @And("^I Verify whether application displays the label descripton$")
    public void iVerifyWhetherApplicationDisplaysTheLabelDescriptonAs() throws Throwable {
        CAPinPage.verifySixDigitPin();
    }

    @When("^I click on Set Cash Advance Pin option$")
    public void iClickOnSetCashAdvancePinOption() throws Throwable {
        CAPinPage.click_SetCardPin();

    }
    @Then("^Verify application allow user to clear the entered pin by clicking CLEAR PIN option$")
    public void verifyApplicationAllowUserToClearTheEnteredPinByClickingOption() throws Throwable {
        CAPinPage.click_ClearPin();
    }

    @When("^I click on Reset Cash Advance Pin option$")
    public void iClickOnResetCashAdvancePinOption() throws Throwable {
        CAPinPage.click_ResetCardPin();
    }

    @Then("^I Verify whether application displayed Reset Cash Advance Pin option$")
    public void iVerifyWhetherApplicationDisplayedOption() throws Throwable {
        CAPinPage.verifyResetCashAdvancedPin();
    }

    @When("^user click on the listed accounts from Reset$")
    public void userClickOnTheListedAccountsFromReset() throws Throwable {
        CAPinPage.click_ResetCardAccount();
    }

    @And("^I Verify whether application displays the Reset cash label descripton$")
    public void iVerifyWhetherApplicationDisplaysTheResetCashLabelDescriptonAs() throws Throwable {
        CAPinPage.verifySixDigitCreditPin();
    }

    @Then("^User able to enter doesn't match the previous six digits Pin$")
    public void userAbleToEnterDoesnTMatchThePreviousSixDigitsPin() throws ApplicationException {
        CAPinPage.SetOTP();
        CAPinPage.SetOTP1();
    }

    @Then("^User should be displayed with Pin Doesnt Match ErrMsg$")
    public void userShouldBeDisplayedWithPinDoesntMatchErrMsg() throws Throwable {
        CAPinPage.PinDoesntMatchErrMsg();
    }

    @Then("^User able to enter consecutive six digits$")
    public void userAbleToEnterConsecutiveSixDigits() throws Throwable {
        CAPinPage.enterConsecutiveSixDigits();

    }

    @Then("^User should be displayed with consecutive Numeric Values ErrMsg$")
    public void userShouldBeDisplayedWithConsecutiveNumericValuesErrMsg() throws Throwable {
        CAPinPage.consecutiveErrMsg();

    }

    @Then("^User able to enter six digits same Pin$")
    public void userAbleToEnterSixDigitsSamePin() throws Throwable {
        CAPinPage.enterSameDigitsPin();

    }

    @And("^User should be displayed with same Pin ErrMsg$")
    public void userShouldBeDisplayedWithSamePinErrMsg() throws Throwable {
        CAPinPage.samePinErrMgs();
    }

    @Then("^user verifies the correct Reminders$")
    public void userVerifiesTheCorrectReminders() throws Throwable {
        CAPinPage.verifyReminders();
    }

    @And("^User able to enter Valid six DigitPin$")
    public void userAbleToEnterValidSixDigitPin() throws Throwable {
        CAPinPage.ValidDigitsPin();
        CAPinPage.ValidDigitsPin();
    }

    @Then("^Verify the Invalid OTP Message$")
    public void verifyTheInvalidOTPMessage() throws Throwable {
        CAPinPage.verifyInvalidOTPMessage();
    }

    @When("^user clicks an playeveryday card(\\d+)$")
    public void userClicksAnPlayeverydayCard(int arg0) {
    }

    @And("^Click on manage cards(\\d+)$")
    public void clickOnManageCards(int arg0) {
    }

    @And("^Click on Set Pin$")
    public void clickOnSetPin() {
    }

    @And("^I Verify the OTP Filed is page is displayed$")
    public void iVerifyTheOTPFiledIsPageIsDisplayed() {
    }

    @And("^User enter OTP$")
    public void userEnterOTP() {
    }

    @Then("^verify the success message$")
    public void verifyTheSuccessMessage() {
    }

    @And("^Click on reset Pin option$")
    public void clickOnResetPinOption() {
    }
}
