package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import pages.LmsPage;

public class C042_LMS {
    LmsPage  LMS = new LmsPage();
    @Then("^Check if application allows user to select any one of the master card in dashboard screen$")
    public void checkIfApplicationAllowsUserToSelectAnyOneOfTheMasterCardInDashboardScreen() throws Throwable {
        LMS.SelectCard();
    }

    @And("^check if application navigated to account details page and click to redeem$")
    public void checkIfApplicationNavigatedToAccountDetailsPageAndClickToRedeem() throws Throwable {
        LMS.ClickRedeem();
    }

    @Then("^enter the amount to be redeemed in amount text box$")
    public void enterTheAmountToBeRedeemedInAmountTextBox() throws Throwable {
        LMS.EnterAmount();
    }

    @And("^click to next button$")
    public void clickToNextButton() throws Throwable {
        LMS.ClickNext();
    }

    @Then("^verify if the application navigates to review and redeem page$")
    public void verifyIfTheApplicationNavigatesToReviewAndRedeemPage() throws Throwable {
        LMS.VerifyNavigationToReviewPage();
    }

    @Then("^click to redeem$")
    public void clickToRedeem() throws Throwable {
        LMS.ClickRedeemBtn();
    }

    @And("^verify the success message for redemption$")
    public void verifyTheSuccessMessageForRedemption() throws Throwable {
        LMS.VerifySuccessMessage();
    }


    @And("^click back to dashboard button$")
    public void clickBackToDashboardButton() throws Throwable {
        LMS.ClickBackToDashBoard();
    }

    @Then("^check whether application displays the increment inline message$")
    public void checkWhetherApplicationDisplaysTheIncrementInlineMessage() throws Throwable {
        LMS.VerifyIncrementInlineMessage();
    }

    @Then("^enter the Invalid amount to be redeemed in amount text box$")
    public void enterTheInvalidAmountToBeRedeemedInAmountTextBox() throws Throwable {
        LMS.EnterInvalidAmount();
    }

    @Then("^verify the error message for invalid amount entered$")
    public void verifyTheErrorMessageForInvalidAmountEntered() throws Throwable {
        LMS.VerifyErrorMessage();

    }

    @Then("^enter the new amount to be redeemed in amount text box$")
    public void enterTheNewAmountToBeRedeemedInAmountTextBox() throws Throwable {
        LMS.EnterNewAmount();

    }

    @And("^click edit button$")
    public void clickEditButton() throws Throwable {
        LMS.ClickEdit();
    }

    @And("^click on cancel redemption$")
    public void clickOnCancelRedemption() throws Throwable {
        LMS.ClickCancelRedemption();
    }

    @Then("^click to cancel Button$")
    public void clickToCancelButton() throws Throwable {
        LMS.ClickCancel();
    }


    }
