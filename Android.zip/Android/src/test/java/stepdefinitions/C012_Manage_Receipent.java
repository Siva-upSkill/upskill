package stepdefinitions;

import actions.Swipe;
import actions.Wait;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverManager;
import exceptions.ApplicationException;
import helper.PropertyReader;
import pages.HomePage;
import pages.LoginPage;
import pages.OTPPage;
import pages.WelcomePage;
import pages.ManageReceipentPage;
import pages.*;
import runners.ConvergentTestRunner;

import static base.Keywords.swipe;


public class C012_Manage_Receipent {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private ManageReceipentPage mangerecepent = new ManageReceipentPage();
    ConvergentTestRunner Devicename = new ConvergentTestRunner();

    @Given("^I'm on Dashboard page$")
    public void i_m_on_Dashboard_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(3);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {

            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(10);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }

    }

    @Then("^I click the manage receipent link$")
    public void i_click_the_manage_receipent_link() throws Throwable {
        Wait.forSeconds(3);
        swipe.swipeVertical(2, 0.6, .2, 2);
        mangerecepent.clickManagereceipent();
    }

    @Then("^I click the send request tab$")
    public void i_click_the_send_request_tab() throws Throwable {
        Wait.forSeconds(3);
        home.gotoSendRequestTab();
        Wait.forSeconds(3);
    }

    @When("^I should see the \"([^\"]*)\" page in Manage Receipent$")
    public void i_should_see_the_page_in_Manage_Receipent(String arg1) throws Throwable {
        mangerecepent.verifyPageTitleinManageRecepient(arg1);

        ///otp.verifyPageTitle(arg1);
    }


    @Then("^I should able to add New Recipients details and Save$")
    public void i_Should_Able_To_Add_New_Recipients_Details_And_Save() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.addNewManagereceipent();

    }

    @Then("^I enter the less than three characters in the account name$")
    public void iEnterTheLessThanThreeCharactersInTheAccountName() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.addNewManagereceipentbutton();
        mangerecepent.entertheAccountNumber(12);
        mangerecepent.entertheAccountName(2);
    }

    @Then("^I should see the error message \"([^\"]*)\" in account name field$")
    public void iShouldSeeTheErrorMessageInAccountNameField(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.verifyManageReciepentaccountnamefieldErrorMsg(arg0);
    }

    @Then("^I click the add new manage receipent button$")
    public void iClickTheAddNewManageReceipentButton() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.addNewManagereceipentbutton();
    }

    @And("^I select the manage receipent bank from list$")
    public void iSelectTheManageReceipentBankFromList() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.selecttheReceipentBank();
    }

    @Then("^I enter the less than three six digit in the account number$")
    public void iEnterTheLessThanThreeSixDigitInTheAccountNumber() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.addNewManagereceipentbutton();
        mangerecepent.entertheAccountNumber(3);
        mangerecepent.entertheAccountName(5);
    }

    @Then("^I should see the error message \"([^\"]*)\" in account number field$")
    public void iShouldSeeTheErrorMessageInAccountNumberField(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(5);
        mangerecepent.verifyManageReciepentaccountnumberfieldErrorMsg(arg0);
    }

    @Then("^I should able to add New Recipients details and make it favourite and save$")
    public void iShouldAbleToAddNewRecipientsDetailsAndMakeItFavouriteAndSave() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.addNewManagereceipentFav();
    }

    @And("^I click the search manage receipent search icon$")
    public void iClickTheSearchManageReceipentSearchIcon() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.searchManagereceipent();
        Wait.forSeconds(5);
    }

    @And("^I Search the receipent \"([^\"]*)\" and mark it as favourite$")
    public void iSearchTheReceipentAndMarkItAsFavourite(String receipentname) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.searchManagereceipentandfavourite((PropertyReader.testDataOf(receipentname)));
    }

    @Then("^I verify receipent   \"([^\"]*)\" in the favourite page$")
    public void i_verify_receipent_in_the_favourite_page(String receipentname) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.verifythereceipentfavouritepage((PropertyReader.testDataOf(receipentname)));
    }

    @Then("^I make it receipent as unfavourite$")
    public void i_make_it_receipent_as_unfavourite() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }


    @And("^I click the existing manage receipent in the manage receipent$")
    public void iClickTheExistingManageReceipentInTheManageReceipent() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(15);
        // Swipe.swipe.scrollDownToTextandClick(arg0);
        mangerecepent.clicktheexistingmanagereceipent();

    }

    @And("^I click the Edit Button of the existing manage receipent$")
    public void iClickTheEditButtonOfTheExistingManageReceipent() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.clicktheeditingmanagereceipent();
        Wait.forSeconds(8);

    }

    @And("^I Enter the name and changed manage recipient to favourite$")
    public void iEnterTheNameAndChangedManageRecipientToFavourite() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(10);
        mangerecepent.clicktheeditingmanagereceipentandmarkfavourite();


    }

    @And("^I enter the account name and save existing manage receipent$")
    public void iEnterTheAccountNameAndSaveExistingManageReceipent() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.entertheeditrecipientname();

    }

    @And("^I enter the account number and save existing manage receipent$")
    public void iEnterTheAccountNumberAndSaveExistingManageReceipent() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.entertheeditrecipientnumber();
    }

    @And("^I click the Delete Button of the existing manage receipent$")
    public void iClickTheDeleteButtonOfTheExistingManageReceipent() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        mangerecepent.deletetheecipient();


    }

    @And("^I verify the favourite item \"([^\"]*)\" displayed in the Manage Receipent$")
    public void iVerifyTheFavouriteItemDisplayedInTheManageReceipent(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        // throw new PendingException();
        mangerecepent.verifytheFavouriterecipient(arg0);
    }


    @And("^I click the existing manage receipent in the manage receipent \"([^\"]*)\" using search$")
    public void iClickTheExistingManageReceipentInTheManageReceipentUsingSearch(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(8);
        mangerecepent.clickSearchicon();
        mangerecepent.enterinSearchtextfieldmanagerec(arg0);
        Wait.forSeconds(10);


    }

    @And("^Modified manage receipent to \"([^\"]*)\" and \"([^\"]*)\" update$")
    public void modifiedManageReceipentToAndUpdate(String arg0, String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.clicktheeditingmanagereceipent(arg0, arg1);
    }

    @Then("^verify the \"([^\"]*)\" and \"([^\"]*)\" in the search results$")
    public void verifyTheAndInTheSearchResults(String arg0, String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.verifytheeditingmanagereceipent(arg0, arg1);
    }

    @And("^I click the existing manage receipent$")
    public void iClickTheExistingManageReceipent() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.clicktheexistingmanagereceipent();
    }

    @And("^I click the favourite button to mark as favourite$")
    public void iClickTheFavouriteButtonToMarkAsFavourite() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.markasfavourite();
    }

    @And("^I click update button in the manage receipient page$")
    public void iClickUpdateButtonInTheManageReceipientPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        mangerecepent.clickUpdatebutton();
    }

    @And("^I click the favourite link$")
    public void iClickTheFavouriteLink() throws Throwable {
        mangerecepent.clickFavouritelink();

    }

    @Then("^I should able to verify success msg on confirmation screen$")
    public void iShouldAbleToVerifySuccessMsgOnConfirmationScreen() throws ApplicationException {
        mangerecepent.verifySuccessMsg();
    }
}
