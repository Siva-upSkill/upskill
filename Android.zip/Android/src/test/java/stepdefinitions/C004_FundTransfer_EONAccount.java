package stepdefinitions;

import java.time.ZonedDateTime;
import java.time.format.TextStyle;
import java.util.Locale;


import actions.*;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.zh_tw.但是;
import driver.DriverManager;
import helper.PropertyReader;
import pages.*;
import runners.ConvergentTestRunner;


public class C004_FundTransfer_EONAccount {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private SendRequestPage sendrequest = new SendRequestPage();
    private TransferFromPage eonfrompage = new TransferFromPage();
    private TransferToPage eontopage = new TransferToPage();
    private TransferDetailsPage eondetailpage = new TransferDetailsPage();
    private ReviewandTransferPage eonreviewpage = new ReviewandTransferPage();
    private TransferSuccessfulPage eonsuccesspage = new TransferSuccessfulPage();
    private PesonetPage pesonet = new PesonetPage();
    private ReviewandTransferPage ownreviewpage = new ReviewandTransferPage();
    Touch action = new Touch();
    ConvergentTestRunner Devicename = new ConvergentTestRunner();
    public static Swipe swipe = new Swipe();


    //Test data for verification
    private String transferamount;
    private String remarkmsg;
    private String frequency;
    private String date = "Today";
    private String repeat = "Never";
    private String updatedamount;
    private String refernenceno;

    /////
    static String day;
    static String pastdate;
    static ZonedDateTime zdt = ZonedDateTime.now();
    static String year = Integer.toString(zdt.getYear());
    static String monthName = zdt.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
    static String dayOfMonth = Integer.toString(zdt.getDayOfMonth());

    static {
        if (dayOfMonth.length() == 1) {
            day = "0" + dayOfMonth;
        } else {
            day = dayOfMonth;

        }
    }

    static {
        if (!day.contentEquals("01")) {
            pastdate = Integer.toString(Integer.parseInt(day) - 1);
        }
    }

    private static String transactiondate = monthName + " " + day + ", " + year;


    /////


    @Given("^I'm on the landing page of union bank mobile application$")
    public void i_m_on_the_landing_page_of_union_bank_mobile_application() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        welcome.clickGotITBtn_Biometrics();
        welcome.clickNext();
        welcome.clickNext();
        welcome.clickNext();
        if (Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            welcome.clickNext();
        }
        welcome.clickGetStarted();
        welcome.clickLogin();
        login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
        login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
        login.clickLogin();
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        home.closeRegisterDevicePopup();
    }

    @When("^I choose Send/Request tab from the footer section$")
    public void i_choose_Send_Request_tab_from_the_footer_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //home.clickSendRequestTab();
        home.gotoSendRequestTab();

    }

    @Then("^I should see \"([^\"]*)\" link in the Send/Request page$")
    public void i_should_see_link_in_the_Send_Request_page(String ilink) throws Throwable {
        sendrequest.verifyEONAccountLink(ilink);
    }


    @Given("^I'm on \"([^\"]*)\" Transfer from\\? page$")
    public void i_m_on_Transfer_from_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(4);
            welcome.clickGotITBtn_Biometrics();
            welcome.clickNext();
            welcome.clickNext();
            welcome.clickNext();
            if (Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                welcome.clickNext();
            }
            welcome.clickGetStarted();
            welcome.clickLogin();
            login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(4);
          /*
           if(Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30") )
           {
               Thread.sleep(15000);
           }

           */
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(2);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(2);
            home.clickContinue();
            Wait.forSeconds(2);
//           home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(4);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.gotoSendRequestTab();
            sendrequest.verifyEONAccountLink(arg1);
            sendrequest.clickEONAccountLink();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {


            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(25);
            home.gotoSendRequestTabIOS();
            sendrequest.verifyEONAccountLink(arg1);
            sendrequest.clickEONAccountLink();
        }

    }

    @When("^I choose source account from the list of availabel transfer from accounts$")
    public void i_choose_source_account_from_the_list_of_availabel_transfer_from_accounts() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            eonfrompage.chooseTranferFromAccount(PropertyReader.testDataOf("Source_Account"));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(10);
            // Swipe.swipe.scrollDownToTextandClick(PropertyReader.testDataOf("Source_Account"));
            eonfrompage.chooseTranferFromAccountios();
        }
    }

    @Then("^I should see \"([^\"]*)\" page with facility to enter recipients account number$")
    public void i_should_see_page_with_facility_to_enter_recipients_account_number(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eontopage.verifyTransferToPageTitle(arg1);
        eontopage.verifyTransferToRecepientTxtBox();

    }

    @And("^I enter valid ubp \"([^\"]*)\" in the Transfer To\\? page$")
    public void I_enter_valid_ubp_in_the_Transfer_To_page(String arg1) throws Throwable {
        eontopage.enterRecipientAccount(PropertyReader.testDataOf(arg1));
    }

    @Then("^on sucessfull account validation the button NEXT should be enabled$")
    public void on_sucessfull_account_validation_the_button_NEXT_should_be_enabled() throws Throwable {
        Thread.sleep(200);
        eontopage.checkNextBtnEnabled();
    }

    @And("^I enter invalid ubp \"([^\"]*)\" in the Transfer To\\? page$")
    public void I_enter_invalid_ubp_in_the_Transfer_To_page(String arg1) throws Throwable {
        Wait.forSeconds(10);
        eontopage.enterRecipientAccount(PropertyReader.testDataOf(arg1));
    }

    @Then("^on account validation the button NEXT should not be enabled$")
    public void on_account_validation_the_button_NEXT_should_not_be_enabled() throws Throwable {
        eontopage.checkNextBtnDisabled();
    }

    @And("^I choose recipient account from the select My recipient list$")
    public void I_choose_recipient_account_from_the_select_My_recipient_list() throws Throwable {
        eontopage.clickSelectFromList();
        eontopage.clickMyRecipient(PropertyReader.testDataOf("Recipient_Account"));
        //eonaccount.clickMyRecipient();
    }

    @And("^I choose recipient account from the favourite recipient list$")
    public void I_choose_recipient_account_from_the_favourite_recipient_list() throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(10);
            eontopage.clickSelectFromList();
            Wait.forSeconds(10);
            eontopage.clickFavouriteRecipient(PropertyReader.testDataOf("EONRecipient_Account"));
            Wait.forSeconds(5);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {


            Wait.forSeconds(10);
            eontopage.clickSelectFromList();
            Wait.forSeconds(10);
            eontopage.clickFavouritelinkreceipientsearch();
            Wait.forSeconds(8);
            eontopage.clickMyRecipientios(PropertyReader.testDataOf("Recipient_Account"));


        }


    }

    @When("^I enter \"([^\"]*)\" and \"([^\"]*)\" information$")
    public void i_enter_and_information(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        eonfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg1));
        eontopage.clickSelectFromList();
        eontopage.clickMyRecipient(PropertyReader.testDataOf(arg2));
    }

    @When("^click next button$")
    public void click_next_button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(2);

        eontopage.clickNextBtn();
        Wait.forSeconds(3);
        ownreviewpage.clickGotitButton();


    }

    @Then("^\"([^\"]*)\" page should be displayed$")
    public void page_should_be_displayed(String arg1) throws Throwable {
        eondetailpage.verifyTransferDetailsPageTile(arg1);

    }

    @Then("^click OK button$")
    public void click_ok_button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eontopage.clickOKBtn();
        Wait.forSeconds(20);
    }


    @When("^I try to enter non-numeric characters \"([^\"]*)\" in amount field$")
    public void i_try_to_enter_non_numeric_characters_in_amount_field(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eondetailpage.enterTransferAmt(arg1);
    }

    @Then("^the application should not allow to user to keyin the non-numeric characters in amount field$")
    public void the_application_should_not_allow_to_user_to_keyin_the_non_numeric_characters_in_amount_field() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eondetailpage.checkDefaultTransferAmtval();
    }


    @When("^I enter transaction amount PHP \"([^\"]*)\" greater than the account balance in amount field$")
    public void i_enter_transaction_amount_PHP_greater_than_the_account_balance_in_amount_field(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Thread.sleep(3000);
        eondetailpage.enterTransferAmt(arg1);
    }

    @Then("^I should see an error message \"([^\"]*)\"$")
    public void i_should_see_an_error_message(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eondetailpage.clickRepeatMsgbox();
        eondetailpage.verifyAmtErrorMsg(arg1);

    }

    ///
    @When("^I enter transaction amount \"([^\"]*)\" PHP in amount field$")
    public void i_enter_transaction_amount_PHP_in_amount_field(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(2);
        transferamount = "PHP " + arg1;
        eondetailpage.enterTransferAmt(arg1);

    }

    @And("^Turn on repeat toggle button$")
    public void turn_on_repeat_toggle_button() throws Throwable {
        Wait.forSeconds(2);
        eondetailpage.turnONToggleBtn();
    }

    @Then("^I should see a option to provide \"([^\"]*)\" and \"([^\"]*)\" functionality$")
    public void i_should_see_a_option_to_provide_and_functionality(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eondetailpage.verifyFrequencyElement(arg1);
        eondetailpage.verifyEndRepeatElement(arg2);
    }

    @Then("^I should see a \"([^\"]*)\" page$")
    public void i_should_see_page(String arg1) throws Throwable {
        //action.touchLongPress(0,250,0,1000);
        // Keywords.refreshPage();
        // Touch.touchLongPress(100,200,100,500);
        Wait.forSeconds(10);
        eonreviewpage.verifyReviewandTransfertitle(arg1);
        Wait.forSeconds(4);
    }

    @Then("^I should see a Review and Transfer page$")
    public void i_should_see_review_and_transfer_page() throws Throwable {
        Wait.forSeconds(4);
        Touch.touchLongPress(0, 50, 0, 500);
        eonreviewpage.verifyReviewandTransfertitle1();


    }


    @When("^I choose \"([^\"]*)\" as a repeat option from select frequency$")
    public void i_choose_as_a_repeat_option_from_select_frequency(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        frequency = arg1;
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(2);
            turn_on_repeat_toggle_button();
            eondetailpage.clickFrequencyElement();
            eondetailpage.chooseSelectFrequency();
            eondetailpage.ClickEndDate();
            eondetailpage.SelectDateWeekly();
            eondetailpage.clickDatePickerOkBtn();

        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {


            turn_on_repeat_toggle_button();
            eondetailpage.clickFrequencyElement();
            eondetailpage.chooseSelectFrequencyios(arg1);
            eondetailpage.clickTransferfrequencydone();
            Wait.forSeconds(10);
        }


    }

    @Given("^I'm on \"([^\"]*)\" Transfer details page with the \"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_m_on_Transfer_details_page_with_the_and(String arg1, String arg2, String arg3) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        welcome.clickGotITBtn_Biometrics();
        welcome.clickNext();
        welcome.clickNext();
        welcome.clickNext();
        welcome.clickNext();
        welcome.clickGetStarted();
        welcome.clickLogin();
        login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
        login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
        login.clickLogin();
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        home.clickSubscribeToAppOtpNotNow();
        home.clickContinue();
//        home.clickNotNowtoSubscribe();
        home.clickNotNowToTurnOnNotification();
        home.clickGotoDashBoard();
//        home.clickNotNowfingerprintNotification();
//        home.clickNotNowfingerprintNotification();
        //home.closeRegisterDevicePopup();
        //home.clickSendRequestTab();
        home.gotoSendRequestTab();
        Thread.sleep(15000);
        sendrequest.verifyEONAccountLink(arg1);
        sendrequest.clickEONAccountLink();
        eonfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg2));
        Wait.forSeconds(10);
        eontopage.clickSelectFromList();
        Wait.forSeconds(8);
        eontopage.clickFavouriteRecipientTabios_EON();
        eontopage.clickMyRecipient(PropertyReader.testDataOf(arg3));
        eontopage.clickNextBtn();
        //eonaccount.enterTransferAmt(PropertyReader.testDataOf("Transfer_Amount"));

    }

    @When("^I enter remark message with text \"([^\"]*)\"$")
    public void i_enter_remark_message_with_text(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eondetailpage.enterRemarkMessageText(PropertyReader.testDataOf(arg1));
    }

    @Then("^I should see the entered remark message in the message text area$")
    public void i_should_see_the_entered_remark_message_in_the_message_text_area() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //eonaccount.verifyRemarkMessageTextlessthan256();
        eondetailpage.verifyRemarkMessageText(PropertyReader.testDataOf("less_than_256_characters"));
    }

    @Then("^I should see the entered remark message with only (\\d+) characters in the message text area$")
    public void i_should_see_the_entered_remark_message_with_only_characters_in_the_message_text_area(int arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //eonaccount.verifyRemarkMessageTextequal256();
        eondetailpage.verifyRemarkMessageText(PropertyReader.testDataOf("equal_to_256_characters"));
    }

    @Then("^I should see the remark message with only (\\d+) characters in the message text area$")
    public void i_should_see_the_remark_message_with_only_characters_in_the_message_text_area(int arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //eonaccount.verifyRemarkMessageTextgreaterthan256();
        eondetailpage.verifyRemarkMessageText(PropertyReader.testDataOf("greater_than_256_characters").substring(0, 256));
    }


    @When("^I enter remark message as \"([^\"]*)\"$")
    public void i_enter_remark_message_as(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        remarkmsg = arg1;
        eondetailpage.enterRemarkMessageText(arg1);

        //////////

        eondetailpage.clickTransactionDate();
        Thread.sleep(25000);

        //////////////
    }


    @Then("^I should see a \"([^\"]*)\" page with \"([^\"]*)\",\"([^\"]*)\",transaction \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and remark \"([^\"]*)\" details$")
    public void i_should_see_a_page_with_transaction_and_remark_details(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eonreviewpage.verifyReviewandTransfertitle(arg1);
        eonreviewpage.verifyReviewPagelabel(arg2);
        eonreviewpage.verifyReviewPagelabel(arg3);
        eonreviewpage.verifyReviewPagelabel(arg4);
        eonreviewpage.verifyReviewPagelabel(arg5);
        eonreviewpage.verifyReviewPagelabel(arg6);
        eonreviewpage.verifyReviewPagelabel(arg7);
        eonreviewpage.verifyReviewPagelabel(arg8);

        //////few hard coded refer string declaration
        eonreviewpage.verifyReviewPagedetails(PropertyReader.testDataOf("Source_Name"), PropertyReader.testDataOf("Recipient_Name"), PropertyReader.testDataOf("Source_Account"), PropertyReader.testDataOf("Recipient_Account"), transferamount, date, frequency, repeat, remarkmsg);

        eonreviewpage.clickTransfer();

    }


    @Given("^I'm on \"([^\"]*)\" \"([^\"]*)\" page with the \"([^\"]*)\",\"([^\"]*)\" and amount PHP \"([^\"]*)\"$")
    public void i_m_on_page_with_the_and_amount_PHP(String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            transferamount = "PHP " + arg5;
            i_m_on_Transfer_details_page_with_the_and(arg1, arg3, arg4);
            Wait.forSeconds(15);
            eondetailpage.enterTransferAmt(arg5);
            eondetailpage.clickNextBtn();
            Wait.forSeconds(6);
//            eonreviewpage.verifyReviewandTransfertitle(arg2);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {

            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(25);
            home.gotoSendRequestTabIOS();
            Thread.sleep(15000);
            sendrequest.verifyEONAccountLink(arg1);
            sendrequest.clickEONAccountLink();
            eonfrompage.chooseTranferFromAccountios();
            eontopage.clickSelectFromList();
            Thread.sleep(30000);
            eontopage.clickMyRecipientios(PropertyReader.testDataOf("EONRecipient_Account"));
            Thread.sleep(3000);
            eontopage.clickNextBtn();
            eondetailpage.enterTransferAmt(arg5);
            eontopage.clickNextBtn();
            ownreviewpage.clickGotitButton();
            Wait.forSeconds(15);
            eonreviewpage.verifyReviewandTransfertitle(arg2);
            //eontopage.clickOKBtn();
            //eonreviewpage.verifyReviewandTransfertitle(arg2);

        }


    }

    @When("^I click Edit link present in the From account section$")
    public void i_click_Edit_link_present_in_the_From_account_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //eonreviewpage.clickEditlinkFromAccount();
            if (Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                Wait.forSeconds(15);
                //ouch.touchLongPress(1000, 350, 1000, 350);
                eonreviewpage.clickEditlinkFromAccount();
            }
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            eonreviewpage.clickEditlinkFromAccountios();
        }
    }

    @Then("^I should see \"([^\"]*)\" page with option to change source account$")
    public void i_should_see_page_with_option_to_change_source_account(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eonfrompage.verifyTransferFromPageTitle(arg1);

    }

    @When("^I choose \"([^\"]*)\" from the list$")
    public void i_choose_from_the_list(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            eonfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg1));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            //eonfrompage.chooseTranferFromAccountios();
            Wait.forSeconds(10);
            eonfrompage.chooseTranferFromeditAccountios();
        }

    }

    @Then("^I should see \"([^\"]*)\" page with updated source account$")
    public void i_should_see_page_with_updated_source_account(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {

//            Keywords.refreshPage();
//            eonreviewpage.verifyReviewandTransfertitle2(arg1);
//            eonreviewpage.verificationafterfromaccounteditlink(PropertyReader.testDataOf("OWN_Another_Source_Name"), PropertyReader.testDataOf("OWN_Another_Source_Account"));

        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            eonreviewpage.verifyReviewandTransfertitle2(arg1);
        }


    }


    @When("^I click Edit link present in the To account section$")
    public void i_click_Edit_link_present_in_the_To_account_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //eonreviewpage.clickEditlinkToAccount();
            if (Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                Wait.forSeconds(15);
                // Touch.pressByCoordinates(970, 630, 5);
                eonreviewpage.clickEditlinkToAccount();
            }
            //Touch.touchLongPress(950,650,950,650);
            //Touch.touchLongPress(950,540,950,540);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            eonreviewpage.clickEditlinkToAccountios();
        }
    }

    @Then("^I should see \"([^\"]*)\" page with option to change recipient account$")
    public void i_should_see_page_with_option_to_change_recipient_account(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(8);
        eontopage.verifyTransferToPageTitle(arg1);
    }


    @When("^I change the recipient account to \"([^\"]*)\"$")
    public void i_change_the_recipient_account_to(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //eontopage.clickSelectFromList();
        //Wait.forSeconds(8);
        //eontopage.clickMyRecipient(arg1);
        try {
            eontopage.verifyDoneBtn("DONE");
            eontopage.clickDoneBtn();
        } catch (Exception e) {

            eontopage.clickNextBtninstapay();
        }
    }

    @Then("^I should see \"([^\"]*)\" page with updated recipient account$")
    public void i_should_see_page_with_updated_recipient_account(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//                eonreviewpage.verifyReviewandTransfertitle(arg1);
//            eonreviewpage.verificationaftertoaccounteditlink(PropertyReader.testDataOf("Another_Recipient_Account"), PropertyReader.testDataOf("Another_Recipient_Name"));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {

            eonreviewpage.verifyReviewandTransfertitle(arg1);
        }
    }

    @When("^I click Edit link present in the Amount section$")
    public void i_click_Edit_link_present_in_the_Amount_section() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eonreviewpage.clickEditlinkAmount();
    }

    @Then("^I should see \"([^\"]*)\" page with option to change transfer amount details$")
    public void i_should_see_page_with_option_to_change_transfer_amount_details(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eondetailpage.verifyTransferDetailsPageTile(arg1);

    }

    @When("^I change the transfer amount to PHP \"([^\"]*)\"$")
    public void i_change_the_transfer_amount_to_PHP(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        updatedamount = "PHP " + arg1;
        eondetailpage.enterTransferAmt(arg1);
        eondetailpage.verifyDoneBtn("DONE");
        eondetailpage.clickDoneBtn();
    }

    @Then("^I should see \"([^\"]*)\" page with updated transfer account$")
    public void i_should_see_page_with_updated_transfer_account(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eonreviewpage.verifyReviewandTransfertitle(arg1);
        eonreviewpage.verificationafteramounteditlink(updatedamount);
    }


    //////
    @When("^I click on \"([^\"]*)\" button$")
    public void i_click_on_button(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //Thread.sleep(7000);

            //swipe.swipeVertical(2, 0.8, 0.2, 5);
            Wait.forSeconds(3);
//         if(Devicename.currentdevicename.equalsIgnoreCase("NOKIA7")) {
//             Touch.pressByCoordinates(500, 950, 2);
//             Touch.pressByCoordinates(500, 1050, 2);
//             Touch.pressByCoordinates(500, 1200, 2);
//             Touch.pressByCoordinates(500, 1350, 2);
//             Touch.pressByCoordinates(500, 1475, 2);
//             Touch.pressByCoordinates(500, 1550, 2);
//             Touch.pressByCoordinates(500, 1650, 2);
//             Touch.pressByCoordinates(500, 1700, 2);
//
//         }
            swipe.swipeVertical(2, 0.8, 0.2, 5);
            eonreviewpage.clickTransfer();
            //eonreviewpage.verifyTransferBtn(arg1);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {

            eonreviewpage.clickTransfer();
            Wait.forSeconds(5);
            //
            //ownreviewpage.clickGotitButton();
            //Wait.forSeconds(10);
        }

    }

    @Then("^I should see a \"([^\"]*)\" page with facility to enter OTP$")
    public void i_should_see_a_page_with_facility_to_enter_OTP(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otp.verifyPageTitle(arg1);


    }

    @Then("^I should see \"([^\"]*)\" screen$")
    public void i_should_see_screen(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eonsuccesspage.verifyTransferSuccessfultitle(arg1);
        eonsuccesspage.verifyTransferSuccessfulfieldlabels
                ("Reference Number", "Transaction Date", "From Account", "To Account", "Amount", "Date");
    }

    @When("^I enter invalid OTP \"([^\"]*)\"$")
    public void i_enter_invalid_OTP(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otp.enterOTP(PropertyReader.testDataOf("Account1_INVALID_OTP"));
    }

    @Then("^I should see a pop-up with error message \"([^\"]*)\"$")
    public void i_should_see_a_pop_up_with_error_message(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(20);
        otp.verifyOTPAlertMsg(arg1);
    }

    ////////////////////////////////
    @Then("^I should see \"([^\"]*)\" screen with my transaction details$")
    public void i_should_see_screen_with_my_transaction_details(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eonsuccesspage.verifyTransferSuccessfultitle(arg1);
        eonsuccesspage.verifyTransferSuccessfulfieldlabels
                ("Reference Number", "Transaction Date", "From Account", "To Account", "Amount", "Date");
        eonsuccesspage.verifyTransferSuccessfulPageBasicDetails(PropertyReader.testDataOf("Source_Name"), PropertyReader.testDataOf("Recipient_Name"), PropertyReader.testDataOf("Source_Account"), PropertyReader.testDataOf("Recipient_Account"), transferamount, transactiondate, frequency, repeat, remarkmsg);

        //refernenceno=eonsuccesspage.getRefernenceNumber();
    }

    @Given("^I'm on \"([^\"]*)\" \"([^\"]*)\" page$")
    public void i_m_on_page(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        welcome.clickGotITBtn_Biometrics();
        welcome.clickNext();
        welcome.clickNext();
        welcome.clickNext();
        if (Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            welcome.clickNext();
        }
        welcome.clickGetStarted();
        welcome.clickLogin();
        login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
        login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
        login.clickLogin();
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        //home.closeRegisterDevicePopup();
        home.clickContinue();
        home.clickNotNowtoSubscribe();
        home.clickNotNowToTurnOnNotification();
        if (Devicename.currentdevicename.equalsIgnoreCase("ABC") || Devicename.currentdevicename.equalsIgnoreCase("ABC")) {
            home.clickNotNowToTurnOnNotification();
        }
        home.clickGotoDashBoard();
        home.verifyIfDashboardIsDisplayed("Dashboard");
        home.gotoSendRequestTab();
        sendrequest.verifyEONAccountLink(arg1);
        sendrequest.clickEONAccountLink();
        eonfrompage.verifyTransferFromPageTitle(arg2);


    }

    @When("^I click on back button in Transfer from\\? page$")
    public void i_click_on_back_button_in_Transfer_from_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eonfrompage.clickBackBtn();
    }

    @Then("^I should navigate back to \"([^\"]*)\" page$")
    public void i_should_navigate_back_to_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.verifySendRequestTitle(arg1);
    }

    @Given("^I'm on \"([^\"]*)\" \"([^\"]*)\" page after choosing source account details$")
    public void i_m_on_page_after_choosing_source_account_details(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        welcome.clickGotITBtn_Biometrics();
        welcome.clickNext();
        welcome.clickNext();
        welcome.clickNext();
        if (Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            welcome.clickNext();
        }
        welcome.clickGetStarted();
        welcome.clickLogin();
        login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
        login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
        login.clickLogin();
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        //home.closeRegisterDevicePopup();
        home.clickContinue();
        home.clickNotNowtoSubscribe();
        home.clickNotNowToTurnOnNotification();
        if (Devicename.currentdevicename.equalsIgnoreCase("ABC") || Devicename.currentdevicename.equalsIgnoreCase("ABC")) {
            home.clickNotNowToTurnOnNotification();
        }
        home.clickGotoDashBoard();
        home.verifyIfDashboardIsDisplayed("Dashboard");
        home.gotoSendRequestTab();
        sendrequest.verifyEONAccountLink(arg1);
        sendrequest.clickEONAccountLink();
        eonfrompage.chooseTranferFromAccount(PropertyReader.testDataOf("Source_Account"));
        eontopage.verifyTransferToPageTitle(arg2);

    }

    @When("^I click on back button in Transfer to\\? page$")
    public void i_click_on_back_button_in_Transfer_to_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eontopage.clickBackBtn();
    }

    @Then("^I should navigate back to \"([^\"]*)\" page from Transfer to\\? page$")
    public void i_should_navigate_back_to_page_from_Transfer_to_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eonfrompage.verifyTransferFromPageTitle(arg1);
    }

    @Given("^I'm on \"([^\"]*)\" \"([^\"]*)\" page after providing source and recipient account details$")
    public void i_m_on_page_after_providing_source_and_recipient_account_details(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.clickNext();
            welcome.clickNext();
            welcome.clickNext();
            if (Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                welcome.clickNext();
            }
            welcome.clickGetStarted();
            welcome.clickLogin();
            login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            Wait.forSeconds(3);
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(2);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(2);
            home.clickContinue();
            Wait.forSeconds(2);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            home.gotoSendRequestTab();
            Wait.forSeconds(3);
            sendrequest.verifyEONAccountLink(arg1);
            Wait.forSeconds(3);
            sendrequest.clickEONAccountLink();
            Wait.forSeconds(3);
            eonfrompage.chooseTranferFromAccount(PropertyReader.testDataOf("Source_Account"));
            Wait.forSeconds(3);
            eontopage.clickSelectFromList();
            Wait.forSeconds(3);
            eontopage.clickFavouriteRecipientTabios_EON();
            eontopage.clickMyRecipient(PropertyReader.testDataOf("EONRecipient_Account"));
            Wait.forSeconds(3);
            eontopage.clickNextBtn();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {

            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(15);
            home.gotoSendRequestTabIOS();
            sendrequest.verifyEONAccountLink(arg1);
            sendrequest.clickEONAccountLink();
            eonfrompage.chooseTranferFromAccountios();
            Wait.forSeconds(8);
            eontopage.clickSelectFromList();
            Wait.forSeconds(15);
            eontopage.clickMyRecipientios(PropertyReader.testDataOf("Recipient_Account"));
            Wait.forSeconds(3);
            eontopage.clickNextBtn();
            //eontopage.clickOKBtn();
            eondetailpage.verifyTransferDetailsPageTile(arg2);
        }

    }

    @Given("^I'm on \"([^\"]*)\" \"([^\"]*)\" click Eonaccount link  and  providing source and recipient account details$")
    public void i_m_on_page_click_Eonaccount_link_and_providing_source_and_recipient_account_details(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Thread.sleep(5000);
            home.gotoSendRequestTab();
            Thread.sleep(8000);
            sendrequest.clickEONAccountLink();
            Thread.sleep(15000);
            eonfrompage.chooseTranferFromAccount(PropertyReader.testDataOf("Source_Account"));
            Thread.sleep(5000);
            eontopage.clickSelectFromList();
            Thread.sleep(35000);
            eontopage.clickMyRecipient(PropertyReader.testDataOf("EONRecipient_Account"));
            Thread.sleep(3000);
            eontopage.clickNextBtn();
            //eontopage.clickOKBtn();
            eondetailpage.verifyTransferDetailsPageTile(arg2);

        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {

            home.gotoSendRequestTabIOS();
            Thread.sleep(8000);
            sendrequest.verifyEONAccountLink(arg1);
            sendrequest.clickEONAccountLink();
            Thread.sleep(8000);
            eonfrompage.chooseTranferFromAccountios();
            //eonfrompage.chooseTranferFromeditAccountios();
            eontopage.clickSelectFromList();
            eontopage.clickMyRecipientios(PropertyReader.testDataOf("Recipient_Account"));
            Thread.sleep(3000);
            eontopage.clickNextBtn();
            //eontopage.clickOKBtn();
            eondetailpage.verifyTransferDetailsPageTile(arg2);
        }


    }

    @When("^I click on back button in Transfer details page$")
    public void i_click_on_back_button_in_Transfer_details_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eondetailpage.clickBackBtn();
    }

    @Then("^I should navigate back to \"([^\"]*)\" page Transfer details page$")
    public void i_should_navigate_back_to_page_Transfer_details_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eontopage.verifyTransferToPageTitle(arg1);
    }

    @When("^I click on close button in the Review and Transfer page$")
    public void i_click_on_close_button_in_the_Review_and_Transfer_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //Keywords.refreshPage();
            Wait.forSeconds(10);
            //

            if (Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                //Touch.touchLongPress(75, 170, 75, 170);
                eonreviewpage.clickClose();
            }

        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {

            Wait.forSeconds(10);
            eonreviewpage.clickClose();

        }
    }

    @Then("^I should see a \"([^\"]*)\" pop-up window with \"([^\"]*)\" and \"([^\"]*)\" button$")
    public void i_should_see_a_pop_up_window_with_and_button(String arg1, String arg2, String arg3) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eonreviewpage.verifypopup(arg1, arg2, arg3);
    }

    @When("^I click on CANCEL TRANSFER button$")
    public void i_click_on_CANCEL_TRANSFER_button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eonreviewpage.clickpopupcanceltransferbtn();
    }

    @When("^I click on next button in the \"([^\"]*)\" page$")
    public void i_click_on_next_button_in_the_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^I click on next button with an amount of PHP \"([^\"]*)\" in the \"([^\"]*)\" page$")
    public void i_click_on_next_button_with_an_amount_of_PHP_in_the_page(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eondetailpage.enterTransferAmt(arg1);
        eondetailpage.verifyTransferDetailsPageTile(arg2);

        eondetailpage.clickNextBtn();
    }


    @Then("^I should see a \"([^\"]*)\" page with facility to enter OTP, \"([^\"]*)\" button and back button$")
    public void i_should_see_a_page_with_facility_to_enter_OTP_button_and_back_button(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otp.verifyPageTitle(arg1);
        otp.verifyOTPPageElements(arg2);
    }

    @When("^I click on GO TO DASHBOARD button in Transfer Successful page$")
    public void i_click_on_GO_TO_DASHBOARD_button_in_Transfer_Successful_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        eonsuccesspage.clickGoToDashboard();
    }

    @Then("^I should see \"([^\"]*)\" page of union bank$")
    public void i_should_see_page_of_union_bank(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        home.verifyIfDashboardIsDisplayed(arg1);
    }

    @When("^I click on NEW TRANSACTION button in Transfer Successful page$")
    public void i_click_on_NEW_TRANSACTION_button_in_Transfer_Successful_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eonsuccesspage.clickNewTransaction();
    }

    @Then("^I should see \"([^\"]*)\" page for initiating a new transaction$")
    public void i_should_see_page_for_initiating_a_new_transaction(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.verifySendRequestTitle(arg1);
    }

    @When("^I click on trasanction date with an amount PHP \"([^\"]*)\" in the eon account transfer details page$")
    public void i_click_on_trasanction_date_with_an_amount_PHP_in_the_eon_account_transfer_details_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eondetailpage.clickTransactionDate();
    }

    @Then("^I should see a date picker for choosing the transaction date with the past date in disable mode for eon account fund transfer$")
    public void i_should_see_a_date_picker_for_choosing_the_transaction_date_with_the_past_date_in_disable_mode_for_eon_account_fund_transfer() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eondetailpage.verifyDatePicker();
        eondetailpage.choosetransactiondate(date);
    }

    @Then("^I should see a date picker for choosing the transaction date with present and future dates are in enable mode for eon account fund transfer$")
    public void i_should_see_a_date_picker_for_choosing_the_transaction_date_with_present_and_future_dates_are_in_enable_mode_for_eon_account_fund_transfer() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eondetailpage.verifyDatePicker();
        eondetailpage.choosetransactiondate(date);
    }

    @When("^I choose future date as \"([^\"]*)\" for eon account fund transfer$")
    public void i_choose_future_date_as_for_eon_account_fund_transfer(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String data[] = arg1.split(" ");
        eondetailpage.choosetransactiondate(date);
    }

    @When("^Click \"([^\"]*)\" button in the datepicker of eon account fund transfer details page$")
    public void click_button_in_the_datepicker_of_eon_account_fund_transfer_details_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        eondetailpage.clickDatePickerOkBtn();
    }

    @Then("^The selected date \"([^\"]*)\" should be displayed in the transaction date field in the eon account fund transfer details page$")
    public void the_selected_date_should_be_displayed_in_the_transaction_date_field_in_the_eon_account_fund_transfer_details_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String data[] = arg1.split(" ");

        String evalue = data[0] + " " + data[1] + ", " + data[2];
        eondetailpage.verifyTransactionDate(evalue);
    }


    @Then("^I'm on \"([^\"]*)\" \"([^\"]*)\" page after providing source and recipient account details in EonAccount$")
    public void iMOnPageAfterProvidingSourceAndRecipientAccountDetailsInEonAccount(String arg0, String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        home.gotoSendRequestTab();
        sendrequest.verifyEONAccountLink(arg0);
        sendrequest.clickEONAccountLink();
        Thread.sleep(3000);
        eonfrompage.chooseTranferFromAccount(PropertyReader.testDataOf("Source_Account"));
        Thread.sleep(3000);
        eontopage.clickSelectFromList();
        Thread.sleep(8000);
        eontopage.clickMyRecipient(PropertyReader.testDataOf("EONRecipient_Account"));
        Thread.sleep(3000);
        eontopage.clickNextBtn();
        //eontopage.clickOKBtn();
        eondetailpage.verifyTransferDetailsPageTile(arg1);

    }

    @When("^I enter Valid OTP \"([^\"]*)\" in eon account transfer page$")
    public void iEnterValidOTPInEonAccountTransferPage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        //Wait.forSeconds(15);
        otp.enterOTP(PropertyReader.testDataOf(arg0));

    }

    @Then("^I should see a \"([^\"]*)\" Successful page$")
    public void iShouldSeeASuccessfulPage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(4);
        eonreviewpage.verifyReviewandTransfertitle(arg0);
        //Wait.forSeconds(3);
    }

    @When("^I click Edit link present in the To account section EON Account$")
    public void iClickEditLinkPresentInTheToAccountSectionEONAccount() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {

            if (Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                Wait.forSeconds(15);
                //Touch.touchLongPress(950, 550, 950, 550);
                eonreviewpage.clickEditlinkToAccount();
            }
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            eonreviewpage.clickEditlinkToAccountios();
        }
    }

    @And("^I choose Every 6 Months as a repeat option from select frequency$")
    public void iChooseEvery6MonthsAsARepeatOptionFromSelectFrequency() throws Throwable {
        {
            turn_on_repeat_toggle_button();
            eondetailpage.clickFrequencyElement();
            eondetailpage. chooseSelectFrequencyEvery6Months();
            eondetailpage.ClickEndDate();
            eondetailpage.SelectDateWeekly();
            eondetailpage.clickDatePickerOkBtn();
        }
    }

    @And("^I choose Quarterly as a repeat option from select frequency$")
    public void iChooseQuarterlyAsARepeatOptionFromSelectFrequency()throws Throwable {

            turn_on_repeat_toggle_button();
            eondetailpage.clickFrequencyElement();
            eondetailpage.chooseSelectFrequencyQuarterly();
            eondetailpage.ClickEndDate();
            eondetailpage.SelectDateWeekly();
            eondetailpage.clickDatePickerOkBtn();
        }


    @And("^I choose Annually as a repeat option from select frequency$")
    public void iChooseAnnuallyAsARepeatOptionFromSelectFrequency() throws Throwable{
        turn_on_repeat_toggle_button();
        eondetailpage.clickFrequencyElement();
        eondetailpage.chooseSelectFrequencyAnnually();
        eondetailpage.ClickEndDate();
        eondetailpage.SelectDateWeekly();
        eondetailpage.clickDatePickerOkBtn();
    }

    @And("^I choose Every (\\d+) weeks as a repeat option from select frequency$")
    public void iChooseEveryWeeksAsARepeatOptionFromSelectFrequency(int arg0)throws Throwable {
        turn_on_repeat_toggle_button();
        eondetailpage.clickFrequencyElement();
        eondetailpage.chooseSelectFrequencyEvery2weeks();
        eondetailpage.ClickEndDate();
        eondetailpage.SelectDateWeekly();
        eondetailpage.clickDatePickerOkBtn();
    }

    @And("^I choose Monthly as a repeat option from select frequency$")
    public void iChooseMonthlyAsARepeatOptionFromSelectFrequency() throws Throwable {
        turn_on_repeat_toggle_button();
        eondetailpage.clickFrequencyElement();
        eondetailpage.chooseSelectFrequencyMonth();
        eondetailpage.ClickEndDate();
        eondetailpage.SelectDateWeekly();
        eondetailpage.clickDatePickerOkBtn();
    }

//    @And("^I choose \"([^\"]*)\" as a repeat option from select frequency$")
//    public void iChooseAsARepeatOptionFromSelectFrequency(String arg0) throws Throwable {
//        {
//            turn_on_repeat_toggle_button();
//            eondetailpage.clickFrequencyElement();
//            eondetailpage.chooseSelectFrequencySemi();
//            eondetailpage.ClickEndDate();
//            eondetailpage.SelectDateWeekly();
//            eondetailpage.clickDatePickerOkBtn();
//        }
//    }

}
