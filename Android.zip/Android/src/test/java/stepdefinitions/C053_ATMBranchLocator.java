package stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import pages.ATMPage;

public class C053_ATMBranchLocator {

    ATMPage atmPage=new ATMPage();
    @And("^User able to click View all option on Dashboard screen and click ATM & BranchLocator option$")
    public void userAbleToClickViewAllOptionOnDashboardScreenAndClickATMBranchLocatorOption() throws Throwable {
        atmPage.clickViewAll();
    }

//    @And("^check if the user able to  verify \"([^\"]*)\" text$")
//    public void checkIfTheUserAbleToVerifyText(String arg0) throws Throwable {
//
//    }

//    @And("^check if the user able to verify the \"([^\"]*)\" and \"([^\"]*)\" options displays on pop up screen$")
//    public void checkIfTheUserAbleToVerifyTheAndOptionsDisplaysOnPopUpScreen(String arg0, String arg1) throws Throwable {
//
//    }

    @And("^check if the user able to verify the \"([^\"]*)\" and \"([^\"]*)\" Tabs on ATM & BranchLocator Screen$")
    public void checkIfTheUserAbleToVerifyTheAndTabsOnATMBranchLocatorScreen(String arg0, String arg1) throws Throwable {
        atmPage.verifyTabOnATMScreen();
    }

    @And("^check if the application allows user to searchBranch on clicking \"([^\"]*)\" Option$")
    public void checkIfTheApplicationAllowsUserToSearchBranchOnClickingOption(String arg0) throws Throwable {
        atmPage.BranchSearchIcon();
    }

    @And("^user able to search for location ofBranch$")
    public void userAbleToSearchForLocationOfBranch() throws Throwable {
        atmPage.verifyBranchATMScreen();
    }


    @Then("^user able to search for location ofATM$")
    public void userAbleToSearchForLocationOfATM() throws Throwable {
        atmPage.ATMsSearchIcon();
    }

    @Then("^check if the application displays the Results on \"([^\"]*)\" in ATM &BranchLocator Screen$")
    public void checkIfTheApplicationDisplaysTheResultsOnInATMBranchLocatorScreen(String arg0) throws Throwable {
        atmPage.verifyATMLocation();

    }

    @Then("^verify if the application displays the Results  on \"([^\"]*)\" in ATM &BranchLocator Screen$")
    public void verifyIfTheApplicationDisplaysTheResultsOnInATMBranchLocatorScreen(String arg0) throws Throwable {
        atmPage.verifyBranchLocation();

    }
}
