package stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.*;
import runners.ConvergentTestRunner;

public class C024_Insurance {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private UITFPage uitfPage = new UITFPage();
    private WesternUnionPage westernUnionPage = new WesternUnionPage();

    ConvergentTestRunner Devicename=new ConvergentTestRunner();
    WelcomePage welcomepage = new WelcomePage();
    Insurance insurancePage = new Insurance();



    @When("^I am on the insurance page$")
    public void i_am_on_the_insurance_page() throws Throwable {
        insurancePage.click_viewInsuranceBtn();
    }

    @Then("^i verify the market place page$")
    public void i_verify_the_market_place_page() throws Throwable {
        insurancePage.Verify_MarketPlacePage();
    }

    @Then("^I verify Inlife purchased product from My Insurances$")
    public void i_verify_Inlife_purchased_product_from_My_Insurances() throws Throwable {
        insurancePage.verify_InlifePurchasedProduct();
    }

    @When("^I cancel the previous accident insurance$")
    public void i_cancel_the_previous_accident_insurance() throws Throwable {
        insurancePage.cancelPreviousAccident();
    }

    @When("^I purchase the accident product$")
    public void i_purchase_the_accident_product() throws Throwable {
        insurancePage.purchase_AccidentProduct();
    }

    @Then("^I verify purchase successful title$")
    public void i_verify_purchase_successful_title() throws Throwable {
        insurancePage.verify_PurchaseSuccessTitle();
    }

    @When("^I click the transactions from Inbox$")
    public void i_click_the_transactions_from_Inbox() throws Throwable {
        insurancePage.click_Transactions();
    }

    @Then("^I verify the details of successful purchased product$")
    public void i_verify_the_details_of_successful_purchased_product() throws Throwable {
        insurancePage.verify_Details_PurchasedProduct();
    }

    @And("^I click compare option on \"([^\"]*)\"$")
    public void iClickCompareOptionOn(String arg0) throws Throwable {
       insurancePage.clickComapre();
    }

    @And("^User able to navigate \"([^\"]*)\" Page and click Select option below \"([^\"]*)\"$")
    public void userAbleToNavigatePageAndClickSelectOptionBelow(String arg0, String arg1) throws Throwable {
       insurancePage.clickSelect();
    }


    @When("^I click \"([^\"]*)\" on Product Page naviagates to Filter Search Page displays with Slider$")
    public void iClickOnProductPageNaviagatesToFilterSearchPageDisplaysWithSlider(String arg0) throws Throwable {
      insurancePage.clickFilter();
    }

    @And("^I am able to filter the amount and click \"([^\"]*)\"\\.$")
    public void iAmAbleToFilterTheAmountAndClick(String arg0) throws Throwable {
        insurancePage.clickSlider();
    }

    @And("^I Choose any Inlife Product on Select a product screen and click \"([^\"]*)\" Option$")
    public void iChooseAnyInlifeProductOnSelectAProductScreenAndClickOption(String arg0) throws Throwable {
        insurancePage.SelectLifeProduct();
    }

    @Then("^I Should see the details in \"([^\"]*)\" for Life Product$")
    public void iShouldSeeTheDetailsInForLifeProduct(String arg0) throws Throwable {
        insurancePage.verifyCompareInsurancesHeader();
    }

    @And("^I click Back Button in \"([^\"]*)\" Page$")
    public void iClickBackButtonInPage(String arg0) throws Throwable {
        insurancePage.clickBackbtn();
    }
}
