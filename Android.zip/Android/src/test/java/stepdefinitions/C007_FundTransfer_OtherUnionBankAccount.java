package stepdefinitions;

import java.awt.Transparency;
import java.time.ZonedDateTime;
import java.time.format.TextStyle;
import java.util.Locale;


import actions.Touch;
import actions.Wait;
import base.Keywords;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverManager;
import helper.PropertyReader;
import pages.*;
import runners.ConvergentTestRunner;
public class C007_FundTransfer_OtherUnionBankAccount {
	
	private WelcomePage welcome = new WelcomePage();
	private LoginPage login = new LoginPage();
	private OTPPage otp = new OTPPage();
	private HomePage home = new HomePage();
	private SendRequestPage sendrequest = new SendRequestPage();
	private TransferFromPage otherUBPfrompage = new TransferFromPage();
	private TransferToPage otherUBPtopage = new TransferToPage();
	private TransferDetailsPage otherUBPdetailpage = new TransferDetailsPage();
	private ReviewandTransferPage otherUBPreviewpage = new ReviewandTransferPage();
	private TransferSuccessfulPage otherUBPsuccesspage=new TransferSuccessfulPage();
	ConvergentTestRunner Devicename=new ConvergentTestRunner();


	//Test data for verification
			private String transferamount;
			private String remarkmsg;
			private String frequency;
			private String date="Today";
			private String repeat="Never";
			private String updatedamount;
			private String refernenceno;
			
			/////
			static String day;		
			static ZonedDateTime zdt = ZonedDateTime.now();
			static String year=Integer.toString(zdt.getYear());
			static String monthName=zdt.getMonth().getDisplayName(TextStyle.FULL,Locale.ENGLISH) ;
			static String dayOfMonth=Integer.toString(zdt.getDayOfMonth());
			
			static String pastdate=Integer.toString(zdt.minusDays(1).getDayOfMonth());
			
			static
			{
				if(dayOfMonth.length()==1)
				{
					day="0"+dayOfMonth;
				}
				else
				{
					day=dayOfMonth;
				}
			}
			private static  String transactiondate=monthName+" "+day+", "+year;

		@Given("^I'm on the landing page of union bank application$")
		public void i_m_on_the_landing_page_of_union_bank_application() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			welcome.clickGotITBtn_Biometrics();
			welcome.clickNext();
			welcome.clickNext();
			welcome.clickNext();
			if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
				welcome.clickNext();
			}
			welcome.clickGetStarted();
			welcome.clickLogin();
			login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
			login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
			login.clickLogin();
			otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
			home.clickContinue();
			home.clickNotNowtoSubscribe();
			home.clickNotNowToTurnOnNotification();
			home.clickNotNowToTurnOnNotification();
			home.clickGotoDashBoard();
		}

		@When("^I choose Send/Request tab from the footer section of union bank$")
		public void i_choose_Send_Request_tab_from_the_footer_section_of_union_bank() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    home.gotoSendRequestTab();
		}

		@Then("^I should see \"([^\"]*)\" link in the \"([^\"]*)\" page$")
		public void i_should_see_link_in_the_page(String arg1, String arg2) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			sendrequest.verifySendRequestTitle(arg2);
			sendrequest.verifyOtherUBPAccountLink(arg1);
		}

		@Given("^I'am on \"([^\"]*)\" page of union bank application$")
		public void i_am_on_page_of_union_bank_application(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			welcome.clickGotITBtn_Biometrics();
			welcome.clickNext();
			welcome.clickNext();
			welcome.clickNext();
			if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
				welcome.clickNext();
			}
			welcome.clickGetStarted();
			welcome.clickLogin();
			login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
			login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
			login.clickLogin();
			otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
			home.clickContinue();
			home.clickNotNowtoSubscribe();
			if(Devicename.currentdevicename.equalsIgnoreCase("ABC") || Devicename.currentdevicename.equalsIgnoreCase("ABC")) {
				home.clickNotNowToTurnOnNotification();
			}
			home.clickNotNowToTurnOnNotification();
			home.clickGotoDashBoard();
			home.gotoSendRequestTab();
			sendrequest.verifySendRequestTitle(arg1);
		}

		@When("^I click on \"([^\"]*)\" fund transfer option from Send/Request page$")
		public void i_click_on_fund_transfer_option_from_Send_Request_page(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			sendrequest.clickOtherUBPAccountLink();
		}

		@When("^choose \"([^\"]*)\" from the list of source accounts in \"([^\"]*)\" page$")
		public void choose_from_the_list_of_source_accounts_in_page(String arg1, String arg2) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			otherUBPfrompage.verifyTransferFromPageTitle(arg2);
			otherUBPfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg1));
		}


		@Then("^I should see a \"([^\"]*)\" page with facility to choose transfer to account details$")
		public void i_should_see_a_page_with_facility_to_choose_transfer_to_account_details(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			otherUBPtopage.verifyTransferToPageTitle(arg1);
		}

		@Given("^I'm on \"([^\"]*)\" \"([^\"]*)\" page with valid credentials$")
		public void i_m_on_page_with_valid_credentials(String arg1, String arg2) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions

			if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
				welcome.clickGotITBtn_Biometrics();
				welcome.closeWelcomeMessages();
				login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
				login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
				login.clickLogin();
				otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
				Wait.forSeconds(2);
				home.clickSubscribeToAppOtpNotNow();
				Wait.forSeconds(2);
				home.clickContinue();
				Wait.forSeconds(2);
//				home.clickNotNowtoSubscribe();
				home.clickNotNowToTurnOnNotification();
				Wait.forSeconds(2);
				home.clickGotoDashBoard();
//				home.clickNotNowfingerprintNotification();
//				home.clickNotNowfingerprintNotification();
				home.verifyIfDashboardIsDisplayed("Dashboard");
				home.gotoSendRequestTab();
				Wait.forSeconds(5);
				sendrequest.verifyOtherUBPAccountLink(arg1);
				sendrequest.clickOtherUBPAccountLink();

				//otherUBPfrompage.verifyTransferFromPageTitle(arg2);
			}
			else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
				login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
				login.clickLogin();
				otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
				Wait.forSeconds(5);
				otp.clickNotnow();
				Wait.forSeconds(5);
				home.gotoSendRequestTabIOS();
				Wait.forSeconds(8);
				sendrequest.verifyOtherUBPAccountLink(arg1);
				sendrequest.clickOtherUBPAccountLink();
				Wait.forSeconds(5);
				otherUBPfrompage.verifyTransferFromPageTitle(arg2);
			}
		}

		@When("^I choose \"([^\"]*)\" from the list of available source accounts$")
		public void i_choose_from_the_list_of_available_source_accounts(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
				otherUBPfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg1));
			}
			else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
				Wait.forSeconds(10);
				otherUBPfrompage.chooseTranferFromAccountios();
			}
		}

		@When("^Enter valid ubp \"([^\"]*)\" in the \"([^\"]*)\" page$")
		public void enter_valid_ubp_in_the_page(String arg1, String arg2) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			otherUBPtopage.verifyTransferToPageTitle(arg2);
			Wait.forSeconds(10);
			otherUBPtopage.enterRecipientAccountubp(PropertyReader.testDataOf(arg1));
			Wait.forSeconds(10);
			otherUBPtopage.enterAccountName("test");
		}

		@Then("^On sucessfull account validation the button NEXT should be enabled in Other UnionBank Account transfer to page$")
		public void on_sucessfull_account_validation_the_button_NEXT_should_be_enabled_in_Other_UnionBank_Account_transfer_to_page() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			Wait.forSeconds(2);
			otherUBPtopage.clickNextBtninstapay();
		}

		@When("^Enter invalid ubp \"([^\"]*)\" in the \"([^\"]*)\" page$")
		public void enter_invalid_ubp_in_the_page(String arg1, String arg2) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			otherUBPtopage.verifyTransferToPageTitle(arg2);
			otherUBPtopage.enterRecipientAccount(PropertyReader.testDataOf(arg1));
		}

		@Then("^on account validation the button NEXT should not be enabled in Other UnionBank Account transfer to page$")
		public void on_account_validation_the_button_NEXT_should_not_be_enabled_in_Other_UnionBank_Account_transfer_to_page() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			Wait.forSeconds(2);
			otherUBPtopage.checkNextBtnDisabled();
		}
		
		@When("^I choose \"([^\"]*)\" from the select My recipient list in \"([^\"]*)\" page$")
		public void i_choose_from_the_select_My_recipient_list_in_page(String arg1, String arg2) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   otherUBPtopage.verifyTransferToPageTitle(arg2);
		   otherUBPtopage.clickSelectFromList();
		   otherUBPtopage.clickMyRecipient(PropertyReader.testDataOf(arg1));
		}

		@When("^I choose \"([^\"]*)\" from the favourite recipient list in \"([^\"]*)\" page$")
		public void i_choose_from_the_favourite_recipient_list_in_page(String arg1, String arg2) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
				otherUBPtopage.verifyTransferToPageTitle(arg2);
				otherUBPtopage.clickSelectFromList();
				Wait.forSeconds(10);
				otherUBPtopage.clickFavouriteRecipient(PropertyReader.testDataOf(arg1));
			}
			else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
				otherUBPtopage.verifyTransferToPageTitle(arg2);
				otherUBPtopage.clickSelectFromList();
				Wait.forSeconds(10);
				otherUBPtopage.clickFavouriteRecipientios();
			}
		}


		@Given("^I'm on \"([^\"]*)\" \"([^\"]*)\" page with \"([^\"]*)\" and \"([^\"]*)\"$")
		public void i_m_on_page_with_and(String arg1, String arg2, String arg3, String arg4) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
            if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
				welcome.clickGotITBtn_Biometrics();
                welcome.closeWelcomeMessages();
                login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
                login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
                login.clickLogin();
                otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
				Wait.forSeconds(8);
                home.clickContinue();
                home.clickNotNowtoSubscribe();
					home.clickNotNowToTurnOnNotification();
                home.clickGotoDashBoard();
//                home.clickNotNowfingerprintNotification();
//                home.clickNotNowfingerprintNotification();
                home.verifyIfDashboardIsDisplayed("Dashboard");
                home.gotoSendRequestTab();
				Wait.forSeconds(8);
                sendrequest.verifyOtherUBPAccountLink(arg1);
                sendrequest.clickOtherUBPAccountLink();
                otherUBPfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg3));
                Wait.forSeconds(8);
                otherUBPtopage.clickSelectFromList();
				Wait.forSeconds(10);
                otherUBPtopage.clickMyRecipient(PropertyReader.testDataOf(arg4));
               // otherUBPtopage.clickNextBtn();
               // otherUBPdetailpage.verifyTransferDetailsPageTile(arg2);

            }
            else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
                login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
                login.clickLogin();
                otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
				Wait.forSeconds(5);
				otp.clickNotnow();
				Wait.forSeconds(5);
                home.gotoSendRequestTabIOS();
				Wait.forSeconds(8);
                sendrequest.verifyOtherUBPAccountLink(arg1);
                sendrequest.clickOtherUBPAccountLink();
				otherUBPfrompage.chooseTranferFromAccountios();
				Wait.forSeconds(5);
				otherUBPtopage.enterRecipientAccount(PropertyReader.testDataOf(arg4));
				Wait.forSeconds(5);
				otherUBPtopage.clickNextBtn();
				otherUBPfrompage.verifyTransferdetailsTitle(arg2);


            }

		}

		@When("^I try to enter non-numeric characters \"([^\"]*)\" in amount field of Other UBP fund \"([^\"]*)\" page$")
		public void i_try_to_enter_non_numeric_characters_in_amount_field_of_Other_UBP_fund_page(String arg1, String arg2) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			otherUBPdetailpage.verifyTransferDetailsPageTile(arg2);
			otherUBPdetailpage.enterTransferAmt(arg1);
		}

		@Then("^The application should not allow to user to keyin non-numeric characters in the amount field section of Other UBP fund Transfer details page$")
		public void the_application_should_not_allow_to_user_to_keyin_non_numeric_characters_in_the_amount_field_section_of_Other_UBP_fund_Transfer_details_page() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			otherUBPdetailpage.checkDefaultTransferAmtval();
		}

		@When("^I enter a transaction amount PHP \"([^\"]*)\" in amount field, which is greater than the account balance$")
		public void i_enter_a_transaction_amount_PHP_in_amount_field_which_is_greater_than_the_account_balance(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			otherUBPdetailpage.enterTransferAmt(arg1);
		}

		@Then("^I should see an error message \"([^\"]*)\" in the Other UBP fund Transfer details page$")
		public void i_should_see_an_error_message_in_the_Other_UBP_fund_Transfer_details_page(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			//otherUBPdetailpage.
//			otherUBPdetailpage.turnONToggleBtn();
			otherUBPdetailpage.verifyAmtErrorMsg(arg1);
		}
		
		@When("^I click on trasanction date with an amount PHP \"([^\"]*)\" in the other UBP account transfer details page$")
		public void i_click_on_trasanction_date_with_an_amount_PHP_in_the_other_UBP_account_transfer_details_page(String arg1) throws Throwable {

			otherUBPdetailpage.enterTransferAmt(arg1);
			Wait.forSeconds(5);
			otherUBPdetailpage.clickTransactionDate();
		}
	
		@Then("^I should see a date picker for choosing the transaction date with the past date in disable mode for Other UBP account fund transfer$")
		public void i_should_see_a_date_picker_for_choosing_the_transaction_date_with_the_past_date_in_disable_mode_for_Other_UBP_account_fund_transfer() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			otherUBPdetailpage.verifyDatePicker();
			otherUBPdetailpage.choosetransactiondate(year, monthName, pastdate);
		}

	

		@Then("^I should see a date picker for choosing the transaction date with present and future dates are in enable mode for other UBP account fund transfer$")
		public void i_should_see_a_date_picker_for_choosing_the_transaction_date_with_present_and_future_dates_are_in_enable_mode_for_other_UBP_account_fund_transfer() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			otherUBPdetailpage.clickTransactionDate();
			//otherUBPdetailpage.verifyDatePicker();
			//otherUBPdetailpage.choosetransactiondate(year, monthName, day);
		}

		@When("^I choose future date from \"([^\"]*)\" for other UBP account fund transfer$")
		public void q23qi_choose_future_date_as_for_other_UBP_account_fund_transfer(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
				String data[] = arg1.split(" ");
				//otherUBPdetailpage.choosetransactiondate(data[2],data[0],data[1]);
				otherUBPdetailpage.choosefuturetransctiondate(arg1);
			}
			else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

              Wait.forSeconds(5);
				Touch.pressByCoordinates(479,454,5);

			}

		}

		@When("^Click \"([^\"]*)\" button in the datepicker of other UBP account fund transfer details page$")
		public void click_button_in_the_datepicker_of_other_UBP_account_fund_transfer_details_page(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
				otherUBPdetailpage.clickDatePickerOkBtn();
				Wait.forSeconds(10);
			}
			else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
				otherUBPdetailpage.clickTransferfrequencydone();
			}
		}

		@Then("^The selected date \"([^\"]*)\" should be displayed in the transaction date field in the other UBP account fund transfer details page$")
		public void the_selected_date_should_be_displayed_in_the_transaction_date_field_in_the_other_UBP_account_fund_transfer_details_page(String arg1) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			otherUBPdetailpage.verifyTransactionDate(arg1);
		}


	@And("^click next button in Another UBP Account fund transfer details page$")
	public void clickNextButtonInAnotherUBPAccountFundTransferDetailsPage() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		Wait.forSeconds(3);
		otherUBPtopage.clickNextBtn();
		Wait.forSeconds(5);
		//Wait.forSeconds(2);
		otherUBPreviewpage.clickGotitButton();
		//
	}

	@Then("^I should see \"([^\"]*)\" page in another UBP fundtransfer$")
	public void iShouldSeePageInAnotherUBPFundtransfer(String arg0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		otherUBPdetailpage.verifyTransferDetailsPageTile(arg0);
	}

	@When("^I enter transaction amount \"([^\"]*)\" PHP in amount field in UBP Account fund transfer details page$")
	public void iEnterTransactionAmountPHPInAmountFieldInUBPAccountFundTransferDetailsPage(String arg0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		transferamount="PHP "+arg0;
		otherUBPdetailpage.enterTransferAmt(arg0);
		Wait.forSeconds(2);
	}

	@When("^I click on \"([^\"]*)\" button in UBP Account review and transfer page$")
	public void iClickOnButtonInUBPAccountReviewAndTransferPage(String arg0) throws Throwable {
		if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

			// Write code here that turns the phrase above into concrete actions
//		Keywords.refreshPage();
//		otherUBPreviewpage.verifyTransferBtn(arg0);
			Wait.forSeconds(10);
//		otherUBPreviewpage.clickTransfer();
			if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
//				Touch.touchLongPress(500, 1075, 500, 1075);
//				Touch.touchLongPress(500, 1325, 500, 1325);
//				Touch.touchLongPress(500, 1475, 500, 1475);
//				Touch.touchLongPress(500, 1650, 500, 1650);
				//otherUBPreviewpage.clickTransferbytext(arg0);
				otherUBPreviewpage.clickTransfer();
			}
		}
		else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
			otherUBPreviewpage.clickTransfer();
		}
	}

	@Then("^I should see a \"([^\"]*)\" page to enter OTP during UBP account transfer scenario$")
	public void iShouldSeeAPageToEnterOTPDuringUBPAccountTransferScenario(String arg0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		otp.verifyPageTitle(arg0);
	}

	@When("^I enter Valid OTP \"([^\"]*)\" for UBP account transfer scenario$")
	public void iEnterValidOTPForUBPAccountTransferScenario(String arg0) throws Throwable {
		Wait.forSeconds(5);
		otp.enterOTP(PropertyReader.testDataOf(arg0));
		Wait.forSeconds(20);
	}

	@Then("^I should see \"([^\"]*)\" screen for UBP account transfer scenario$")
	public void iShouldSeeScreenForUBPAccountTransferScenario(String arg0) throws Throwable {
		otherUBPsuccesspage.verifyTransferSuccessfultitle(arg0);
	}

	@Then("^verify the error message\"([^\"]*)\"$")
	public void verifyTheErrorMessage(String arg0) throws Throwable {
			login.verifyAccountBlockedErrorMessage(arg0);
	}

	@Then("^verify the invalidOTP error message\"([^\"]*)\"$")
	public void verifyTheInvalidOTPErrorMessage(String arg0) throws Throwable {
		login.verifyInvalidOTPErrorMessage(arg0);
	}


	@And("^I navigate \"([^\"]*)\" \"([^\"]*)\" to another union bank fund transfer screen$")
	public void iNavigateToAnotherUnionBankFundTransferScreen(String arg0 ,String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		home.gotoSendRequestTab();
		sendrequest.verifyOtherUBPAccountLink(arg0);
		sendrequest.clickOtherUBPAccountLink();
		otherUBPfrompage.verifyTransferFromPageTitle(arg1);
	}

	@When("^I click on trasanction date button in the transfer details page  page$")
	public void iClickOnTrasanctionDateButtonInTheTransferDetailsPagePage() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		otherUBPdetailpage.clickTransactionDate();
	}

	@Then("^The selected future date from \"([^\"]*)\" should be displayed in the transaction date field in the other UBP account fund transfer details page$")
	public void theSelectedFutureDateFromShouldBeDisplayedInTheTransactionDateFieldInTheOtherUBPAccountFundTransferDetailsPage(String arg0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//otherUBPdetailpage.verifyTransactionfutureDate(arg0);
		otherUBPdetailpage.verifyTransactionDate(arg0);

	}

	@Then("^if i see the gotit button click the gotit button$")
	public void ifISeeTheGotitButtonClickTheGotitButton() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		otherUBPreviewpage.clickGotitButton();

	}

	@Then("^I enter the mail id \"([^\"]*)\" in email field$")
	public void iEnterTheMailIdInEmailField(String arg0) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		otherUBPtopage.enterEmailid(arg0);
	}

    @Then("^I click the account \"([^\"]*)\" in dashboard and store the value UBP tranfser$")
    public void iClickTheAccountInDashboardAndStoreTheValueUBPTranfser(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
        otherUBPdetailpage.storetheEndbalance();
    }

    @Then("^I'm on \"([^\"]*)\" \"([^\"]*)\" page with valid credentials in ubp page$")
    public void iMOnPageWithValidCredentialsInUbpPage(String arg0, String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
//        login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
//        login.clickLogin();
//        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        Wait.forSeconds(10);
        home.gotoSendRequestTabIOS();
		Wait.forSeconds(20);
        //sendrequest.verifyOtherUBPAccountLink(arg1);
        sendrequest.clickOtherUBPAccountLink();
        //otherUBPfrompage.verifyTransferFromPageTitle(arg1);
    }


}
