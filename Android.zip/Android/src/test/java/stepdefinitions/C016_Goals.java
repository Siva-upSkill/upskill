package stepdefinitions;

import actions.Swipe;
import actions.Wait;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;
import driver.DriverManager;
import gherkin.lexer.Pa;
import helper.PropertyReader;
import pages.*;
import runners.ConvergentTestRunner;

import static org.testng.Assert.assertEquals;

public class C016_Goals {
    private LoginPage login = new LoginPage();
    private GoalsPage Goals = new GoalsPage();
    private OTPPage otp = new OTPPage();
    private ReviewandTransferPage ReviewandTransfer = new ReviewandTransferPage();
    ConvergentTestRunner Devicename = new ConvergentTestRunner();


    @When ("^I click Manage button in Goals$")
    public void i_click_Manage_button_in_goals() throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals. clickManageButtonInDashBord();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            Goals.clickAddGoalsInDashBoardIOS();
        }
    }

    @Then ("^i validate Goals title available in Dashboard$")
    public void i_validate_goals_title_available_in_dashboard() throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(5);
            Goals.verifyAddGoalsIsPresentInDashBoard();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.verifyAddGoalsIsPresentInDashBoard();
        }
    }

    @And ("^I navigate to \"([^\"]*)\" screen$")
    public void i_navigate_to_My_Goals_screen(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.verifyMyGoalsPageTitle(arg1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.verifyMyGoalsPageTitle(arg1);
        }
    }

    @And ("^On successful clicking select this goal button \"([^\"]*)\" screen will diaplay$")
    public void on_successful_clicking_select_this_goal_button_my_goals_screen_will_display(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
               // actions.Touch.pressByCoordinates(341, 1163, 5);

                Goals.clickSelectGoals();
            }
            else if (Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")){
                //actions.Touch.pressByCoordinates(533, 1978, 5);
                Goals.clickSelectGoals();

            }

             else{

                Goals.clickSelectGoals();
            }
            Wait.forSeconds(2);

        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickSelectThisGoalInMyGoalPage();
        }
    }

    @And ("^I enter \"([^\"]*)\" goal name and goal amount and navigate to next page$")
    public void i_enter_goal_name_and_goal_amount_and_navigate_to_next_page(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(8);
            Goals.enterGoalName(arg1);
            Goals.clickAdditionInMyGoals();
            //Goals.clickSubstationInMyGoals();
            //Goals.clickNextInMyGoals();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.enterGoalName(arg1);
            //Goals.clickAdditionInMyGoals();
        }
    }

    @Then ("^I validate next button is disabled by default in \"([^\"]*)\" screen$")
    public void i_validate_next_button_is_disabled_by_default_in_my_goal_screen(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.verifyNextButtonIsDisabledInMyGoals();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

        }
    }

    @Then ("^I verify user to initiate transaction less than 5000 PHP$")
    public void i_verify_user_to_initiate_transaction_less_than_5000_PHP() throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.clickSubstationUpTo5000InMyGoalsAndroid();
            Goals.verifySubstationIsDisabledInMyGoals();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickSubstationUpTo5000InMyGoalsAndroid();
            Goals.verifySubstationIsDisabledInMyGoals();
        }
    }

    @Then ("^I navigate to next \"([^\"]*)\" screen$")
    public void i_navigate_to_next_screen(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.clickNextInMyGoals();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickNextInMyGoals();
        }
    }

    @And ("^I able to click on Weekly buttons$")
    public void i_able_to_click_on_weekly_buttons() throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.clickWeeklyInMyGoals();
//            Goals.clickMonthlyInMyGoals();
//            Goals.clickQuarterlyInMyGoals();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickWeeklyInMyGoals();
            Goals.clickMonthlyInMyGoals();
            Goals.clickQuarterlyInMyGoals();
        }
    }

    @Then ("^I verify user to set transaction less than \"([^\"]*)\" PHP$")
    public void i_verify_user_to_set_transaction_less_than_500_php(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.clickAdditionInMyGoals();
            Goals.clickSubstationInMyGoals();
            Goals.clickStartDateInMyGoals();
            Goals.clickOkInDate();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickAdditionInMyGoals();
            Goals.clickSubstationInMyGoals();
            Goals.clickStartDateInMyGoals();
            Goals.clickSaveStartDateInMyGoals();
        }
    }

//    @And ("^On successfuly selecting account in \"([^\"]*)\" system should navigate to next \"([^\"]*)\" screen$")
//    public void on_successfuly_selecting_account_in_select_account_system_should_navigate_to_next_screen(String arg1, String arg2) throws Throwable {
//        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            Goals.clickTapToSelectAccountInMyGoals();
//            //Goals.verifySelectAccountPageTitle(arg1);
//            Goals.clickAccountsInMyGoals();
//            Goals.clickNextInMyGoals();
//            Wait.forSeconds(8);
//            Goals.clickSaveInEditGoalName();
//            Goals.verifyLetsKickStartYourGoalPageTitle(arg2);
//            Wait.forSeconds(8);
//        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
//            Goals.clickTapToSelectAccountInMyGoalsIOS();
//            Goals.verifySelectAccountPageTitle(arg1);
//            Goals.clickAccountsInMyGoals();
//            Goals.clickNextInMyGoals();
//            Goals.verifyLetsKickStartYourGoalPageTitle(arg2);
//        }
//    }

    @Then ("^I click OK DEPOSIT PHP button and navigate to \"([^\"]*)\" screen$")
    public void i_click_ok_deposit_php_button_and_navigate_to_review_and_set_goal_screen(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.clickOkDepositPHP();
            Wait.forSeconds(3);
            Goals.verifyReviewAndSetGoalPageTitle(arg1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickOkDepositPHP();
            Goals.verifyReviewAndSetGoalPageTitle(arg1);
        }
    }

    @Then ("^I click Maybe later button and navigate to  \"([^\"]*)\" screen$")
    public void i_click_maybe_later_button_and_navigate_to_review_and_set_goal_screen(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.clickBackInReviewAndSetGoal();
            Goals.clickYesInHangOn();
            Wait.forSeconds(2);
//            Goals.clickAddGoalsInDashBoardIOS();
            //Goals.clickAdditionInMyGoals();
            Wait.forSeconds(2);
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
                actions.Touch.pressByCoordinates(341, 1163, 5); }
            if (Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30") ){
                //actions.Touch.pressByCoordinates(520, 1882, 5);
                Goals.clickSelectThisGoalInMyGoalPage();
            }
            Wait.forSeconds(2);

            Goals.enterGoalName("test");
            Goals.clickNextInMyGoals();
            Goals.clickStartDateInMyGoals();
            Goals.clickOkInDate();
            Goals.clickTapToSelectAccountInMyGoals();
            Goals.clickAccountsInMyGoals();
            Goals.clickNextInMyGoals();
            Wait.forSeconds(3);
            Goals.clickMaybeLater();
            Wait.forSeconds(5);
            Goals.verifyReviewAndSetGoalPageTitle(arg1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickBackInReviewAndSetGoal();
            Goals.clickYesInHangOn();
            //Wait.forSeconds(2);
//            Goals.clickAddGoalsInDashBoardIOS();
            //Goals.clickAdditionInMyGoals();
            //Wait.forSeconds(2);
            //actions.Touch.pressByCoordinates(341, 1163, 5);
            Goals.clickSelectThisGoalInMyGoalPage();
            Goals.enterGoalName("TestGoal");
            Goals.clickNextInMyGoals();
            Goals.clickStartDateInMyGoals();
            Goals.clickSaveStartDateInMyGoals();
            Goals.clickTapToSelectAccountInMyGoalsIOS();
            Goals.clickAccountsInMyGoals();
            Goals.clickNextInMyGoals();
            Goals.clickMaybeLater();
            Goals.verifyReviewAndSetGoalPageTitle(arg1);
        }
    }

    @Then ("^I validate \"([^\"]*)\" screen and success \"([^\"]*)\" message$")
    public void i_validate_review_and_set_goal_screen_and_success_message(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.verifySuccessmsg();
//            Goals.clickIAgreeInReviewAndSetGoal();
//            Goals.clickStartSavingInReviewAndSetGoal();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickIAgreeInReviewAndSetGoal();
            Goals.clickStartSavingInReviewAndSetGoal();
            Wait.forSeconds(10);
            Goals.verifyEditGoalSuccessfullyMessage(arg2);

        }
    }

    @Then ("^I edit the \"([^\"]*)\" goal \"([^\"]*)\" name$")
    public void i_edit_the_edit_goal_name_goal_name(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            Goals.clickGoalNameEditInReviewAndSetGoal();
            //Goals.verifyEditGoalNamePageTitle(arg1);

            Wait.forSeconds(3);
            Goals.enterEditGoalNametextBox(arg2);
            Goals.clickSaveInEditGoalName();
            Wait.forSeconds(8);
//            Goals.verifyReviewAndSetGoalPageTitle("Review and Set Goal");
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickGoalNameEditInReviewAndSetGoal();
            Goals.verifyEditGoalNamePageTitle(arg1);
            Goals.enterEditGoalNametextBox(arg2);
            Goals.clickSaveInEditGoalName();
            Goals.verifyReviewAndSetGoalPageTitle("Review and Set Goal");
        }
    }

    @Then ("^I edit \"([^\"]*)\" target \"([^\"]*)\" amount$")
    public void i_edit_target_amount(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.clickEditTargetAmountInReviewandSetGoal();
            Goals.verifyEditTargetAmountPageTitle(arg1);
            Goals.clickAdditionInEditTargetAmount();
            Goals.clickSaveInEditTargetAmounnt();
            Wait.forSeconds(10);
            Goals.verifyEditTargetAmountlabelInReviewAndSetGoal(arg2);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickEditTargetAmountInReviewandSetGoal();
            Goals.verifyEditTargetAmountPageTitle(arg1);
            Goals.clickAdditionInEditTargetAmount();
            Goals.clickAdditionInEditTargetAmount();
            Goals.clickSaveInEditTargetAmounnt();
            Goals.verifyEditTargetAmountlabelInReviewAndSetGoal(arg2);

        }
    }

    @Then ("^I edit \"([^\"]*)\" from \"([^\"]*)\" account$")
    public void i_edit_from_account(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.clickEditFromAmountInReviewandSetGoal();
            Wait.forSeconds(10);
            Goals.clickEditAccountInReviewandSetGoal();
            //Goals.verifylabelFromAccountInReviewAndSetGoal(arg2);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickEditFromAmountInReviewandSetGoal();
            Wait.forSeconds(15);
            Goals.clickEditAccountInReviewandSetGoal();
            Goals.verifylabelFromAccountInReviewAndSetGoal(arg2);
        }
    }

    @When ("^I click Top Up button in \"([^\"]*)\" screen$")
    public void i_click_top_up_button_in_goals(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID"))
        {
            Goals.clickGoalsCardInDashBoard();
            Wait.forSeconds(10);
            //Goals.verifyGoalDetailsPageTitle(arg1);
            if (DriverManager.OS.equalsIgnoreCase("ANDROID")){
                //actions.Touch.pressByCoordinates(555, 908, 5);
            Goals.clickTopUpInGoalDetails(); }
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(5);
            Goals.clickGoalsCardInDashBoardIOS();
            //if(Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2126")){
            //actions.Touch.pressByCoordinates(16, 403, 3);
            // }
            Wait.forSeconds(5);
            Goals.verifyGoalDetailsPageTitle(arg1);
            Goals.clickTopUpInGoalDetails();
        }
    }

    @And ("^I select account in \"([^\"]*)\" screen$")
    public void i_select_account_in_select_account_screen(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.verifySelectAccountPageTitle(arg1);
            Goals.clickAccountsInMyGoals();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.verifySelectAccountPageTitle2(arg1);
            Goals.clickAccountsInMyGoals();
        }
    }

    @And ("^I enter \"([^\"]*)\" TopUp amount in \"([^\"]*)\" screen$")
    public void i_enter_topup_amount_in_top_up_goal_screen(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.verifyTopUpGoalPageTitle(arg2);
            Goals.enterTopUpAmount(arg1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.verifyTopUpGoalPageTitle(arg2);
            Goals.enterTopUpAmount(arg1);
        }
    }

    @Then ("^I enter less than 100 \"([^\"]*)\" TopUp amount system should display \"([^\"]*)\" error message$")
    public void i_enter_less_than_100_topup_amount_system_should_display_error_message(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.enterTopUpAmount(arg1);
            //Goals.verifyTopUpAmountErrorMessage(arg2);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

        }
    }

    @Then ("^I enter multiplies \"([^\"]*)\" TopUp amount$")
    public void i_enter_multiplies_topup_amount(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.enterTopUpAmount(arg1);
            Goals.clickNexyTopUpGoal();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.enterTopUpAmount(arg1);
            Goals.clickNexyTopUpGoal();
        }
    }

    @And ("^On successful clicking next button \"([^\"]*)\" screen should display$")
    public void on_successful_clicking_next_button_review_and_top_up_screen_should_display(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            Goals.verifyReviewAndTopUpGoalPageTitle(arg1);
            Wait.forSeconds(5);
            Goals.clickTopUpPHPInReviewAndTopUpGoal();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.verifyReviewAndTopUpGoalPageTitle(arg1);
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2126")){
                actions.Touch.pressByCoordinates(16, 722, 3);
            }
            //Goals.clickTopUpPHP200InReviewAndTopUpGoalIOS();
            //Wait.forSeconds(5);
            // Goals.clickTopUpPHPInReviewAndTopUpGoal();
        }
    }

    @Then ("^On successful clicking Top Up PHP button system should display \"([^\"]*)\" success message$")
    public void on_successful_clicking_top_up_php_button_system_should_display_success_message(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.verifyTopUpSuccessMessage(arg1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(10);
            if(arg1.contentEquals("Top up of PHP 200 success!")) {
                Goals.verifyTopUpSuccess200MessageIOS(arg1);
            }
            else {
                Goals.verifyTopUp100SuccessMessageIOS(arg1);
            }
        }
    }

    @And ("^I click Edit button TopUp amount \"([^\"]*)\" under review and Top Up screen$")
    public void i_click_edit_button_topup_amount_under_review_and_top_up_screen(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.clickEditInReviewAndTopUp();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickEditInReviewAndTopUp();
        }
    }

    @And ("^I edit topup amount \"([^\"]*)\" in \"([^\"]*)\" screen$")
    public void i_edit_topup_amount_in_topup_goal_screen(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.clickMinusTopupBtn();
            Goals.clickNexyTopUpGoal();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.enterTopUpAmount(arg1);
            Goals.clickNexyTopUpGoal();
        }
    }

    @When ("^I click Pause Goal button in \"([^\"]*)\" screen$")
    public void i_click_pause_goal_button_in_goal_details_screen(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //Goals.clickGoalsCardInDashBoard();
            Wait.forSeconds(5);
            //if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
            //    actions.Touch.pressByCoordinates(555, 908, 5); }

            //Goals.clickCloseInSelectAccount();
            //Swipe.swipe.swipeVertical(2,.8,.2,.5);
            Goals.verifyAddGoalsIsPresentInDashBoard();
            Goals.clickExistingGoalsInDashBoard();
            Wait.forSeconds(5);
            Goals.clickPauseGoalInGoalDetails();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickGoalsCardInDashBoardIOS();
            //Goals.clickCloseInSelectAccount();
            //Wait.forSeconds(5);
            Goals.clickPauseGoalInGoalDetails();
        }
    }

    @Then ("^I validate \"([^\"]*)\" Pause Goal \"([^\"]*)\" Success Message$")
    public void i_validate_pause_goal_success_message(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.verifyPauseGoalPageTitle(arg1);
            Goals.clickPauseGoalButtonInPauseGoal();
            Goals.verifyPauseGoalSuccessMessage(arg2);
            Goals.clickPauseGoalOkButtonInPauseGoalp();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.verifyPauseGoalPageTitle(arg1);
            Goals.clickPauseGoalButtonInPauseGoal();
            Goals.verifyPauseGoalSuccessMessage(arg2);
            Goals.clickPauseGoalOkButtonInPauseGoalp();
        }
    }

    @When ("^I click Resume Goal button in \"([^\"]*)\" screen$")
    public void i_click_resume_goal_button_in_goal_details_screen(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //Goals.clickGoalsCardInDashBoard();
            Wait.forSeconds(5);
           // if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
                //actions.Touch.pressByCoordinates(555, 908, 5);
           //     }
           // Goals.clickCloseInSelectAccount();
            Goals.verifyAddGoalsIsPresentInDashBoard();
            Goals.clickExistingGoalsInDashBoard();
            Goals.clickResumeInGoalDetails();
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickResumeInGoalDetails();
        }
    }

    @And ("^I navigate to \"([^\"]*)\" resume screen$")
    public void i_navigate_to_review_and_resume_goal_screen(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.clickNextInMyGoals();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickNextInMyGoals();
            Goals.verifyResumeGoalPageTitle(arg1);
        }
    }

    @Then ("^I click Resume button$")
    public void i_click_resume_button() throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.clickReviewPageResumeBtn();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(15);
            Goals.clickResumeInGoalDetails();
            Wait.forSeconds(15);
        }
    }

    @When ("^I click Withdraw Funds button in \"([^\"]*)\" screen$")
    public void i_click_withdraw_goal_button_in_goal_details_screen(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.verifyAddGoalsIsPresentInDashBoard();
            Goals.clickExistingGoalsInDashBoard();
            Wait.forSeconds(5);
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
                actions.Touch.pressByCoordinates(555, 908, 5); }
           // Goals.clickCloseInSelectAccount();
            Goals.clickWithdrawFundsInGoalDetails();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickGoalsCardInDashBoardIOS();
            //Goals.clickCloseInSelectAccount();
            Goals.clickWithdrawFundsInGoalDetailsIOS();
        }
    }

    @And ("^I enter withdraw \"([^\"]*)\" amount in \"([^\"]*)\" screen$")
    public void i_enter_withdraw_amount_in_withdraw_funds_screen(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.verifyWithdrawFundsPageTitle(arg2);
            Goals.enterWithdrawAmount(arg1);
            Wait.forSeconds(4);
            Goals.clickNextInWithdrawFunds();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.verifyWithdrawFundsPageTitle(arg2);
            Goals.enterWithdrawAmountIOS(arg1);
            Wait.forSeconds(4);
            Goals.clickNextInWithdrawFunds();
        }
    }

    @Then ("^I withdraw amount on clicking withdraw PHP in \"([^\"]*)\" screen$")
    public void i_withdraw_amount_on_clicking_withdraw_php_in_review_and_withdraw_screen(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.verifyReviewAndWithdrawPageTitle(arg1);
            Goals.clickWithdrawPHPInReviewAndWithdraw();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.verifyReviewAndWithdrawPageTitle(arg1);
            Wait.forSeconds(10);
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2126")){
                actions.Touch.pressByCoordinates(16, 722, 5);
            }
            Wait.forSeconds(5);
        }
    }

    @Then ("^I click withdrawPHP confirmation in \"([^\"]*)\" screen$")
    public void i_click_withdrawPHP_confirmation_in_withdraw_confirmation_screen(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.verifyWithdrawConfirmationPageTitle(arg1);
            Goals.clickWithdrawPHPInWithdrawConfirmation();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.verifyWithdrawConfirmationPageTitle(arg1);
            Goals.clickWithdrawPHPInWithdrawConfirmation();
        }
    }

    @Then ("^I validate funds withdrawn successfully \"([^\"]*)\" message$")
    public void i_validate_funds_withdraw_successfully_message(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.verifyWithdrawnSuccessfullyMessage(arg1);
            Goals.clickViewGoalInWithdrawnSuccessfully();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(10);
            Goals.verifyWithdrawnSuccessfullyMessage(arg1);
            //Goals.clickViewGoalInWithdrawnSuccessfully();
        }
    }

    @And ("^I do Topup \"([^\"]*)\" to achive goal$")
    public void i_do_topup_to_achive_goal(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.clickGoalsCardInDashBoard();
            Wait.forSeconds(5);
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
                actions.Touch.pressByCoordinates(555, 908, 5); }
            Goals.clickAccountsInMyGoals();
            Goals.enterTopUpAmount(arg1);
            Goals.clickNexyTopUpGoal();
            Goals.clickTopUpPHPInReviewAndTopUpGoal();
            Goals.clickViewGoalInWithdrawnSuccessfully();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.clickGoalsCardInDashBoardIOS();
            Goals.clickTopUpInGoalDetails();
            Goals.clickAccountsInMyGoals();
            Goals.enterTopUpAmount(arg1);
            Goals.clickNexyTopUpGoal();
            Wait.forSeconds(7);
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2126")){
                actions.Touch.pressByCoordinates(16, 722, 5);
            }
            Wait.forSeconds(10);
            Goals.clickViewGoalInWithdrawnSuccessfully();
        }
    }

    @When ("^I click Withdraw button in \"([^\"]*)\" screen$")
    public void i_click_withdraw_button_in_goal_details_screen(String arg1) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //Goals.verifyGoalDetailsPageTitle(arg1);
            Wait.forSeconds(5);
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
                actions.Touch.pressByCoordinates(555, 908, 5); }
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.verifyGoalDetailsPageTitle(arg1);
            Wait.forSeconds(5);
            Goals.clickWithdrawFundsInIOSGoalDetails();

        }
    }

    @Then ("^I click WithdrawClose button \"([^\"]*)\" and validate withdraw success \"([^\"]*)\" message$")
    public void i_click_withdrawclose_button_and_validate_withdraw_success_message(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.verifyWithdrawAndCloseGoalPageTitle(arg1);
            Goals.clickWithdrawAndCloseInWithdrawAndCloseGoal();
            Goals.verifySuccessmessageInWithdrawAndCloseGoal(arg2);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Goals.verifyWithdrawAndCloseGoalPageTitle(arg1);
            Goals.clickWithdrawAndCloseInWithdrawAndCloseGoal();
            Goals.verifySuccessmessageInWithdrawAndCloseGoal(arg2);
        }
    }

    @When("^I click On View History in Goals$")
    public void iClickOnViewHistoryInGoals() throws Throwable {
        Wait.forSeconds(3);
        Goals.clickViewHistory();
    }

    @And("^I able to click \"([^\"]*)\" Goals in DashboardPage$")
    public void iAbleToClickGoalsInDashboardPage(String arg0) throws Throwable {
        Wait.forSeconds(2);
        Goals.clickGoals();
    }

    @And("^I able to click Edit button on Details Screen$")
    public void iAbleToClickEditButtonOnDetailsScreen() throws Throwable {
        Wait.forSeconds(2);
        Goals.clickEditBtn();
    }

    @Then("^I verify user to click on Weekly Monthly and Quaterly buttons$")
    public void iVerifyUserToClickOnWeeklyMonthlyAndQuaterlyButtons() throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.verifyQuarterlyInMyGoals();
            Goals.verifyWeeklyInMyGoals();
            Goals.verifyMonthlyInMyGoals();
        }
    }

    @And("^I able to click Next btn and click Save$")
    public void iAbleToClickNextBtnAndClickSave() throws Throwable {
        Goals.clickNextInMyGoals();
        Goals.clickSaveInEditGoalName();
    }

    @And("^On successfully selecting account in \"([^\"]*)\" system should navigate to next screen$")
    public void onSuccessfullySelectingAccountInSystemShouldNavigateToNextScreen(String arg0) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Goals.clickTapToSelectAccountInMyGoals();
            //Goals.verifySelectAccountPageTitle(arg1);
//            Goals.clickAccountsInMyGoals();
            Goals.clickNextInMyGoals();
            Wait.forSeconds(8);
            Goals.clickSaveInEditGoalName();
        }
    }

    @Then("^I Verify the Success Msg \"([^\"]*)\"$")
    public void iVerifyTheSuccessMsg(String arg0) throws Throwable {
        Wait.forSeconds(3);
        Goals.verifyGoalNameSuccessMsg();
    }

    @And("^I able to click \"([^\"]*)\" in DashboardPage$")
    public void iAbleToClickInDashboardPage(String arg0) throws Throwable {
        Wait.forSeconds(2);
        Goals.clickGoals();
    }

    @And("^I able to click the Edit Button to Edit target amount on Details Screen$")
    public void iAbleToClickTheEditButtonToEditTargetAmountOnDetailsScreen() throws Throwable {
        Wait.forSeconds(3);
        Goals.clickGoalNameEdit();
    }

    @And("^On successfully selecting Another account in \"([^\"]*)\" system should navigate to next screen$")
    public void onSuccessfullySelectingAnotherAccountInSystemShouldNavigateToNextScreen(String arg0) throws Throwable {
        Wait.forSeconds(3);
        Goals.clickSelectAnotherAccount();
    }

    @And("^I able to click Goal Name Edit button on Details Screen$")
    public void iAbleToClickGoalNameEditButtonOnDetailsScreen() throws Throwable {
        Wait.forSeconds(3);
        Goals.clickGoalNameEdit();
    }

    @Then("^I should verify \"([^\"]*)\" and \"([^\"]*)\" on Select action Popup\\.$")
    public void iShouldVerifyAndOnSelectActionPopup(String arg0, String arg1) throws Throwable {

    }

    @And("^user should navigate to Goal History page on clicking View History action$")
    public void userShouldNavigateToGoalHistoryPageOnClickingViewHistoryAction() {
    }

    @And("^user should verify the Name , Status, Goal Amount on Goal History Page\\.$")
    public void userShouldVerifyTheNameStatusGoalAmountOnGoalHistoryPage() {
    }

    @And("^I click Back button on \"([^\"]*)\"$")
    public void iClickBackButtonOn(String arg0) throws Throwable {

    }

    @When("^I click Add button in Goals$")
    public void iClickAddButtonInGoals() {
    }

    @And("^On successfuly selecting account in \"([^\"]*)\" system should navigate to next \"([^\"]*)\" screen$")
    public void onSuccessfulySelectingAccountInSystemShouldNavigateToNextScreen(String arg0, String arg1) throws Throwable {

    }

    @And("^I should see the \"([^\"]*)\" after clicking StartSaving in \"([^\"]*)\" page$")
    public void iShouldSeeTheAfterClickingStartSavingInPage(String arg0, String arg1) throws Throwable {

    }
}

