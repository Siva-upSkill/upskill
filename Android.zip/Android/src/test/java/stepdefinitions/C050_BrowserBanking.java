package stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.BrowserBanking;

public class C050_BrowserBanking {
    BrowserBanking browserBanking=new BrowserBanking();
    @And("^User click \"([^\"]*)\" option on Footer Section\\.$")
    public void userClickOptionOnFooterSection(String arg0) throws Throwable {
        browserBanking.clickMoreTab();
    }

    @And("^Verify application display \"([^\"]*)\" on MoreTab Page$")
    public void verifyApplicationDisplayOnMoreTabPage(String arg0) throws Throwable {
        browserBanking.verifyBrowserBanking();
    }

    @And("^user able to click \"([^\"]*)\" on More tab$")
    public void userAbleToClickOnMoreTab(String arg0) throws Throwable {
       browserBanking.clickBrowserBanking();
    }

    @When("^user able to \"([^\"]*)\" the Browser banking option$")
    public void userAbleToTheBrowserBankingOption(String arg0) throws Throwable {
        browserBanking.clickToggleoff();
    }

    @Then("^verify the confirm Popup message \"([^\"]*)\"$")
    public void verifyTheConfirmPopupMessage(String arg0) throws Throwable {
        browserBanking.verifyDisablePopUpMsg();
    }


    @And("^verify the success message and click ok$")
    public void verifyTheSuccessMessageAndClickOk() throws Throwable {
        browserBanking.verifySucessmsg();
    }

    @And("^user able to \"([^\"]*)\" the Enable Browser Banking option$")
    public void userAbleToTheEnableBrowserBankingOption(String arg0) throws Throwable {
        browserBanking.clickToggleOn();
    }

    @And("^User verify Enabling Popup message appears$")
    public void userVerifyEnablingPopupMessageAppears() throws Throwable {
        browserBanking.verifyEnablePopUpMsg();
    }

    @And("^application Navigates to Transaction Limits page on clicking \"([^\"]*)\" option$")
    public void applicationNavigatesToTransactionLimitsPageOnClickingOption(String arg0) throws Throwable {
       browserBanking.clickTransactionLimit();
    }

    @And("^user click \"([^\"]*)\" FundTransfer$")
    public void userClickFundTransfer(String arg0) throws Throwable {
        browserBanking.clickTransferType();
    }

    @And("^user select php amount Limit displays on \"([^\"]*)\"$")
    public void userSelectPhpAmountLimitDisplaysOn(String arg0) throws Throwable {
       browserBanking.clickLimitAmount();
    }

    @And("^user click Save button$")
    public void userClickSaveButton() throws Throwable {
        browserBanking.clickSave();

    }

    @And("^verify the success message on clicking \"([^\"]*)\"\\.$")
    public void verifyTheSuccessMessageOnClicking(String arg0) throws Throwable {
        browserBanking.clickGoToSettings();
    }

    @And("^verify application displays \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" below MoreInfo Header\\.$")
    public void verifyApplicationDisplaysBelowMoreInfoHeader(String arg0, String arg1, String arg2) throws Throwable {
        browserBanking.verifyMoreInfo();
    }
}
