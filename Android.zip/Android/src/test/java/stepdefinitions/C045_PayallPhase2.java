package stepdefinitions;

import actions.Swipe;
import actions.Wait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import pages.PayallPhase2Page;

public class C045_PayallPhase2 {

    PayallPhase2Page payall = new PayallPhase2Page();


    @And("^I click from account number$")
    public void iClickFromAccountNumber() throws Throwable {
        payall.ClickFromAccount();
    }

    @And("^User verify the paydirect reminders$")
    public void userVerifyThePaydirectReminders() throws Throwable {
        payall.PayDirectReminders();
    }

    @And("^user click the gotit button in paydirect reminders page$")
    public void userClickTheGotitButtonInPaydirectRemindersPage() throws Throwable {
        payall.clickGotItBtn();

    }

    @Then("^user enter account number and name of the target account$")
    public void userEnterAccountNumberAndNameOfTheTargetAccount() throws Throwable {
        payall.EnterAccountNoAndName();
    }

    @And("^User click next btn$")
    public void userClickNextBtn() throws Throwable {
        payall.ClickNext();
    }

    @Then("^user enter amount details in pay direct page which is lesser than quoted amount$")
    public void userEnterAmountDetailsInPayDirectPageWhichIsLesserThanQuotedAmount() throws Throwable {
        payall.EnterLesserAmount();
    }

    @And("^verify the inline message for invalid amount entered$")
    public void verifyTheInlineMessageForInvalidAmountEntered() throws Throwable {
        payall.VerifyInvalidAmountMessage();
    }

    @Then("^user enter the amount  in pay direct page which is greater than quoted amount$")
    public void userEnterTheAmountInPayDirectPageWhichIsGreaterThanQuotedAmount() throws Throwable {
        payall.EnterGreaterAmount();
    }

    @Then("^user enter the proper amount details in pay direct page$")
    public void userEnterTheProperAmountDetailsInPayDirectPage() throws Throwable {
        payall.EnterAmount();
    }

    @Then("^user select the purpose of transaction$")
    public void userSelectThePurposeOfTransaction() throws Throwable {
        payall.SelectPurpose();

    }

    @Then("^verify application navigates to review and paypage$")
    public void verifyApplicationNavigatesToReviewAndPaypage() throws Throwable {
        payall.VerifyReviewAndPayHeader();
    }

    @And("^check the target account details and click to pay$")
    public void checkTheTargetAccountDetailsAndClickToPay() throws Throwable {
        payall.VerifyTargetAccount();
    }

    @And("^user click cancel button$")
    public void userClickCancelButton() throws Throwable {
        payall.ClickCancelButton();
    }

    @And("^user click Yes cancel payment$")
    public void userClickYesCancelPayment() throws Throwable {
        payall.ClickYesyCancelPayment();
    }

    @Then("^user enter account number and name of the target account for other bank$")
    public void userEnterAccountNumberAndNameOfTheTargetAccountForOtherBank() throws Throwable {
        payall.EnterAccNumOtherBank();
    }

    @And("^User click to proceed with payment$")
    public void userClickToProceedWithPayment() throws Throwable {
        payall.ProceedWithPayment();
    }

    @Then("^user select the purpose of transaction for other bank$")
    public void userSelectThePurposeOfTransactionForOtherBank() throws Throwable {
        payall.SelectPurposeOtherBank();
    }

    @And("^I Click UBaccount link$")
    public void iClickUBaccountLink() throws Throwable{
        payall.ClickAnotherUnionBankAccount();
    }

    @And("^I select the bank BDO Network Bank from listbox$")
    public void iSelectTheBankBDONetworkBankFromListbox()throws Throwable {
        Wait.forSeconds(10);
        payall.clickBankPesonet();
        Wait.forSeconds(10);
        payall.selectBankName();
    }

}
