package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.EasyPayment_Page;

public class C036_EasyPayment {

    EasyPayment_Page easyPayment_page = new EasyPayment_Page();

    @When("^User to select the credit card accounts under Send from which Account Screen$")
    public void userToSelectTheCreditCardAccountsUnderSendFromWhichAccountScreen() throws Throwable {
        easyPayment_page.ClickCreditCard();
    }
    @Then("^Verify if application display EasyPayment Pay Via Credit screen$")
    public void verifyIfApplicationDisplayEasyPaymentPayViaCreditScreen() throws Throwable {
        easyPayment_page.VerifyEasyPayment();
    }
    @And("^Verify that Pay To screen details$")
    public void verifyThatPayToScreenDetails() throws Throwable {
        easyPayment_page.VerifyPayToScreenDetails();
    }
    @When("^I enter the UBP account number and account name in EasyPayment$")
    public void iEnterTheUBPAccountNumberAndAccountNameInEasyPayment() throws Throwable {
        easyPayment_page.EnterAccountNumberAndAccountName();
    }
    @Then("^Verify whether the application navigates to Easy Payment Details screen$")
    public void verifyWhetherTheApplicationNavigatesToEasyPaymentDetailsScreen() throws Throwable {
        easyPayment_page.VerifyEasyPaymentDetailsHeader();
    }
    @And("^Verify whether the application displays the following fields under Easy Payment Details Screen$")
    public void verifyWhetherTheApplicationDisplaysTheFollowingFieldsUnderEasyPaymentDetailsScreen() throws Throwable {
//        easyPayment_page.VerifyEasyPaymentDetailsScreen();
    }
    @When("^User enter the amount under Amount to Pay field under Easy Payment Details screen$")
    public void userEnterTheAmountUnderAmountToPayFieldUnderEasyPaymentDetailsScreen() throws Throwable {
        easyPayment_page.ClickAmount();
    }
   @Then("^Verify whether the in-line message under Amount to Pay field turns red if the amount entered is below PHP (\\d+)$")
   public void verifyWhetherTheInLineMessageUnderAmountToPayFieldTurnsRedIfTheAmountEnteredIsBelowPHP(int arg0) throws Throwable {
      easyPayment_page.ValidationMinimumErrorMessage();
   }
   @And("^Verify whether the in-line message under Amount to Pay field turns red if the amount entered is above PHP (\\d+),(\\d+)$")
   public void verifyWhetherTheInLineMessageUnderAmountToPayFieldTurnsRedIfTheAmountEnteredIsAbovePHP(int arg0, int arg1) throws Throwable {
       easyPayment_page.ValidationMaximumErrorMessage();
   }
    @And("^Verify whether the Processing Fee displayed is always (\\d+)%$")
    public void verifyWhetherTheProcessingFeeDisplayedIsAlways(int arg0) throws Throwable {
        easyPayment_page.VerifyProcessing();
    }
    @When("^Verify whether the application displays a purpose dropdown list once clicked on Purpose Field$")
    public void verifyWhetherTheApplicationDisplaysAPurposeDropdownListOnceClickedOnPurposeField() throws Throwable {
       easyPayment_page.VerifyPurposeDrop_Down();
    }
    @Then("^Verify whether the application displays all purposes list$")
    public void verifyWhetherTheApplicationDisplaysAllPurposesList() throws Throwable {
        easyPayment_page.ClickDrop_Down();
    }
    @When("^User select any purpose dropdown values once clicked on Purpose Field$")
    public void userSelectAnyPurposeDropdownValuesOnceClickedOnPurposeField() throws Throwable {
        easyPayment_page.ClickSchoolFee();
    }
    @Then("^Verify whether the application displays  under the field Allowed number of payments this month$")
    public void verifyWhetherTheApplicationDisplaysUnderTheFieldAllowedNumberOfPaymentsThisMonth() throws Throwable {
        easyPayment_page.VerifyAllowedPayments();
    }
    @And("^Verify whether the application displays under the field Available Credit Limit is$")
    public void verifyWhetherTheApplicationDisplaysUnderTheFieldAvailableCreditLimitIs() throws Throwable {
        easyPayment_page.VerifyCardLimit();
    }
    @And("^Verify whether the application displays the reminder message$")
    public void verifyWhetherTheApplicationDisplaysTheReminderMessage() throws Throwable {
        easyPayment_page.VerifyReminderMessage();
    }
    @When("^User click Next Button is clicked on EasyPayment Details Screen$")
    public void userClickNextButtonIsClickedOnEasyPaymentDetailsScreen() throws Throwable {
        easyPayment_page.NextButton();
    }
    @Then("^Verify whether the application displays the following fields under Review & Pay Screen$")
    public void verifyWhetherTheApplicationDisplaysTheFollowingFieldsUnderReviewPayScreen() throws Throwable {
        easyPayment_page.VerifyReviewPaymentScreen();
    }
    @And("^Verify whether the Reminder spiel is displayed having description$")
    public void verifyWhetherTheReminderSpielIsDisplayedHavingDescription() throws Throwable {
        easyPayment_page.VerifyReminderMessage();
    }
    @And("^Verify whether the application displays Terms & Conditions$")
    public void verifyWhetherTheApplicationDisplaysTermsConditions() throws Throwable {
        easyPayment_page.VerifyTermsAndCondition();
    }
    @When("^User able to click on Pay button$")
    public void userAbleToClickOnPayButton() throws Throwable {
        easyPayment_page.ClickPayPHP();
    }
    @Then("^Verify whether a popup is displayed having a Information animation,Reminder message & CTA Got it$")
    public void verifyWhetherAPopupIsDisplayedHavingAInformationAnimationReminderMessageCTAGotIt() throws Throwable {
        easyPayment_page.VerifyInformationPage();
    }
    @And("^Verify whether the application navigates to OTP screen once clicked on Got It Button in Pop-up message$")
    public void verifyWhetherTheApplicationNavigatesToOTPScreenOnceClickedOnGotItButtonInPopUpMessage() throws Throwable {
        easyPayment_page.ClickGotIt();
    }
    @Then("^I Verify the Fromaccount and Toaccount and Amount and Purpose$")
    public void iVerifyTheFromaccountAndToaccountAndAmountAndPurpose() throws Throwable {
        easyPayment_page.VerifyTransactionPaymentDetailsPage();

    }
    @And("^I select the Account number from saved recipient EasyPayment$")
    public void iSelectTheAccountNumberFromSavedRecipientEasyPayment() throws Throwable {
        easyPayment_page.ClickSelectRecipients();
    }
    @And("^User able to enter From account Amount under Pay to another UnionBank account section$")
    public void userAbleToEnterFromAccountAmountUnderPayToAnotherUnionBankAccountSection() throws Throwable {
        easyPayment_page.EnterPhp();
    }
    @And("^Then Verify whether a popup is displayed having a Information animation,Reminder message & CTA Got it$")
    public void thenVerifyWhetherAPopupIsDisplayedHavingAInformationAnimationReminderMessageCTAGotIt() throws Throwable {
        easyPayment_page.VerifyInformationPage();
    }
    @And("^User click on  the 'Cancel' button in 'Review & Pay' Screen$")
    public void userClickOnTheCancelButtonInReviewPayScreen() throws Throwable {
        easyPayment_page.ClickCancel();
    }
    @Then("^Verify whether the application displays popup message with the heading 'Do you Wish to Cancel This Payment' once clicked on Cancel Button$")
    public void verifyWhetherTheApplicationDisplaysPopupMessageWithTheHeadingDoYouWishToCancelThisPaymentOnceClickedOnCancelButton() throws Throwable {
        easyPayment_page.VerifyPopUpMessages();
    }
    @When("^User clicked on the button 'No, Continue Payment option$")
        public void userClickedOnTheButtonNoContinuePaymentOption () throws Throwable {
            easyPayment_page.ClickNoCta();
    }
    @Then("^Verify that the application should displayed in the 'Review & Pay' Screen$")
        public void verifyThatTheApplicationShouldDisplayedInTheReviewPayScreen () throws Throwable {
//            easyPayment_page.VerifyDetails();
    }
    @When("^User clicked on the button 'Yes, Cancel Payment'$")
        public void userClickedOnTheButtonYesCancelPayment () throws Throwable {
            easyPayment_page.ClickYesCta();
    }
    @Then("^Verify that the application should navigate to 'Send/Receive' Money Screen$")
        public void verifyThatTheApplicationShouldNavigateToSendReceiveMoneyScreen () {
    }
    @When("^I click the amount  edit button and enter amount click update$")
    public void iClickTheAmountEditButtonAndEnterAmountClickUpdate() throws Throwable {
        easyPayment_page.ClickEdit();
    }

    @And("^I Verify the Transaction Details$")
    public void iVerifyTheTransactionDetails() throws Throwable {
        easyPayment_page.VerifyTransactionPaymentDetailsValuesPage();

    }

    @And("^I Verify the Transaction Details  after edit$")
    public void iVerifyTheTransactionDetailsAfterEdit() throws Throwable {
        easyPayment_page.VerifyTransactionPaymentDetailsValuesPage_Edit();
    }
}

