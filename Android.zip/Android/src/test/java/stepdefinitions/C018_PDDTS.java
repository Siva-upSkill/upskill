package stepdefinitions;

import actions.Wait;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import helper.PropertyReader;
import pages.*;
import runners.ConvergentTestRunner;


public class C018_PDDTS {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private SendRequestPage sendrequest = new SendRequestPage();
    private PesonetPage pesonet = new PesonetPage();
    private TransferDetailsPage transferDetailsPage = new TransferDetailsPage();
    private TransferToPage transferToPage = new TransferToPage();
    private TransferSuccessfulPage ownsuccesspage = new TransferSuccessfulPage();
    private ReviewandTransferPage otherreviewpage = new ReviewandTransferPage();
    private TransferFromPage otherfrompage = new TransferFromPage();
    private TransferToPage othertopage = new TransferToPage();
    private TransferDetailsPage otherdetailpage = new TransferDetailsPage();
    private AccountDetailsPage accountdetailspage = new AccountDetailsPage();
    private TransferFromPage pesonetfrompage = new TransferFromPage();
    private ReviewandTransferPage pesonetreviewpage = new ReviewandTransferPage();
    private ManageReceipentPage mangerecepent = new ManageReceipentPage();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();
    private TransferDetailsPage transferdetails=new TransferDetailsPage();

    @And("^I should see \"([^\"]*)\" link and click the otherbank link$")
    public void iShouldSeeLinkAndClickTheOtherbankLink(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.clickOtherBanksExist();
        sendrequest.clickOtherBanks();
    }

    @Then("^I verify the PDDTS links presented in this screen$")
    public void iVerifyThePDDTSLinksPresentedInThisScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.verifypddtsisexist();
    }

    @And("^I click the PDDTS from this screen$")
    public void iClickThePDDTSFromThisScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.clickpddts();
    }


    @Then("^I naviagted to PDDTS \"([^\"]*)\" Page$")
    public void iNaviagtedToPDDTSPage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(5);
        othertopage.verifyTransferToPageTitle(arg0);
    }

    @And("^I choose Recipient Account \"([^\"]*)\" from my recipient to transfer$")
    public void iChooseRecipientAccountFromMyRecipientToTransfer(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        pesonet.clickSelectFromRecipient();
        pesonet.clickAccNumselect(arg0);
    }


    @And("^I enter the recipent address details unit no \"([^\"]*)\" street \"([^\"]*)\" village \"([^\"]*)\" province \"([^\"]*)\" city \"([^\"]*)\"$")
    public void iEnterTheRecipentAddressDetailsUnitNoStreetVillageProvinceCity(String arg0, String arg1, String arg2, String arg3, String arg4) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        othertopage.entertheRecipientdetails(arg0,arg1,arg2,arg3,arg4);
    }

    @Then("^I should see the \"([^\"]*)\" page$")
    public void iShouldSeeThePage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        othertopage.verifyTransferToPageTitle(arg0);
    }

    @And("^I enter the transfer amount less than \"([^\"]*)\" USD$")
    public void iEnterTheTransferAmountLessThanUSD(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferdetails.enterTransferAmt(arg0);
    }

    @Then("^I verify the Error message \"([^\"]*)\" in PDDTS$")
    public void iVerifyTheErrorMessageInPDDTS(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferdetails.verifytransferdetailsErrorMsg(arg0);
    }

    @Then("^I verify the Error message \"([^\"]*)\" in PDDTS page$")
    public void iVerifyTheErrorMessageInPDDTSPage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferdetails.verifyAmtisgreaterthanaccountbalanceErrorMsg(arg0);
    }

    @And("^I select the source account \"([^\"]*)\" from the \"([^\"]*)\" page$")
    public void iSelectTheSourceAccountFromThePage(String arg0, String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        othertopage.verifyTransferToPageTitle(arg1);
        otherfrompage.chooseTranferFromAccountUSD(arg0);

    }

    @Given("^I'm on Welcome page in Convergent mobile application multiple usd accont user$")
    public void iMOnWelcomePageInConvergentMobileApplicationMultipleUsdAccontUser() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        welcome.clickGotITBtn_Biometrics();
        welcome.closeWelcomeMessages();
        login.enterUsername(PropertyReader.testDataOf("AccountUSD_UserID"));
        login.enterPassword(PropertyReader.testDataOf("AccountUSD_Password"));
        login.clickLogin();
        Wait.forSeconds(15);
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        Wait.forSeconds(30);
        home.clickContinue();
        home.clickNotNowtoSubscribe();
        home.clickNotNowToTurnOnNotification();
        home.clickNotNowToTurnOnNotification();
        home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
        Wait.forSeconds(15);
        home.verifyIfDashboardIsDisplayed("Dashboard");
        Wait.forSeconds(15);
    }

    @And("^I enter the transfer amount is \"([^\"]*)\" USD in Transfer details page$")
    public void iEnterTheTransferAmountIsUSDInTransferDetailsPage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferdetails.enterTransferAmt(arg0);
    }

    @And("^I click the transfer USD button in Review and Transfer page$")
    public void iClickTheTransferUSDButtonInReviewAndTransferPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otherreviewpage.clickTransfer();
    }

    @Then("^i should see the pop up message before successful and verify decscription \"([^\"]*)\" and title \"([^\"]*)\"$")
    public void iShouldSeeThePopUpMessageBeforeSuccessfulAndVerifyDecscription(String arg0,String arg1) throws Throwable {
        otherreviewpage.verifyReviewandTransferpopuptitle(arg1);
        otherreviewpage.verifyReviewandTransferpopupdecr(arg0);
    }

    @And("^I click the proceed with transfer transfer button$")
    public void iClickTheProceedWithTransferTransferButton() throws Throwable {
        pesonet.clickProceedWithTransfer();
    }

    @And("^I Verify the \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" in Review and Transfer Page$")
    public void iVerifyTheAndAndAndInReviewAndTransferPage(String arg0, String arg1, String arg2, String arg3) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otherreviewpage.verifyReviewandTransferscreen(arg0,arg1,arg2,arg3);
    }

    @Then("^I enter \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" in \"([^\"]*)\" PDDTS page$")
    public void i_enter_in_PDDTS_page(String arg1, String arg2, String arg3, String arg4) throws Throwable {
        Wait.forSeconds(3);
        pesonet.clickBankPDDTS();
        Wait.forSeconds(3);
//        pesonet.selectBankName();
        Wait.forSeconds(3);
        pesonet.enterAccountNumber(PropertyReader.testDataOf(arg2));
        Wait.forSeconds(3);
        pesonet.enterAccountName(PropertyReader.testDataOf(arg3));
    }


//    @And("^I Should see the \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" options in send money page$")
//    public void iShouldSeeTheOptionsInSendMoneyPage(String arg0, String arg1, String arg2) throws Throwable {
//        pesonet.verifyOptions_SendMoney();
//
//    }
    @Then("^I should verify the Remaining FundTransfer Limit in TransferDetails$")
    public void iShouldVerifyTheRemainingFundTransferLimitInTransferDetails() throws Throwable {
        pesonet.verifyRemainingTransactionlimit();

    }
    @Then("^I should verify the \"([^\"]*)\",\"([^\"]*)\"in TransferDetails Page$")
    public void iShouldVerifyTheInTransferDetailsPage(String arg0, String arg1) throws Throwable {
        pesonet.verifyTransactionLimit();
    }

    @And("^I should click Edit option in \"([^\"]*)\" and select Account Send From page$")
    public void iShouldClickEditOptionInAndSelectAccountSendFromPage(String arg0) throws Throwable {
        pesonet.clickFromEditbtn();
    }

    @And("^I should click Edit option in \"([^\"]*)\" and select Account Transfer To page$")
    public void iShouldClickEditOptionInAndSelectAccountTransferToPage(String arg0) throws Throwable {
        pesonet.clickToEditBtn();
    }

    @And("^I should click Edit option in \"([^\"]*)\" and edit the USD Amount$")
    public void iShouldClickEditOptionInAndEditTheUSDAmount(String arg0) throws Throwable {
       pesonet.clickAmtEditBtn();
    }

    @And("^verify application displays popup message Having \"([^\"]*)\" and \"([^\"]*)\" option$")
    public void verifyApplicationDisplaysPopupMessageHavingAndOption(String arg0, String arg1) throws Throwable {
        pesonet.clickBackbtn();
    }

    @And("^I click No Option in Cancel Transfer popup msg$")
    public void iClickNoOptionInCancelTransferPopupMsg() throws Throwable {
        pesonet.clickNoBtn();
    }

    @And("^verify application displays \"([^\"]*)\" , \"([^\"]*)\" option on Important popup message\\.$")
    public void verifyApplicationDisplaysOptionOnImportantPopupMessage(String arg0, String arg1) throws Throwable {
        pesonet.verifyPopUp();
    }
}
