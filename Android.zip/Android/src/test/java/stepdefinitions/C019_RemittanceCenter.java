package stepdefinitions;

import actions.Swipe;
import actions.Wait;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import driver.DriverManager;
import pages.*;
import runners.ConvergentTestRunner;


public class C019_RemittanceCenter {
    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private SendRequestPage sendrequest = new SendRequestPage();
    private PesonetPage pesonet = new PesonetPage();
    private TransferDetailsPage transferDetailsPage = new TransferDetailsPage();
    private TransferToPage transferToPage = new TransferToPage();
    private TransferSuccessfulPage ownsuccesspage = new TransferSuccessfulPage();
    private ReviewandTransferPage otherreviewpage = new ReviewandTransferPage();
    private TransferFromPage otherfrompage = new TransferFromPage();
    private TransferToPage othertopage = new TransferToPage();
    private TransferDetailsPage otherdetailpage = new TransferDetailsPage();
    private AccountDetailsPage accountdetailspage = new AccountDetailsPage();
    private TransferFromPage pesonetfrompage = new TransferFromPage();
    private ReviewandTransferPage pesonetreviewpage = new ReviewandTransferPage();
    private ManageReceipentPage mangerecepent = new ManageReceipentPage();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();
    private String updatedamount;




    @And("^I navigate to other banks and verify the RemiitanceCenter in Convergent mobile application$")
    public void iNavigateToOtherBanksAndVerifyTheRemiitanceCenterInConvergentMobileApplication() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.verifyremittancecenterisexist();
    }

    @Given("^I'm RemiitanceCenter on Welcome page in Convergent mobile application$")
    public void iMRemiitanceCenterOnWelcomePageInConvergentMobileApplication() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @And("^I click the Remittance center link in the Send Request screen$")
    public void iClickTheRemittanceCenterLinkInTheSendRequestScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.clickremittancecenter();
    }

    @And("^I click the GetStarted button in Remittance center starting page$")
    public void iClickTheGetStartedButtonInRemittanceCenterStartingPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.clickGetstarted();
    }

    @And("^I select the palawan Express service provider from the displayed list$")
    public void iSelectThePalawanExpressServiceProviderFromTheDisplayedList() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.clickpalawanexpress();
    }

    @Then("^I should see the remittance center page with service provider$")
    public void iShouldSeeTheRemittanceCenterPageWithServiceProvider() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.verifypalawanexpressisexist();
    }

    @And("^I Enter the Amont \"([^\"]*)\" and purpose \"([^\"]*)\" transfer details screen and choose the acccount number \"([^\"]*)\"$")
    public void iEnterTheAmontTransferDetailsScreenAndChooseTheAcccountNumber(String arg0, String arg1,String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferToPage.enterremmitancetransferamountandacccountdetails(arg0,arg1,arg2);
    }

    @Then("^I should see the \"([^\"]*)\" popup window$")
    public void iShouldSeeThePopupWindow(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferToPage.verifyServiceTitle(arg0);
    }

    @And("^I enter the Recipient Fname \"([^\"]*)\" Lname \"([^\"]*)\" Nationality \"([^\"]*)\" mobile \"([^\"]*)\"  details in \"([^\"]*)\" page$")
    public void iEnterTheRecipientFnameLnameNationalityMobileDetailsInPage(String arg0, String arg1, String arg2, String arg3, String arg4) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^I should see the Review and Send page \"([^\"]*)\"$")
    public void iShouldSeeTheReviewAndSendPage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @And("^I click the next button in remittancecenter page$")
    public void iClickTheNextButtonInRemittancecenterPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferToPage.clicnexttnremittancecenter();
        otherreviewpage.clickGotitButton();
    }

    @And("^I click the proceed with transfer transfer button in remittancecenter page$")
    public void iClickTheProceedWithTransferTransferButtonInRemittancecenterPage() throws Throwable {
        transferToPage.clickproccedwithtransferremittance();
    }

    @And("^I should leave it as Firstname and Lastname fields is blank$")
    public void iShouldLeaveItAsFirstnameAndLastnameFielsIsBlank() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferDetailsPage.blankremittancerecipientdetails();
    }

    @Then("^I verify the \"([^\"]*)\" and \"([^\"]*)\" error message in recipient details screen$")
    public void iVerifyTheAndErrorMessageInRecipientDetailsScreen(String arg0, String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferDetailsPage.verifyRemittanccenterrecpientnameErrorMsg(arg0,arg1);
    }

    @And("^I Enter the Firstname \"([^\"]*)\" Lastname\"([^\"]*)\" and select birthdate and nationality \"([^\"]*)\"$")
    public void iEnterTheFirstnameLastnameAndSelectBirthdateAndNationality(String arg0, String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferDetailsPage.enteremittanccenterrecpientdetails(arg0,arg1,arg2);
    }

    @And("^I Enter the mobilenumber \"([^\"]*)\" emailid\"([^\"]*)\"$")
    public void iEnterTheMobilenumberEmailid(String arg0, String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferDetailsPage.enteremittanccenterrecpientdetailsmobileandenail(arg0,arg1);
    }

    @And("^I should leave it as unitno and Streetname and village fields is blank$")
    public void iShouldLeaveItAsUnitnoAndStreetnameAndVillageFieldsIsBlank() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferDetailsPage.blankremittancerecipientaddressdetails();
    }

    @Then("^I verify the \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" error message in recipient address details screen$")
    public void iVerifyTheAndAndErrorMessageInRecipientAddressDetailsScreen(String arg0, String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferDetailsPage.verifyRemittanccenterrecpientaddressErrorMsg(arg0,arg1,arg2);
    }

    @And("^I click the terms and condition and click submit button$")
    public void iClickTheTermsAndConditionAndClickSubmitButton() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Swipe.swipe.swipeVertical(2,0.8,.2,5);
        otherreviewpage.clickremittancetermsandcondition();
        Swipe.swipe.swipeVertical(2,0.8,.2,5);
        otherreviewpage.clickremittancesubmit();
    }

    @And("^I click the cancel button in popwindow$")
    public void iClickTheCancelButtonInPopwindow() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otherreviewpage.clickremittancecancel();
    }

    @And("^I click the click submit button$")
    public void iClickTheClickSubmitButton() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otherreviewpage.clickremittancesubmit();
    }



    @Then("^I should see the \"([^\"]*)\" in remittancecenter successful page$")
    public void iShouldSeeTheInRemittancecenterSuccessfulPage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        othertopage.verifyTransferToPageTitle(arg0);
    }

    @And("^I Verify the Review and send fields Amount \"([^\"]*)\" and Fee\"([^\"]*)\" and purpose \"([^\"]*)\" name \"([^\"]*)\" nationality\"([^\"]*)\"mobilenmber\"([^\"]*)\"Address\"([^\"]*)\"$")
    public void iVerifyTheReviewAndSendFieldsAmountAndFeeAndPurposeNameNationalityMobilenmberAddress(String arg0, String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otherreviewpage.verifyremittancereviewandsenddetails(arg0,arg1,arg2,arg3,arg4,arg5,arg6);
    }

    @And("^I click the transferdetails edit button$")
    public void iClickTheTransferdetailsEditButton() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otherreviewpage.clickremittancetransferdetailedit();
    }

    @And("^I click done button in remittance center page$")
    public void iClickDoneButtonInRemittanceCenterPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otherreviewpage.clickremittancedone();
    }

    @And("^I click the recipientdetails edit button$")
    public void iClickTheRecipientdetailsEditButton() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otherreviewpage.clickremittancerecipientdetailedit();
    }

    @And("^I click the recipient adress details edit button$")
    public void iClickTheRecipientAdressDetailsEditButton() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        otherreviewpage.clickremittancerecipientaddressedit();
    }

    @And("^I select the KeyCebuanaLhuillie service provider from the displayed list$")
    public void iSelectTheKeyCebuanaLhuillieServiceProviderFromTheDisplayedList() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.clickCebuanaLhuillie();
    }

    @And("^I Click History in the remittance center$")
    public void iClickHistoryInTheRemittanceCenter() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        sendrequest.clickhistory();
    }

    @Then("^I should see the \"([^\"]*)\" and \"([^\"]*)\" status remittance center transaction$")
    public void iShouldSeeTheAndStatusRemittanceCenterTransaction(String arg0, String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferDetailsPage.verifyRemittanccenterHistorysection(arg0,arg1);
    }

    @And("^I click the INPROCESS record in the transaction$")
    public void iClickTheINPROCESSRecordInTheTransaction() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferDetailsPage.blankremittanceinprocess();
    }



    @And("^I click the FAILED record in the transaction$")
    public void iClickTheFAILEDRecordInTheTransaction() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferDetailsPage.blankremittancefailed();
    }

    @And("^I Verify the Transaction details screen fields Amount \"([^\"]*)\" and Fee\"([^\"]*)\" and purpose \"([^\"]*)\" name \"([^\"]*)\" nationality\"([^\"]*)\"mobilenmber\"([^\"]*)\"mailid\"([^\"]*)\"Address\"([^\"]*)\"$")
    public void iVerifyTheTransactionDetailsScreenFieldsAmountAndFeeAndPurposeNameNationalityMobilenmberMailidAddress(String arg0, String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        transferDetailsPage.verifyremittancetransactiondetails(arg0,arg1,arg2,arg3,arg4,arg5,arg5,arg6);
    }

    @And("^I click the proceed with button in remittancecenter page$")
    public void iClickTheProceedWithButtonInRemittancecenterPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(10);
        transferToPage.clickproccedremittance();
    }

    @And("^I verify the different Service providers in Send money page$")
    public void iVerifyTheDifferentServiceProvidersInSendMoneyPage() throws Throwable {
        sendrequest.verifyProviders();
    }
}
