package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import exceptions.ApplicationException;
import pages.GoRewardsPage;


public class C033_GoRewards {
    GoRewardsPage ccPage = new GoRewardsPage();


    @When("^User click on the Go Rewards Gold Credit Account in the dashboard page$")
    public void userClickOnTheGoRewardsGoldCreditAccountInTheDashboardPage() throws Throwable {
        ccPage.selectGORewardsGoldCreditCard();
    }

    @Then("^Verify if application displays the GoldCreditCard product name as \"([^\"]*)\" of the account details page$")
    public void verifyIfApplicationDisplaysTheGoldCreditCardProductNameAsOfTheAccountDetailsPage(String arg0) throws Throwable {
        ccPage.verifyGoldCreditCardHeader(arg0);
    }

    @Then("^Verify if application display the all details in the manage cards page$")
    public void verifyIfApplicationDisplayTheAllDetailsInTheManageCardsPage() throws Throwable {
        ccPage.verify_ManagePageDetails();
    }

    @And("^User to click on About card field under manage cards link$")
    public void userToClickOnAboutCardFieldUnderManageCardsLink() throws Throwable {
        ccPage.clickAboutCardLink();
    }

    @Then("^Verify if application display the 'Hide details' option$")
    public void verifyIfApplicationDisplayTheHideDetailsOption() throws Throwable {
        ccPage.verifyHideDetailsLink();
    }

    @When("^User to click on 'Hide details' option$")
    public void userToClickOnHideDetailsOption() throws Throwable {
        ccPage.clickHideDetailsLink();
    }

    @Then("^Verify if application hide all the features of the Card$")
    public void verifyIfApplicationHideAllTheFeaturesOfTheCard() throws Throwable {
        ccPage.verifyAfterHideDetailsPage();
    }

    @And("^Verify if application displayed transaction controls options$")
    public void verifyIfApplicationDisplayedTransactionControlsOptions() throws Throwable {
        ccPage.verifyTransactionControlsOptions();
    }
    @Then("^Verify if application enables the Save button after selecting the transaction limit$")
    public void verifyIfApplicationEnablesTheSaveButtonAfterSelectingTheTransactionLimit() throws ApplicationException {
        ccPage.VerifySaveButtonEnabled();
    }
    @When("^Verify if application allow the user to click on save button$")
    public void verifyIfApplicationAllowTheUserToClickOnSaveButton() throws Throwable {
        ccPage.clickSaveButton();
    }
    @When("^Verify if application allow the user to click on 'Enable' option$")
    public void verifyIfApplicationAllowTheUserToClickOnEnableOption() throws Throwable {
        ccPage.clickEnableButton();
    }

    @Then("^Verify if application display the enable transaction limit on the Transaction control$")
    public void verifyIfApplicationDisplayTheEnableTransactionLimitOnTheTransactionControl() throws Throwable {
        ccPage.verifyTransactionControlsSpentLimit();
    }

    @When("^user to click on Transaction control options as Online$")
    public void userToClickOnTransactionControlOptionsAsOnline() throws Throwable {
        ccPage.clickTransactionControls_Online();
    }

    @And("^User enter transaction limits \"([^\"]*)\" as per user requirement$")
    public void userEnterTransactionLimitsAsPerUserRequirement(String arg0) throws Throwable {
        ccPage.enterLimitAmount(arg0);
    }

    @Then("^Verify if application display the pop up with \"([^\"]*)\" and \"([^\"]*)\" options$")
    public void verifyIfApplicationDisplayThePopUpWithAndOptions(String arg0, String arg1) throws Throwable {
    ccPage.verifyTransaction_Popups(arg0, arg1);
    }

    @When("^User click on the Go Rewards Platinum Credit Account in the dashboard page$")
    public void userClickOnTheGoRewardsPlatinumCreditAccountInTheDashboardPage() throws Throwable {
        ccPage.selectGoRewardsPlatinumCredit();
    }

    @Then("^Verify if application displays the PlatinumCreditCard product name as \"([^\"]*)\" of the account details page$")
    public void verifyIfApplicationDisplaysThePlatinumCreditCardProductNameAsOfTheAccountDetailsPage(String arg0) throws Throwable {
       ccPage.verifyPlatinumCreditCardHeader(arg0);
    }

    @Then("^I lock/unlock the card if card id unlock/locked from Go Rewards$")
    public void iLockUnlockTheCardIfCardIdUnlockLockedFromGoRewards() throws Throwable {
        ccPage.lockAndUnlockCard();
    }

    @Then("^Verify if card is locked or not$")
    public void verifyIfCardIsLockedOrNot() throws Throwable {
        ccPage.verifyCardStatus_ValidateFunctionality();
    }

    @Then("^Verify if application display the 'CardSettings' option in the page$")
    public void verifyIfApplicationDisplayTheCardSettingsOptionInThePage() throws Throwable {
        ccPage.verifyCardSettings();
    }
}
