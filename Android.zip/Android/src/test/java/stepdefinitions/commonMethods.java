package stepdefinitions;

import actions.Wait;
import cucumber.api.java.en.Given;
import driver.DriverManager;
import exceptions.ApplicationException;
import helper.PropertyReader;
import pages.*;

//import static driver.DriverManager.Drivertype;
//import static driver.DriverManager.EnvironmentType;

public class commonMethods {
    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private SendRequestPage sendrequest = new SendRequestPage();


    @Given("^I'm on login page of UB online banking application with ADA user")
    public void i_m_on_login_page_of_UB_online_banking_application_with_ada_user() throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("ADA_UserName"));
            login.enterPassword(PropertyReader.testDataOf("ADA_Password"));
            login.clickLogin();
            Wait.forSeconds(3);
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
            home.clickNotNowToTurnOnNotification();
//            home.clickNotNowtoSubscribe();
//            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(4);
            home.verifyIfDashboardIsDisplayed("Dashboard");

        }
    }

    @Given("^I'm on login page of UB online banking application with EasyCash user")
    public void i_m_on_login_page_of_UB_online_banking_application_with_easycash_user() throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("EasyCash_UserName"));
            login.enterPassword(PropertyReader.testDataOf("EasyCash_Password"));
            login.clickLogin();
            Wait.forSeconds(3);
            otp.enterOTP(PropertyReader.testDataOf("EasyCash_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
            home.clickNotNowtoSubscribe();
//            home.clickNotNowToTurnOnNotification();
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(8);
            home.verifyIfDashboardIsDisplayed("Dashboard");
            Wait.forSeconds(11);
        }
    }

    @Given("^I'm on login page of UB online banking application with EasyCash Installment user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithEasyCashInstallmentUser() throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("EasyCashInstallment_UserName"));
            login.enterPassword(PropertyReader.testDataOf("EasyCashInstallment_Password"));
            login.clickLogin();
            Wait.forSeconds(3);
            otp.enterOTP(PropertyReader.testDataOf("EasyCashInstallment_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
            home.clickNotNowtoSubscribe();
//            home.clickNotNowToTurnOnNotification();
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(4);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with No FX account user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithNoFXAccountUser() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("FX_UserName"));
            login.enterPassword(PropertyReader.testDataOf("EasyCashInstallment_Password"));
            login.clickLogin();
            Wait.forSeconds(3);
            otp.enterOTP(PropertyReader.testDataOf("EasyCashInstallment_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
            home.clickNotNowtoSubscribe();
//            home.clickNotNowToTurnOnNotification();
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(4);
            home.verifyIfDashboardIsDisplayed("Dashboard");
    }}

    @Given("^I'm on login page of UB online banking application with ReportCard user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithReportCardUser() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("ReportCard_UserName"));
            login.enterPassword(PropertyReader.testDataOf("ReportCard_Password"));
            login.clickLogin();
            Wait.forSeconds(3);
            otp.enterOTP(PropertyReader.testDataOf("ReportCard_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(4);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with ChangePin user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithChangePinUser() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("CP_UserName"));
            login.enterPassword(PropertyReader.testDataOf("CP_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("CP_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(4);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with  GoRewards user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithGoRewardsUser() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("GR_UserName"));
            login.enterPassword(PropertyReader.testDataOf("GR_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("GR_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(4);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with CLI user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithCLIUser() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("CLI_UserName"));
            login.enterPassword(PropertyReader.testDataOf("CLI_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("CLI_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
//              home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with EasyPayment Another Unionbank Fund Transfer user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithEasyPaymentAnotherUnionbankFundTransferUser() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("EasyPayment_UserName"));
            login.enterPassword(PropertyReader.testDataOf("EasyPayment_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
//              home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
            home.gotoSendRequestTab();
            Wait.forSeconds(5);
            sendrequest.clickOtherUBPAccountLink();
        }
    }

    @Given("^I'm on login page of UB online banking application with Set Cash Advance Pin user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithSetCashAdvancePinUser() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Set_UserName"));
            login.enterPassword(PropertyReader.testDataOf("Set_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
//              home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");

        }
    }

    @Given("^I'm on login page of UB online banking application with  ResetCashAdvancePin user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithResetCashAdvancePinUser() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Reset_UserName"));
            login.enterPassword(PropertyReader.testDataOf("Reset_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
//              home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");

        }
    }

    @Given("^I'm on login page of UB online banking application with WesternUnion user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithWesternUnionUser() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("WU_UserName"));
            login.enterPassword(PropertyReader.testDataOf("WU_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("CLI_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
//              home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");

        }
    }
    @Given("^I'm on login page of UB online banking application with Ewallet user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithEwalletUser() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Ewallet_UserName"));
            login.enterPassword(PropertyReader.testDataOf("Ewallet_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("CLI_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
//              home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(5);
//            home.verifyIfDashboardIsDisplayed("Dashboard");

        }
    }
    @Given("^I'm on login page of UB online banking application with Installment History user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithInstallmentHistoryUser() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Installment_UserName"));
            login.enterPassword(PropertyReader.testDataOf("Installment_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Installment_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
//              home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with SWIFT user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithSWIFTUser() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Swift_UserName"));
            login.enterPassword(PropertyReader.testDataOf("Swift_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Swift_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }


    @Given("^I'm on login page of UB online banking application with Lockunlock user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithLockunlockUser() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Lock_UserName"));
            login.enterPassword(PropertyReader.testDataOf("BTO_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Blue_Card_BTO_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }
    @Given("^I'm on login page of UB online banking application with easy transfer BTO user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithEasyTransferBTOUser() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("BTO_BlueCard_UserName"));
            login.enterPassword(PropertyReader.testDataOf("BTO_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Blue_Card_BTO_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with Credit Limit settings user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithCardLimitSettingUser() throws ApplicationException {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("CreditLimit_UserName"));
            login.enterPassword(PropertyReader.testDataOf("CreditLimit_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Credit_Otp"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }


    }

    @Given("^I'm on login page of UB online banking application with LMS User$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithLMSUser() throws ApplicationException {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("LMS_UserName"));
            login.enterPassword(PropertyReader.testDataOf("LMS_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("LMS_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with Virtual card user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithVirtualCardUser() throws Throwable{
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("VirtualCards_UserName"));
            login.enterPassword(PropertyReader.testDataOf("VirtualCards_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("VirtualCards_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with Retcon user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithRetconUser() throws Throwable{
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Retcon_UserName"));
            login.enterPassword(PropertyReader.testDataOf("Retcon_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Retcon_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with payall user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithPayallUser() throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Payall_UserName"));
            login.enterPassword(PropertyReader.testDataOf("Payall_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Payall_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }}
        @Given("^I'm on login page of UB online banking application with LazadaCreditELMS user$")
        public void iMOnLoginPageOfUBOnlineBankingApplicationWithLazadaCreditELMSUser() throws ApplicationException {
            if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
                welcome.clickGotITBtn_Biometrics();
                welcome.closeWelcomeMessages();
                login.enterUsername(PropertyReader.testDataOf("LazadaCreditELMS_User"));
                login.enterPassword(PropertyReader.testDataOf("LazadaCreditELMS_Password"));
                login.clickLogin();
                Wait.forSeconds(4);
                otp.enterOTP(PropertyReader.testDataOf("LazadaCreditELMS_OTP"));
                Wait.forSeconds(3);
                home.clickSubscribeToAppOtpNotNow();
                Wait.forSeconds(3);
                home.clickContinue();
                Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
                home.clickNotNowToTurnOnNotification();
                Wait.forSeconds(3);
                home.clickGotoDashBoard();
                Wait.forSeconds(5);
                home.verifyIfDashboardIsDisplayed("Dashboard");
            }
    }

    @Given("^I'm on login page of UB online banking application with LazadaDebitELMS user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithLazadaDebitELMSUser() throws ApplicationException {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("LazadaDebittELMS_User"));
            login.enterPassword(PropertyReader.testDataOf("LazadaDebitELMS_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("LazadaDebitELMS_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with S&R user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithSRUser() throws ApplicationException {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("SandR_User"));
            login.enterPassword(PropertyReader.testDataOf("SandR_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("LazadaDebitELMS_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with the paydirect user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithThePaydirectUser() throws ApplicationException {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Paydirect_User"));
            login.enterPassword(PropertyReader.testDataOf("Paydirect_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Paydirect_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
//            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with the Cryptowallet user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithTheCryptowalletUser() throws ApplicationException {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Cryptowalet_User"));
            login.enterPassword(PropertyReader.testDataOf("InstapayWaived_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Cryptowalet_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
//            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with Instapaywaived user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithInstapaywaivedUser() throws ApplicationException {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("InstapayWaived_User"));
            login.enterPassword(PropertyReader.testDataOf("InstapayWaived_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("InstapayWaived_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with SetPin user$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithSetPinUser() throws ApplicationException {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("SP_UserName"));
            login.enterPassword(PropertyReader.testDataOf("InstapayWaived_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("InstapayWaived_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with LMS User for BlueCards$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithLMSUserForBlueCards() throws ApplicationException {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("BlueCard_LMS_UserName"));
            login.enterPassword(PropertyReader.testDataOf("ELMS_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("ELMS_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }

    @Given("^I'm on login page of UB online banking application with ELMS User for OrangeCards\\.$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithELMSUserForOrangeCards() throws ApplicationException {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("OrangeCard_ELMS_UserName"));
            login.enterPassword(PropertyReader.testDataOf("ELMS_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("ELMS_OTP"));
            Wait.forSeconds(3);
            home.clickSubscribeToAppOtpNotNow();
            Wait.forSeconds(3);
            home.clickContinue();
            Wait.forSeconds(3);
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            Wait.forSeconds(3);
            home.clickGotoDashBoard();
            Wait.forSeconds(5);
            home.verifyIfDashboardIsDisplayed("Dashboard");
        }
    }
}


