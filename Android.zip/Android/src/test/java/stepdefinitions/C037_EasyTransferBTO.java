package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.EasyCashPage;
import pages.EasyTransferBTOPage;

public class C037_EasyTransferBTO {
    EasyTransferBTOPage easytransfer = new EasyTransferBTOPage();
    EasyCashPage easycash=new EasyCashPage();


    @When("^user to select required credit card from dashboard$")
    public void userToSelectRequiredCreditCardFromDashboard() throws Throwable {
        easytransfer.ClickCard();

    }

    @And("^User to  select Installments option on available credit card$")
    public void userToSelectInstallmentsOptionOnAvailableCreditCard() throws Throwable {
        easytransfer.ClickInstallments();
    }


    @Then("^Check if application displays the EasyTransfer option on Installments Dashboard$")
    public void checkIfApplicationDisplaysTheEasyTransferOptionOnInstallmentsDashboard() throws Throwable {
        easytransfer.VerifyEasyTransferOption();
    }

    @When("^user to select the EasyTransfer Option and click$")
    public void userToSelectTheEasyTransferOptionAndClick() throws Throwable {
        easytransfer.clickEasyTransferOption();
    }

    @And("^Check if application navigate to easy transfer screen$")
    public void checkIfApplicationNavigateToEasyTransferScreen() throws Throwable {
        easytransfer.verifyEasyTransferHeader();
    }

    @And("^Check if application displays Payment Plan under Select Payment Plan$")
    public void checkIfApplicationDisplaysPaymentPlanUnderSelectPaymentPlan() throws Throwable {
        easytransfer.VerifyPaymentPlanHeader();
    }
    @And("^Check if application allows user to select any one of the payment plan under Select Payment Plan$")
    public void checkIfApplicationAllowsUserToSelectAnyOneOfThePaymentPlanUnderSelectPaymentPlan() throws Throwable {
        easytransfer.ClickPaymentPlan();
    }
    @Then("^Check if application allows user to click Next$")
    public void checkIfApplicationAllowsUserToClickNext() throws Throwable {
        easytransfer.VerifyAndClickNext();

    }
    @Then("^check from credit card details are masked$")
    public void checkFromCreditCardDetailsAreMasked() throws Throwable {
        easytransfer.VerifyMaskedFromCardDetails();
    }
    @Then("^check to card details are masked$")
    public void checkToCardDetailsAreMasked() throws Throwable {
        easytransfer.VerifyMaskedToCardDetails();
    }
    @And("^Check if application navigates to Credit Card Detail screen$")
    public void checkIfApplicationNavigatesToCreditCardDetailScreen() throws Throwable {
        easytransfer.VerifyCreditCardHeader();
    }
    @Then("^Check if application allows user to input valid (\\d+) digit credit card number$")
    public void checkIfApplicationAllowsUserToInputValidDigitCreditCardNumber(int arg0) throws Throwable {
        easytransfer.EnterCardNumber();
    }

    @Then("^application navigates to EasyTransfer Summary page$")
    public void applicationNavigatesToEasyTransferSummaryPage() throws Throwable {
        easytransfer.verifyEasyTransferHeader();

    }

    @When("^Check if application allows user to click Terms and Conditions$")
    public void checkIfApplicationAllowsUserToClickTermsAndConditions() throws Throwable {
        easytransfer.ClickTermsAndConditions();
    }

    @Then("^Check if application navigates to Terms and Conditions page$")
    public void checkIfApplicationNavigatesToTermsAndConditionsPage() throws Throwable {
        easytransfer.TermsAndConditionsLink();

    }

    @And("^Check if application allows user to click Agree and Continue$")
    public void checkIfApplicationAllowsUserToClickAgreeAndContinue() throws Throwable {
        easytransfer.IAgreeButton();
    }

    @And("^Check if application allows user to click Request for EasyTransfer in easytransfer summary page$")
    public void checkIfApplicationAllowsUserToClickRequestForEasyTransferInEasytransferSummaryPage() throws Throwable {
        easytransfer.ClickRequestForEasyTransfer();
    }
    @Then("^Check if application navigates to Success screen \\(EasyTransfer Request Received\\)$")
    public void checkIfApplicationNavigatesToSuccessScreenEasyTransferRequestReceived() throws Throwable {
        easytransfer.VerifySuccessMessage();
    }
    @And("^Check if application allows user to click Okay$")
    public void checkIfApplicationAllowsUserToClickOkay() throws Throwable {
        easytransfer.ClickOkay();
    }

    @Then("^verify the Invalid bank and/or credit card details message$")
    public void verifyTheInvalidBankAndOrCreditCardDetailsMessage() throws Throwable {
        easytransfer.VerifyInvalidCardNumberErrorMessage();
    }
    @And("^Verify application allows to click goit button$")
    public void verifyApplicationAllowsToClickGoitButton() throws Throwable {
        easytransfer.ClickGotItButton();

    }
    @Then("^check whether application allows user to click easy transfer$")
    public void checkWhetherApplicationAllowsUserToClickEasyTransfer() throws Throwable {
        easytransfer.ClickToEasyTransferPage();
    }
    @Then("^click to edit and enter lesser amount than the minimum amount$")
    public void clickToEditAndEnterLesserAmountThanTheMinimumAmount() {
    }
    @Then("^Check if application allows user to click amount edit button$")
    public void checkIfApplicationAllowsUserToClickAmountEditButton() throws Throwable {
        easytransfer.ClickAmountEditOption();
    }
    @And("^enter the amount for installement conversion$")
    public void enterTheAmountForInstallemtConversion() throws Throwable{
        easytransfer.click_Slider();
//        easytransfer.ClickAmount();
    }
    @Then("^click Amount and enter maximum amount$")
    public void clickAmountAndEnterMaximumAmount() throws Throwable {
        easytransfer.EnterMaximumAmount();
        
    }
    @When("^user to input Invalid (\\d+) digit credit card number$")
    public void userToInputInvalidDigitCreditCardNumber(int arg0) throws Throwable {
        easytransfer.EnterInvalidCardNumber();
    }
    @And("^check if application allows user to edit credit card details by clicking to edit option$")
    public void checkIfApplicationAllowsUserToEditCreditCardDetailsByClickingToEditOption() throws Throwable {
        easytransfer.ClickEditInCreditCardDetails();
    }
    @Then("^click Amount and enter minimum amount$")
    public void clickAmountAndEnterMinimumAmount() throws Throwable {
        easytransfer.EnterMinimumAmount();
    }
//    @Then("^check if the user is able to click edit in easy transfer details$")
//    public void checkIfTheUserIsAbleToClickEditInEasyTransferDetails() throws Throwable {
//        easytransfer.ClickEditInEasyTransferDetails();
//    }
    @And("^enter the new amount for installement conversion$")
    public void enterTheNewAmountForInstallementConversion() throws Throwable {
        easytransfer.ClickNewAmount();
    }
    @When("^Verify that user able to enter Requested Amount from EasyTransfer$")
    public void verifyThatUserAbleToEnterRequestedAmountFromEasyTransfer() throws Throwable {
        easycash.EnterAmount_EasyTransfer();
    }

    @When("^After edit user to enter valid (\\d+) digit credit card number$")
    public void afterEditUserToEnterValidDigitCreditCardNumber(int arg0) throws Throwable {
        easytransfer.EnterCardNumber_Edit();
    }

    @Then("^user should click to get started button$")
    public void userShouldClickToGetStartedButton() throws Throwable {
        easytransfer.clickGetstarted();
    }

    @Then("^Application should display the label description as 'Turn my other bank credit card statement balance to installments'$")
    public void applicationShouldDisplayTheLabelDescriptionAsTurnMyOtherBankCreditCardStatementBalanceToInstallments() throws Throwable {
        easytransfer.verifyTurnOnMessage();
    }

    @Then("^Application should display a description under EasyTransfer label as 'Easily transfer your credit card statement balance from other banks to installments\\.'$")
    public void applicationShouldDisplayADescriptionUnderEasyTransferLabelAsEasilyTransferYourCreditCardStatementBalanceFromOtherBanksToInstallments() throws Throwable {
        easytransfer.verifyEasyTransferlabelMsg();
    }

    @And("^Application should display a Reminder 'Processing may take up to (\\d+) banking days\\.'$")
    public void applicationShouldDisplayAReminderProcessingMayTakeUpToBankingDays(int arg0) throws Throwable {
        easytransfer.verifyRemainderMsg();
    }

    @Then("^Application should displays a description under Credit Card Details label as 'Enter the credit card details that you want to transfer balance from\\.'$")
    public void applicationShouldDisplaysADescriptionUnderCreditCardDetailsLabelAsEnterTheCreditCardDetailsThatYouWantToTransferBalanceFrom() throws Throwable {
        easytransfer.verifyCardDetailsLabelMsg();
    }

    @And("^Application should displays the following under Credit Card Details Transfer Balance From,Transfer Balance to,Principal Amount,Installment,Term,Factor rate, interest,processing fee\\.$")
    public void applicationShouldDisplaysTheFollowingUnderCreditCardDetailsTransferBalanceFromTransferBalanceToPrincipalAmountInstallmentTermFactorRateInterestProcessingFee() throws Throwable {
        easytransfer.verifyCreditcardDetails();
    }

    @Then("^Application should displays a Reminder$")
    public void applicationShouldDisplaysAReminder() throws Throwable {
        easytransfer.verifyEasyTransferRemainderMsg();
    }

    @Then("^user should click to easy transfer terms and conditions and click to agree$")
    public void userShouldClickToEasyTransferTermsAndConditionsAndClickToAgree() throws Throwable {
        easytransfer.ClickTermsAndConditions();
    }


    @And("^verify the inline message for the minimum amount allowed\\.$")
    public void verifyTheInlineMessageForTheMinimumAmountAllowed() throws Throwable {
        easytransfer.verifyMinimumMsg();
    }

    @And("^verify the inline message for the maximum amount allowed$")
    public void verifyTheInlineMessageForTheMaximumAmountAllowed() throws Throwable {
        easytransfer.verifyMaximumMsg();
    }

    @Given("^I'm on login page of UB online banking application with easy transfer BTO user for orange cards$")
    public void iMOnLoginPageOfUBOnlineBankingApplicationWithEasyTransferBTOUserForOrangeCards() {
    }

    @When("^user to select required credit card from dashboard for orange cards$")
    public void userToSelectRequiredCreditCardFromDashboardForOrangeCards() {
    }


    @And("^Application should displays the following under Credit Card Details Transfer Balance From,Transfer Balance to,Principal Amount,Installment,Term,Factor rate, interest,rpocessing fee$")
    public void applicationShouldDisplaysTheFollowingUnderCreditCardDetailsTransferBalanceFromTransferBalanceToPrincipalAmountInstallmentTermFactorRateInterestRpocessingFee() {
    }

    @And("^check and confirm the details of your EasyTransfer request below\\.$")
    public void checkAndConfirmTheDetailsOfYourEasyTransferRequestBelow() throws Throwable {
        easytransfer.verifyLabelMessage();
    }

    @And("^Check if application allow user to click on skip button$")
    public void checkIfApplicationAllowUserToClickOnSkipButton() {
    }

    @And("^Check if the application allows user to click skip$")
    public void checkIfTheApplicationAllowsUserToClickSkip() {
    }


}

