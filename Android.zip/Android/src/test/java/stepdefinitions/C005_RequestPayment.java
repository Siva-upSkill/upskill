package stepdefinitions;




import actions.Swipe;
import actions.Wait;
import constants.Device;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverManager;
import helper.*;
import pages.*;
import runners.ConvergentTestRunner;

public class C005_RequestPayment {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private SendRequestPage sendrequest = new SendRequestPage();
    private RequestPaymentPage requestPayment = new RequestPaymentPage();
    private RequestTab requestTab = new RequestTab();
    private SelectRecipient add_participant = new SelectRecipient();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();


    @Given("^I'm on Request page in Convergent mobile application$")
    public void iMOnRequestPageInConvergentMobileApplication() throws Throwable {
        welcome.clickGotITBtn_Biometrics();
        welcome.closeWelcomeMessages();
        login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
        login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
        login.clickLogin();
        Wait.forSeconds(4);
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        Wait.forSeconds(2);
        home.clickSubscribeToAppOtpNotNow();
        Wait.forSeconds(2);
        home.clickContinue();
        Wait.forSeconds(2);
//        home.clickNotNowtoSubscribe();
        home.clickNotNowToTurnOnNotification();
        Wait.forSeconds(2);
        home.clickGotoDashBoard();
        Wait.forSeconds(4);
        home.gotoSendRequestTab();
        Wait.forSeconds(8);
        sendrequest.gotoRequestTab();
    }

    @Given("^I'm on Request page in Convergent mobile applications$")
    public void iMOnRequestPageInConvergent() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Account1_UserID_2_accounts"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password_2_accounts"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(2);
            home.clickContinue();
            Wait.forSeconds(2);
            home.clickNotNowtoSubscribe();
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung"))
            {
                Wait.forSeconds(2);
                home.clickNotNowToTurnOnNotification();
            }
            Wait.forSeconds(2);
            home.clickGotoDashBoard();
            Wait.forSeconds(4);
            home.gotoSendRequestTab();
            Wait.forSeconds(8);
            sendrequest.gotoRequestTab();
            iClickRequestPaymentScreen();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(25);
            home.gotoSendRequestTabIOS();
            home.clickRequestTabIOS();
            home.clickRequestPaymentLinkIOS();
        }
    }

    @When("^I click Request Payment screen$")
    public void iClickRequestPaymentScreen() throws Throwable {
        Wait.forSeconds(5);
        sendrequest.clickOtherUBPAccountLink();
        requestTab.clickRequestPayment();
    }

    @Then("^Request payment screen should be opened containing the fields Amount, Request from, Message, Deposit to$")
    public void requestPaymentScreenShouldBeOpenedContainingTheFieldsAmountRequestFromMessageDepositTo() throws Throwable {
        Wait.forSeconds(4);
        requestPayment.verifyPageTitle(PropertyReader.testDataOf("Request_Payment_Screen_Validation>PageTitle"));
    }

    @And("^Next button in request payment screen should be disabled$")
    public void nextButtonInRequestPaymentScreenShouldBeDisabled() throws Throwable {
        requestPayment.verifyIfNextButtonDisabled();
    }

    @When("^I select the recipient in add recipient field$")
    public void iSelectTheRecipientInAddRecipientField() throws Throwable {
        requestPayment.clickRequestFrom();
        requestPayment.enteraddtonewcontactName("jaya");
        requestPayment.clickCheckBox();
        requestPayment.clickAddButton();
        //add_participant.selectFirstContact();
        //add_participant.clickDone();
    }

    @Then("^System should show and error \"([^\"]*)\" at the bottom of the screen$")
    public void systemShouldShowAndErrorAtTheBottomOfTheScreen(String arg0) throws Throwable {
        requestPayment.verifyAmountError(arg0.trim());
    }

    @Given("^I'm on Request Payment screen in Convergent mobile application$")
    public void iMOnRequestPaymentScreenInConvergentMobileApplication() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            iMOnRequestPageInConvergentMobileApplication();
            Wait.forSeconds(10);
            iClickRequestPaymentScreen();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(25);
            home.gotoSendRequestTabIOS();
            home.clickRequestTabIOS();
            home.clickRequestPaymentLinkIOS();
        }
    }

    @When("^I enter a non-numeric character in amount field$")
    public void iEnterANonNumericCharacterInAmountField() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.clickRequestAmountOf();
            Wait.forSeconds(2);
            requestPayment.enterAmount(".........");
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickRequestAmountOfIOS();
            Wait.forSeconds(2);
            requestPayment.enterAmountIOS(".........");
        }
    }

    @Then("^System should not accept it$")
    public void systemShouldNotAcceptIt() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //requestPayment.clickAmount();
            requestPayment.verifyError("Invalid amount.");
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyInvalidAmount("Invalid amount.");
        }
    }

    @When("^I enter amount > than the limit \"([^\"]*)\"$")
    public void iEnterAmountThanTheLimit(String arg0) throws Throwable {
        requestPayment.enterAmount(arg0.trim());
    }

    @Then("^System should through an error \"([^\"]*)\" and save button should be disabled$")
    public void systemShouldThroughAnError(String arg0) throws Throwable {
        requestPayment.verifyError(arg0.trim());
        requestPayment.verifySaveButtonIsDisabled();
    }

    @When("^I enter the amount \"([^\"]*)\", select split evenly$")
    public void iEnterTheAmountSelectSplitEvenly(String arg0) throws Throwable {
        requestPayment.clickAmount();
        requestPayment.enterAmount(arg0.trim());
        requestPayment.selectSplitOptionAsEvenly();
        requestPayment.clickSave();

    }

    @When("^I enter the amount \"([^\"]*)\", select split unevenly$")
    public void iEnterTheAmountSelectSplitUnevenly(String arg0) throws Throwable {
        requestPayment.clickAmount();
        requestPayment.enterAmount(arg0.trim());
        requestPayment.selectSplitOptionsAsUnEvenly();

    }

    @Then("^System should display a text \"([^\"]*)\"$")
    public void systemShouldDisplayAText(String arg0) throws Throwable {
        requestPayment.verifyDescription(arg0.trim());
        requestPayment.clickSave();
    }

    @When("^I select (\\d+) recipients$")
    public void iSelectRecipients(int arg0) throws Throwable {
        requestPayment.clickRequestFrom();
        requestPayment.clickRequestFromAfterSelectAmount();
        //add_participant.selectRecipients(arg0);
        add_participant.clickDone();
    }

    @When("^I select (\\d+) recipients and verify amt in participent is not editable$")
    public void iSelectRecipientsAndVerifyAmtIsNotEditable(int arg0) throws Throwable {
        requestPayment.clickRequestFrom();
        //requestPayment.clickRequestFromAfterSelectAmount();
        add_participant.selectRecipients(arg0);
        add_participant.clickDone();
        //requestPayment.checkIfParticipentAmountIsClickable(arg0);
    }

    @When("^I select (\\d+) recipients and verify amt in participent is editable$")
    public void iSelectRecipientsAndVerifyAmtIsEditable(int arg0) throws Throwable {
        requestPayment.clickRequestFrom();
        //requestPayment.clickRequestFromAfterSelectAmount();
        add_participant.selectRecipients(arg0);
        add_participant.clickDone();
        //requestPayment.checkIfParticipentAmountIsClickable(arg0);
    }


    @Then("^Request amount should be changed to \"([^\"]*)\" & system should split the amount equally into (\\d+) line items with \"([^\"]*)\" & the amount should non editable$")
    public void requestAmountShouldBeChangedToSystemShouldSplitTheAmountEquallyIntoLineItemsWithTheAmountShouldNonEditable(String arg0, int arg1, String arg2) throws Throwable {
        requestPayment.checkIfAmountEvenlySplit(arg0.trim(), arg2.trim(), arg1);
    }

    @When("^I click back button in \"([^\"]*)\" pages$")
    public void i_click_back_button_in_transfer_details_page(String arg1) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.clickBackBtn();
            Wait.forSeconds(5);
            requestPayment.verifyPageTitle(arg1);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyRequestPaymentPageTitleIOS(arg1);
            Wait.forSeconds(5);
            requestPayment.clickBackBtnIOS();
        }
    }

    @Then("^I should able to see \"([^\"]*)\" page$")
    public void i_should_able_to_see(String arg1) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.verifyPageTitle(arg1);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifySendRequestPageTitleIOS(arg1);
        }
    }

    @And("^I entering amount \"([^\"]*)\" more than account current balance in request payment$")
    public void i_entering_amount_more_then_account_current_balance_in_request_payment(String amount) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.clickRequestAmountOf();
            Wait.forSeconds(2);
            requestPayment.enterAmount(amount);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickRequestAmountOfIOS();
            Wait.forSeconds(2);
            requestPayment.enterAmountIOS(amount);
        }
    }

    @Then("^I should see the request amount filed error message \"([^\"]*)\"$")
    public void i_should_see_the_request_amount_field_error_message(String errormessage) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(10);
            requestPayment.verifyRequestAmountErrorMessage(errormessage);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyRequestAmountErrorMessageIOS(PropertyReader.testDataOf("RequestAmountErrorIOS"));
        }
    }

    @When("^I enter \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" in \"([^\"]*)\" page$")
    public void i_enter_transfer_details(String arg0, String arg1, String arg2, String arg3, String arg4) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(8);
//            requestPayment.verifyPageTitle(arg4);
            requestPayment.clickAmount();
            Wait.forSeconds(5);
            requestPayment.enterAmount(arg0);
            Wait.forSeconds(5);
            requestPayment.clickEvenlyBtn();
            requestPayment.clickRequestTheAmountOfSaveBtn();
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131"))
            {
                actions.Touch.pressByCoordinates(347, 630, 5);
            }
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                Wait.forSeconds(10);
                Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
                requestPayment.clickRequestFrom();
            }
            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFrom"));
            requestPayment.selectParticipant();
//            Swipe.swipe.swipeVertical(2,0.8,0.2,5);
            //requestPayment.clickRequestFrom();
            Wait.forSeconds(2);
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                //for samsung galaxy J7
                actions.Touch.pressByCoordinates(333, 768, 5);
            }
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                requestPayment.clickRequestFrom();
                requestPayment.enterContactName(PropertyReader.testDataOf("RequestFromname"));
            }
            requestPayment.selectParticipant();
            Wait.forSeconds(2);
            requestPayment.enterMessageDetails(PropertyReader.testDataOf("Message"));
            requestPayment.clickDepositTo();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {

            requestPayment.verifyRequestPaymentPageTitleIOS(arg4);
            requestPayment.clickRequestAmountOfIOS();
            Wait.forSeconds(2);
            requestPayment.enterAmountIOS(PropertyReader.testDataOf("Amount"));
            requestPayment.clickEvenlyBtn();
            requestPayment.clickRequestTheAmountOfSaveBtn();
            requestPayment.clickRequestFrom();

            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFrom"));
            requestPayment.selectFirstParticipantIOS();
            Wait.forSeconds(5);
            requestPayment.clickRequestFromsecondIOS();
            Wait.forSeconds(10);
            Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
            Wait.forSeconds(2);
            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFromname"));
            Wait.forSeconds(2);
            requestPayment.selectSecondParticipantIOS();
            Wait.forSeconds(2);
            requestPayment.enterMessageDetails(arg2);
            requestPayment.clickDepositTo();
        }
    }

    @Then("^On successful transfer entries Next button should be enabled in \"([^\"]*)\" page$")
    public void on_successful_transfer_entries_Next_button_should_be_enabled(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            requestPayment.verifyPageTitle(arg1);
            requestPayment.verifyIfNextButtonIsPresent();
            requestPayment.clickNext();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyRequestPaymentPageTitleIOS(arg1);
            requestPayment.verifyIfNextButtonIsPresent();
            requestPayment.clickNext();
        }
    }

    @And("^I add Invalid participent Name \"([^\"]*)\" and Mobile number \"([^\"]*)\"$")
    public void i_add_invalid_participent_name_mobile_number(String arg0, String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            // requestPayment.clickparticipants();
            //actions.Touch.pressByCoordinates(347, 630, 5);
            Wait.forSeconds(5);
            Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
            Wait.forSeconds(5);
            requestPayment.clickRequestFrom();
            requestPayment.clickAddToMyContacts();
            requestPayment.enteraddtonewcontactName(arg0);
            requestPayment.enteraddtonewMobileNumber(arg1);
        }
        else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(5);
            Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
            Wait.forSeconds(5);
            requestPayment.clickRequestFrom();
            requestPayment.clickAddToMyContacts();
            requestPayment.enteraddtonewcontactName(arg0);
            requestPayment.enteraddtonewMobileNumber(arg1);
        }
    }

    @Then("^I should see the add new contact mobile number error message \"([^\"]*)\"$")
    public void i_should_see_the_add_new_contact_mobile_number_error_message(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.verifyaddtocontactMobilenumberErrorMessage(arg1);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyaddtocontactMobilenumberErrorMessage(arg1);
        }
    }

    @And("^I enter amount \"([^\"]*)\" in request payment$")
    public void i_enter_amount_in_request_payment(String amount) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.clickRequestAmountOf();
            Wait.forSeconds(2);
            requestPayment.enterAmount(amount);
            requestPayment.clickUnEvenlyBtn();
            requestPayment.clickRequestTheAmountOfSaveBtn();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickRequestAmountOfIOS();
            Wait.forSeconds(2);
            requestPayment.enterAmountIOS(amount);
            requestPayment.clickUnEvenlyBtn();
            requestPayment.clickRequestTheAmountOfSaveBtn();
        }
    }

    @Then("^I should see the Split option as Unevenly \"([^\"]*)\" for Request payment$")
    public void i_should_see_the_split_option_as_unevenly_for_request_payment(String arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {

            Swipe.swipe.swipeVertical(2, 0.8, .2, 5);
            requestPayment.verifyUnEvenlylabel(arg0);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Swipe.swipe.swipeVertical(2, 0.8, .2, 5);
            requestPayment.verifyUnEvenlylabel(arg0);
        }
    }

    @And("^I enter payment amount \"([^\"]*)\" in request payment$")
    public void i_enter_payment_amount_in_request_payment(String amount) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.clickRequestAmountOf();
            Wait.forSeconds(8);
            requestPayment.enterAmount(amount);
            C013_ManageTransfers.Requestpaymentamount="PHP"+" "+amount;
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickRequestAmountOfIOS();
            Wait.forSeconds(2);
            requestPayment.enterAmountIOS(amount);
            C013_ManageTransfers.Requestpaymentamount="PHP"+" "+amount;
        }
    }

    @And("^I click on Each button in Request payment page and save$")
    public void i_click_on_each_button_in_request_payment_page_and_save() throws Throwable {
            requestPayment.clickEachBtn();
            requestPayment.clickSave();
    }

    @And("^I click on Each button in Request payment page$")
    public void i_click_on_each_button_in_request_payment_page() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.clickEachBtn();
            // requestPayment.clickSave();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickEachBtn();
            requestPayment.clickSave();

        }
    }

    @And("^I click on Each button in Request payment$")
    public void i_click_on_each_button_in_request_payment() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.clickEachBtn();
            //requestPayment.clickSave();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickEachBtn();
            //requestPayment.clickSave();

        }

    }
    @Then("^I should see the Split option as Each \"([^\"]*)\" for Request payment$")
    public void i_should_see_the_split_option_as_each_for_request_payment(String arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //requestPayment.clickRequestTheAmountOfSaveBtn();
           // requestPayment.clickSave();
            Swipe.swipe.swipeVertical(2, 0.8, .2, 5);
            requestPayment.verifyEachlabel(arg0);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            //requestPayment.clickRequestTheAmountOfSaveBtn();
            Swipe.swipe.swipeVertical(2, 0.8, .2, 5);
            requestPayment.verifyEachlabel(arg0);
        }
    }

    @And("^I click on Evenly button in Request payment page$")
    public void i_click_on_evenly_button_in_request_payment_page() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.clickEvenlyBtn();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickEvenlyBtn();
        }
    }

    @Then("^I should see the Split option as Evenly \"([^\"]*)\" for Request payment$")
    public void i_should_see_the_split_option_as_evenly_for_request_payment(String arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.clickSave();
            Swipe.swipe.swipeVertical(2, 0.8, .2, 5);
            requestPayment.verifyEvenlylabel(arg0);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickRequestTheAmountOfSaveBtn();
            Swipe.swipe.swipeVertical(2, 0.8, .2, 5);
            requestPayment.verifyEvenlylabel(arg0);
        }
    }

    @And("^I click on Unevenly button in Request payment page$")
    public void i_click_on_unevenly_button_in_request_payment_page() throws Throwable {
        requestPayment.clickUnEvenlyBtn();
    }

    @Then("^I should the description \"([^\"]*)\" for Evenly split option$")
    public void i_should_the_description_for_evenly_option(String arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.verifyDescriptionForEvenlySplit(arg0);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyDescriptionForEvenlySplitIOS(arg0);
        }
    }

    @Then("^I should the description \"([^\"]*)\" for Unevenly split option$")
    public void i_should_the_description_for_unevenly_split(String arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.verifyDescriptionForUnEvenlySplit(arg0);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyDescriptionForUnEvenlySplitIOS(arg0);
        }
    }

    @Then("^I should the description \"([^\"]*)\" for Each split option$")
    public void i_should_the_description_each_split(String arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Swipe.swipe.swipeVertical(2,0.8,.2,5);
            requestPayment.verifyDescriptionForEachSplit(arg0);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyDescriptionForEachSplitIOS(arg0);
        }
    }

    @When("^I click back button in \"([^\"]*)\" screen to cancel request$")
    public void i_click_back_button_in_review_request_page(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.verifyPageTitle(arg1);
            requestPayment.clickBackBtn();
            requestPayment.clickCancelBtn();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyReviewAndRequestPageTitleIOS(arg1);
            requestPayment.clickBackBtn();
            requestPayment.clickCancelYesBtnIOS();
        }
    }

    @When("^I enter message with text \"([^\"]*)\" in other account request payment page$")
    public void i_enter_remark_message_with_text_in_other_account_transfer_to_page(String arg1) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.clickMessage();
            requestPayment.enterMessage(PropertyReader.testDataOf(arg1));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickMessageIOS();
            requestPayment.enterMessageIOS(PropertyReader.testDataOf(arg1));

        }
    }

    @Then("^I should see the message with only (\\d+) characters in other account request payment page$")
    public void i_should_see_the_message_with_only_characters_in_other_account_transfer_to_page(int arg1) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.verifyMessageLength();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyMessageLengthIOS();
        }
    }

    @When("^I click Request payment request form deposit to in \"([^\"]*)\" screen to view Target accounts$")
    public void i_click_Rayment_request_form_deposit_to_in_to_view_Target_accounts(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.verifyPageTitle(arg1);
            requestPayment.clickDepositToViewTargetAccount();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyRequestPaymentPageTitleIOS(arg1);
            requestPayment.clickDepositToViewTargetAccount();
        }
    }

    @Then("^I should see targer accounts displayed in \"([^\"]*)\" in \"([^\"]*)\" Page$")
    public void i_should_see_targer_accounts_displayed_in_in_Page(String arg1, String arg2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.verifyPageTitle(arg2);
            requestPayment.verifyTargetAccountColor();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifySelectAccountPageTitleIOS(arg2);
            requestPayment.verifyTargetAccountColorIOS();
        }
    }

    @When("^I click Request From to add participant in \"([^\"]*)\" screen$")
    public void i_click_Request_From_to_add_participant_in_screen(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.clickRequestFrom();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickRequestFrom();
        }
    }

    @When("^I click Add to My Contacts in \"([^\"]*)\" screen to add new participant$")
    public void i_click_in_screen_to_add_new_participant(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            requestPayment.verifyPageTitle(arg1);
            requestPayment.clickAddToMyContacts();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyAddParticipantsPageTitleIOS(arg1);
            requestPayment.clickAddToMyContacts();
        }
    }

    @When("^I enter \"([^\"]*)\" and \"([^\"]*)\" in \"([^\"]*)\" screen$")
    public void i_enter_and_in_screen(String arg1, String arg2, String arg3) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.verifyPageTitle(arg3);
            requestPayment.verifyAddNewContactSaveButtonIsDisabled();
            requestPayment.enteraddtonewcontactName(PropertyReader.testDataOf(arg1));
            requestPayment.enteraddtonewMobileNumber(PropertyReader.testDataOf(arg2));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(8);
            requestPayment.verifyAddContactPageTitleIOS(arg3); //Defect raised manual team (Page title mismatchs (Android, IOS and Web)
            requestPayment.verifyAddNewContactSaveButtonIsDisabled();
            requestPayment.enteraddtonewcontactName(PropertyReader.testDataOf(arg1));
            requestPayment.enteraddtonewMobileNumber(PropertyReader.testDataOf(arg2));
        }
    }


    @When("^I enter random \"([^\"]*)\" and \"([^\"]*)\" in \"([^\"]*)\" screen$")
    public void i_enter_random_and_in_screen(String arg1, String arg2, String arg3) throws Throwable {
        //requestPayment.participantname=
        arg1=Tools.RANDOMTEXT("RANDOMTEXT",10);
        C013_ManageTransfers.participantname=arg1;
        //requestPayment.participantnumber=
        arg2=Tools.RANDOMTEXT("RANDOMNUMBER",11);
        C013_ManageTransfers.participantnumber=arg2;

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.verifyPageTitle(arg3);
            requestPayment.verifyAddNewContactSaveButtonIsDisabled();
            requestPayment.enteraddtonewcontactName(arg1);
            requestPayment.enteraddtonewMobileNumber(arg2);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(8);
            //requestPayment.verifyAddContactPageTitleIOS(arg3); //Defect raised manual team (Page title mismatchs (Android, IOS and Web)
            //requestPayment.verifyAddNewContactSaveButtonIsDisabled();

            requestPayment.enteraddtonewcontactName(arg1);
            requestPayment.enteraddtonewMobileNumber(arg2);
        }
    }



    @When("^On successful transfer entries save button should be enabled and favorite button should be disabled$")
    public void on_successful_transfer_entries_save_button_should_be_enabled_and_favorite_button_should_be_disabled() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.verifyAddNewContactSaveButtonIsEnabled();
            requestPayment.verifyIfFavoriteButtonIsDisabled();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyAddNewContactSaveButtonIsEnabled();
            requestPayment.verifyIfFavoriteButtonIsDisabled();
        }
    }

    @And("^I select participents in participant page$")
    public void i_select_participents_in_participant_page() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(347, 630, 5);
                // J7
            }
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                Wait.forSeconds(10);
                Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
                Wait.forSeconds(10);
                requestPayment.clickRequestFrom();
            }

            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFrom"));
            Wait.forSeconds(3);
            requestPayment.selectParticipant();
            Wait.forSeconds(3);
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
                Wait.forSeconds(4);
                requestPayment.clickRequestFrom();
                Wait.forSeconds(2);
            }

            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(333, 768, 5); //J7
            }

            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFromname"));

            requestPayment.selectParticipant();
            //Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
//            requestPayment.enterMessageDetails(PropertyReader.testDataOf("Message"));
//            requestPayment.clickDepositTo();
            //requestPayment.checkIfParticipentAmountIsClickable();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {

            Wait.forSeconds(10);
            //requestPayment.clickEachBtn();
            //requestPayment.clickRequestTheAmountOfSaveBtn();
            // Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
            requestPayment.clickRequestFrom();
            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFrom"));
            requestPayment.selectFirstParticipantIOS();
            Wait.forSeconds(5);
            // Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
            requestPayment.clickRequestFromsecondIOS();
            Wait.forSeconds(2);
            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFromname"));
            Wait.forSeconds(2);
            requestPayment.selectSecondParticipantIOS();
        }
    }

    @Then("^I should see the requested amounted is same for each participants \"([^\"]*)\" \"([^\"]*)\" for Each split option$")
    public void i_should_see_the_requested_anounted_is_same_for_each_participants_for_each_split_option(String amount1, String amount2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //requestPayment.verifyrequestpaymentsplitedamount(amount1,amount2);
            // requestPayment.clickNext();
            requestPayment.clickReviewandRequestEditBtn();
            requestPayment.clickDone();
            Wait.forSeconds(5);
            requestPayment.verifyReviewAndRequestAmount1(amount1);
            Wait.forSeconds(3);
            requestPayment.verifyReviewAndRequestAmount2(amount2);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickReviewandRequestEditBtn();
            //requestPayment.clickDone();
            Wait.forSeconds(5);
            requestPayment.verifyReviewAndRequestAmount1(amount1);
            Wait.forSeconds(3);
            requestPayment.verifyReviewAndRequestAmount2(amount2);
        }
    }

    @And("^I click on Save button and select participents$")
    public void I_click_on_Save_button_and_select_participents() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.clickRequestTheAmountOfSaveBtn();
            // actions.Touch.pressByCoordinates(347, 630, 5);
            Wait.forSeconds(10);
            Swipe.swipe.swipeVertical(2, 0.8, 0.5, 5);
            requestPayment.clickRequestFrom();
            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFrom"));
            requestPayment.selectParticipant();
            Wait.forSeconds(10);
            Swipe.swipe.swipeVertical(2, 0.8, 0.5, 5);
            requestPayment.clickRequestFrom();
            Wait.forSeconds(5);
            //Swipe.swipe.swipeVertical(2, 0.8, 0.5, 5);
            //actions.Touch.pressByCoordinates(333, 768, 5);
            Wait.forSeconds(2);
            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFromname"));
            Wait.forSeconds(2);
            requestPayment.selectParticipant();
        }
        else if (DriverManager.OS.equalsIgnoreCase("IOS"))
        {
            requestPayment.clickRequestTheAmountOfSaveBtn();
            Wait.forSeconds(5);
            Swipe.swipe.swipeVertical(2, 0.8, 0.5, 5);
            requestPayment.clickRequestFrom();
            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFrom"));
            requestPayment.selectFirstParticipantIOS();
            Wait.forSeconds(5);
            requestPayment.clickRequestFromsecondIOS();
            Swipe.swipe.swipeVertical(2, 0.8, 0.5, 5);
            Wait.forSeconds(2);
            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFromname"));
            Wait.forSeconds(2);
            requestPayment.selectSecondParticipantIOS();
        }
    }

    @Then("^I should see the requested amounted is same for each participants \"([^\"]*)\" \"([^\"]*)\" for Evenly split option$")
    public void i_should_see_the_requested_amounte_is_same_for_each_participants_for_evenly_split_option(String amount1, String amount2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //requestPayment.verifyrequestpaymentsplitedamount(amount1,amount2);
            Wait.forSeconds(3);
            requestPayment.verifyReviewAndRequestAmount1(PropertyReader.testDataOf("ReviewAndRequestAmount1"));
            Wait.forSeconds(4);
            requestPayment.verifyReviewAndRequestAmount2(amount2);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyReviewAndRequestAmount1(PropertyReader.testDataOf("ReviewAndRequestAmount1"));
            requestPayment.verifyReviewAndRequestAmount2(PropertyReader.testDataOf("ReviewAndRequestAmount2"));
        }
    }

    @And("^I select participents and amount details in requesting split option as Unevenly$")
    public void i_select_partipents_and_amount_details_in_requesting_split_option_as_Unevenly() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            // actions.Touch.pressByCoordinates(347, 630, 5);
            Wait.forSeconds(10);
            Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
            requestPayment.clickRequestFrom();
            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFrom"));
            requestPayment.selectParticipant();
            Wait.forSeconds(10);
            Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);

            requestPayment.clickRequestFrom();
            Wait.forSeconds(2);

            //actions.Touch.pressByCoordinates(333, 768, 5);

            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFromname"));

            requestPayment.selectParticipant();
            //Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
            requestPayment.enterMessageDetails(PropertyReader.testDataOf("Message"));
            requestPayment.clickDepositTo();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(5);
            Swipe.swipe.swipeVertical(2, 0.8, 0.5, 5);
            requestPayment.clickRequestFrom();
            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFrom"));
            requestPayment.selectFirstParticipantIOS();
            Wait.forSeconds(5);
            requestPayment.clickRequestFromsecondIOS();
            Swipe.swipe.swipeVertical(2, 0.8, 0.5, 5);
            Wait.forSeconds(7);
            requestPayment.enterContactName(PropertyReader.testDataOf("RequestFromname"));
            Wait.forSeconds(2);
            requestPayment.selectSecondParticipantIOS();
        }
    }

    @And("^I enter participent amount details in Request the amount \"([^\"]*)\" \"([^\"]*)\" of page$")
    public void i_enter_participent_amount_details_in_request_the_amount_of_page(String amount1, String amount2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID"))
        {

            Wait.forSeconds(8);
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30"))
            {
                requestPayment.clickUnevenlyRequestFromFirstAmount();
            }
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131"))
            {
                actions.Touch.pressByCoordinates(328, 375, 5); //J7
            }
            requestPayment.enterRequesttheamountofUnevenlyAmount1(amount1);
            Wait.forSeconds(2);

            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30"))
            {
                requestPayment.clickUnevenlyRequestFromSecondAmount();
            }
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131"))
            {
                actions.Touch.pressByCoordinates(331, 503, 5); //J7
            }
            requestPayment.enterRequesttheamountofUnevenlyAmount2(amount2);
        }

        else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(10);
            //requestPayment.clickUnevenlyRequestFromFirstAmount();
            actions.Touch.pressByCoordinates(258, 300, 5);
            requestPayment.enterRequesttheamountofUnevenlyAmount1(amount1);
            Wait.forSeconds(10);
            //requestPayment.clickUnevenlyRequestFromSecondAmount();
            actions.Touch.pressByCoordinates(258, 331, 5);
            requestPayment.enterRequesttheamountofUnevenlyAmount2(amount2);
        }
    }

    @And("^i enter message \"([^\"]*)\" and Deposit to fields and navigate to next page$")
    public void i_enter_message_and_deposit_to_fields_and_navigate_to_next_page(String msg) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(5);
            requestPayment.enterMessageDetails(msg);
            requestPayment.clickDepositTo();
            requestPayment.clickNext();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.enterMessageDetails(msg);
            Wait.forSeconds(10);
            requestPayment.clickDepositTo();
            requestPayment.clickNext();
        }
    }

    @Then("^i should see the participents amount \"([^\"]*)\" \"([^\"]*)\" in Review and Request page$")
    public void i_should_see_the_participents_amount_in_review_and_request_page(String amount1, String amount2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(10);
            requestPayment.verifyReviewAndRequestAmount1(amount1);
            requestPayment.verifyReviewAndRequestAmount2(amount2);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyReviewAndRequestAmount3(amount1);
            requestPayment.verifyReviewAndRequestAmount4(amount2);
        }
    }

    @Then("^i should see the error message \"([^\"]*)\" in request payment page when option is selected as Unevenly$")
    public void i_should_see_the_error_message_in_request_payment_page_when_option_is_selected_as_Unevenly(String Errormessage) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(10);
            Swipe.swipe.swipeVertical(2,.8,.2,5);
            requestPayment.verifyRequestPaymentUnevenlyTotalnotSameAsRequestedErrorMessage(Errormessage);
            requestPayment.isDisabledRequestPaymentNextBtn();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyRequestPaymentUnevenlyTotalnotSameAsRequestedErrorMessage(Errormessage);
            requestPayment.isDisabledRequestPaymentNextBtn();
        }
    }

    @Then("^I verify (\\d+) participent amount is editable for Evenly$")
    public void i_verfiy_participent_amount_is_editable_for_Evenly(int arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //requestPayment.checkIfParticipentAmountIsClickable(arg0);
            Wait.forSeconds(8);
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                //actions.Touch.pressByCoordinates(850, 850, 5); //Nokia7plus
                requestPayment.clickUnevenlyRequestFromFirstAmount();
            }
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(328, 375, 5); //J7
            }
            requestPayment.verifyPageTitle("Request Payment");
            Wait.forSeconds(2);
            //actions.Touch.pressByCoordinates(527, 751, 5);
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                //actions.Touch.pressByCoordinates(850, 1000, 5); //Nokia7plus
                requestPayment.clickUnevenlyRequestFromSecondAmount();
            }
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(331, 503, 5); //J7
            }
            requestPayment.verifyPageTitle("Request Payment");


        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.checkIfParticipentAmountIsClickableIOS(arg0);
        }
    }

    @Then("^I verify (\\d+) participent amount is editable for Each$")
    public void i_verfiy_participent_amount_is_editable_for_Each(int arg0) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //requestPayment.checkIfParticipentAmountIsClickable(arg0);
            Wait.forSeconds(8);
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                //actions.Touch.pressByCoordinates(850, 850, 5); //Nokia7plus
                requestPayment.clickUnevenlyRequestFromFirstAmount();
            }
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(328, 375, 5); //J7
            }
            requestPayment.verifyPageTitle("Request Payment");
            Wait.forSeconds(2);
            //actions.Touch.pressByCoordinates(527, 751, 5);
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                //actions.Touch.pressByCoordinates(850, 1000, 5); //Nokia7plus
                requestPayment.clickUnevenlyRequestFromSecondAmount();
            }
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(331, 503, 5); //J7
            }
            requestPayment.verifyPageTitle("Request Payment");
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.checkIfParticipentAmountIsClickableIOS(arg0);
        }
    }


    @Then("^I check newly added \"([^\"]*)\" is successfully added in \"([^\"]*)\" screen$")
    public void i_verify_newly_added_contact_in_screen(String arg1, String arg2) throws Throwable {


        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {

            Wait.forSeconds(10);
            //Swipe.swipe.swipeVertical(2, 0.8, .2, 5);
            requestPayment.enterContactName(PropertyReader.testDataOf(arg1));
            requestPayment.verifyAddContactName();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Swipe.swipe.swipeVertical(2, 0.8, .2, 5);
            requestPayment.enterContactName(PropertyReader.testDataOf("Name"));
            requestPayment.verifyAddContactNameIOS();
            requestPayment.deleteNewlyAddedContactIOS();
        }

    }

    @Then("^I should see error message \"([^\"]*)\" in \"([^\"]*)\" screen$")
    public void i_should_see_error_msg(String arg1, String arg2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            requestPayment.verifyPageTitle(arg2);
            requestPayment.verifyError(arg1);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyRequestTheAmountOfPageTitleIOS(arg2);
            requestPayment.verifyError(arg1);
        }
    }

    @Then("^I check save button is disabled in \"([^\"]*)\" screen$")
    public void i_check_save_button_is_disabled(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.verifyPageTitle(arg1);
            requestPayment.verifySaveButtonIsDisabled();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyRequestTheAmountOfPageTitleIOS(arg1);
            requestPayment.verifySaveButtonIsDisabledIOS();
        }
    }

    @When("^I leave amount field blank$")
    public void i_leave_amt_blank() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.clickAmount();
            requestPayment.clickUnEvenlyBtn();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickAmount();
            requestPayment.clickUnEvenlyBtn();
        }
    }

    @When("^I click Edit button in \"([^\"]*)\" screen$")
    public void i_click_edit_button_in_review_request_page(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.verifyPageTitle(arg1);
            requestPayment.clickEditLink();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyReviewAndRequestPageTitleIOS(arg1);
            requestPayment.clickEditLink();
        }
    }

    @Then("^I should able to edit \"([^\"]*)\" details and \"([^\"]*)\" details Successfully$")
    public void i_should_able_to_edit_details_and_details_Successfully(String arg1, String arg2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            actions.Touch.pressByCoordinates(333, 635, 5);
            requestPayment.enterRequestFromAmount(PropertyReader.testDataOf("RequestAmt1"));
            Wait.forSeconds(8);
            actions.Touch.pressByCoordinates(323, 756, 5);
            requestPayment.enterRequestFromAmount(PropertyReader.testDataOf("RequestAmt2"));
            Wait.forSeconds(8);
            requestPayment.enterMessageDetails(arg2);
            requestPayment.clickDoneBtn();
            requestPayment.clickRequestBtn();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickFirstRequestFormAmountEdit();
            requestPayment.enterRequestFromAmountIOS(PropertyReader.testDataOf("RequestAmt1"));
            Wait.forSeconds(8);
            requestPayment.clickSecondRequestFormAmountEdit();
            requestPayment.enterRequestFromAmountIOS(PropertyReader.testDataOf("RequestAmt2"));
            Wait.forSeconds(8);
            requestPayment.enterMessageDetails(arg2);
            requestPayment.clickDoneBtn();
            requestPayment.clickRequestandRequestRequestBtn();
        }
    }

    @Then("^I should see successful \"([^\"]*)\" message$")
    public void i_should_see_success_msg(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.verifySuccessMessage(arg1);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifySuccessMessage(arg1);
        }
    }

    @Then("^I click request button in \"([^\"]*)\" page$")
    public void i_click_request_button(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
//            requestPayment.verifyPageTitle(arg1);
            requestPayment.clickRequestBtn();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.verifyReviewAndRequestPageTitleIOS(arg1);
            requestPayment.clickRequestandRequestRequestBtn();
        }

    }

    @And("^I click Save Button$")
    public void i_click_save_button() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(10);
            requestPayment.clickSave();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickSave();
        }
    }
    @And("^I click Save Button bottom$")
    public void i_click_save_buttonbottom() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(10);
            requestPayment.clickSaveBtnbottom();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickSaveBtnbottom();
        }
    }

    @Then("^I should able to edit requestfrom amount \"([^\"]*)\" \"([^\"]*)\" details and \"([^\"]*)\" details Successfully$")
    public void i_should_able_to_edit_details_and_details_Successfully(String arg1, String arg2, String arg3) throws Throwable {


        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestPayment.clickRequestAmountOf();
            requestPayment.clickEachBtn();
            requestPayment.clickRequestTheAmountOfSaveBtn();
/*
            if(Devicename.currentdevicename.equalsIgnoreCase("NOKIA7") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                //actions.Touch.pressByCoordinates(850, 850, 5); //Nokia7plus
                requestPayment.clickUnevenlyRequestFromFirstAmount();
            }
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(333, 635, 5); //J7
            }
            Wait.forSeconds(8);
            requestPayment.enterRequestFromAmount(arg1);
            Wait.forSeconds(8);
            if(Devicename.currentdevicename.equalsIgnoreCase("NOKIA7") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                //actions.Touch.pressByCoordinates(850, 1000, 5); //Nokia7plus
                requestPayment.clickUnevenlyRequestFromSecondAmount();
            }
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(323, 756, 5); //J7
            }
            //requestPayment.clickUnevenlyRequestFromSecondAmount();
            Wait.forSeconds(8);
            requestPayment.enterRequestFromAmount(arg2);
            Wait.forSeconds(8);
            requestPayment.enterAmountinportion("5");
            requestPayment.clickRequestTheAmountOfSaveBtn();
            Wait.forSeconds(8);

 */
            //requestPayment.enterMessageDetails(arg3);
            //actions.Touch.pressByCoordinates(592, 1209, 5); //J7
            //Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
            requestPayment.clickDoneBtn();
            Wait.forSeconds(2);
            requestPayment.clickRequestBtn();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            requestPayment.clickRequestAmountOfIOS();
            Wait.forSeconds(2);
            requestPayment.enterAmountIOS(PropertyReader.testDataOf("Amount"));
            requestPayment.clickEvenlyBtn();
            requestPayment.clickRequestTheAmountOfSaveBtn();
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(258, 331, 5);
            }
            requestPayment.enterRequesttheamountofUnevenlyAmount1(arg1);
            Wait.forSeconds(2);
            if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(258, 370, 5);
            }
            requestPayment.enterRequesttheamountofUnevenlyAmount2(arg2);
            requestPayment.clickMessageIOS();
            Wait.forSeconds(2);
            requestPayment.enterMessageIOS(PropertyReader.testDataOf(arg3));
            requestPayment.clickNext(); //once defect fixes, need to capture Done button.
            Wait.forSeconds(2);
            requestPayment.clickRequestandRequestRequestBtn();
        }
    }

    @And("^I enter message randomtext and Deposit to fields and navigate to next page$")
    public void iEnterMessageRandomtextAndDepositToFieldsAndNavigateToNextPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String arg1;
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
             arg1=Tools.RANDOMTEXT("RANDOMTEXT",8);
            C013_ManageTransfers.Requestpaymentmessage=arg1;
            Wait.forSeconds(5);
            requestPayment.enterMessageDetails(arg1);
            requestPayment.clickDepositTo();
            requestPayment.clickNext();



        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            arg1=Tools.RANDOMTEXT("RANDOMTEXT",8);

            C013_ManageTransfers.Requestpaymentmessage=arg1;
            Wait.forSeconds(5);
            requestPayment.enterMessageDetails(arg1);
            requestPayment.clickDepositTo();
            requestPayment.clickNext();

        }
    }

    @Then("^I Click the save button in message page$")
    public void iClickTheSaveButtonInMessagePage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {

            requestPayment.clickRequestTheAmountOfSaveBtn();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {

            requestPayment.clickRequestTheAmountOfSaveBtn();
        }
    }

    @And("^I click cross symbol on participents name$")
    public void iClickCrossSymbolOnParticipentsName() throws Throwable {
        requestPayment.clickCrosssymbol();
    }

    @And("^I verify the \"([^\"]*)\" Popupmsg having \"([^\"]*)\"$")
    public void iVerifyThePopupmsgHaving(String arg0, String arg1) throws Throwable {
        requestPayment.verifyPopupmsg();
    }

    @And("^I verify the \"([^\"]*)\" and \"([^\"]*)\" option on popup message$")
    public void iVerifyTheAndOptionOnPopupMessage(String arg0, String arg1) throws Throwable {
        requestPayment.verifyCOancelptions();

    }

    @Then("^I verify the \"([^\"]*)\" and \"([^\"]*)\" button$")
    public void iVerifyTheAndButton(String arg0, String arg1) throws Throwable {
        requestPayment. verifyDashboardOptions();

    }

    @And("^i verify the \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" on \"([^\"]*)\"$")
    public void iVerifyTheOn(String arg0, String arg1, String arg2, String arg3, String arg4) throws Throwable {
        requestPayment.verifyHeaderOptions();
    }
}

