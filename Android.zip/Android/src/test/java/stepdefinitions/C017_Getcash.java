package stepdefinitions;

import actions.Verify;
import actions.Wait;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverManager;
import helper.PropertyReader;
import pages.*;
import pages.LoginPage;
import pages.OTPPage;
import pages.ReviewandTransferPage;
import runners.ConvergentTestRunner;


public class C017_Getcash {
    private LoginPage login = new LoginPage();
    private GetCash GetCash = new GetCash();
    private OTPPage otp = new OTPPage();
    private ReviewandTransferPage ReviewandTransfer = new ReviewandTransferPage();
    ConvergentTestRunner Devicename = new ConvergentTestRunner();
    private TransferFromPage ownfrompage = new TransferFromPage();




    @Then("^I Verify the Getcash Section in card page$")
    public void iVerifyTheGetcashSectionInCardPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            GetCash.verifygetcashelement();
            //GetCash.verifygetcashelementsubtitle();
        }
    }

    @And("^I Click the Getcash Section in card page$")
    public void iClickTheGetcashSectionInCardPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.clickGetcasharrow();
    }

    @Then("^I verify the Getcash fields are exist in Getcash page$")
    public void iVerifyTheGetcashFieldsAreExistInGetcashPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.verifyGetcashpageelements();
    }

    @Then("^I verify Amount field validation error message \"([^\"]*)\" for \"([^\"]*)\" and \"([^\"]*)\"$")
    public void iVerifyAmountFieldValidationErrorMessageAnd(String arg0, String arg1,String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.validateAmountfield(arg0,arg1,arg2);

    }

    @Then("^I validate the select payment terms field in getcash screen$")
    public void iValidateTheSelectPaymentTermsFieldInGetcashScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.validatepaymenttermsfield();
        Wait.forSeconds(16);
    }

    @And("^I Enter the Request amount \"([^\"]*)\" and select the payment terms is months$")
    public void iEnterTheRequestAmountAndSelectThePaymentTermsIsMonths(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.enterRequestamountandselectpaymentterms(arg0);
    }

    @Then("^I verify the interest nterest rates \"([^\"]*)\" based on the months to repay \"([^\"]*)\"$")
    public void iVerifyTheInterestNterestRatesBasedOnTheMonthsToRepay(String arg0,String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.verifyGetcashrateandrepayamount(arg0,arg1);
    }

    @And("^I am able select receive funds By and verify the values$")
    public void iAmAbleSelectReceiveFundsByAndVerifyTheValues() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.selectandverifyFundsreceiveby();
    }

    @And("^I am able select receive funds By is \"([^\"]*)\"$")
    public void iAmAbleSelectReceiveFundsByIs(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.selectandverifyFundsreceiveby1(arg0);
    }

    @Then("^I select the accountnumber \"([^\"]*)\" using tap to select account option$")
    public void iSelectTheAccountnumberUsingTapToSelectAccountOption(String arg1) throws Throwable {
        GetCash.selectAccountnumber();

    }

    @Then("^I select the pick up point and pickup avenue$")
    public void iSelectThePickUpPointAndPickupAvenue() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.selectPickuppoint();
    }

    @Then("^I enter the other bank details$")
    public void iEnterTheOtherBankDetails() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.selectOtherbankdeatils();
    }

    @Then("^I verify the error message \"([^\"]*)\"$")
    public void iVerifyTheErrorMessage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.pickupBrancherrormessagevalidation(arg0);
    }

    @And("^I select the bank name and change the requested amount$")
    public void iSelectTheBankNameAndChangeTheRequestedAmount() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       GetCash.selectBankandchangerequestedamount();
    }

    @And("^I click the next button$")
    public void iClickTheNextButton() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.clickNextbutton();

    }




    @Then("^I verify details in the  Getcash \"([^\"]*)\" page \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
    public void iVerifyDetailsInTheGetcashPageAndAndAndAndAnd(String arg0, String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     GetCash.verifyGetcashReviewpage( arg0,  arg1,  arg2,  arg3,  arg4,  arg5,  arg6);
    }

    @And("^I verify the header \"([^\"]*)\" and click Applynow in this page$")
    public void iVerfifyTheHeaderAndClickApplynowInThisPage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     GetCash.verifyGetcashReviewandsubmitgetcash(arg0);
    }

    @Then("^I verify the Getcash Success message \"([^\"]*)\"$")
    public void iVerifyTheGetcashSuccessMessage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.verifySuccessmessaeingetcash(arg0);
    }

    @Then("^I able to modify the values Request amount \"([^\"]*)\" in \"([^\"]*)\" edit page$")
    public void iAbleToModifyTheValuesInGetcashEditPage(String arg0,String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.modifythevalesingetcashEditpage(arg0,arg1);
    }


    @And("^I click Edit Button in review and apply screen$")
    public void iClickEditButtonInReviewAndApplyScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
      GetCash.clicktheEditbuttoningetcash();
    }

    @Then("^I verify Amount field validation error message \"([^\"]*)\"$")
    public void iVerifyAmountFieldValidationErrorMessage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetCash.validateAmountfield(arg0);
    }
}
