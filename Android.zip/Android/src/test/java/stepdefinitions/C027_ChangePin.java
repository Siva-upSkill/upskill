package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import exceptions.ApplicationException;
import pages.ChangePinPage;

public class C027_ChangePin {

    ChangePinPage CP=new ChangePinPage();
    @When("^user clicks an playeveryday card$")
    public void userClicksAnPlayeverydayCard() throws ApplicationException {
        CP.clickPlayEverdayCard();
    }
    @And("^Click on manage cards$")
    public void clickOnManageCards() throws ApplicationException {
        CP.clickManageCards();
    }
    @And("^Click on Change Pin$")
    public void clickOnChangePin() throws ApplicationException {
        CP.clickChangePin();
    }

}
