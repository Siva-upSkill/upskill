package stepdefinitions;


import actions.Touch;
import actions.Wait;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverManager;
import exceptions.ApplicationException;
import helper.PropertyReader;
import pages.*;
import runners.ConvergentTestRunner;

public class C010_FundTransfer_Instapay {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private SendRequestPage sendrequest = new SendRequestPage();
    private PesonetPage pesonet = new PesonetPage();
    private TransferDetailsPage transferDetailsPage = new TransferDetailsPage();
    private TransferToPage transferToPage = new TransferToPage();
    private ReviewandTransferPage otherreviewpage = new ReviewandTransferPage();
    private TransferFromPage otherfrompage = new TransferFromPage();
    private TransferToPage othertopage = new TransferToPage();
    private ManageReceipentPage mangerecepent = new ManageReceipentPage();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();
    private String updatedamount;
    private String transferamount;

    @Given("^I'm on OtherBanks Fund Transfer from page$")
    public void i_am_on_otherbanks_fund_transfer_from_page() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            home.clickSubscribeToAppOtpNotNow();
            home.clickContinue();
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            home.clickGotoDashBoard();
            Wait.forSeconds(10);
            home.verifyIfDashboardIsDisplayed("Dashboard");
            Wait.forSeconds(15);
            home.gotoSendRequestTab();
            Wait.forSeconds(20);
            sendrequest.clickOtherBanks();
            Wait.forSeconds(8);
            sendrequest.clickSendMoneyViaInstaPay();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(10);
            home.verifyIfDashboardIsDisplayed("Dashboard");
            Wait.forSeconds(2);
            home.gotoSendRequestTabIOS();
            Wait.forSeconds(5);
            sendrequest.clickOtherBanksIOS();
            Wait.forSeconds(5);
            sendrequest.clickSendMoneyViaInstaPayIOS();
            Wait.forSeconds(5);
        }
    }


    @Then("^I navigate to \"([^\"]*)\" instapay in Convergent mobile application$")
    public void i_navigate_to_instapay_in_Convergent_mobile_application(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            sendrequest.clickOtherBanks();
            sendrequest.clickSendMoneyViaInstaPay();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(5);
            sendrequest.clickOtherBanksIOS();
            sendrequest.clickSendMoneyViaInstaPayIOS();
        }
    }

    @When("^I choose Purpose as Donation for transfer$")
    public void i_choose_purpose_as_donation_for_transfer() throws Throwable {

        sendrequest.selectTransferPurpose();

    }

    @When("^I enter transaction amount \"([^\"]*)\" PHP in amount field in \"([^\"]*)\" page$")
    public void i_enter_transaction_amount_PHP_in_amount_field(String arg1, String arg2) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //transferDetailsPage.clickBackBtn();
            Wait.forSeconds(10);

                try {
                    transferDetailsPage.clicktransferpurposeinstpay();//instpay
                    Wait.forSeconds(10);
                    transferDetailsPage.clicktransferpurposeinstpay();
                    Wait.forSeconds(10);
                    sendrequest.selectPurpose();
                }
                catch(Exception e){

                }

            transferamount = "PHP " + arg1;
            transferDetailsPage.enterTransferAmt(arg1);
            Wait.forSeconds(5);

        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            transferDetailsPage.verifyTransferDetailsPageTile(arg2);
            transferamount = "PHP " + arg1;
            transferDetailsPage.enterTransferAmt(arg1);
            transferDetailsPage.clicktransferpurposeIOS();
            sendrequest.selectPurpose();
        }
    }

    @When("^I enter \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" in \"([^\"]*)\" instapay pages$")
    public void i_enter_in_page(String arg1, String arg2, String arg3, String arg4) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
           // othertopage.verifyTransferToPageTitle(arg4);
            Wait.forSeconds(5);
            pesonet.clickBankInstapay();
              //pesonet.clickBank();
              Wait.forSeconds(8);
            pesonet.selectBankName();
            Wait.forSeconds(10);
            pesonet.enterAccountNumber(PropertyReader.testDataOf(arg2));
            Wait.forSeconds(10);
            pesonet.enterAccountName(PropertyReader.testDataOf(arg3));
            Wait.forSeconds(15);

        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            othertopage.verifyTransferToPageTitleIOS(arg4);
            Wait.forSeconds(5);
            pesonet.clickBankIOS();
            pesonet.selectBankName();
            pesonet.enterAccountNumber(PropertyReader.testDataOf(arg2));
            pesonet.enterAccountName(PropertyReader.testDataOf(arg3));
        }
    }

    @When("^I choose Source Account from list of accounts to instapay transfer in \"([^\"]*)\" page$")
    public void i_choose_from_list_of_accounts_to_transfer_in_transfer_from_page(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(5);
            //otherfrompage.verifyTransferFromPageTitle(arg1);
            pesonet.selectAccountFromList(PropertyReader.testDataOf("OWN_Source_Account"));
            Wait.forSeconds(5);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(3);
            //otherfrompage.verifyTransferFromPageTitle(arg1);
            pesonet.selectAccountFromListIOS(PropertyReader.testDataOf("OWN_Source_Account"));
            Wait.forSeconds(2);
        }
    }

    @Then("^On successful instapay transfer entries Next button should be enabled$")
    public void on_successful_transfer_entries_Next_button_should_be_enabled() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(10);
            //transferToPage.checkNextBtnEnabled();
           try {
               transferToPage.clickNextBtn();
           }
           catch(Exception e){

               try {
                   transferToPage.clickNextBtninstapay();
               }
               catch(Exception e2){
                   transferToPage.clickNextBtninstapay2();
               }
           }

        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            transferToPage.checkNextBtnEnabled();
            transferToPage.clickNextBtn();
        }
    }

    @When("^I don't enter transfer amount and select purpose in \"([^\"]*)\" page next button should be disabled$")
    public void i_dont_enter_transfer_entries_next_button_should_be_disabled(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            // transferDetailsPage.clickBackBtn();
            Wait.forSeconds(8);
            transferDetailsPage.verifyTransferDetailsPageTile(arg1);
            transferDetailsPage.checkNextButtonDisabled();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            // transferDetailsPage.clickBackBtn();
            Wait.forSeconds(8);
            transferDetailsPage.verifyTransferDetailsPageTile(arg1);
            transferDetailsPage.checkNextButtonDisabledIOS();
        }
    }

    @Then("^I should see warning message \"([^\"]*)\" for Amount field and \"([^\"]*)\" for select purpose field$")
    public void i_should_see_error_msg(String arg1, String arg2) throws Throwable {
        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {

        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            transferDetailsPage.enterTransferAmt(" ");
            transferDetailsPage.clicktransferpurposeIOS();
            sendrequest.selectPurpose();
            transferDetailsPage.verifyAmterrorInTransferDetails(arg1);
        }
    }

    @When("^I choose Inactive Source Account from list of accounts to instapay transfer in \"([^\"]*)\" page$")
    public void i_choose_inactive_from_list_of_accounts_to_transfer_in_transfer_from_page(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(5);
            otherfrompage.verifyTransferFromPageTitle(arg1);
            pesonet.selectAccountFromList(PropertyReader.testDataOf("Source_Inactive_Account"));
            Wait.forSeconds(5);
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(5);
            otherfrompage.verifyTransferFromPageTitle(arg1);
            pesonet.selectAccountFromListIOS(PropertyReader.testDataOf("Source_Inactive_Account"));
            Wait.forSeconds(5);
        }
    }

    @When("^I enter message with text \"([^\"]*)\" in other account transfer to page$")
    public void i_enter_remark_message_with_text_in_other_account_transfer_to_page(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            transferToPage.enterMessageText(PropertyReader.testDataOf(arg1));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {

            transferToPage.enterMessageTextIOS(PropertyReader.testDataOf(arg1));
        }
    }

    @When("^I enter \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" in \"([^\"]*)\" pages$")
    public void i_enter_in_page(String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            othertopage.verifyTransferToPageTitle(arg5);
            pesonet.clickBankInstapay();
            pesonet.selectBankName();
            pesonet.enterAccountNumber(PropertyReader.testDataOf(arg2));
            pesonet.enterAccountName(PropertyReader.testDataOf(arg3));
            othertopage.enterRecipientEmail(PropertyReader.testDataOf(arg4));
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            //othertopage.verifyTransferToPageTitleIOS(arg4);
            Wait.forSeconds(5);
            pesonet.clickBankIOS();
            pesonet.selectBankName();
            pesonet.enterAccountNumber(PropertyReader.testDataOf(arg2));
            pesonet.enterAccountName(PropertyReader.testDataOf(arg3));
            othertopage.enterRecipientEmailIOS(PropertyReader.testDataOf(arg4));
        }
    }

    @Then("^I should see the message with only (\\d+) characters in other account transfer to page$")
    public void i_should_see_the_message_with_only_characters_in_other_account_transfer_to_page(int arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            othertopage.verifyMessageText(arg1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            othertopage.verifyMessageTextIOS(arg1);
        }
    }

    @Then("^I validate error message \"([^\"]*)\" to ensure account name is blank$")
    public void i_validate_error_message_to_ensure_account_name_is_blank(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            transferToPage.verifyAccountNameIsBlank(arg1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            transferToPage.verifyAccountNameIsBlank(arg1);
        }
    }

    @When("^I enter \"([^\"]*)\" \"([^\"]*)\" in \"([^\"]*)\" pages$")
    public void i_enter_in_page(String arg1, String arg2, String arg3) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            othertopage.verifyTransferToPageTitle(arg3);
            pesonet.clickBankInstapay();
            //pesonet.clickBank();
            pesonet.selectBankName();
            pesonet.clickAccountName();
            pesonet.enterAccountNumber(PropertyReader.testDataOf(arg2));
            pesonet.clickAccountNumber();
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            othertopage.verifyTransferToPageTitleIOS(arg3);
            Wait.forSeconds(5);
            pesonet.clickBankIOS();
            pesonet.selectBankName();
            pesonet.clickAccountName();
            pesonet.enterAccountNumber(PropertyReader.testDataOf(arg2));
        }
    }

    @Then("^I should see \"([^\"]*)\" in Account Name field in \"([^\"]*)\" page for instapay transfer$")
    public void i_should_see_account_name_in_account_name_field(String arg1, String arg2) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            transferToPage.verifyTransferToPageTitle(arg2);
            pesonet.verifyAccountNameFieldIsFilled(PropertyReader.testDataOf(arg1));
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            transferToPage.verifyTransferToPageTitleIOS(arg2);
            pesonet.verifyAccountNameFieldIsFilledIOS(PropertyReader.testDataOf(arg1));
        }
    }

    @Then("^I should see \"([^\"]*)\" in Account Number field in \"([^\"]*)\" page for instapay transfer$")
    public void i_should_see_account_name_in_account_number_field(String arg1, String arg2) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            transferToPage.verifyTransferToPageTitle(arg2);
            pesonet.verifyAccoutNumberFilled(PropertyReader.testDataOf(arg1));
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            transferToPage.verifyTransferToPageTitleIOS(arg2);
            pesonet.verifyAccoutNumberFilledIOS(PropertyReader.testDataOf(arg1));
        }
    }

    @When("^I choose Dormant Source Account from list of accounts to instapay transfer in \"([^\"]*)\" page$")
    public void i_choose_dormant_from_list_of_accounts_to_transfer_in_transfer_from_page(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(5);
            otherfrompage.verifyTransferFromPageTitle(arg1);
            pesonet.selectAccountFromList(PropertyReader.testDataOf("Source_Dormant_Account"));
            Wait.forSeconds(5);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(3);
            //otherfrompage.verifyTransferFromPageTitle(arg1);
            pesonet.selectAccountFromListIOS(PropertyReader.testDataOf("Source_Dormant_Account"));
            Wait.forSeconds(2);
        }
    }

    @When("^I click back button in \"([^\"]*)\" page for instapay transfer$")
    public void i_click_back_button_in_transfer_details_page(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            otherfrompage.verifyTransferFromPageTitle(arg1);
            otherfrompage.clickBackBtn();
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            otherfrompage.verifyTransferFromPageTitle(arg1);
            otherfrompage.clickcloseBtnInTransferFromIOS();
        }
    }

    @Then("^I should see \"([^\"]*)\" to other banks Send money via page$")
    public void i_should_see_send_request_to_other_banks_send_money_page(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            sendrequest.verifySendRequestTitle(arg1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            sendrequest.verifySendRequestTitle(arg1);
        }
    }

    @Given("^I'm on \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" page with the \"([^\"]*)\",\"([^\"]*)\" and amount in PHP \"([^\"]*)\" for instapay transfer$")
    public void verifyOtherAccountLinki_m_on_page_with_the_and_an_amount_PHP(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws Throwable {
        welcome.clickGotITBtn_Biometrics();
        welcome.closeWelcomeMessages();
        login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
        login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
        login.clickLogin();
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        home.clickContinue();
        home.clickNotNowtoSubscribe();
        home.clickNotNowToTurnOnNotification();
        home.clickGotoDashBoard();
        home.verifyIfDashboardIsDisplayed("Dashboard");
        home.gotoSendRequestTab();
        Wait.forSeconds(5);
        Wait.forSeconds(5);
        pesonet.clickOtherBanks();
        sendrequest.clickSendMoneyViaInstaPay();
        pesonet.selectAccountFromList(PropertyReader.testDataOf("AnotherUBP_Source_Account"));
        Wait.forSeconds(5);
        pesonet.clickBankInstapay();
        pesonet.selectBankName();
        pesonet.enterAccountNumber(PropertyReader.testDataOf(arg4));
        pesonet.enterAccountName(PropertyReader.testDataOf(arg5));
        pesonet.clickNext();
        transferDetailsPage.clickBackBtn();
        transferDetailsPage.verifyTransferDetailsPageTile(arg2);
        transferDetailsPage.checkNextButtonDisabled();
        transferDetailsPage.clickTransferAmt();
        transferDetailsPage.clicktransferpurpose();
        pesonet.clickNext();
        otherreviewpage.verifyReviewandTransfertitle(arg3);
        Wait.forSeconds(5);

    }

    @When("^I click Edit link present in the From account section of Other Account review and transfer page for instapay transfer$")
    public void i_click_Edit_link_present_in_the_From_account_section_of_Other_Account_review_and_transfer_page_for_instapay_transfer() throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //otherreviewpage.clickEditlinkFromAccount();
            if(Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")) {
                actions.Touch.pressByCoordinates(723, 194, 8);
            }
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                Wait.forSeconds(15);
                //Touch.touchLongPress(1000, 500, 1000, 500);
                otherreviewpage.clickEditlinkFromAccount();
            }
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            otherreviewpage.clickEditlinkFromAccountios();
        }
    }

    @Then("^I should see Other Account \"([^\"]*)\" page with an option to change source account for instapay transfer$")
    public void i_should_see_Other_Account_page_with_an_option_to_change_source_account_for_instapay_transfer(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(5);
            otherfrompage.verifyTransferFromPageTitle(arg1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            otherfrompage.verifyTransferFromPageTitle(arg1);
        }
    }

    @When("^I choose \"([^\"]*)\" from the list in Other Account page for instapay$")
    public void i_choose_from_the_list_in_Other_Account_page(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            otherfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg1));
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            //otherfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg1));
            otherfrompage.chooseTranferFromAccountiosInstapay();
        }
    }

    @When("^I click on \"([^\"]*)\" button in \"([^\"]*)\" pages$")
    public void i_click_on_button_in_review_and_transfer_page(String arg1, String arg2) throws Throwable {
        //actions.Touch.pressByCoordinates(340, 1074, 8);
        actions.Touch.pressByCoordinates(381, 554, 8);
       //otherreviewpage.verifyReviewandTransfertitle(arg2);
        // otherreviewpage.verifyTransferBtn(arg1);
        // otherreviewpage.clickTransfer();
        //pesonet.clickProceedWithTransfer();
    }

    @And("^I choose Recipient Account from my recipient to transfer in instapay$")
    public void iChooseRecipientAccountFromMyRecipientToTransferInInstapay() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(15);
        pesonet.clickSelectFromRecipientinstapay();
        Wait.forSeconds(5);
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(25);
            pesonet.clickAccNum(PropertyReader.testDataOf("Recipient_Account"));
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(10);
            // Swipe.swipe.scrollDownToTextandClick(PropertyReader.testDataOf("Source_Account"));
            Wait.forSeconds(8);
            mangerecepent.clickSearchicon();
            mangerecepent.enterinSearchtextfield("CBCInstapay");
            Wait.forSeconds(10);
            otherfrompage.chooseTranferPesonetios();
        }
        Wait.forSeconds(2);
    }

    @Then("^verify the remaining fund transfer limit to e-wallets Instapay$")
    public void verifyTheRemainingFundTransferLimitToEWalletsInstapay() {
    }

    @And("^verify the Daily transaction limit to e-wallets Instapay$")
    public void verifyTheDailyTransactionLimitToEWalletsInstapay() {

    }

    @And("^I enter \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" in \"([^\"]*)\" Instapay page$")
    public void iEnterInInstapayPage(String arg0, String arg1, String arg2, String arg3) throws Throwable {
        Wait.forSeconds(5);
        pesonet.clickBankInstapay();
        Wait.forSeconds(8);
        pesonet.selectBankName_EwalletPeso();
        pesonet.enterMobileNumber(PropertyReader.testDataOf("EwalletInsta_Mobilenumber"));
        pesonet.enterAccountName(PropertyReader.testDataOf("EwalletInsta_Accountname"));

    }

    @Then("^Verify the error message the maximum limit per transaction via Instapay is Php (\\d+),(\\d+)\\.(\\d+)$")
    public void verifyTheErrorMessageTheMaximumLimitPerTransactionViaInstapayIsPhp(int arg0, int arg1, int arg2) throws ApplicationException, InterruptedException {
      pesonet.verifyMaximumLimitErrorMessage();
    }
}


