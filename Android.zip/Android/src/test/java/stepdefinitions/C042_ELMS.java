package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import pages.ELmsPage;

public class C042_ELMS {
    ELmsPage  ELMS = new ELmsPage();

    @And("^check if application navigated to account detailspage and click to redeem$")
    public void checkIfApplicationNavigatedToAccountDetailsPageAndClickToRedeem() throws Throwable {
       ELMS.ClickRedeem();
    }

    @Then("^enter the amount to be redeemed in amounttextbox$")
    public void enterTheAmountToBeRedeemedInAmountTextBox() throws Throwable {
        ELMS.EnterAmount();
    }

    @And("^click to nextbutton$")
    public void clickToNextButton() throws Throwable {
        ELMS.ClickNext();
    }

    @Then("^verify if the application navigates to review and redeempage$")
    public void verifyIfTheApplicationNavigatesToReviewAndRedeemPage() throws Throwable {
        ELMS.VerifyNavigationToReviewPage();
    }

    @Then("^click toredeem$")
    public void clickToRedeem() throws Throwable {
        ELMS.ClickRedeemBtn();
    }

    @And("^verify the successmessage for redemption$")
    public void verifyTheSuccessMessageForRedemption() throws Throwable {
        ELMS.VerifySuccessMessage();
    }


    @And("^click back to dashboardbutton$")
    public void clickBackToDashboardButton() throws Throwable {
        ELMS.ClickBackToAccountDetails();
    }

    @Then("^check whether application displays the increment inlinemessage$")
    public void checkWhetherApplicationDisplaysTheIncrementInlineMessage() throws Throwable {
        ELMS.verify_IncrementInlineMessage();
    }

    @Then("^enter the Invalid amount to be redeemed in amount textbox$")
    public void enterTheInvalidAmountToBeRedeemedInAmountTextBox() throws Throwable {
        ELMS.EnterInvalidAmount();
    }

    @Then("^verify the error message for invalidamount entered$")
    public void verifyTheErrorMessageForInvalidAmountEntered() throws Throwable {
        ELMS.VerifyErrorMessage();

    }

    @Then("^enter the new amount to be redeemed in amount textbox$")
    public void enterTheNewAmountToBeRedeemedInAmountTextBox() throws Throwable {
        ELMS.EnterNewAmount();

    }

    @And("^click editbutton$")
    public void clickEditButton() throws Throwable {
        ELMS.ClickEdit();
    }

    @And("^click on cancelredemption$")
    public void clickOnCancelRedemption() throws Throwable {
        ELMS.ClickCancelRedemption();
    }

    @Then("^click to cancelButton$")
    public void clickToCancelButton() throws Throwable {
        ELMS.ClickCancel();
    }


    @Then("^Check if application allows user to select Orange Card \"([^\"]*)\" in dashboard screen$")
    public void checkIfApplicationAllowsUserToSelectOrangeCardInDashboardScreen(String arg0) throws Throwable {
        ELMS.SelectOrangeCard();
    }

    @And("^click \"([^\"]*)\" merchants on \"([^\"]*)\" Page\\.$")
    public void clickMerchantsOnPage(String arg0, String arg1) throws Throwable {
        ELMS.clickAnnualFee();
    }

    @And("^verify the Header details on \"([^\"]*)\" Screen$")
    public void verifyTheHeaderDetailsOnScreen(String arg0) throws Throwable {
        ELMS.verifyHeaders();

    }

    @And("^check if the user able to click \"([^\"]*)\" on \"([^\"]*)\" screen$")
    public void checkIfTheUserAbleToClickOnScreen(String arg0, String arg1) throws Throwable {
        ELMS.ClickRedeemBtn();
    }

    @And("^Verify the success message on \"([^\"]*)\" Page and Instruction Message$")
    public void verifyTheSuccessMessageOnPageAndInstructionMessage(String arg0) throws Throwable {
        ELMS.SuccessInstruction();
    }

    @And("^I should navigate to \"([^\"]*)\" Page on clicking \"([^\"]*)\"\\.$")
    public void iShouldNavigateToPageOnClicking(String arg0, String arg1) throws Throwable {
        ELMS.clickViewHistory();
    }

    @And("^I click \"([^\"]*)\" merchants on \"([^\"]*)\" Page\\.$")
    public void iClickMerchantsOnPage(String arg0, String arg1) throws Throwable {
        ELMS.clickAnnualFeeSupplementary();

    }

    @And("^click \"([^\"]*)\" on \"([^\"]*)\" Page\\.$")
    public void clickOnPage(String arg0, String arg1) throws Throwable {
        ELMS.clickRustans();
    }

    @And("^click Select Btranch Dropdown and select Branch and click continue Button$")
    public void clickSelectBtranchDropdownAndSelectBranchAndClickContinueButton() throws Throwable {
        ELMS.clickBranchDropdown();
    }

    @And("^click \"([^\"]*)\" as merchant Name on \"([^\"]*)\" Page\\.$")
    public void clickAsMerchantNameOnPage(String arg0, String arg1) throws Throwable {
        ELMS.clickSmStore();
    }

    @Then("^select Branch Name for SM Store on clicking Branch Dropdown$")
    public void selectBranchNameForSMStoreOnClickingBranchDropdown() throws Throwable {
        ELMS.clickSMBranchName();
    }
}
