package stepdefinitions;

import base.Keywords;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import helper.PropertyReader;
import pages.OTPPage;
import pages.SwiftPage;

public class C038_Swift extends Keywords {
    SwiftPage swift = new SwiftPage();
    OTPPage otp = new OTPPage();

    @And("^user to click the International Button$")
    public void userToClickTheInternationalButton() throws Throwable {
        swift.ClickInternationalButton();
    }

    @Then("^Verify if application allow the user to navigate to International Reminder Page$")
    public void verifyIfApplicationAllowTheUserToNavigateToInternationalReminderPage() throws Throwable {
        swift.VerifyInternationalReminderPage();
    }

    @When("^user click the show more button$")
    public void userClickTheShowMoreButton() throws Throwable {
        swift.ClickShowMoreButton();
    }

    @Then("^verify the reminders details section$")
    public void verifyTheRemindersDetailsSection() throws Throwable {
        swift.VerifyReminderDetailsSection();
    }

    @When("^user click swift in international partners$")
    public void userClickSwiftInInternationalPartners() throws Throwable {
        swift.ClickSwift();
    }

    @Then("^verify the swift code required message and click okay$")
    public void verifyTheSwiftCodeRequiredMessageAndClickOkay() throws Throwable {
        swift.VerifySwiftCodeRequiredMessage();

    }

    @When("^user search for the country name and select country from list$")
    public void userSearchForTheCountryNameAndSelectCountryFromList() throws Throwable {
        swift.SelectCountry();
    }

    @And("^user enter amount, source of funds and purpose in amount details page$")
    public void userEnterAmountSourceOfFundsAndPurposeInAmountDetailsPage() throws Throwable {
        swift.EnterAmountSourceAndPurpose();
    }
    @And("^user click on next button$")
    public void userClickOnNextButton() throws Throwable {
        swift.ClickNext();
    }

    @And("^user click the got it button$")
    public void userClickTheGotItButton() throws Throwable {
        swift.ClickGotIt();
    }

    @And("^user enter swift code, account name, account number, recipient relationship and email  in transfer details page$")
    public void userEnterSwiftCodeAccountNameAccountNumberRecipientRelationshipAndEmailInTransferDetailsPage() throws Throwable {
        swift.EnterTransferDetails();
    }

    @When("^User click next button$")
    public void userClickNextButton() throws Throwable {
        swift.ClickNextButton1();
    }

    @Then("^verify the recipient address header$")
    public void verifyTheRecipientAddressHeader() throws Throwable {
        swift.VerifyRecipientAddressHeader();
    }

    @And("^user enter city, address and zip code$")
    public void userEnterCityAddressAndZipCode() throws Throwable {
        swift.EnterAddressDetails();
    }

    @Then("^verify the review and send header$")
    public void verifyTheReviewAndSendHeader() throws Throwable {
        swift.VerifyReviewAndSendHeader();
    }

    @And("^click to terms and conditions check box$")
    public void clickToTermsAndConditionsCheckBox() throws Throwable {
        swift.ClickTermsAndConditions();
    }

    @And("^I click send button$")
    public void iClickSendButton() throws Throwable {
        swift.ClickSend();
    }

    @Then("^verify the transaction cancellation and cut off message$")
    public void verifyTheTransactionCancellationAndCutOffMessage() throws Throwable {
        swift.VerifyTransactionCutOffMessage();
    }

    @And("^I click to proceed with transfer$")
    public void iClickToProceedWithTransfer() throws Throwable {
        swift.ClickProceed();
    }

    @Then("^verify the transaction details Page$")
    public void verifyTheTransactionDetailsPage() throws Throwable {
        swift.VerifyTransactionDetailsPage();
    }
    @Then("^verify the transaction details Page after Edit amount details$")
    public void verifyTheTransactionDetailsPage_Edit() throws Throwable {
        swift.VerifyTransactionDetailsPage_Edit();
    }
    @And("^user click on next button(\\d+)$")
    public void userClickOnNextButton(int arg0) throws Throwable {
        swift.ClickNextButton2();
    }

    @And("^user click edit button in amount details section$")
    public void userClickEditButtonInAmountDetailsSection() throws Throwable {
        swift.userClickEditButtonInAmountDetailsSection();
    }

    @And("^user click save and continue$")
    public void userClickSaveAndContinue() throws Throwable {
        swift.ClickSaveAndContinue();
    }

    @And("^user click to save changes button$")
    public void userClickToSaveChangesButton() throws Throwable {
        swift.ClickSaveChanges();

    }

    @And("^user click edit button in Transfer Details$")
    public void userClickEditButtonInTransferDetails() throws Throwable {
        swift.ClickEditButtonInTransferDetails();
    }

    @And("^user click edit button in Recipient Address details$")
    public void userClickEditButtonInRecipientAddressDetails() throws Throwable {
        swift.ClickEditButtonInRecipientDetails();
    }

    @Then("^verify the error message for exceeding amount$")
    public void verifyTheErrorMessageForExceedingAmount() throws Throwable {
        swift.VerifyInlineMessageForExceedingAmount();
    }

    @And("^user enter Invalid amount$")
    public void userEnterInvalidAmount() throws Throwable {
        swift.EnterInvalidAmount();
    }

    @Then("^verify the error message for country not eligible for Swift Transfer$")
    public void verifyTheErrorMessageForCountryNotEligibleForSwiftTransfer() throws Throwable {
        swift.VerifyErrorMessageForCountryNotEligible();

    }

    @When("^user search for the country not eligible for Swift Transfer and select the country$")
    public void userSearchForTheCountryNotEligibleForSwiftTransferAndSelectTheCountry() throws Throwable {
        swift.SelectCountryThatIsNotEligibleForSwift();
    }

    @When("^I enter Valid OTP \"([^\"]*)\" in Swift account transfer page$")
    public void iEnterValidOTPInSwiftAccountTransferPage(String arg0) throws Throwable {
        otp.enterOTP(PropertyReader.testDataOf(arg0));
    }

    @Then("^verify the application Displays the options in Send/Receive Page$")
    public void verifyTheApplicationDisplaysTheOptionsInSendReceivePage() throws Throwable {
        swift.verifySendPage();
    }

    @Then("^veify the application Displays the options on clicking Receive Tab on Send/Receive Page$")
    public void veifyTheApplicationDisplaysTheOptionsOnClickingReceiveTabOnSendReceivePage() throws Throwable {
        swift.verifyReceivePage();
    }

    @Then("^verify the application displays the options Below \"([^\"]*)\" Header in Receive Tab \\.$")
    public void verifyTheApplicationDisplaysTheOptionsBelowHeaderInReceiveTab(String arg0) throws Throwable {
       swift.verifyManageHeaders();
    }

    @Then("^verify the application displays the Remainder Popup Message on clicking grayscale Country\\.$")
    public void verifyTheApplicationDisplaysTheRemainderPopupMessageOnClickingGrayscaleCountry() throws Throwable {
        swift.verifyGrayscalePopupmsg();
    }

    @Then("^verify the applications displays the Source fields on clicking \"([^\"]*)\" dropdown$")
    public void verifyTheApplicationsDisplaysTheSourceFieldsOnClickingDropdown(String arg0) throws Throwable {
        swift.verifySourceFundDropDown();
    }

    @Then("^verify the applications displays the Purposes on clicking \"([^\"]*)\" Dropdown$")
    public void verifyTheApplicationsDisplaysThePurposesOnClickingDropdown(String arg0) throws Throwable {
        swift.verifyPurposeDropDown();
    }

    @Then("^verify application displays the \"([^\"]*)\" in transfer details page$")
    public void verifyApplicationDisplaysTheInTransferDetailsPage(String arg0) throws Throwable {
       swift.verifyHeadersinTransactiondetails();
    }

    @And("^user navigate to Swift Details page on clicking \"([^\"]*)\" in Transfer Details page$")
    public void userNavigateToSwiftDetailsPageOnClickingInTransferDetailsPage(String arg0) throws Throwable {
        swift.clickLearnMore();

    }

    @Then("^verify aplication displays the \"([^\"]*)\" on Receipent Address Page$")
    public void verifyAplicationDisplaysTheOnReceipentAddressPage(String arg0) throws Throwable {
        swift.verifyHeaderonReviewScreen();
    }
}
