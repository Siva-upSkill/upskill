package stepdefinitions;

import actions.Wait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import driver.DriverManager;
import gherkin.lexer.Th;
import helper.PropertyReader;
import net.bytebuddy.implementation.bytecode.Throw;
import pages.*;
import runners.ConvergentTestRunner;

public class C023_UITF {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private UITFPage uitfPage = new UITFPage();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();
    WelcomePage welcomepage = new WelcomePage();


    @Given("^I'm on Welcome page in Convergent mobile application for UITF$")
    public void i_m_on_landing_page_in_Convergent_mobile_application_for_UITF() throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Account6_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            Wait.forSeconds(8);
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(10);
            home.clickContinue();
            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(8);
            home.verifyIfDashboardIsDisplayed("Dashboard");
            Wait.forSeconds(5);
        }
    }


    @When("^I click on UITF Account in the dashboard$")
    public void I_click_on_UITF_Account_in_the_sdashboard() throws Throwable {
        Wait.forSeconds(10);
        uitfPage.clickUITFAccount();
    }

    @And("^I click Subscribe button in Account details page$")
    public void I_click_Subscribe_button_in_Account_details_page()throws Throwable {
        Wait.forSeconds(5);
        uitfPage.clickSubscribeBtn();
    }

    @And("^I enter amount \"([^\"]*)\" and select account and click next button in details page$")
    public void I_enter_amount_and_select_account_and_click_next_button_in_details_page(String arg1) throws Throwable {

        uitfPage.enterAmountTxt(arg1);
        //uitfPage.selectAccountforUITF();
        uitfPage.clickNextBtn();
    }

    @And("^I click Subscribe PHP button in Review and Subscribe page$")
    public void I_click_Subscribe_PHP_button_in_Review_and_Subscribe_page() throws Throwable {
        uitfPage.clickSubcribePHPBtn();
    }

    @And("^I click proceed button in IMPORTANT and enter valid otp \"([^\"]*)\"$")
    public void I_click_proceed_button_in_IMPORTANT_and_enter_valid_otp(String arg0) throws Throwable {
        uitfPage.clickProceedBtn();
        Wait.forSeconds(5);
        otp.enterOTP(PropertyReader.testDataOf(arg0));
    }

    @Then("^I should see Subscription order received page along with correct details$")
    public void I_should_see_Subscription_order_received_page_along_with_correct_details() throws Throwable {
        uitfPage.verifyOrderReceivedTitle();
        uitfPage.verifySubsciptionTxt();
        //uitfPage.verifySubscriptionAmt();
    }

    @And("^I click Redeem button in Account details page$")
    public void I_click_Redeem_button_in_Account_details_page() throws Throwable {
        uitfPage.clickRedeemBtn();
    }

    @And("^I click Redeem units button in Review and Redeem page$")
    public void I_click_Redeem_units_button_in_Review_and_Redeem_page() throws Throwable {
        uitfPage.clickRedeemUnits();
    }

    @Then("^I should see Redemption order received page along with correct details$")
    public void I_should_see_Redemption_order_received_page_along_with_correct_details() throws Throwable {
        uitfPage.verifyOrderReceivedTitle();
        uitfPage.verifyRedemptionTxt();
        //uitfPage.verifyRedemptionAmt();
    }

    @When("^I click Add button under Accounts in Dashboard page$")
    public void I_click_Add_button_under_Accounts_in_Dashboard_page() throws Throwable {
        uitfPage.clickAddAccountsBtn();
    }

    @And("^I click UITF button in Add Account page$")
    public void I_click_UITF_button_in_Add_Account_page() throws Throwable {
        uitfPage.clickUITFBtn_AddAccounts();
    }

    @And("^I enter \"([^\"]*)\" in UITF Account Number field$")
    public void I_enter_in_UITF_Account_Number_field(String arg1) throws Throwable {
        uitfPage.enterUITFAccountNumber(arg1);
    }

    @Then("^I should see Next button is not enabled$")
    public void I_should_see_Next_button_is_not_enabled() throws Throwable {
        uitfPage.verifyNextButtonDisabled();
    }

    @Then("^I should verify alphabets \"([^\"]*)\" are not accepted$")
    public void I_should_verify_alphabets_are_not_accepted(String emptyStr) throws Throwable {
        uitfPage.verifyUITFAccountNoTxt(emptyStr);
    }

    @Then("I should see \"([^\"]*)\" in UITF Account Number field")
    public void I_should_see_in_UITF_Account_Number_filed(String arg1) throws Throwable {
        uitfPage.verifyUITFAccountNoTxt(arg1);
    }

    @And("^I click the next button in UITF page$")
    public void I_click_the_next_button_in_UITF_page() throws Throwable {
        uitfPage.clickNextBtn();
    }

    @Then("^I verify the error message and click ok button$")
    public void I_verify_the_error_message_and_click_ok_button() throws Throwable {
        uitfPage.verifyErrMsgAndOk();
    }

    @Then("^I should see Next button is enabled$")
    public void I_should_see_Next_button_is_enabled() throws Throwable {
        uitfPage.verifyNextButtonEnabled();
    }

    @Then("^I see All,PHP Fixed Income, USD Fixed Income,Equity and Multi-Asset buttons in UITF Page$")
    public void I_see_All_PHP_Fixed_Income_USD_Fixed_Income_Equity_and_Multi_Asset_buttons_in_UITF_Page() throws Throwable {
        uitfPage.verifyUITFPageValidations();
    }

    @When("^I click on PHP Fixed Income Content$")
    public void I_click_on_PHP_Fixed_Income_Content() throws Throwable {
        uitfPage.clickPHPFixedContent();
    }

    @Then("^I see Weekly,Monthly,Yearly Button along with Investment objective$")
    public void I_see_Weekly_Monthly_Yearly_Button_along_with_Investment_objective() throws Throwable {
        uitfPage.verifyPHPFixedPageValidations();
    }

    @When("^I'm on the Sign up page in mobile application for UITF$")
    public void I_m_on_the_Sign_up_page_in_mobile_application_for_UITF() throws Throwable {
        welcomepage.clickNext();
        welcomepage.clickNext();
        welcomepage.clickNext();
        if (Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            welcomepage.clickNext();
        }
        welcomepage.clickNext();

    }

    @When("^I click on Sign up with my existing account button and accept T and C$")
    public void I_click_on_Sign_up_with_my_existing_account_button_and_accept_T_and_C() throws Throwable {
        uitfPage.clickExistingAccountBtn();
    }

    @And("^I click UITF button in Sign Up page$")
    public void I_click_UITF_button_in_Sign_Up_page() throws Throwable {
        uitfPage.clickUITFBtnSignuppage();
    }


    @When("^I click on the UITF account in the dashboard$")
    public void i_click_on_the_UITF_account_in_the_dashboard() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        uitfPage.clickUITFAccount();
    }

    @Then("^I verify the recent transactions label and view more button$")
    public void i_verify_the_recent_transactions_label_and_view_more_button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        uitfPage.verifyRecentTransacLbl_ViewMoreBtn();
    }

    @Then("^I verify the other buttons after clicking the view more button$")
    public void i_verify_the_other_buttons_after_clicking_the_view_more_button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       uitfPage.verifyOtherBtns_UITF();
    }

    @When("^I click on the Subscription product$")
    public void i_click_on_the_Subscription_product() throws Throwable {
        uitfPage.clickSubsProduct();
    }

    @Then("^I Verify whether the Subscription Transaction details screen is displayed$")
    public void i_Verify_whether_the_Subscription_Transaction_details_screen_is_displayed() throws Throwable {
        uitfPage.verifySubsDetails();
    }

    @When("^I click on UITF Button in Dashboard$")
    public void i_click_on_UITF_Button_in_Dashboard() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       uitfPage.clickUITFBtn_Dashboard();
    }
}
