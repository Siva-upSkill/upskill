package stepdefinitions;


import actions.Swipe;
import actions.Touch;
import actions.Wait;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverManager;
import exceptions.ApplicationException;
import helper.PropertyReader;
import pages.*;
import runners.ConvergentTestRunner;


public class C009_Pesonet {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();
    private SendRequestPage sendrequest = new SendRequestPage();
    private PesonetPage pesonet = new PesonetPage();
    private TransferDetailsPage transferDetailsPage = new TransferDetailsPage();
    private TransferToPage transferToPage = new TransferToPage();
    private TransferSuccessfulPage ownsuccesspage = new TransferSuccessfulPage();
    private ReviewandTransferPage otherreviewpage = new ReviewandTransferPage();
    private TransferFromPage otherfrompage = new TransferFromPage();
    private TransferToPage othertopage = new TransferToPage();

    public static Swipe swipe=new Swipe();
    private TransferDetailsPage otherdetailpage = new TransferDetailsPage();
    private AccountDetailsPage accountdetailspage = new AccountDetailsPage();
    private TransferFromPage pesonetfrompage = new TransferFromPage();
    private ReviewandTransferPage pesonetreviewpage = new ReviewandTransferPage();
    private ManageReceipentPage mangerecepent = new ManageReceipentPage();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();
    private String updatedamount;
    private String date = "18 May 2019";


    @Given("^I'm on Welcome page in Convergent mobile application$")
    public void i_m_on_landing_page_in_Convergent_mobile_application() throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            Wait.forSeconds(4);
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(3);
            home.clickContinue();
            home.clickNotNowtoSubscribe();
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung"))
            {
                home.clickNotNowToTurnOnNotification();
            }
            Wait.forSeconds(5);
            home.clickGotoDashBoard();
           //home.clickNotNowfingerprintNotification();
           //home.clickNotNowfingerprintNotification();
            Wait.forSeconds(4);
            home.verifyIfDashboardIsDisplayed("Dashboard");
            Wait.forSeconds(7);

        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(10);
            home.verifyIfDashboardIsDisplayed("Dashboard");
            Wait.forSeconds(2);
        }

    }

    @Given("^I'm on Welcome page in Convergent mobile application user2$")
    public void i_m_on_landing_page_in_Convergent_mobile_application_user2() throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Account1_UserID_2_accounts"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password_2_accounts"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            home.clickSubscribeToAppOtpNotNow();
            home.clickContinue();
//            home.clickNotNowtoSubscribe();
            home.clickNotNowToTurnOnNotification();
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(10);
            home.verifyIfDashboardIsDisplayed("Dashboard");
            Wait.forSeconds(5);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(10);
            home.verifyIfDashboardIsDisplayed("Dashboard");
            Wait.forSeconds(2);
        }

    }

    @Given("^I'm on \"([^\"]*)\" page after providing source and recipient account detail$")
    public void i_m_on_transfer_details_page_in_Convergent_mobile_application(String arg1) throws Throwable {
        transferToPage.clickSelectFromList();
        Wait.forSeconds(5);
        transferToPage.clickMyRecipient(PropertyReader.testDataOf("Other_Recipient_Account"));
        Wait.forSeconds(5);
        transferToPage.clickNextBtn();
        transferDetailsPage.verifyTransferDetailsPageTile(arg1);
    }

    @Given("^I'm in Dashboard of Convergent mobile application$")
    public void i_m_on_Dashboard_in_Convergent_mobile_application() throws Throwable {
        welcome.clickGotITBtn_Biometrics();
        welcome.closeWelcomeMessages();
        login.enterUsername(PropertyReader.testDataOf("Account1_UserID_2_accounts"));
        login.enterPassword(PropertyReader.testDataOf("Account1_Password_2_accounts"));
        login.clickLogin();
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        home.clickContinue();
        home.clickNotNowtoSubscribe();
        home.clickNotNowToTurnOnNotification();
        home.clickNotNowToTurnOnNotification();
        home.clickGotoDashBoard();
        home.verifyIfDashboardIsDisplayed("Dashboard");
    }


    @When("^I choose Send/Request tab from the footer section in welcome page$")
    public void i_choose_Send_Request_tab_from_the_footer_section_welcome_page() throws Throwable {


        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(3);
            home.gotoSendRequestTab();

        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            home.gotoSendRequestTabIOS();
            Wait.forSeconds(5);
        }
    }

    @When("^I navigate to \"([^\"]*)\" Pesonet in Convergent mobile application$")
    public void i_navigate_to_OtherBanks_Pesonet_in_Convergent_mobile_application(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(1);
            sendrequest.clickOtherBanks();
            sendrequest.clickSendMoneyViaPesoNet();

        }
    else if (DriverManager.OS.equalsIgnoreCase("IOS"))

    {
        sendrequest.clickOtherBanks();
        Wait.forSeconds(10);
        actions.Touch.pressByCoordinates(400, 720, 5);

    }

    }

    @When("^I choose Source Account from list of accounts to transfer in \"([^\"]*)\" page$")
    public void i_choose_from_list_of_accounts_to_transfer_in_transfer_from_page(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //otherfrompage.verifyTransferFromPageTitle(arg1);
            Wait.forSeconds(5);
            pesonet.selectAccountFromList(PropertyReader.testDataOf("AnotherUBP_Source_Account"));

        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(10);
            // Swipe.swipe.scrollDownToTextandClick(PropertyReader.testDataOf("Source_Account"));
            otherfrompage.chooseTranferFromAccountios();
        }

    }

    @When("^I choose an Account from list of accounts to transfer in \"([^\"]*)\" page$")
    public void i_choose_from_list_of_accounts_to_transfer_in_transfer(String arg1) throws Throwable {
        //otherfrompage.verifyTransferFromPageTitle(arg1);
        pesonet.selectAccountFromList(PropertyReader.testDataOf("User_With_2_Accounts"));
        Wait.forSeconds(5);

    }

    @When("^I choose Dormant Account from list of accounts to transfer in \"([^\"]*)\" page$")
    public void i_choose_dormant_account_from_list_of_accounts_to_transfer_in_transfer_from_page(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

            //otherfrompage.verifyTransferFromPageTitle(arg1);
            pesonet.selectAccountFromList(PropertyReader.testDataOf("Source_Dormant_Account"));
            Wait.forSeconds(10);

        }

        else  if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            otherfrompage.chooseTranferDormantToAccountios();

        }



    }

    @When("^I choose Inactive Account from list of accounts to transfer in \"([^\"]*)\" page$")
    public void i_choose_Inactive_Account_from_list_of_accounts_to_transfer_in_transfer_from_page(String arg1) throws Throwable {
        //otherfrompage.verifyTransferFromPageTitle(arg1);

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            pesonet.selectAccountFromList(PropertyReader.testDataOf("Source_Inactive_Account"));
            Wait.forSeconds(5);
        }
          else  if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            otherfrompage.chooseTransferinactiveAccountios();

        }

    }

    @When("^I enter \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" in \"([^\"]*)\" pesonet page$")
    public void i_enter_in_page(String arg1, String arg2, String arg3, String arg4) throws Throwable {

        Wait.forSeconds(10);
        pesonet.clickBankPesonet();
        Wait.forSeconds(10);
        pesonet.selectBankName();
        pesonet.enterAccountNumber(PropertyReader.testDataOf(arg2));
        pesonet.enterAccountName(PropertyReader.testDataOf(arg3));
        pesonet.clickNext();

    }
    @When("^I enter \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" in \"([^\"]*)\" pesonet Ewallet page$")
    public void i_enter_in_Ewalletpage(String arg1, String arg2, String arg3, String arg4) throws Throwable {

        Wait.forSeconds(10);
        pesonet.clickBankPesonet();
        Wait.forSeconds(10);
        pesonet.selectBankName_EwalletPeso();
        pesonet.enterAccountNumber(PropertyReader.testDataOf("EwalletPeso_Accountnumber"));
        pesonet.enterAccountName(PropertyReader.testDataOf("EwalletPeso_Accountname"));
        pesonet.clickNext();

    }

    @When("^I enter \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" in \"([^\"]*)\" screen")
    public void i_enter_in_transfer_to_page(String arg1, String arg2, String arg3, String arg4) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

            Wait.forSeconds(4);
            othertopage.verifyTransferToPageTitle(arg4);
            Wait.forSeconds(5);
            pesonet.clickBankPesonet();
            Wait.forSeconds(5);
            pesonet.selectBankName();
            pesonet.enterAccountNumber(PropertyReader.testDataOf(arg2));
            pesonet.enterAccountName(PropertyReader.testDataOf(arg3));
            Wait.forSeconds(5);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS"))  {
            pesonet.clickNext();
            othertopage.verifyTransferToPageTitleIOS(arg4);
            pesonet.clickBankIOS();
            pesonet.selectBankName();
            Wait.forSeconds(4);
            pesonet.enterAccountNumber(PropertyReader.testDataOf(arg2));
            Wait.forSeconds(2);
            pesonet.enterAccountName(PropertyReader.testDataOf(arg3));
            Wait.forSeconds(2);
           // pesonet.clickAccountNumberPageToIOS();
        }
    }

    @And("^I enter a transaction amount PHP \"([^\"]*)\" in amount field and transaction date in union bank \"([^\"]*)\" page$")
    public void i_enter_a_transaction_amount_PHP_in_amount_field_which_is_less_than_for_Pesonet_transaction(String arg1, String arg2) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(5);
            //pesonet.clickOk();
            pesonet.enterTransferAmt(arg1);

        } else if(DriverManager.OS.equalsIgnoreCase("IOS"))  {

            transferDetailsPage.verifyTransferDetailsPageTile(arg2);
            pesonet.enterTransferAmt(arg1);
        }

    }

    @Then("^I should see a date picker for choosing the transaction date$")
    public void i_should_see_a_date_picker_for_choosing_the_transaction_date() throws Throwable {
        //transferDetailsPage.verifyDatePicker();
        //pesonet.clickDate();


    }

    @When("^I choose Purpose for transfer$")
    public void i_choose_for_transfer() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(3);
            pesonet.selectPurpose();
            pesonet.clickPurpose();
        }
        else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            pesonet.selectPurpose2();
            pesonet.clickPurpose();

        }
    }
    @When("^I choose Purpose for transfer pesonet$")
    public void i_choose_for_transfer_pesonet() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(10);
            pesonet.selectPurpose();
            Wait.forSeconds(15);
            pesonet.clickPurpose();
        }
        else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            pesonet.selectPurposepesonet();
            pesonet.clickPurpose();

        }
    }
    @Then("^On successful transfer entries Next button should be enabled$")
    public void on_successful_transfer_entries_Next_button_should_be_enabled() throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(5);
            try {
                swipe.androidScrollToAnElementByText("NEXT");
                pesonet.verifyNextEnabled();
                Wait.forSeconds(9);
                pesonet.clickNext();
                Wait.forSeconds(9);
            }
            catch (Exception e){
                try {
                    transferToPage.clickNextBtninstapay();
                }
                catch(Exception e2){
                    transferToPage.clickNextBtninstapay2();
                }
            }
            otherreviewpage.clickGotitButton();
        } else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            pesonet.verifyNextEnabled();
            Wait.forSeconds(2);
            pesonet.clickNext();
            Wait.forSeconds(1);
            otherreviewpage.clickGotitButton();
        }
    }

    @Then("^On successful transfer entries Next button should be enabled Instapay$")
    public void on_successful_transfer_entries_Next_button_should_be_enabled_Instapay() throws Throwable
    {
        Wait.forSeconds(5);
        pesonet.clickNext_InstaPay();
    }

        @When("^I click on Transfer PHP from \"([^\"]*)\" page$")
    public void i_click_on_Transfer_PHP_from_page(String arg1) throws Throwable {
        pesonet.verifyReviewAndTransferPageTile(arg1);
        pesonet.clickTransfer();
        pesonet.clickProceedWithTransfer();


    }

    @When("^I enter Valid OTP$")
    public void i_enter() throws Throwable {
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));

    }

    @Then("^I should see the error message \"([^\"]*)\"$")
    public void i_should_see_the_error_message(String arg1) throws Throwable {
        Wait.forSeconds(20);
        pesonet.verifyErrorMessageBM(arg1.trim());
    }

    @When("^I click back button in \"([^\"]*)\" page$")
    public void i_click_back_button_in_transfer_details_page(String arg1) throws Throwable {
        transferDetailsPage.verifyTransferDetailsPageTile(arg1);
        transferDetailsPage.clickBackBtn();
    }

    @Then("^I should navigate to \"([^\"]*)\" page$")
    public void i_should_navigate_to_transfer_to_page(String arg1) throws Throwable {
        transferToPage.verifyTransferToPageTitle(arg1);

    }

    @When("^I enter \"([^\"]*)\" in \"([^\"]*)\" page$")
    public void i_enter_account_name_transfer_page(String arg1, String arg2) throws Throwable {
        transferToPage.verifyTransferToPageTitle(arg2);
        pesonet.enterAccountNumber(PropertyReader.testDataOf(arg1));
    }

    @Then("^I should see \"([^\"]*)\" in Account Name field in \"([^\"]*)\" page$")
    public void i_should_see_account_name_in_account_name_field(String arg1, String arg2) throws Throwable {
        transferToPage.verifyTransferToPageTitle(arg2);

        pesonet.verifyAccountNameFieldIsFilled(PropertyReader.testDataOf(arg1));


    }

    @Then("^I should see a \"([^\"]*)\" page to enter otp during account transfer$")
    public void i_should_see_a_page_to_enter_otp_during_Own_account_transfer_scenario(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            // Write code here that turns the phrase above into concrete actions
            otp.verifyPageTitle(arg1);
            Wait.forSeconds(4);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            otp.verifyPageTitle(arg1);
            Wait.forSeconds(1);
        }

    }

    @When("^I click on \"([^\"]*)\" button in \"([^\"]*)\" page$")
    public void i_click_on_button_in_review_and_transfer_page(String arg1, String arg2) throws Throwable {
        //actions.Touch.pressByCoordinates(340, 1074, 8);
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {

                Wait.forSeconds(20);
                otherreviewpage.clickTransfer();
                pesonet.clickProceedWithTransfer();
            }
            //otherreviewpage.verifyReviewandTransfertitle(arg2);
            // otherreviewpage.verifyTransferBtn(arg1);
            // otherreviewpage.clickTransfer();


        }

        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            pesonetreviewpage.clickTransfer();
            pesonet.clickProceedWithTransfer();
        }

    }

    @When("^I enter Valid OTP \"([^\"]*)\" for transfer$")
    public void i_enter_Valid_OTP_for_Other_account_transfer_scenario(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            otp.enterOTP(PropertyReader.testDataOf(arg1).trim());
            Wait.forSeconds(5);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            otp.enterOTP(PropertyReader.testDataOf(arg1).trim());
            Wait.forSeconds(5);
        }
    }

    @When("^I enter invalid OTP \"([^\"]*)\" for transfer$")
    public void i_enter_invalid_OTP_for_Other_account_transfer_scenario(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            otp.enterOTP(PropertyReader.testDataOf(arg1).trim());
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            otp.enterOTP(PropertyReader.testDataOf(arg1).trim());
        }
    }

    @Then("^I should see pop up with the error message \"([^\"]*)\"$")
    public void i_should_see_popup_with_error_message(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            pesonet.verifyInvalidOtpErrorMessage(arg1.trim());
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            pesonet.verifyInvalidOtpErrorMessage(arg1.trim());
        }
    }

    @Then("^I should see \"([^\"]*)\" screen for scenario$")
    public void i_should_see_screen_for_Other_account_transfer_scenario(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(6);
        ownsuccesspage.verifyTransferSuccessfultitle(arg1);
        pesonet.clickNewTransaction();
    }

    @And("^I choose \"([^\"]*)\" from my recipient of accounts to transfer$")
    public void i_choose_source_account_from_my_recipient(String arg1) throws Throwable {
        pesonet.clickSelectFromRecipient();
        Wait.forSeconds(4);
        pesonet.clickAccNum(PropertyReader.testDataOf("Recipient_Account_Favourites"));
        Wait.forSeconds(3);
    }

    @Then("^I should see pop up with the amt warning message \"([^\"]*)\"$")
    public void i_should_see_popup_with_amt_warning_message(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(10);
            pesonet.verifyAmtErrorMessage(arg1.trim());
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            pesonet.verifyAmtErrorMessage(arg1.trim());
        }
    }


    @Then("^I should not see Leave a purpose\\* text box in \"([^\"]*)\" page$")
    public void i_should_not_see_Leave_a_purpose_text_box_in_page(String arg1) throws Throwable {
        transferDetailsPage.verifyTransferDetailsPageTile(arg1);
        pesonet.verifyLeaveaPurposeTextBoxNotExist();
    }

    @When("^I choose Purpose as \\*OTHERS \\(Please specify\\)$")
    public void i_choose_Purpose_as_OTHERS_Please_specify() throws Throwable {
        pesonet.selectPurpose();
        pesonet.clickPurposeOthers();

    }

    @Then("^I should see Leave a purpose\\* text box in \"([^\"]*)\" page$")
    public void i_should_see_Leave_a_purpose_text_box_in_page(String arg1) throws Throwable {
        transferDetailsPage.verifyTransferDetailsPageTile(arg1);
        pesonet.verifyLeaveaPurposeTextBoxExist();
    }

    @Given("^I'm on \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" page with the \"([^\"]*)\",\"([^\"]*)\" and amount in PHP \"([^\"]*)\"$")
    public void verifyOtherAccountLinki_m_on_page_with_the_and_an_amount_PHP(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws Throwable {
        welcome.clickGotITBtn_Biometrics();
        welcome.closeWelcomeMessages();
        login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
        login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
        login.clickLogin();
        otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
        home.clickContinue();
        home.clickNotNowtoSubscribe();
        if(Devicename.currentdevicename.equalsIgnoreCase("ABC") || Devicename.currentdevicename.equalsIgnoreCase("ABC")) {
            home.clickNotNowToTurnOnNotification();
        }
        home.clickNotNowToTurnOnNotification();
        home.clickGotoDashBoard();
        home.verifyIfDashboardIsDisplayed("Dashboard");
        home.gotoSendRequestTab();
        Wait.forSeconds(5);
        Wait.forSeconds(5);
        pesonet.clickOtherBanks();
        pesonet.selectSendMoneyViaPesonet();
        pesonet.selectAccountFromList(PropertyReader.testDataOf("AnotherUBP_Source_Account"));
        Wait.forSeconds(5);
        pesonet.clickBankPesonet();
        pesonet.selectBankName();
        pesonet.enterAccountNumber(PropertyReader.testDataOf(arg4));
        pesonet.enterAccountName(PropertyReader.testDataOf(arg5));
        pesonet.clickNext();
        transferDetailsPage.verifyTransferDetailsPageTile(arg2);
        transferDetailsPage.clickTransactionDate();
        pesonet.clickOk();
        pesonet.enterTransferAmt(arg6);
        pesonet.selectPurpose();
        pesonet.clickPurpose();
        pesonet.verifyNextEnabled();
        pesonet.clickNext();
        otherreviewpage.verifyReviewandTransfertitle(arg3);
        Wait.forSeconds(5);

    }

    @When("^I click Edit link present in the From account section of Other Account review and transfer page$")
    public void i_click_Edit_link_present_in_the_From_account_section_of_Other_Account_review_and_transfer_page() throws Throwable {
        Wait.forSeconds(15);
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                otherreviewpage.clickGotitButton();
                //Touch.touchLongPress(1000, 450, 1000, 450);
                Wait.forSeconds(10);
                otherreviewpage.clickEditlinkFromAccount();
            }
            // otherreviewpage.clickEditlinkFromAccount();
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            otherreviewpage.clickEditlinkFromAccountios();
        }
    }

    @Then("^I should see Other Account \"([^\"]*)\" page with an option to change source account$")
    public void i_should_see_Other_Account_page_with_an_option_to_change_source_account(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(2);
         otherreviewpage.clickGotitButton();
        //otherfrompage.verifyTransferFromPageTitle(arg1);
    }

    @When("^I choose \"([^\"]*)\" from the list in Other Account page$")
    public void i_choose_from_the_list_in_Other_Account_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")){
            otherfrompage.chooseTranferFromAccount(PropertyReader.testDataOf(arg1));
            Wait.forSeconds(10);
            otherreviewpage.clickGotitButton();
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(10);
            // Swipe.swipe.scrollDownToTextandClick(PropertyReader.testDataOf("Source_Account"));
            otherfrompage.chooseTranferFromAccountios();
            otherreviewpage.clickGotitButton();
        }
    }

    @Then("^I should see Other Account \"([^\"]*)\" page with updated source account$")
    public void i_should_see_Other_Account_page_with_updated_source_account(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")){
            // Write code here that turns the phrase above into concrete actions
            //otherreviewpage.verifyReviewandTransfertitle(arg1);
            //ownreviewpage.verifyReviewandTransfertitle(arg1);
            //otherreviewpage.verificationafterfromaccounteditlink(PropertyReader.testDataOf("Other_Another_Source_Name"), PropertyReader.testDataOf("Other_Another_Source_Account"));
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            //ownreviewpage.verifyReviewandTransfertitle(arg1);
        }
    }

    @When("^I click Edit link present in the To account section of Other Account review and transfer page$")
    public void i_click_Edit_link_present_in_the_To_account_section_of_Other_Account_review_and_transfer_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                Wait.forSeconds(8);
                otherreviewpage.clickGotitButton();
                otherreviewpage.clickEditlinkToAccount();
                //Touch.touchLongPress(950, 711, 950, 711);
            }
            //Touch.touchLongPress(950,600,950,600);

        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(5);
            otherreviewpage.clickEditlinkToAccountios();
        }
    }

    @Then("^I should see Other Account \"([^\"]*)\" page with an option to change recipient account$")
    public void i_should_see_Other_Account_page_with_an_option_to_change_recipient_account(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            // Write code here that turns the phrase above into concrete actions
            Wait.forSeconds(3);
            othertopage.verifyTransferToPageTitle(arg1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            othertopage.verifyTransferToPageTitleIOS(arg1);
        }
    }

    @When("^I change the recipient account to \"([^\"]*)\" in Other Account transfer to\\? page$")
    public void i_change_the_recipient_account_to_in_Other_Account_transfer_to_page(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

            Wait.forSeconds(3);
            pesonet.enterAccountNumber(PropertyReader.testDataOf(arg1));

           try {
               pesonet.clickNext();
           }
           catch(Exception e){

               transferToPage.clickNextBtninstapay();
           }
            Wait.forSeconds(5);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Thread.sleep(2000);
            pesonet.enterAccountNumberTransferToIOS(PropertyReader.testDataOf(arg1));
            pesonet.clickDoneIOS();
        }
    }

    @When("^I click Edit link present in the Amount section of Other Account review and transfer page$")
    public void i_click_Edit_link_present_in_the_Amount_section_of_Other_Account_review_and_transfer_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung") || Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
                Wait.forSeconds(15);
                otherreviewpage.clickGotitButton();
                //Touch.touchLongPress(950, 960, 950, 960);
                otherreviewpage.clickEditlinkAmount();
            }
            //Touch.touchLongPress(950,900,950,900);

        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(2);
            otherreviewpage.clickEditlinkamountios();
        }
    }

    @Then("^I should see Other Account \"([^\"]*)\" page with option to change transfer amount details$")
    public void i_should_see_Other_Account_page_with_option_to_change_transfer_amount_details(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            // Write code here that turns the phrase above into concrete actions
            otherdetailpage.verifyTransferDetailsPageTile(arg1);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            transferDetailsPage.verifyTransferDetailsPageTile(arg1);
        }
    }

    @When("^I change the transfer amount to PHP \"([^\"]*)\" in Other Account transfer details page$")
    public void i_change_the_transfer_amount_to_PHP_in_Other_Account_transfer_details_page(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            // Write code here that turns the phrase above into concrete actions
            updatedamount = "PHP " + arg1;
            otherdetailpage.enterTransferAmt(arg1);
           try {
               otherdetailpage.clickDoneBtn();
               Wait.forSeconds(8);
           }
           catch(Exception e){
               transferToPage.clickNextBtninstapay2();
           }
            otherreviewpage.clickGotitButton();

        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            updatedamount = "PHP " + arg1;
            otherdetailpage.enterTransferAmt(arg1);
            otherdetailpage.clickDoneBtn();
        }
    }

    @Then("^I should see Other Account \"([^\"]*)\" page with updated transfer account$")
    public void i_should_see_Other_Account_page_with_updated_transfer_account(String arg1) throws Throwable {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            otherreviewpage.verifyReviewandTransfertitle(arg1);
            //ownreviewpage.verificationafteramounteditlink(updatedamount);
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            otherreviewpage.verifyReviewandTransfertitle(arg1);
        }
    }

    @Then("^I should see Other Account \"([^\"]*)\" page with peso accounts in Orange Background$")
    public void i_should_see_Other_Account_page_with_peso_acc_orange_background(String arg1) throws Throwable {

       // otherfrompage.verifyTransferFromPageTitle(arg1);
        otherfrompage.verifyBackGroundColor();

    }

    @Given("^I'm on \"([^\"]*)\" \"([^\"]*)\" page with the \"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_am_on_transfer_details_page(String arg1, String arg2, String arg3, String arg4) throws Throwable {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("Account1_UserID"));
            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            home.clickContinue();
            home.clickNotNowtoSubscribe();
                home.clickNotNowToTurnOnNotification();
            home.clickGotoDashBoard();
//        home.clickNotNowfingerprintNotification();
//        home.clickNotNowfingerprintNotification();
            home.verifyIfDashboardIsDisplayed("Dashboard");
            home.gotoSendRequestTab();
            Wait.forSeconds(35);
            pesonet.clickOtherBanks();
            Wait.forSeconds(15);
            pesonet.selectSendMoneyViaPesonet();
            pesonet.selectAccountFromList(PropertyReader.testDataOf("AnotherUBP_Source_Account"));
            Wait.forSeconds(5);
            pesonet.clickBankPesonet();
            pesonet.selectBankName();
            pesonet.enterAccountNumber(PropertyReader.testDataOf(arg3));
            pesonet.enterAccountName(PropertyReader.testDataOf(arg4));
            pesonet.clickNext();
            transferDetailsPage.verifyTransferDetailsPageTile(arg2);

        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(10);
            home.verifyIfDashboardIsDisplayed("Dashboard");
            Wait.forSeconds(20);
            home.gotoSendRequestTab();
            Wait.forSeconds(12);
            sendrequest.clickOtherBanks();
            sendrequest.clickSendMoneyViaPesoNet();
            Wait.forSeconds(10);
            otherfrompage.chooseTranferFromAccountios();
            pesonet.clickNext();
            pesonet.clickBankPesonet();
            pesonet.selectBankName();
            pesonet.enterAccountNumber("106400001643");
            pesonet.enterAccountName("test");
            Wait.forSeconds(3);
            othertopage.clickNextBtn();
            Wait.forSeconds(5);
            transferDetailsPage.verifyTransferDetailsPageTile(arg2);

        }

    }

    @Then("^I should see warning message \"([^\"]*)\" for Account Number and \"([^\"]*)\" for Account name in \"([^\"]*)\" page$")
    public void i_should_see_warning_message_for_Account_Number_and_for_Account_name_in_page(String arg1, String arg2, String arg3) throws Throwable {
        // othertopage.verifyTransferToPageTitle(arg3);
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

            othertopage.verifyAccNumErrorMessage(arg1);

            Wait.forSeconds(10);
            othertopage.verifyAccNameErrorMessage(arg2);


        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            //pesonet.clickAccountNumberPageToIOS2();
            arg1=arg1+".";
            othertopage.verifyAccNumErrorMessage(arg1);

            //pesonet.clickBank();
            //pesonet.selectBankName();


            othertopage.enterRecipientEmailIOS("abc@gmail.com");
            Wait.forSeconds(5);
            othertopage.verifyAccNameErrorMessage(arg2);
        }

    }

    @Then("^I should verify the button next should not be enabled when purpose is not selected$")
    public void i_should_verify_button_next_is_disabled() throws Throwable {
        //otherdetailpage.verifyleavepurposetxt();
        otherdetailpage.checkNextButtonDisabled();

    }

    @When("^I choose Source Account from the dashboard to get current account balance$")
    public void i_choose_account_from_dashboard_to_view_balance() throws Throwable {
        //pesonet.clickAccountToViewBalance1(PropertyReader.testDataOf("Source_Account"));
        accountdetailspage.getAccountBalance();
        pesonetfrompage.chooseTranferFromAccount(PropertyReader.testDataOf("Source_Account"));

    }

    @And("^I choose Recipient Account from favourites to transfer$")
    public void i_choose_source_account_from_favourites() throws Throwable {
        pesonet.clickSelectFromRecipient();
        pesonet.clickFavourites();
        Wait.forSeconds(35);
        if(DriverManager.OS.equalsIgnoreCase("ANDROID"))
        {
            pesonet.clickAccNum(PropertyReader.testDataOf("Recipient_Account"));
            Wait.forSeconds(2);

        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(10);
            // Swipe.swipe.scrollDownToTextandClick(PropertyReader.testDataOf("Source_Account"));
            Wait.forSeconds(8);
            mangerecepent.clickSearchicon();
            mangerecepent.enterinSearchtextfield("CBCInstapay");
            Wait.forSeconds(10);
            otherfrompage.chooseTranferPesonetios();
        }
    }

    @Then("^I should see Account number field is filled in \"([^\"]*)\" page$")
    public void i_should_see_account_number_field_is_filled(String arg1) throws Throwable {
        //othertopage.verifyTransferToPageTitle(arg1);
        pesonet.verifyAccoutNumberFilled(PropertyReader.testDataOf("Account_Numbers"));
    }

    @And("^I choose Recipient Account from my recipient to transfer$")
    public void i_choose_source_account_from_recipient() throws Throwable {
        Wait.forSeconds(4);
        pesonet.clickSelectFromRecipient();
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(10);
            pesonet.clickAccNum(PropertyReader.testDataOf("Recipient_Account"));
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(10);
            // Swipe.swipe.scrollDownToTextandClick(PropertyReader.testDataOf("Source_Account"));
            Wait.forSeconds(8);
            mangerecepent.clickSearchicon();
            mangerecepent.enterinSearchtextfield("CBCInstapay");
            Wait.forSeconds(10);
            otherfrompage.chooseTranferPesonetios();
        }
        Wait.forSeconds(2);
    }

    @Then("^On account validation bank, account number field and account field should be blank in \"([^\"]*)\" page$")
    public void on_account_validation_bank_accountnumber_accountname_is_blank(String arg1) throws Throwable {
        Wait.forSeconds(5);
        othertopage.verifyTransferToPageTitle(arg1);
//        othertopage.verifyAccNumberIsEmpty();
        othertopage.verifyAccnameIsEmpty();
    }

    @Then("^I validate transactions with amt \"([^\"]*)\" has been updated in \"([^\"]*)\" page$")
    public void recent_transaction_history(String arg1, String arg2) throws Throwable {
        pesonet.clickAccountToViewBalance(PropertyReader.testDataOf("Source_Account"));
        accountdetailspage.clickViewMore();
        accountdetailspage.verifyTransactionHistoryPageTitle(arg2);
        accountdetailspage.transactionhistory(arg1);

    }

    @When("^I choose future date from \"([^\"]*)\" for other UBP account fund transfers$")
    public void i_choose_future_date_as_for_other_UBP_account_for_fund_transfer(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //String data[] = date.split(" ");
        //otherUBPdetailpage.choosetransactiondate(data[2],data[0],data[1]);
        //otherdetailpage.choosefuturetransctiondate(arg1);
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            String data[] = arg1.split(" ");
            //otherUBPdetailpage.choosetransactiondate(data[2],data[0],data[1]);
            otherdetailpage.choosefuturetransctiondate(arg1);
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            Wait.forSeconds(5);
            Touch.pressByCoordinates(479,454,5);

        }
    }


    @When("^Click \"([^\"]*)\" button in the datepicker of other UBP account fund transfer details pages$")
    public void click_button_in_the_datepicker_of_other_UBP_account_fund_transfer_details_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            otherdetailpage.clickDatePickerOkBtn();
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            otherdetailpage.clickTransferfrequencydone();
        }
    }

    @Then("^The selected future date \"([^\"]*)\" should be displayed in the transaction date field in the other UBP account fund transfer details pages$")
    public void the_selected_future_date_should_be_displayed_in_the_transaction_date_field_in_the_other_UBP_account_fund_transfer_details_page(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        //otherdetailpage.verifyTransactionDate(arg1);
        otherdetailpage.verifyTransactionDate(arg1);
    }

    @Then("^I should see error message \"([^\"]*)\" in \"([^\"]*)\" page$")
    public void i_should_see_error_msg(String arg1, String arg2) throws Throwable {
        //otherdetailpage.verifyTransferDetailsPageTile(arg2);
        pesonet.verifyErrorMsg(arg1);


    }

    @When("^I change the recipient account to \"([^\"]*)\" in pesonet page$")
    public void iChangeTheRecipientAccountToInPesonetPage(String arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
//        pesonet.clickSelectFromRecipient();
 //       pesonet.clickFavourites();
//        Wait.forSeconds(2);
 //       pesonet.clickAccNum("CBfavourite");
//        Wait.forSeconds(2);
        //transferToPage.enterRecipientEmailIOS("abc@gmail.com");
        transferToPage.enterToAccount(arg0);
        transferToPage.verifyDoneBtn("DONE");
        transferToPage.clickDoneBtn();
        Wait.forSeconds(15);
        otherreviewpage.clickGotitButton();
    }

    @And("^I navigate to other banks and verify the PDDTS in Convergent mobile application$")
    public void iNavigateToAndVerifyThePDDTSInConvergentMobileApplication() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Wait.forSeconds(10);
        sendrequest.clickOtherBanks();
        sendrequest.verifypddtsisexist();

    }

    @Given("^I'm on Welcome page in Convergent mobile application with no usd account$")
    public void iMOnWelcomePageInConvergentMobileApplicationWithNoUsdAccount() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            welcome.clickGotITBtn_Biometrics();
            welcome.closeWelcomeMessages();
            login.enterUsername(PropertyReader.testDataOf("AccountnoUSD_UserID"));
            login.enterPassword(PropertyReader.testDataOf("AccountnoUSD_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            home.clickContinue();
            home.clickNotNowtoSubscribe();
                home.clickNotNowToTurnOnNotification();
            home.clickGotoDashBoard();
//            home.clickNotNowfingerprintNotification();
//            home.clickNotNowfingerprintNotification();
            Wait.forSeconds(10);
            home.verifyIfDashboardIsDisplayed("Dashboard");
            Wait.forSeconds(5);
        } else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            login.enterPassword(PropertyReader.testDataOf("Account1_Password"));
            login.clickLogin();
            otp.enterOTP(PropertyReader.testDataOf("Account1_OTP"));
            Wait.forSeconds(5);
            otp.clickNotnow();
            Wait.forSeconds(10);
            home.verifyIfDashboardIsDisplayed("Dashboard");
            Wait.forSeconds(2);
        }
    }

    @Then("^verify the remaining fund transfer limit to e-wallets pesonet$")
    public void verifyTheRemainingFundTransferLimitToEWalletsPesonet() throws ApplicationException, InterruptedException {
        pesonet.verifyRemainingFundLimit();
    }

    @And("^verify the Daily transaction limit to e-wallets pesonet$")
    public void verifyTheDailyTransactionLimitToEWalletsPesonet() throws ApplicationException, InterruptedException {
        pesonet.verifyDailyFundLimit();
    }

    @Then("^Verify the error message amount should be atleast PHP (\\d+)\\.(\\d+)$")
    public void verifyTheErrorMessageAmountShouldBeAtleastPHP(int arg0, int arg1) throws ApplicationException, InterruptedException {
        pesonet.verifyDailyLimitErrorMessage();
    }

    @And("^verify the application displays the Remainder Message on TransferDetails Screen$")
    public void verifyTheApplicationDisplaysTheRemainderMessageOnTransferDetailsScreen() throws Throwable {
        pesonet.verifyRemainderMessage();
    }

    @Then("^I verify the \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" fields on \"([^\"]*)\" page$")
    public void iVerifyTheFieldsOnPage(String arg0, String arg1, String arg2, String arg3, String arg4) throws Throwable {
       pesonet.verifyReviewTransferPage();
    }

    @And("^I click Select From Recipients in Transfer to page$")
    public void iClickSelectFromRecipientsInTransferToPage() throws Throwable {
        pesonet.clickSelectRecipients();
    }

    @And("^I click Add Symbol$")
    public void iClickAddSymbol() throws Throwable {
        pesonet.clickAddNew();
    }

    @And("^I click on Bank DropDown and select Preferred Bank$")
    public void iClickOnBankDropDownAndSelectPreferredBank() throws Throwable {
        pesonet.clickBank_Name();
    }

    @And("^I click \"([^\"]*)\" Button\\.$")
    public void iClickButton(String arg0) throws Throwable {
        pesonet.clickFavourite();

    }
}
