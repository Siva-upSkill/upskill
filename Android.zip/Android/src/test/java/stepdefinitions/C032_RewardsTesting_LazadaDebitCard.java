package stepdefinitions;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.*;
import runners.ConvergentTestRunner;

public class C032_RewardsTesting_LazadaDebitCard {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();

    private LazadaDebitCardPages lazadaDebitCardPages = new LazadaDebitCardPages();

    ConvergentTestRunner Devicename=new ConvergentTestRunner();

    @When("^I selects the Lazada debit card$")
    public void i_selects_the_Lazada_debit_card() throws Throwable {
      lazadaDebitCardPages.select_debitCard();
    }

    @When("^I click the Transfer Debit for the Lazada card$")
    public void i_click_the_Transfer_Debit_for_the_Lazada_card() throws Throwable {
        lazadaDebitCardPages.select_TransferCredits();
    }


}
