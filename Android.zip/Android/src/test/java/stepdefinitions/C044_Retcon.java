package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Retcon_Page;


public class C044_Retcon {


    Retcon_Page retcon = new Retcon_Page();



    @When("^user to select required credit card for retcon from dashboard$")
    public void userToSelectRequiredCreditCardForRetconFromDashboard() throws Throwable {
        retcon.clickcard();

    }

 //   @Then("^Verify user able to navigate to next screen Turn to Installments$")
 //   public void verifyUserAbleToNavigateToNextScreenTurnToInstallments() throws Throwable {
 //       retcon.VerifyTurnToInstallmentsScreen();
 //   }

    @And("^user click the easy convert button$")
    public void userClickTheEasyConvertButton() throws Throwable {
        retcon.ClickEasyConvert();
    }

    @Then("^Verify whether application  navigates to Select a Purchase screen$")
    public void verifyWhetherApplicationNavigatesToSelectAPurchaseScreen() throws Throwable {
        retcon.VerifySelectPurchaseScreen();
    }

    @And("^Verify whether application displays an in-line description of EasyConvert screen as Select a transaction from your qualified purchases list and easily convert them to installments$")
    public void verifyWhetherApplicationDisplaysAnInLineDescriptionOfEasyConvertScreenAsSelectATransactionFromYourQualifiedPurchasesListAndEasilyConvertThemToInstallments() throws Throwable {
        retcon.VerifyEasyConvertInlineMessage();
    }

    @Then("^verify application shows the eligible transaction list by clicking view all$")
    public void verifyApplicationShowsTheEligibleTransactionListByClickingViewAll() throws Throwable {
        retcon.ClickViewAll();
    }

    @And("^Search for a purchase and select it$")
    public void searchForAPurchaseAndSelectIt() throws Throwable {
        retcon.EnterTextInSearchBox();
    }

    @Then("^Verify whether application  navigates to easy convert screen$")
    public void verifyWhetherApplicationNavigatesToEasyConvertScreen() throws Throwable {
        retcon.VerifyEasyConvertScreen();
    }

    @And("^select a payment plan in easy convert page$")
    public void selectAPaymentPlanInEasyConvertPage() throws Throwable {
        retcon.SelectPaymentPlan();
    }

    @Then("^click to next button in easy convert page$")
    public void clickToNextButtonInEasyConvertPage() throws Throwable {
        retcon.ClickNext();
    }

    @And("^verify whether application  navigates to easy summary screen$")
    public void verifyWhetherApplicationNavigatesToEasySummaryScreen() throws Throwable {
        retcon.VerifyEasyConvertSummaryScreen();
    }


    @Then("^click to view plan option$")
    public void clickToViewPlanOption() throws Throwable {
        retcon.ClickViewPaymentPlan();
    }

    @Then("^verify the payment plan details and close$")
    public void verifyThePaymentPlanDetailsAndClose() throws Throwable {
        retcon.verifyThePaymentPlanDetailsAndClose();
    }

    @And("^click to terms and conditions link then to agree and continue$")
    public void clickToTermsAndConditionsLinkThenToAgreeAndContinue() throws Throwable {
        retcon.ClickTermsAndConditions();
    }

    @And("^click to request for easy convert$")
    public void clickToRequestForEasyConvert() throws Throwable {
        retcon.ClickRequestForEasyConvert();
    }

    @Then("^verify the easy convert requested message$")
    public void verifyTheEasyConvertRequestedMessage() throws Throwable {
        retcon.VerifyEasyConvertMessage();
    }

    @And("^user click the gotit button$")
    public void userClickTheGotitButton() throws Throwable {
        retcon.ClickGotItBtn();
    }

    @Then("^Search for a purchase$")
    public void searchForAPurchase() throws Throwable {
        retcon.EnterInvalidPurchaseNumber();
    }

    @And("^Verify the error message No search results found$")
    public void verifyTheErrorMessageNoSearchResultsFound() throws Throwable {
        retcon.NoSearchResultFoundError();
    }

    @Then("^verify application navigates to Installment History screen$")
    public void verifyApplicationNavigatesToInstallmentHistoryScreen() throws Throwable {
        retcon.VerifyInstallmentHistoryScreen();
    }

    @And("^user click the Skip button$")
    public void userClickTheSkipButton() throws Throwable {
        retcon.ClickSkipBtn();


    }

    @And("^SetUp the EasyConvert Page$")
    public void setupTheEasyConvertPage() throws Throwable{
        retcon.ClickGetStarted();
    }

    @And("^User able to click on next button EasyConvert Page$")
    public void userAbleToClickOnNextButtonEasyConvertPage() throws Throwable{
        retcon.ClickbtnNext();
    }

    @And("^user to  click Installments option on available credit card$")
    public void userToClickInstallmentsOptionOnAvailableCreditCard()throws Throwable {
        retcon.clickInstallments();
    }


    @Then("^user verify navigates to next screen with Turn To Installments on Accounts$")
    public void userVerifyNavigatesToNextScreenWithTurnToInstallmentsOnAccounts() throws Throwable {
        retcon.verify_TurntoInstallments();
    }
    @Then("^verify the inline message Your Request For Installment Is Being Processed$")
    public void verifyTheInlineMessageYourRequestForInstallmentIsBeingProcessed() throws Throwable {
        retcon.VerifyProcessingMessage();
    }

    @And("^Search for a new purchase and select it$")
    public void searchForANewPurchaseAndSelectIt() throws Throwable {
        retcon.EnterNewPurchaseNumber();
    }

    @Then("^click to edit icon in purchase details$")
    public void clickToEditIconInPurchaseDetails() throws Throwable {
        retcon.ClickEditIconInPurchaseDetails();
    }

    @And("^Search for a Another purchase and select it$")
    public void searchForAAnotherPurchaseAndSelectIt() throws Throwable {
        retcon.EnterAnotherPurchaseNumber();
    }

    @And("^click edit icon in easy concert details$")
    public void clickEditIconInEasyConcertDetails() throws Throwable {
        retcon.ClickEditIconInEasyConvert();
    }
}
