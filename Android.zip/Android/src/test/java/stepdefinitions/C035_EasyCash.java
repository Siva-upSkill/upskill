package stepdefinitions;

import actions.Wait;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.EasyCashPage;

public class C035_EasyCash {

    EasyCashPage easycash = new EasyCashPage();


//    @When("^User select easycash card on the dashboard screen$")
//    public void userSelectEasycashCardOnTheDashboardScreen() throws Throwable {
//        easycash.clickOnEasyCashCard();
//    }

    @Then("^Check if the application allows to select getcash option available card$")
    public void checkIfTheApplicationAllowsToSelectgetcashOptionAvailableCard() throws Throwable {
        easycash.clickOnGetCashOption();
    }

//    @When("^Check if application user able to click on Easycash Straight$")
//    public void checkIfApplicationUserAbleToClickOnEasycashStraight() throws Throwable {
//        easycash.clickOnEasycashStraight();
//    }
//
//    @Then("^Verify application navigates to Easycash Straight$")
//    public void verifyApplicationNavigatesToEasycashStraight() throws Throwable {
//        easycash.verifyEasyCashStraightHeader();
//    }

    @When("^Verify that user able to select account from Get Cash$")
    public void verifyThatUserAbleToSelectAccountFromGetCash() throws Throwable {
        easycash.clickSelectAccount();
    }

    @Then("^Check if application application navigate to easycash-summary page$")
    public void checkIfApplicationApplicationNavigateToEasycashSummaryPage() throws Throwable {
        easycash.verifyEasycashSummaryPage();
    }

    @When("^Check if application user able to clickable in cash advance terms and condition$")
    public void checkIfApplicationUserAbleToClickableInCashAdvanceTermsAndCondition() throws Throwable {
        easycash.clickOnCheckbox();
    }

    @And("^Check if application user able to click on Request for easycash$")
    public void checkIfApplicationUserAbleToClickOnRequestForEasycash() throws Throwable {
        easycash.clickOnRequestforEasyCashStraightButton();
    }

    @Then("^Check if application navigate to Reminder screen$")
    public void checkIfApplicationNavigateToReminderScreen() throws Throwable {
        easycash.verifyReminderPage();
    }

    @When("^Check if application user able to click Got it$")
    public void checkIfApplicationUserAbleToClickGotIt() throws Throwable {
        easycash.clickOnGotittButton();
    }

    @Then("^Check if application navigate to OTP page$")
    public void checkIfApplicationNavigateToOTPPage() throws Throwable {
        easycash.verifyOtpScreen();
    }

    @When("^Check if application allow to select or enter below minimum of PHP getting error message$")
    public void checkIfApplicationAllowToSelectOrEnterBelowMinimumOfPHPGettingErrorMessage() throws Throwable {
        easycash.EnterMinimumAmount_EasyCash();
    }

    @Then("^Verify that enter below minimum of PHP getting error message$")
    public void verifyThatEnterBelowMinimumOfPHPGettingErrorMessage() throws Throwable {
        easycash.ValidationMinimumErrorMessage();
    }

    @When("^Check if application allow to select or enter above maximum of PHP getting error message$")
    public void checkIfApplicationAllowToSelectOrEnterAboveMaximumOfPHPGettingErrorMessage() throws Throwable {
        easycash.EnterMaxmumAmount_EasyCash();
    }

    @Then("^Verify that enter above maximum of PHP getting error message$")
    public void verifyThatEnterAboveMaximumOfPHPGettingErrorMessage() throws Throwable {
        easycash.ValidationMaxmumErrorMessage();
    }

    @Then("^Verify that next button is disabled in Easycash Straight$")
    public void verifyThatNextButtonIsDisabledInEasycashStraight() throws Throwable {
        easycash.verifyNextButton();
    }

    @And("^I click the next button in Easycash Straight$")
    public void iClickTheNextButtonInEasycashStraight() throws Throwable {
        easycash.clickNextButton();
    }

//    @When("^User select easycash Installment card on the dashboard screen$")
//    public void userSelectEasycashInstallmentCardOnTheDashboardScreen() throws Throwable {
//        easycash.clickOnEasyCashInstallmentCard();
//    }

    @When("^Check if application allow user able to click on Easycash-installment$")
    public void checkIfApplicationAllowUserAbleToClickOnEasycashInstallment() throws Throwable {
        easycash.clickOnEasyCashIntallmentTransaction();
    }

    @And("^Check if application allow user to click on skip or Next$")
    public void checkIfApplicationAllowUserToClickOnSkipOrNext() throws Throwable {
        easycash.clickOnSkipOrNextButton();
    }

    @And("^Check if application allow user to click on skip or Next button under installments$")
    public void checkIfApplicationAllowUserToClickOnSkipOrNextButtonUnderInstallments() throws Throwable {
        easycash.clickonNextButton_Installments();
    }

    @And("^Check if application user able to click on Request for easycash under Installments$")
    public void checkIfApplicationUserAbleToClickOnRequestForEasycashUnderInstallments() throws Throwable {
        easycash.clickOnRequestforEasycash();

    }

    @Then("^Verify that enter below minimum of PHP getting error message in Installment$")
    public void verifyThatEnterBelowMinimumOfPHPGettingErrorMessageInInstallment() throws Throwable {
        easycash.ValidationMinimumErrorMessage_Installment();
    }

    @Then("^Verify that enter above maximum of PHP getting error message in Installment$")
    public void verifyThatEnterAboveMaximumOfPHPGettingErrorMessageInInstallment() throws Throwable {
        easycash.ValidationMaxmumErrorMessage_Installment();
    }

    @Then("^Verify application navigates to Easycash installments$")
    public void verifyApplicationNavigatesToEasycashInstallments() throws Throwable {
        easycash.verifyEasyCashInstallmentHeader();
    }

    @When("^Verify that user able to enter Requested Amount from EasyCash Installments$")
    public void verifyThatUserAbleToEnterRequestedAmountFromEasyCashInstallments() throws Throwable {
        easycash.EnterAmount_EasyCashInstallment();
    }

    @And("^User able to click on next button$")
    public void userAbleToClickOnNextButton() throws Throwable {
        easycash.clickOnNextButton();
    }

    @Then("^Check if application application navigate to easycash Installments summary page$")
    public void checkIfApplicationApplicationNavigateToEasycashInstallmentsSummaryPage() throws Throwable {
        easycash.verifyEasycashInstallmentsSummaryPage();
    }

    @When("^User able to click on installment in quick access section$")
    public void userAbleToClickOnInstallmentInQuickAccessSection() throws Throwable {
        easycash.clickOnInstallments();
    }

    @Then("^Check if application navigate to Turn to installment Account details page$")
    public void checkIfApplicationNavigateToTurnToInstallmentAccountDetailsPage() throws Throwable {
        easycash.verifyEasyCashTurntoInstallments();
    }

    @When("^User able to click view all option in installment history$")
    public void userAbleToClickViewAllOptionInInstallmentHistory() throws Throwable {
        easycash.clickOnViewAll();
    }

    @When("^User able to click valid transaction for easycash- Installment$")
    public void userAbleToClickValidTransactionForEasycashInstallment() throws Throwable {
        easycash.clickOnEasyCashIntallmentTransaction();
    }

    @Then("^Check if application navigate to installment details page$")
    public void checkIfApplicationNavigateToInstallmentDetailsPage() throws Throwable {
        easycash.verifyInstallmentsDetailsPage();
    }

    @When("^Check if application allow user able to click on View payment plan$")
    public void checkIfApplicationAllowUserAbleToClickOnViewPaymentPlan() throws Throwable {
        easycash.clickOnViewPaymentPlan();
    }

    @Then("^Check if application navigate to payment plan screen$")
    public void checkIfApplicationNavigateToPaymentPlanScreen() throws Throwable {
        easycash.verifyPaymentPlan();
    }


    @When("^Check if application user able to click on Cash Advance Option$")
    public void checkIfApplicationUserAbleToClickOnCashAdvanceOption() throws Throwable {
        easycash.clickCashAdvanceOption();

    }
    @Then("^I verify the reminder section$")
    public void iVerifyTheReminderSection() {

    }

    @Then("^Click to edit icon and enter the amount$")
    public void clickToEditIconAndEnterTheAmount() throws Throwable {
        easycash.click_Slider();
//        easycash.clickEditAndEnterAmount();
    }

    @Then("^select the account for transaction$")
    public void selectTheAccountForTransaction() throws Throwable {
        easycash.clickOnSelectaccountoptions();

    }

    @Then("^verify user able to enter OTP$")
    public void verifyUserAbleToEnterOTP() throws Throwable {
        easycash.EnterOTP();

    }

    @Then("^verify success message easycash requested$")
    public void verifySuccessMessageEasycashRequested() throws Throwable {
        easycash.verifySucessmsg();
    }

    @Then("^check user able to click edit option in cash advance summary page$")
    public void checkUserAbleToClickEditOptionInCashAdvanceSummaryPage() throws Throwable {
        easycash.clickCashAdvanceEdit();

    }

    @Then("^Click to edit icon and enter the amount new amount$")
    public void clickToEditIconAndEnterTheAmountNewAmount() throws Throwable {
        easycash.clickNewAmount();
    }

    @Then("^select the new account for transaction$")
    public void selectTheNewAccountForTransaction() throws Throwable {
        easycash.clickNewAccount();
    }

    @Then("^verify the AccountName,AccountNumber with Php amount,RecentTransactions,Rewards Header On \"([^\"]*)\" Page$")
    public void verifyTheAccountNameAccountNumberWithPhpAmountRecentTransactionsRewardsHeaderOnPage(String arg0) throws Throwable {
        easycash.verifyHeaders();
    }
    @When("^User select Credit card on the dashboard screen$")
    public void userSelectCreditCardOnTheDashboardScreen() throws Throwable {
        easycash.clickOnCreditCard();
    }


    @When("^Check if application user able to click on Easycash Option$")
    public void checkIfApplicationUserAbleToClickOnEasycashOption() throws Throwable {
        easycash.clickonEasyCashOption();
    }

    @Then("^Click to edit icon and enter the amount minimum amount$")
    public void clickToEditIconAndEnterTheAmountMinimumAmount() throws Throwable {
        easycash.clickEditOption();
    }

    @And("^user verify the inline error message for minimum amount$")
    public void userVerifyTheInlineErrorMessageForMinimumAmount() throws Throwable {
        easycash.verifyInlineErrorMsg();
    }

    @Then("^Click to edit icon and enter the amount maximum amount$")
    public void clickToEditIconAndEnterTheAmountMaximumAmount() throws Throwable {
        easycash.MaximumAmount();
    }

    @And("^user verify the inline error message for maximum amount$")
    public void userVerifyTheInlineErrorMessageForMaximumAmount() throws Throwable {
        easycash.verifyMaximumInlineErrormsg();
    }

    @Then("^select Own UnionBank Account$")
    public void selectOwnUnionBankAccount() throws Throwable {
        easycash.clickOwnUnionBank();
    }


    @And("^user verify easy cash from,requested amount,monthly installment,term,processing fee, monthly factor,Interest rate and transfer to my account$")
    public void userVerifyEasyCashFromRequestedAmountMonthlyInstallmentTermProcessingFeeMonthlyFactorInterestRateAndTransferToMyAccount() throws Throwable {
        easycash.verifyHeadersonSummaryPage();
    }

    @And("^user click to edit option in easycash summary$")
    public void userClickToEditOptionInEasycashSummary() throws Throwable {
        easycash.click_Slider();
//        easycash.clickEditAndEnterAmount();
    }

    @And("^user click to update button$")
    public void userClickToUpdateButton() throws Throwable {
        easycash.clickUpdate();
    }

    @Then("^user click to other banks and ewallet option$")
    public void userClickToOtherBanksAndEwalletOption() throws Throwable {
        easycash.clickOtherBanksewallet();
    }

    @Then("^verify application navigates to Transfer To Other Banks & e-Wallets page$")
    public void verifyApplicationNavigatesToTransferToOtherBanksEWalletsPage() throws Throwable {
        easycash.verifyTransferToOtherbank();
    }

    @And("^user select bank, enter account number and click to next$")
    public void userSelectBankEnterAccountNumberAndClickToNext() throws Throwable {
        easycash.clickBankName();
    }

    @And("^user verify easy cash from,requested amount,monthly installment,term,processing fee, monthly factor,Interest rate,BankorEwallet,AccountNumber$")
    public void userVerifyEasyCashFromRequestedAmountMonthlyInstallmentTermProcessingFeeMonthlyFactorInterestRateBankorEwalletAccountNumber() throws Throwable {
        easycash.verifyHeadersonSummaryPage();
    }

    @Then("^user click edit option in easy cash details section$")
    public void userClickEditOptionInEasyCashDetailsSection() throws Throwable {
        easycash.click_Slider();
//        easycash.clickEditAndEnterAmount();
    }
    @Then("^user click to edit option in transfer to other banks section$")
    public void userClickToEditOptionInTransferToOtherBanksSection() throws Throwable {
        easycash.clickEditOption();
    }
    @And("^user select bank, enter account number and click to update$")
    public void userSelectBankEnterAccountNumberAndClickToUpdate() {
    }

    @Then("^user click installment option$")
    public void userClickInstallmentOption() throws Throwable {
        easycash.clickOnInstallments();
    }

    @And("^click to view all option in installment history page$")
    public void clickToViewAllOptionInInstallmentHistoryPage() throws Throwable {
        easycash.clickOnViewAll();
    }

    @Then("^verify application navigates to installment history page$")
    public void verifyApplicationNavigatesToInstallmentHistoryPage() throws Throwable {
        easycash.verifyInstallmentHistory();
    }

    @When("^User select easycash card on the dashboard screen$")
    public void userSelectEasycashCardOnTheDashboardScreen() throws Throwable {
        easycash.clickOnCashAdvanceCard();
    }
}
