package stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import exceptions.ApplicationException;
import pages.*;
import runners.ConvergentTestRunner;

public class C040_Cryptowallet {

    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();

    private pages.FAQPage FAQPage = new FAQPage();
    private CryptoWalletPage cryptoWalletPage = new CryptoWalletPage();

    ConvergentTestRunner Devicename=new ConvergentTestRunner();


    @When("^I Check whether the application displays the Crypto wallet feature to every user having savings account$")
    public void i_Check_whether_the_application_displays_the_Crypto_wallet_feature_to_every_user_having_savings_account() throws Throwable {
        cryptoWalletPage.verify_CryptoWallet();
    }

    @When("^I click the crypto wallet option$")
    public void i_click_the_crypto_wallet_option() throws Throwable {
        cryptoWalletPage.click_cryptowallet();
    }

    @When("^I click Bitcoin option under crytocurrency$")
    public void i_click_Bitcoin_option_under_crytocurrency() throws Throwable {
        cryptoWalletPage.click_Bitcoin();
    }

    @When("^I click the \"([^\"]*)\" Button$")
    public void i_click_the_Button(String arg1) throws Throwable {
        if(arg1.equalsIgnoreCase("Buy BTC"))
        {
            cryptoWalletPage.click_BuyBTC();
        }
        else if (arg1.equalsIgnoreCase("SELL BTC"))
        {
            cryptoWalletPage.click_SellBTC();
        }
    }

    @When("^I select the Saving account from the account list$")
    public void i_select_the_Saving_account_from_the_account_list() throws Throwable {
        cryptoWalletPage.selectAccount();
    }

    @When("^I enter \"([^\"]*)\" as From PHP amount for \"([^\"]*)\"$")
    public void i_enter_as_From_PHP_amount(String amount,String BTC) throws Throwable {
        if(BTC.equalsIgnoreCase("Buy BTC"))
        {
            cryptoWalletPage.enterAmount(amount);
        }
        else if(BTC.equalsIgnoreCase("Sell BTC"))
        {
            cryptoWalletPage.enterAmount_AfterSwitching(amount);
        }

    }

    @When("^I check two checkbox in confirm order screen$")
    public void i_check_two_checkbox_in_confirm_order_screen() throws Throwable {
        cryptoWalletPage.checkboxes();
    }

    @When("^I click confirm button$")
    public void i_click_confirm_button() throws Throwable {
        cryptoWalletPage.click_ConfirmButton();
    }

    @When("^I verify Confirmation Title and Text in \"([^\"]*)\" Confirmation Screen$")
    public void i_verify_Confirmation_Title_and_Text_in_Confirmation_Screen(String a) throws Throwable {
        cryptoWalletPage.verify_ConfirmationScreen(a);
    }

    @When("^I click Okay button in Confirmation Screen$")
    public void i_click_Okay_button_in_Confirmation_Screen() throws Throwable {
        cryptoWalletPage.click_OkayBtn_ConfirmationScreen();
    }

    @When("^I verify whether all the details are displayed correctly in Transaction Details screen for \"([^\"]*)\"$")
    public void i_verify_whether_all_the_details_are_displayed_correctly_in_Transaction_Details_screen_for(String arg1) throws Throwable {
        if(arg1.equalsIgnoreCase("Buy BTC"))
        {
            cryptoWalletPage.verify_TransactionDetailsPage_BuyBTC();
        }
        else if (arg1.equalsIgnoreCase("Sell BTC"))
        {
            cryptoWalletPage.verify_TransactionDetailsPage_SellBTC();
        }

    }

    @When("^The application should display different options to share the transaction detail screen$")
    public void the_application_should_display_different_options_to_share_the_transaction_detail_screen() throws Throwable {
        cryptoWalletPage.Verify_ShareOption();
    }

    @When("^I click the \"([^\"]*)\" Button in Bitcoin page$")
    public void i_click_the_Button_in_Bitcoin_page(String arg1) throws Throwable {
        if(arg1.equalsIgnoreCase("Buy BTC"))
        {
            cryptoWalletPage.click_BuyBTCButton();
        }
        else if (arg1.equalsIgnoreCase("SELL BTC"))
        {
            cryptoWalletPage.click_SellBTCButton();
        }
    }



    @And("^I verify the application displays \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" on Bitcoin ExchangePage$")
    public void iVerifyTheApplicationDisplaysOnBitcoinExchangePage(String arg0, String arg1, String arg2, String arg3) throws Throwable {
        cryptoWalletPage.verify_BitcoinPage();
    }

    @And("^I verify the \"([^\"]*)\" Page displays \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" in BuyBtc page$")
    public void iVerifyThePageDisplaysInBuyBtcPage(String arg0, String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {
        cryptoWalletPage.verify_BuyBTCPage();
    }

    @And("^I verify the error Message \"([^\"]*)\"$")
    public void iVerifyTheErrorMessage(String arg0) throws Throwable {
      cryptoWalletPage.verify_Errormsg();
    }

    @And("^I verify the \"([^\"]*)\" Page displays \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" in SellBtc page$")
    public void iVerifyThePageDisplaysInSellBtcPage(String arg0, String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {
        cryptoWalletPage.verify_SellBTCPage();
    }

    @And("^I enter OTP For transfer$")
    public void iEnterOTPForTransfer() throws ApplicationException {
        cryptoWalletPage.Enter_OTP();
    }
}


