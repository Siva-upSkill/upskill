package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import pages.InstapayWaived_Pages;


public class C049_InstapayWaived {

    InstapayWaived_Pages InstapayWaived=new InstapayWaived_Pages();

    @And("^I click the from account number for Instapaywaived$")
    public void iClickTheFromAccountNumberForInstapaywaived() throws Throwable {
        InstapayWaived.FromAccountNumber_Instapay();
    }

    @Then("^I enter Account number and Account name$")
    public void iEnterAccountNumberAndAccountName() throws Throwable {
        InstapayWaived.EnterAccNumAndName();

    }

    @And("^I Enter the Amount in instapaywaived$")
    public void iEnterTheAmountInInstapaywaived() throws Throwable {
        InstapayWaived.enterTheAmount();

    }

    @Then("^User verify service fee$")
    public void userVerifyServiceFee() throws Throwable {
        InstapayWaived.VerifyServiceFee();
    }

    @And("^user click next button$")
    public void userClickNextButton() throws Throwable {
        InstapayWaived.ClickNext();

    }

    @And("^verify the inline message for account number less than (\\d+) digit$")
    public void verifyTheInlineMessageForAccountNumberLessThanDigit(int arg0) throws Throwable {
        InstapayWaived.InlineMessageAccNo();
        
    }

    @Then("^I enter Account number less than (\\d+) digit$")
    public void iEnterAccountNumberLessThanDigit(int arg0) throws Throwable {
        InstapayWaived.EnterAccNumLessThan8Digit();
    }

    @Then("^user select mobile number option and enter mobile number$")
    public void userSelectMobileNumberOptionAndEnterMobileNumber() throws Throwable {
        InstapayWaived.EnterMobileNum();
    }}
