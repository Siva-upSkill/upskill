package stepdefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.PayDirect_Pages;


public class C048_PayDirect {

    PayDirect_Pages payDirectPages = new PayDirect_Pages();

    @When("^User to select the credit card accounts for paydirect under Send from which Account Screen$")
    public void userToSelectTheCreditCardAccountsForPaydirectUnderSendFromWhichAccountScreen()throws Throwable {
        payDirectPages.ClickCreditCard();
    }

    @Then("^User verify the reminders section in paydirect reminders and click to got it button$")
    public void userVerifyTheRemindersSectionInPaydirectRemindersAndClickToGotItButton() throws Throwable{
        payDirectPages.VerifyRemindersSection();
    }

    @Then("^user enter account number and name$")
    public void userEnterAccountNumberAndName() throws Throwable {
        payDirectPages.EnterAccNumAndName();
    }

    @And("^User click the next button$")
    public void userClickTheNextButton() throws Throwable {
        payDirectPages.ClickNext();
    }

    @Then("^user click to pay button$")
    public void userClickToPayButton() throws Throwable{
        payDirectPages.ClickPayBtn();
    }

    @Then("^User click select dropdown option$")
    public void userClickSelectDropdownOption()throws Throwable {
        payDirectPages.ClickSelectPurposeDropDown();
    }

    @When("^User enter the invalid amount under Amount to Pay field under Easy Payment Details screen$")
    public void userEnterTheInvalidAmountUnderAmountToPayFieldUnderEasyPaymentDetailsScreen() throws Throwable{
        payDirectPages.InvalidAmount();
    }

    @Then("^verify the invalid amount inline error$")
    public void verifyTheInvalidAmountInlineError() throws Throwable {
        payDirectPages.VerifyInvalidAmountInline();

    }

    @Then("^user enter invalid account number and name$")
    public void userEnterInvalidAccountNumberAndName() throws Throwable {
        payDirectPages.EnterInvalidAccNo();
    }

    @Then("^user verify the invalid account number inline message$")
    public void userVerifyTheInvalidAccountNumberInlineMessage()throws Throwable {
        payDirectPages.VerifyInvalidAccInline();
    }

    @Then("^user enter account number and alpha numeric name$")
    public void userEnterAccountNumberAndAlphaNumericName() throws Throwable {
        payDirectPages.EnterAccNoAndAlphaNumericName();
    }

    @And("^User click to cancel option$")
    public void userClickToCancelOption() throws Throwable {
        payDirectPages.clickBackBtnReviewandpay();
    }

    @Then("^user click to No continue payment$")
    public void userClickToNoContinuePayment() throws Throwable {
        payDirectPages.clickNoContinuePayment();
    }

    @Then("^user verify transfer details$")
    public void userVerifyTransferDetails() throws Throwable {
        payDirectPages.verifyTransactionDetails();
    }

    @Then("^user click to yes,cancel payment$")
    public void userClickToYesCancelPayment() throws Throwable {
        payDirectPages.clickYesCancelPayment();
    }

    @And("^I select the bank Asenso Bank from listbox$")
    public void iSelectTheBankAsensoBankFromListbox() throws Throwable {
        payDirectPages.clickBankDropdown();
    }

    @Then("^verify cutoff message$")
    public void verifyCutoffMessage() {

    }

    @When("^I click the Send/Receive Money btn$")
    public void iClickTheSendReceiveMoneyBtn() {
    }

    @And("^I Select the date for scheduled transfers$")
    public void iSelectTheDateForScheduledTransfers() {
    }

    @Then("^user enter the prohibited Add message mortgage$")
    public void userEnterTheProhibitedAddMessageMortgage() throws Throwable {
        payDirectPages.ProhibitedMsgUb1();
    }

    @Then("^user enter the prohibited Add message credit card$")
    public void userEnterTheProhibitedAddMessageCreditCard() throws Throwable {
        payDirectPages.ProhibitedMsgUb2();
    }

    @Then("^user enter the prohibited Add message loan$")
    public void userEnterTheProhibitedAddMessageLoan() throws Throwable {
        payDirectPages.ProhibitedMsgUb3();
    }

    @Then("^user enter the prohibited Add message bank$")
    public void userEnterTheProhibitedAddMessageBank() throws Throwable {
        payDirectPages.ProhibitedMsgUb4();
    }

    @Then("^user enter the prohibited Add message fund$")
    public void userEnterTheProhibitedAddMessageFund() throws Throwable {
        payDirectPages.ProhibitedMsgUb5();
    }

    @Then("^user enter the prohibited Add message crypto$")
    public void userEnterTheProhibitedAddMessageCrypto() throws Throwable {
        payDirectPages.ProhibitedMsgUb6();
    }

    @Then("^user enter the prohibited Add message investments$")
    public void userEnterTheProhibitedAddMessageInvestments() throws Throwable {
        payDirectPages.ProhibitedMsgUb7();
    }

    @Then("^user enter the prohibited Add message gambling$")
    public void userEnterTheProhibitedAddMessageGambling() throws Throwable {
        payDirectPages.ProhibitedMsgUb8();
    }

    @Then("^user enter the prohibited Add message casino$")
    public void userEnterTheProhibitedAddMessageCasino() throws Throwable {
        payDirectPages.ProhibitedMsgUb9();
    }

    @Then("^user enter the prohibited Add message repayment$")
    public void userEnterTheProhibitedAddMessageRepayment() throws Throwable {
        payDirectPages.ProhibitedMsgUb10();
    }

    @Then("^user enter the prohibited Add message finance house$")
    public void userEnterTheProhibitedAddMessageFinanceHouse() throws Throwable {
        payDirectPages.ProhibitedMsgUb11();
    }
}
