package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import exceptions.ApplicationException;
import pages.*;
public class C041_Quickbalance {
    private WelcomePage welcome = new WelcomePage();
    private LoginPage login = new LoginPage();
    private OTPPage otp = new OTPPage();
    private HomePage home = new HomePage();

    private QuickBalance quickBalance=new QuickBalance();

    
      @When("^I check application displays the account details on the dashboard$")
        public void Icheckapplicationdisplaystheaccountdetailsonthedashboard ()throws Throwable{
            quickBalance.verify_Options();
      }

      @Then("^I Check application displays the Quick Balance option with description \"Enable/Disable Quick Balance$")
       public void iCheckApplicationDisplaysTheQuickBalanceOptionWithDescriptionEnableDisableQuickBalance() throws Throwable {
       quickBalance.verify_ToggleMsg();
     }

      @And("^I Click Quick Balance option in the More screen$")
      public void iClickQuickBalanceOptionInTheMoreScreen() throws Throwable {
            quickBalance.Click_QuickBalance();
        }

      @When("^I verify application allows user to Toggle On the Quick balance feature$")
      public void iVerifyApplicationAllowsUserToToggleOnTheQuickBalanceFeature() throws Throwable {
            quickBalance.Click_SwitchBtn();
        
    }

      @And("^I Toggle On the Quick balance feature$")
      public void iToggleOnTheQuickBalanceFeature() throws Throwable {
            quickBalance.Click_Onbtn();
        }

      @And("^I Verify the pop-up message \"([^\"]*)\" with NO / YES options$")
      public void iVerifyThePopUpMessageWithNOYESOptions() throws Throwable {
            quickBalance.verify_PopupMsg();

    }

      @And("^I Click yes Button in the popup window$")
      public void iClickYesButtonInThePopupWindow() throws Throwable {
            quickBalance.Click_Yesbtn();
        }

      @And("^I Verify linked accounts enabled for quick balance$")
      public void iVerifyLinkedAccountsEnabledForQuickBalance() throws Throwable {
          quickBalance.verify_FeaturesEnabled();
        
    }

      @And("^I Click Back button on quick Balance Screen$")
       public void iClickBackButtonOnQuickBalanceScreen() throws Throwable {
          quickBalance.Click_Backbtn();
      }

       @And("^I Click Log Out Button$")
       public void iClickLogOutButton() {
      }

       @And("^I Click yes button on Hang On message$")
       public void iClickYesButtonOnHangOnMessage() {
      }

     @And("^I verify the quick balance option on the user login screen$")
     public void iVerifyTheQuickBalanceOptionOnTheUserLoginScreen() throws Throwable {
            quickBalance.verify_HomequickBalance();
        
     }

    @When("^I verify application allows user to Toggle Off the Quick balance feature$")
    public void iVerifyApplicationAllowsUserToToggleOffTheQuickBalanceFeature() throws Throwable {
            quickBalance.verify_Toggleoffbtn();
      }

    @And("^I Toggle Off the Quick balance feature$")
    public void iToggleOffTheQuickBalanceFeature() throws Throwable {
            quickBalance.Click_Offbtn();}

    @And("^I Click No Button in the popup window$")
    public void iClickNoButtonInThePopupWindow() throws Throwable {
            quickBalance.Click_nobtn();
      }

    @And("^I Verify user to disable the desired accounts displayed if user has multiple accounts linked$")
    public void iVerifyUserToDisableTheDesiredAccountsDisplayedIfUserHasMultipleAccountsLinked() {
    }

    @And("^I Click any Quick balance feature$")
    public void iClickAnyQuickBalanceFeature() throws Throwable {
            quickBalance.Click_TurnOnFeature();
        
    }

    @Then("^I Verify the Message$")
    public void iVerifyTheMessage() throws Throwable {
          quickBalance.Verify_Message();

    }

    @Then("^User verify \"([^\"]*)\" and  option on Success page$")
    public void userVerifyAndOptionOnSuccessPage() throws Throwable {
        quickBalance.verify_Options();
    }

    @And("^User click \"([^\"]*)\" option on Success page\\.$")
    public void userClickOptionOnSuccessPage() throws Throwable {
          quickBalance.Click_GoSettings();
    }

    @And("^I Check enables Save option when user makes any changes in the quick balance feature$")
    public void iCheckEnablesSaveOptionWhenUserMakesAnyChangesInTheQuickBalanceFeature() throws Throwable {
          quickBalance.verify_Savebtn();
    }

    @And("^I click Save Button in quick balance feature page$")
    public void iClickSaveButtonInQuickBalanceFeaturePage() throws Throwable {
          quickBalance.Click_Savebtn();
    }

    @And("^I Verify  the pop-up message \"([^\"]*)\" with NO / YES options$")
    public void iVerifyThePopUpMessageWithNOYESOptions(String arg0) throws Throwable {
          quickBalance.verify_PopupMsg();

    }

    @And("^I click to  MORE option$")
    public void iClickToMOREOption() throws ApplicationException {
          home.clickBtnmore();
    }

    @And("^User click GOTOSETTINGS option on Success page$")
    public void userClickGOTOSETTINGSOptionOnSuccessPage() throws Throwable{
        quickBalance.Click_GoSettings();
    }
}
