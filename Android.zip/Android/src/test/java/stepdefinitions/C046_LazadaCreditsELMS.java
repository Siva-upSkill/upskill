package stepdefinitions;

import actions.Wait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import driver.DriverManager;
import exceptions.ApplicationException;
import helper.PropertyReader;
import pages.*;

public class C046_LazadaCreditsELMS {

    LazadaCreditELMS lazadaCreditELMS = new LazadaCreditELMS();

    @When("^User click Lazada Credit card$")
    public void userClickLazadaCreditCard() throws Throwable {
        lazadaCreditELMS.ClickLazadaCreditCard();

    }

    @Then("^User click to Transfer credits$")
    public void userClickToTransferCredits() throws Throwable {
        lazadaCreditELMS.ClickTransferDetails();
    }

    @Then("^User verify the reminder section and click to next$")
    public void userVerifyTheReminderSectionAndClickToNext() throws Throwable {
        lazadaCreditELMS.VerifyReminderSectionAndClickNext();
    }

    @And("^User enter the last four digit of the mobile number registered to the account and click next$")
    public void userEnterTheLastFourDigitOfTheMobileNumberRegisteredToTheAccountAndClickNext() throws Throwable {
        lazadaCreditELMS.EnterMobileNumber();
    }

    @Then("^User verify verify details section and the note section$")
    public void userVerifyVerifyDetailsSectionAndTheNoteSection() throws Throwable {
        lazadaCreditELMS.VerifyDetailSection();
    }

    @And("^User click to yes these are correct button$")
    public void userClickToYesTheseAreCorrectButton() throws Throwable {
        lazadaCreditELMS.ClickYesTheseAreCorrectButton();
    }

    @Then("^User enter the amount details and click to next$")
    public void userEnterTheAmountDetailsAndClickToNext() throws Throwable {
        lazadaCreditELMS.EnterAmount();
    }

    @And("^User click to request transfer$")
    public void userClickToRequestTransfer() throws Throwable {
        lazadaCreditELMS.ClickRequestTransfer();
    }

    @Then("^User verify the success message and click ok$")
    public void userVerifyTheSuccessMessageAndClickOk() throws Throwable {
        lazadaCreditELMS.VerifySuccessMsg();
    }

    @Then("^I verify the Invalid OTP error$")
    public void iVerifyTheInvalidOTPError() throws Throwable {
        lazadaCreditELMS.InvalidOTPError();

    }

    @Then("^verify the error message for invalid mobile number$")
    public void verifyTheErrorMessageForInvalidMobileNumber() throws Throwable {
        lazadaCreditELMS.InvalidMobileNumberError();
    }

    @Then("^User enter the invalid amount details and verify the inline message Please enter an amount in increments of Php (\\d+)$")
    public void userEnterTheInvalidAmountDetailsAndVerifyTheInlineMessagePleaseEnterAnAmountInIncrementsOfPhp(int arg0) throws Throwable {
        lazadaCreditELMS.InvalidAmountInlineMessage();
    }

    @And("^User enter the last four digit of the mobile number not registered to the account and click next$")
    public void userEnterTheLastFourDigitOfTheMobileNumberNotRegisteredToTheAccountAndClickNext() throws Throwable {
        lazadaCreditELMS.EnterInvalidMobileNumber();
    }

    @And("^User click to edit and change amount and click to next$")
    public void userClickToEditAndChangeAmountAndClickToNext() throws Throwable {
        lazadaCreditELMS.ClickToEdit();
    }

    @When("^User click Lazada Debit card$")
    public void userClickLazadaDebitCard() throws Throwable {
        lazadaCreditELMS.ClickLazadaDebitCard();
    }

}
