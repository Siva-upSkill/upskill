package runners;

import base.Test;
import constants.Device;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import exceptions.EnvironmentException;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"@rerun/failed_scenarios.txt"},
        glue = {"stepdefinitions"},
        plugin = { "pretty",
                "com.cucumber.listener.ExtentCucumberFormatter:",
                "json:target/json-output/Automation-Summary.json"

        }
        //dryRun = true,
        //tags={"@RegressionNew"}
        //tags={"@WU"}
)
public class RerunRunner extends Test {
    public static String currentdevicename;
    @BeforeClass
    public static void initialize() throws EnvironmentException{
        String deviceName=System.getProperty("Device");
        if(deviceName==null)
        {
             // deviceName=Device.Samsung;
             deviceName=Device.HUAWEIMATE30;
              currentdevicename=deviceName;
        }
        setup(deviceName);
    }

    @AfterClass
    public static void flush(){
        teardown();
    }
}