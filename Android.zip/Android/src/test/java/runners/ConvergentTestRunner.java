package runners;

import base.Test;
import constants.Device;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import exceptions.EnvironmentException;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"classpath:features"},
        glue = {"stepdefinitions"},
        plugin = { "pretty",
                "com.cucumber.listener.ExtentCucumberFormatter:",
                "json:target/json-output/Automation-Summary.json",
                "rerun:rerun/failed_scenarios.txt"
        },
        //dryRun = true,
//         tags={"@RegressionNew"}
           tags={"@Login"}
)
public class ConvergentTestRunner extends Test {
    public static String currentdevicename;
    @BeforeClass
    public static void initialize() throws EnvironmentException{
        String deviceName=System.getProperty("Device");
        if(deviceName==null)
        {
              deviceName=Device.Samsung;
//            deviceName=Device.HUAWEIMATE30;
              currentdevicename=deviceName;
        }
        setup(deviceName);
    }

    @AfterClass
    public static void flush(){
        teardown();
    }
}