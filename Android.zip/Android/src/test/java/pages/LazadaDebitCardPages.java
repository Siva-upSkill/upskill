package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import runners.ConvergentTestRunner;


public class LazadaDebitCardPages extends Keywords {

    private HomePage home = new HomePage();
    private UITFPage uitfPage = new UITFPage();
    private SendRequestPage sendrequest = new SendRequestPage();

    private String  DebitCard = "onlineBanking.RewardsTesting.DebitCard";
    private String TransferCredits = "onlineBanking.RewardsTesting.DebitCard.TransferCredits";

    ConvergentTestRunner Devicename=new ConvergentTestRunner();

    public void select_debitCard() throws ApplicationException {
        click.elementBy(DebitCard);
    }

    public void select_TransferCredits() throws ApplicationException{
        click.elementBy(TransferCredits);
    }

}