package pages;

import actions.Touch;
import actions.Wait;
import base.Keywords;
import helper.PropertyReader;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.interactions.Sequence;

import java.util.Collection;

import static helper.PropertyReader.testDataOf;

public class PayallPhase2Page extends Keywords {

    private String SelectAccountNumber = "onlineBanking.Payall.SelectAccountNumber";
    private String PayDirectReminders = "onlineBanking.Payall.PayDirectReminders";
    private String GotItBtn = "onlineBanking.Payall.GotITBtn";
    private String AccountNumberTxtBox = "onlineBanking.Payall.AccountNumberTxtBox";
    private String NameTxtBox = "onlineBanking.Payall.NameTxtBox";
    private String NextBtn = "onlineBanking.Payall.NextBtn";
    private String AmountTxtBox = "onlineBanking.Payall.AmountTxtBox";
    private String SelectPurposeDropDown = "onlineBanking.Payall.SelectPurposeDrpDown";
    private String SelectPurpose = "onlineBanking.Payall.SelectPurpose";
    private String ReviewAndPayHeader = "onlineBanking.Payall.ReviewAndPayHeader";
    private String PayBtn = "onlineBanking.Payall.PayButton";
    private String InvalidAmountInlineMessage = "onlineBanking.Payall.InvalidAmountInlineMessage";
    private String CancelBtn = "onlineBanking.BuyLoad.CancelButton";
    private String YesCancelPaymentBtn = "onlineBanking.Payall.YesCancelPaymentBtn";
    private String TargetAccount = "onlineBanking.Payall.TargetAccount";

    private String AccNumberTxtBoxOtherBank = "onlineBanking.Payall.AccNumberTxtBoxOtherBank";
    private String NameTxtBoxOtherBank = "onlineBanking.Payall.NameTxtBoxOtherBank";
    private String ProceedWithPayment = "onlineBanking.Payall.ProceedWithPayment";
    private String SelectPurposeDropDownOtherBank = "onlineBanking.Payall.SelectPurposeDrpDownOtherBank";

    private String AnotherUnionBankAccount = "onlineBanking.Payall.AnotherUnionBankAccount";

    private String clickBankPesonet="onlineBanking.Payall.clickBankPesonet";

    private String selectBankName="onlineBanking.Payall.selectBankName";


    public void ClickFromAccount() throws Throwable{
        Wait.waituntillElementVisibleMob(SelectAccountNumber,3);
        click.elementBy(SelectAccountNumber);
    }
    public void clickBankPesonet() throws Throwable{
        Wait.waituntillElementVisibleMob(clickBankPesonet,4);
        click.elementBy(clickBankPesonet);
    }

    public void ClickAnotherUnionBankAccount() throws Throwable{
        Wait.waituntillElementVisibleMob(AnotherUnionBankAccount,4);
        click.elementBy(AnotherUnionBankAccount);
    }
    public void selectBankName() throws Throwable{
        Wait.waituntillElementVisibleMob(selectBankName,3);
        click.elementBy(selectBankName);
    }
    public void PayDirectReminders() throws Throwable {
       Wait.waituntillElementVisibleMob(PayDirectReminders,4);
        verify.elementIsPresent(PayDirectReminders);
//        swipe.swipeVertical(2,0.8,0.2);
 //       Touch.touchLongPress(0,50,0,500);
        swipe.scrollDownToTextandClick("Got It");


    }
    public void clickGotItBtn() throws Throwable{
        Wait.waituntillElementVisibleMob(GotItBtn,3);
  //      swipe.swipeVertical(2,7.27,7.44);
        click.elementBy(GotItBtn);
    }
    public void EnterAccountNoAndName() throws Throwable{
        Wait.waituntillElementVisibleMob(AccountNumberTxtBox,2);
        type.data(AccountNumberTxtBox, PropertyReader.testDataOf("Payall_AccountNumber").trim());
        type.data(NameTxtBox, PropertyReader.testDataOf("Payall_Name").trim());
    }
    public void ClickNext() throws Throwable{
        Wait.waituntillElementVisibleMob(NextBtn,3);
        click.elementBy(NextBtn);
    }
    public void EnterLesserAmount() throws Throwable{
       Wait.waituntillElementVisibleMob(AmountTxtBox,3);
        type.data(AmountTxtBox, PropertyReader.testDataOf("Payall_LesserAmount").trim());

    }
    public void VerifyInvalidAmountMessage() throws Throwable{
        Wait.waituntillElementVisibleMob(InvalidAmountInlineMessage,3);
        verify.elementIsPresent(InvalidAmountInlineMessage);
    }
    public void EnterGreaterAmount()throws Throwable{
        Wait.waituntillElementVisibleMob(AmountTxtBox,3);
        click.elementBy(AmountTxtBox);
        type.data(AmountTxtBox, PropertyReader.testDataOf("Payall_GreaterAmount").trim());
    }
    public void EnterAmount() throws Throwable{
        Wait.waituntillElementVisibleMob(AmountTxtBox,3);
        click.elementBy(AmountTxtBox);

      driver.perform((Collection<Sequence>) new KeyEvent(AndroidKey.DIGIT_1));
        driver.perform((Collection<Sequence>) new KeyEvent(AndroidKey.DIGIT_5));
        driver.perform((Collection<Sequence>) new KeyEvent(AndroidKey.DIGIT_0));
        driver.perform((Collection<Sequence>) new KeyEvent(AndroidKey.DIGIT_0));
//        type.data(AmountTxtBox, PropertyReader.testDataOf("Payall_Amount").trim());
    }
    public void SelectPurpose() throws Throwable{
        Wait.waituntillElementVisibleMob(SelectPurposeDropDown,3);
        click.elementBy(SelectPurposeDropDown);
        click.elementBy(SelectPurpose);
//        swipe.swipeVertical(2,0.8,0.2);


    }
    public void VerifyReviewAndPayHeader() throws Throwable{
        Wait.waituntillElementVisibleMob(ReviewAndPayHeader,3);
        verify.elementIsPresent(ReviewAndPayHeader);
    }
    public void VerifyTargetAccount() throws Throwable{
        Wait.waituntillElementVisibleMob(TargetAccount,3);
        verify.elementTextMatching(TargetAccount, testDataOf("Payall_TargetAccount").trim());
        click.elementBy(PayBtn);
    }
    public void ClickCancelButton() throws Throwable{
        Wait.waituntillElementVisibleMob(CancelBtn,3);
        click.elementBy(CancelBtn);
    }
    public void ClickYesyCancelPayment() throws Throwable{
        Wait.waituntillElementVisibleMob(YesCancelPaymentBtn,3);
        click.elementBy(YesCancelPaymentBtn);
    }
    public void EnterAccNumOtherBank() throws Throwable{
        Wait.waituntillElementVisibleMob(AccountNumberTxtBox,3);
        type.data(AccountNumberTxtBox, PropertyReader.testDataOf("Payall_AccountNumber").trim());
        Wait.waituntillElementVisibleMob(NameTxtBox,4);
        type.data(NameTxtBox, PropertyReader.testDataOf("Payall_Name").trim());

    }
    public void ProceedWithPayment() throws Throwable{
        Wait.waituntillElementVisibleMob(ProceedWithPayment,4);
        click.elementBy(ProceedWithPayment);
    }
    public void SelectPurposeOtherBank() throws Throwable{
        Wait.waituntillElementVisibleMob(SelectPurposeDropDownOtherBank,4);
        click.elementBy(SelectPurposeDropDownOtherBank);
        click.elementBy(SelectPurpose);
    }



}
