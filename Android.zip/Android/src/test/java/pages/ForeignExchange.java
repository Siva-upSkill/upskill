package pages;
import actions.Swipe;
import actions.Wait;
import base.Keywords;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.By;

public class ForeignExchange extends Keywords {

    String KeyFXbuy = "convergent.FX.lblbuy";
    String KeyFXsell="convergent.FX.lblsell";
    String KeyFXtitle="convergent.FX.lbltitle";
    String KeyFXtxtUSD="convergent.FX.txtUSD";
    String KeyFXtaptoselectbuy="convergent.FX.btntaptoselectbuy";
    String KeyFXnext="convergent.FX.btnnext";
    String Keylblforeignexchange="convergent.FX.lblforeignexchange";
    String KeyFXtaptoselectsell="convergent.FX.btntaptoselectsell";
    String KeyValidationmessage="convergent.FX.lblmsg";
    String KeyValidationamountexceedmessage="convergent.FX.lblerrormsg";
    String KeyValidationenoughfundmessage="convergent.FX.lblsellerrormsg";
    String FromAccount = "convergent.BuyLoad.PurchaseFrom.Account1";
    String TaptoselectAccount="convergent.FX.TaptoSelectAccount";
    String SelectAccount="convergent.FX.SelectAccount";
    String AmountExceedErrormsg="convergent.FX.AmountExceedslimitMsg";
    String DealReceivedMsg="convergent.FX.DealReceivedMsg";
    String DealDescription="convergent.FX.DealDescription";
    String BuyUSD="convergent.FX.BuyUSD";
    String SellUSD="convergent.FX.SellUSD";

    public void clickbuyusd() throws Throwable {

        click.elementBy(KeyFXbuy);
    }
    public void verifyUsd()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(KeyFXbuy);
        verify.elementIsPresent(KeyFXsell);
    }
    public void clicksellusd() throws Throwable {
        click.elementBy(KeyFXsell);
    }
    public void clickBuyusd()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(BuyUSD);
    }
    public void clickSellUSD()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(SellUSD);
    }
    public void verifyDealReceivedmsg()throws Throwable{
        Wait.forSeconds(1);
        verify.elementIsPresent(DealReceivedMsg);
    }
    public void verifyDealDescription()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(DealDescription);
    }
    public void verifyFXtitle() throws Throwable {
        verify.elementIsPresent(KeyFXtitle);
    }
    public void clickTapToSelect()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(TaptoselectAccount);
        click.elementBy(SelectAccount);
        type.data(KeyFXtxtUSD,"1");
    }
    public void verifyLimitExceeds()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(AmountExceedErrormsg);
    }
    public void enterUSDamounttotransfer(String Amount) throws Throwable {
       // verify.elementIsPresent(Keygetcasharrow);
        Wait.waituntillElementVisibleMob(KeyFXtxtUSD,2);
        type.data(KeyFXtxtUSD,Amount);
    }

    public void selectfromaccount() throws Throwable  {

        try {
            click.elementBy(KeyFXtaptoselectbuy);
        }
        catch(Exception e){
            click.elementBy(KeyFXtaptoselectsell);

        }
        click.elementBy(FromAccount);

    }

    public void signinsignaturepad() throws Throwable {
        // verify.elementIsPresent(Keygetcasharrow);
        Wait.forSeconds(5);
        driver.findElement(By.id("com.unionbankph.online.qat:id/signature_pad")).click();
        TouchAction touchAction = new TouchAction(driver);
        touchAction.longPress(PointOption.point(310, 310)).moveTo(PointOption.point(380, 380)).release().perform();
        //touchAction.longPress(PointOption.point(291, 291)).release().perform();
        //touchAction.moveTo(PointOption.point(310, 310)).release().perform();
        Wait.forSeconds(5);
    }

    public void clicknext() throws Throwable {

        click.elementBy(KeyFXnext);

    }

    public void clickforeinexchange() throws Throwable {
        click.elementBy(Keylblforeignexchange);
    }

    public void verifyMessagecontent(String message) throws Throwable {
        verify.elementTextMatching(KeyValidationmessage,message);
    }

    public void verifyMessageamountexceed(String message) throws Throwable {
        verify.elementTextMatching(KeyValidationamountexceedmessage,message);
    }

    public void verifyMessageenoughamount(String message) throws Throwable {
        verify.elementTextMatching(KeyValidationenoughfundmessage,message);
    }

}
