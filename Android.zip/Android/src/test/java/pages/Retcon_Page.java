package pages;

import actions.Swipe;
import actions.Wait;
import base.Keywords;
//import com.sun.org.apache.bcel.internal.generic.SWAP;
import exceptions.ApplicationException;
import gherkin.lexer.Th;
import helper.PropertyReader;

import static helper.PropertyReader.testDataOf;

public class Retcon_Page extends Keywords {

    private String SelectCreditcard = "onlineBanking.Retcon.Selectcard";
    private String SelectCardData = testDataOf("Retcon_Card");
    private String Installments="onlineBanking.Retcon.Installments";

    private String TurnToInstallments = "onlineBanking.Retcon.TurnToInstallments";

    private String EasyConvert = "onlineBanking.Retcon.EasyConvert";
    private String ViewAll = "onlineBanking.Retcon.Viewall";

    private String SelectAPurchaseSearchBox = "onlineBanking.Retcon.SelectAPurchaseSearchBox";
    private String SelectAPurchase = "onlineBanking.Retcon.SelectAPurchase";
    private String SelectAPurchaseScreen = "onlineBanking.Retcon.SelectAPurchaseScreen";
    private String SelectAPaymentPlan = "onlineBanking.Retcon.SelectPaymentPlan";
    private String NextBtn = "onlineBanking.Retcon.NextBtn";
    private String ViewPaymentPlan = "onlineBanking.Retcon.ViewPaymentPlan";
    private String CloseOption = "onlineBanking.Retcon.CloseOption";
    private String TermsAndConditions = "onlineBanking.Retcon.TermsAndConditions";
    private String AgreeAndContinueBtn = "onlineBanking.Retcon.AgreeAndContinueBtn";
    private String RequestForEasyConvert = "onlineBanking.Retcon.RequestForEasyConvert";
    private String EasyConvertRequestedMessage = "onlineBanking.Retcon.EasyConvertRequestedMessage";
    private String GotitBtn = "onlineBanking.Retcon.GotItBtn";

    private String EasyConvertInlineMessage = "onlineBanking.Retcon.EasyConvertInlineMessage";
    private String EasyConvertScreen = "onlineBanking.Retcon.EasyConvertScreen";

    private String EasyConvertSummaryScreen = "onlineBanking.Retcon.EasyConvertSummaryScreen";
    private String Skip = "onlineBanking.Retcon.SkipBtn";
    private String NoSearchResultFound = "onlineBanking.Retcon.NoSearchResultFoundError";
    private String InstallmentHistoryScreen = "onlineBanking.Retcon.InstallmentHistoryScreen";

    private String btnGetStarted="onlineBanking.Retcon.btnGetStarted";

    private String btnNext="onlineBanking.Retcon.btnNext";

    private String ProcessingErrorMessage1 = "onlineBanking.Retcon.ProcessingErrorMessage1";
    private String ProcessingErrorMessage2 = "onlineBanking.Retcon.ProcessingErrorMessage2";
    private String PurchaseDetailsEditIcon = "onlineBanking.Retcon.PurchaseDetailsEditBtn";
    private String EasyConvertEditIcon = "onlineBanking.Retcon.EasyConvertDetailsEditBtn";



    //private GreenPinPage greenPinPage = new GreenPinPage();
    //private Dashboard_Home_Page dashboard = new Dashboard_Home_Page();

    public void clickcard()throws Throwable{
        Wait.waituntillElementVisibleMob(SelectCreditcard,4);
        click.elementBy(SelectCreditcard);
    }


 //   public void SelectCreditCard() throws Throwable{
//        Wait.forSeconds(9);
//        click.elementBy(SelectCard);
//    }
 public void clickInstallments()throws Throwable{
     Wait.waituntillElementVisibleMob(Installments,10);
     click.elementBy(Installments);
 }

  //  public void VerifyTurnToInstallmentsScreen() throws Throwable{
  //      Wait.forSeconds(7);
  //      verify.elementIsPresent(TurnToInstallments);
  //  }
    public void verify_TurntoInstallments()throws Throwable{
        Wait.waituntillElementVisibleMob(TurnToInstallments,18);
        verify.elementIsPresent(TurnToInstallments);
    }
    public void ClickEasyConvert() throws Throwable{
        Wait.waituntillElementVisibleMob(EasyConvert,3);
       // click.elementBy(Skip);
        click.elementBy(EasyConvert);
    }
    public void VerifySelectPurchaseScreen() throws Throwable{
        Wait.waituntillElementVisibleMob(SelectAPurchaseScreen,4);
        verify.elementIsPresent(SelectAPurchaseScreen);
    }
    public void VerifyEasyConvertInlineMessage() throws Throwable{
        Wait.waituntillElementVisibleMob(EasyConvertInlineMessage,3);
        verify.elementIsPresent(EasyConvertInlineMessage);
    }
    public void ClickViewAll() throws Throwable{
        Wait.waituntillElementVisibleMob(ViewAll,3);
        click.elementBy(ViewAll);
    }
    public void EnterTextInSearchBox() throws Throwable{
        Wait.waituntillElementVisibleMob(SelectAPurchaseSearchBox,3);
        type.data(SelectAPurchaseSearchBox, PropertyReader.testDataOf("Retcon_SelectPurchase").trim());
        Wait.waituntillElementVisibleMob(SelectAPurchase,3);
        click.elementBy(SelectAPurchase);

    }
    public void SelectPaymentPlan() throws Throwable{
        Wait.waituntillElementVisibleMob(SelectAPaymentPlan,5);
        click.elementBy(SelectAPaymentPlan);
    }
    public void ClickNext() throws Throwable{
        Wait.waituntillElementVisibleMob(NextBtn,5);
        click.elementBy(NextBtn);
    }
    public void VerifyEasyConvertScreen() throws Throwable{
        Wait.waituntillElementVisibleMob(EasyConvertScreen,4);
        verify.elementIsPresent(EasyConvertScreen);
    }
    public void ClickViewPaymentPlan() throws Throwable {
        Wait.waituntillElementVisibleMob(ViewPaymentPlan,4);
        swipe.swipeVertical(2,0.6,0.2);
        click.elementBy(ViewPaymentPlan);
    }
    public void verifyThePaymentPlanDetailsAndClose() throws Throwable{

        Wait.waituntillElementVisibleMob(CloseOption,3);
        click.elementBy(CloseOption);
    }

    public void VerifyEasyConvertSummaryScreen() throws Throwable{
        Wait.waituntillElementVisibleMob(EasyConvertSummaryScreen,4);
        verify.elementIsPresent(EasyConvertSummaryScreen);
    }
    public void ClickTermsAndConditions() throws Throwable{
        Wait.waituntillElementVisibleMob(TermsAndConditions,5);
        swipe.swipeVertical(2,0.8,0.1);
        click.elementBy(TermsAndConditions);
       // click.elementBy(AgreeAndContinueBtn);
    }
    public void ClickRequestForEasyConvert() throws Throwable{
        Wait.waituntillElementVisibleMob(RequestForEasyConvert,4);
        click.elementBy(RequestForEasyConvert);
    }
    public void VerifyEasyConvertMessage() throws Throwable{
        Wait.waituntillElementVisibleMob(EasyConvertRequestedMessage,3);
        verify.elementIsPresent(EasyConvertRequestedMessage);
    }
    public void ClickGotItBtn() throws Throwable{
        Wait.waituntillElementVisibleMob(GotitBtn,4);
        click.elementBy(GotitBtn);
    }
    public void EnterInvalidPurchaseNumber() throws Throwable{
        Wait.waituntillElementVisibleMob(SelectAPurchaseSearchBox,4);
        type.data(SelectAPurchaseSearchBox, PropertyReader.testDataOf("Retcon_InvalidPurchaseNumber").trim());
    }
    public void NoSearchResultFoundError() throws Throwable{
        Wait.waituntillElementVisibleMob(NoSearchResultFound,4);
        verify.elementIsPresent(NoSearchResultFound);
    }
    public void VerifyInstallmentHistoryScreen() throws Throwable{
        Wait.waituntillElementVisibleMob(InstallmentHistoryScreen,4);
        verify.elementIsPresent(InstallmentHistoryScreen);
    }
    public void ClickSkipBtn() throws Throwable{
        Wait.waituntillElementVisibleMob(Skip,3);
        click.elementBy(Skip);
    }

    public void ClickGetStarted() throws Throwable {
        click.elementBy(btnGetStarted);
    }
    public void ClickbtnNext() throws Throwable {
        click.elementBy(btnNext);
        click.elementBy(btnNext);
        click.elementBy(btnNext);
        click.elementBy(btnNext);
    }
    public void VerifyProcessingMessage() throws Throwable {
        Wait.waituntillElementVisibleMob(ProcessingErrorMessage1,4);
        verify.elementIsPresent(ProcessingErrorMessage1);
        verify.elementIsPresent(ProcessingErrorMessage2);
    }

    public void EnterNewPurchaseNumber() throws Throwable {
        Wait.waituntillElementVisibleMob(SelectAPurchaseSearchBox,4);
        type.data(SelectAPurchaseSearchBox, PropertyReader.testDataOf("Retcon_NewPurchase").trim());
        Wait.waituntillElementVisibleMob(SelectAPurchase,4);
        click.elementBy(SelectAPurchase);

    }

    public void EnterAnotherPurchaseNumber() throws Throwable {
        Wait.waituntillElementVisibleMob(SelectAPurchaseSearchBox,3);
        type.data(SelectAPurchaseSearchBox, PropertyReader.testDataOf("Retcon_AnotherPurchase").trim());
        Wait.waituntillElementVisibleMob(SelectAPurchase,3);
        click.elementBy(SelectAPurchase);
    }
    public void ClickEditIconInPurchaseDetails() throws Throwable{
        Wait.waituntillElementVisibleMob(PurchaseDetailsEditIcon,4);
        click.elementBy(PurchaseDetailsEditIcon);
    }
    public void ClickEditIconInEasyConvert() throws Throwable{
        Wait.waituntillElementVisibleMob(EasyConvertEditIcon,3);
        click.elementBy(EasyConvertEditIcon);
    }
   }
