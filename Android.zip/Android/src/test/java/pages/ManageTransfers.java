package pages;

import actions.Wait;
import base.Keywords;
import driver.DriverManager;
import exceptions.ApplicationException;
import org.openqa.selenium.By;
import org.springframework.context.ApplicationContextException;
import pages.*;
import stepdefinitions.C013_ManageTransfers;


public class ManageTransfers extends Keywords {

    private String KeyManageransfertype = "convergent.Manage_Transfers.labeltransfertype";
    private String KeyManagetransferamount = "convergent.Manage_Transfers.labeltransferamount";
    private String KeyManagetransferrefno = "convergent.Manage_Transfers.labeltransferrefno";
    private String KeyManagetransferdate="convergent.Manage_Transfers.labeltransferdate";
    private String KeyManagetransferrequests="convergent.Manage_Transfers.linkrequests";
    private String KeyManagetransferbuyload="convergent.Manage_transfers.Buyload";
    private String KeyManagetransferbuyloadmanagecontact="convergent.Manage_transfers.Buyload_managecontact";
    private String KeyManagetransferbuyloadmanagecontactname="convergent.Manage_transfers.Buyload_managecontactname";
    private String KeyManagetransferbuyloadmanagecontactnumber="convergent.Manage_transfers.Buyload_managecontactnumber";
    private String KeyManagetransferrequestpaymenttotalamount="convergent.Manage_transfers.requestsamt";
    private String KeyManagetransferrequestpaymentmessage="convergent.Manage_transfers.requestsremarkmsg";
    private String KeyManagetransferrequestpaymentresult="convergent.Manage-transfers.requestresult";
    private String KeyManagetransferrequestpaymentresendall="convergent.request_payment.managerequestresend";
    private String KeyManagetransferrequestpaymentcancellall="convergent.request_payment.managerequestcancel";
    private String KeyManagetransferrequestpaymentyes="convergent.request_payment.deleteYes";




            public void verifyManagetransfer(String transfertype,String transferamt) throws ApplicationException
            {

                if(DriverManager.OS.equalsIgnoreCase("ANDROID"))
                {
                    String ReferenceNo = "REF: " + TransferDetailsPage.ReferenceNo;
                    //verify.elementTextMatching(KeyManagetransferrefno,ReferenceNo);
                    swipe.scrollDownToTextandClick(ReferenceNo);

                }

                if(DriverManager.OS.equalsIgnoreCase("IOS"))
                {
                    String ReferenceNo = "REF: " + TransferDetailsPage.ReferenceNo;
                    //verify.elementTextMatching(KeyManageransfertype,transfertype);
                    Wait.forSeconds(8);
                    verify.elementTextMatching(KeyManagetransferamount, transferamt);
                    Wait.forSeconds(8);
                    //verify.elementTextMatching(KeyManagetransferrefno,ReferenceNo);

                }
            }

    public void clickmanagetransferrequests() throws ApplicationException {


        Wait.forSeconds(8);
        click.elementBy(KeyManagetransferrequests);

    }

    public void clickenterbutton() throws ApplicationException {

            Wait.forSeconds(8);
            //click.elementBy(KeyManagetransferrequests);
            actions.Touch.pressByCoordinates(710, 859, 5);

    }
    public void clickbuyloadlink() throws ApplicationException {


        click.elementBy(KeyManagetransferbuyload);

    }
    public void clickbuyloadmanagecontact() throws ApplicationException {


        click.elementBy(KeyManagetransferbuyloadmanagecontact);

    }


    public void verifypaticipantdetails(String arg1,String arg2) throws ApplicationException{

     verify.elementTextMatching(KeyManagetransferbuyloadmanagecontactname,arg1);
        verify.elementTextMatching(KeyManagetransferbuyloadmanagecontactnumber,arg2);


    }
    public String getRequestpaymanetamount() throws ApplicationException{

        String requestamount=null ;

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            requestamount = driver.findElement(By.id("com.unionbankph.online.qat:id/text_value")).getText();

        }
        if(DriverManager.OS.equalsIgnoreCase("IOS")) {
             requestamount = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name='Total Amount Requested']/parent::*/following-sibling::*//XCUIElementTypeStaticText")).getText();

        }
        return requestamount;
    }

    public void verifyrequestpaymentdetails(String arg1,String arg2) throws ApplicationException{

        //String message = Requestpaymentamount;
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //message = driver.findElement(By.xpath("//android.widget.ScrollView/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.support.v7.widget.RecyclerView/android.view.ViewGroup[3]/android.widget.TextView[3]")).getText();
            swipe.scrollDownToTextandClick(C013_ManageTransfers.Requestpaymentamount);

        }


        if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            Wait.forSeconds(10);
            verify.elementTextMatching(KeyManagetransferrequestpaymentmessage, arg1);
            verify.elementTextMatching(KeyManagetransferrequestpaymenttotalamount, arg2);
        }

    }

    public void clicktherequestpaymentsearchfiled() throws ApplicationException
    {
        click.elementBy(KeyManagetransferrequestpaymentresult);

    }

    public void clickresendallrequest() throws ApplicationException
    {
        click.elementBy(KeyManagetransferrequestpaymentresendall);

    }
    public void clickcancelallrequest() throws ApplicationException
    {
        click.elementBy(KeyManagetransferrequestpaymentcancellall);

    }
    public void clickyes() throws ApplicationException
    {
        Wait.forSeconds(10);
        click.elementBy(KeyManagetransferrequestpaymentyes);

    }
}
