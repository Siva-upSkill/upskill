package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;

public class TransferToPage extends Keywords {

    private String Keytopagetitle = "convergent.TransferTopage.verifytitle";
    private String KeyTransferToPageTitle = "convergent.TransferTo.TransferToPageTitle";
    private String Keytopagerecipientxtbox = "convergent.TransferTopage.enteracctno";
    private String Keytopagerecipientxtboxubp = "convergent.TransferTopageubp.enteracctno";
    private String KeyBtnNext = "convergent.TransferTopage.BtnNext";
    private String KeyBtnNext2 ="convergent.TransferTopageinstapay.BtnNext";
    private String KeyBtnNext3 ="convergent.TransferTopageinstapay2.BtnNext";
    private String Keytopagenextbtn2 = "convergent.TransferTopage.clicknextbtn";
    private String Keytopageselectfromlist = "convergent.TransferTopage.clickselectfromlistbtn";
    private String Keytopagemyrecipients = "convergent.TransferTopage.selectrecipient";
    private String Keytopagefavouriterecipients = "convergent.TransferTopage.selectfavouriteacc";
    private String Keytopagefavouritetab = "convergent.TransferTopage.selectfavoritestab";
    private String Keytopagedonebtn = "convergent.TransferTopage.clickdonebtn";
    private String Keytopagebackbtn = "convergent.TransferTopage.backbtn";
    private String Keytopagechooseaccount = "convergent.TransferTopage.selectaccount";
    private String Keytopageenteraccount = "convergent.Pesonet.enteraccountnumber";
    private String Keytoclickokbtn = "convergent.TransferTopage.okbtn";
    private String Keyaccnumerrormsg = "convergent.TransferTopage.accnumerrormsg";
    private String Keyaccnameerrormsg = "convergent.TransferTopage.accnameerrormsg";
    private String Keybankrequiredmsg = "convergent.TransferToPage.bankrequiredmsg";
    private String Keyaccnumrequiredmsg = "convergent.TransferToPage.accnumrequiredmsg";
    private String Keyaccnamerequiredmsg = "convergent.TransferToPage.accnamerequiredmsg";
    private String Keyclickbank = "convergent.TransferToPage.clickbanktab";
    private String Keyclickaccnum = "convergent.TransferToPage.clickaccountnumber";
    private String Keyclickaccname = "convergent.TransferToPage.clickaccountname";
    private String Keytransfertomessagetxtbox = "convergent.TransferToPage.entermessage";
    private String KeytransfertomessagetxtboxIOS ="convergent.TransferToPage.entermessage256";
    private String Keytransfertoemailtxtbox = "convergent.TransferToPage.enterrecipientemail";
    private String Keytransfertounitnotxt="convergent.pddts.pddtspage.txtunithouseno";
    private String Keytransfertobuildingtxt="convergent.pddts.pddtspage.txtbuilding";
    private String Keytransfertovillagetxt="convergent.pddts.pddtspage.txtvillage";
    private String Keytransfertoprovincelst="convergent.pddts.pddtspage.lstprovince";
    private String Keytransfertocitylst="convergent.pddts.pddtspage.lstcity";
    private String  Keyremittancetxtamount="convergent.Remittanccentertransfersendnoneypage.txtamount";
    private String  Keyremittancetxtpurpose="convergent.Remittanccentertransfersendnoneypage.txtpurpose";
    private String  Keyremittancebtntaptoselect = "convergent.Remittanccentertransfersendnoneypage.btntabtoselectaccount";

    private String  Keyremittancelblservivefeetiltle="convergent.Remittanccentertransfersendnoneypage.lblServivefeetitle";
    private String  Keyremittancebtnproceedwithtransfer ="convergent.Remittanccentertransfersendnoneypage.btnproceedwithtransfer";
    private String  Keyremittancebtnselectaccount ="convergent.Remittanccentertransfersendnoneypage.SelectAccount";
    private String  Keyremittancebtnfromaccount="convergent.Remittanccentertransfersendnoneypage.FromAccount";
    private String  Keyremittancebtnfromaccount1 = "convergent.Remittancecenter.SelectAccount";

    private String Keyfrompagetranferaccount = "convergent.TransferFrompage.selectaccount";
    private String Keyremittancenext="convergent.Remittanccentertransfersendnoneypage.btnnext";
    private String Keyremittancebtnproceed="convergent.Remittanccentertransfersendnoneypage.btnproceed";
    private String KeyEnterAccountName = "convergent.Pesonet.enteraccountname";
    private String MetroManila = "convergent.pddts.MetroManila";
    private String Manila = "convergent.pddts.Manila";



    private String itext;

    public void verifyTransferToPageTitle(String ititle) throws ApplicationException {
        Wait.forSeconds(7);
        verify.elementIsPresent(Keytopagetitle);
    }

    public void verifyTransferToPageTitleIOS(String ititle) throws ApplicationException {
        verify.elementTextMatching(KeyTransferToPageTitle, ititle);
    }

    public void verifyTransferToRecepientTxtBox() throws ApplicationException {
        verify.elementIsPresent(Keytopagerecipientxtbox);
    }

    public void enterRecipientAccount(String iaccount) throws ApplicationException {
        //type.sensitiveData(Keytopagerecipientxtbox, iaccount);
        type.data(Keytopagerecipientxtbox,iaccount);
    }
    public void enterRecipientAccountubp(String iaccount) throws ApplicationException {
        //type.sensitiveData(Keytopagerecipientxtbox, iaccount);
        type.data(Keytopagerecipientxtboxubp,iaccount);
    }
    public void checkNextBtnEnabled() throws ApplicationException {
        verify.elementIsEnabled(KeyBtnNext);
    }

    public void checkNextBtnDisabled() throws ApplicationException {
        verify.elementIsDisabled(KeyBtnNext);
    }

    public void clickNextBtn() throws ApplicationException, InterruptedException {
        click.elementBy(KeyBtnNext);
    }
    public void clickNextBtninstapay() throws ApplicationException, InterruptedException {
        click.elementBy(KeyBtnNext2);
    }
    public void clickNextBtninstapay2() throws ApplicationException, InterruptedException {
        WAIT.forSecondsUsingFluentWAIT(2,KeyBtnNext3);
        click.elementBy(KeyBtnNext3);
    }

    /*public void clickOKBtn() throws ApplicationException, InterruptedException
	{
		Thread.sleep(200);
		click.elementBy(Keytoclickokbtn);
	}*/

    public void clickOKBtn() throws ApplicationException {

        if (verify.IfElementExistsboolean(Keytoclickokbtn)) {
            click.elementBy(Keytoclickokbtn);
        }

    }
    public void clickNextBtn2() throws ApplicationException, InterruptedException {
        Thread.sleep(200);
        click.elementBy(KeyBtnNext);

        //click.elementBy(By("com.unionbankph.online.qat:id/button_bottom"));
    }

    public void clickDoneBtn() throws ApplicationException, InterruptedException {
        //Thread.sleep(200);
        click.elementBy(Keytopagedonebtn);
    }

    public void verifyDoneBtn(String expectedval) throws ApplicationException, InterruptedException {
        //verify.elementTextMatching(Keytopagedonebtn, expectedval);
        verify.elementIsPresent(Keytopagedonebtn);
    }


    public void clickSelectFromList() throws ApplicationException {
        click.elementBy(Keytopageselectfromlist);
//        WAIT.forSeconds(5);
    }

    /*
    public void clickMyRecipient() throws ApplicationException
    {
        //ResourceBase.PERFORM.click(Keymyrecipients,"0600 0069 9979");
        ResourceBase.PERFORM.click(Keymyrecipients,"0600 0069 9979");
    }

    public void clickFavouriteRecipient() throws ApplicationException
    {
        ResourceBase.PERFORM.click(Keyfavouritetab);
        //ResourceBase.PERFORM.click(Keyfavouriterecipients,"0600 0069 9979");
        ResourceBase.PERFORM.click(Keyfavouriterecipients,"0600 0069 9979");
    }
    */
    public void clickMyRecipient(String toacc) throws ApplicationException, InterruptedException {
//        WAIT.forSeconds(2);
        //ResourceBase.PERFORM.swipeVertical(2,0.4,0.9);
        WAIT.waituntillElementVisibleMob(Keytopagemyrecipients,4);
        click.elementBy(Keytopagemyrecipients, toacc);
//        WAIT.forSeconds(5);
    }

    public void clickMyRecipientios(String toacc) throws ApplicationException, InterruptedException {
        WAIT.forSeconds(3);
        //ResourceBase.PERFORM.swipeVertical(2,0.4,0.9);
        //click.elementBy(Keytopagemyrecipients,toacc);
        click.elementBy(By.xpath("//XCUIElementTypeStaticText[@name='1094 5325 7914']"));
        WAIT.forSeconds(3);
    }

    public void clickFavouriteRecipient(String tofavouriteacc) throws ApplicationException {
        click.elementBy(Keytopagefavouritetab);
        Wait.waituntillElementVisibleMob(Keytopagefavouriterecipients,2);
        click.elementBy(Keytopagefavouriterecipients);
    }
    public void clickFavouriteRecipientios() throws ApplicationException {
        Wait.waituntillElementVisibleMob(Keytopagefavouritetab,3);
        click.elementBy(Keytopagefavouritetab);
        click.elementBy(By.xpath("//XCUIElementTypeStaticText[@name='1005 7003 7881']"));
    }

    public void clickFavouriteRecipientTabios_EON() throws ApplicationException {
        Wait.waituntillElementVisibleMob(Keytopagefavouritetab,4);
        click.elementBy(Keytopagefavouritetab);
//        Wait.forSeconds(5);
    }

    public void clickBackBtn() throws ApplicationException {

        click.elementBy(Keytopagebackbtn);
    }

    public void chooseTranferToAccount(String toacc) throws ApplicationException {

        //ResourceBase.PERFORM.click(Keychoosetranferfromaccount);
        click.elementBy(Keytopagechooseaccount, toacc);

    }

    public void enterTranferToAccount(String toacc) throws ApplicationException {

        //ResourceBase.PERFORM.click(Keychoosetranferfromaccount);
        type.data(Keytopagechooseaccount, toacc);

    }
    public void enterToAccount(String toacc) throws ApplicationException {

        //ResourceBase.PERFORM.click(Keychoosetranferfromaccount);
        type.data(Keytopageenteraccount, toacc);

    }
    public void verifyAccNumErrorMessage(String expectedDescription) throws ApplicationException {
        verify.elementTextMatching(Keyaccnumerrormsg, expectedDescription);
    }

    public void verifyAccNameErrorMessage(String expectedDescription) throws ApplicationException {
        verify.elementTextMatching(Keyaccnameerrormsg, expectedDescription);

    }

    public void verifyBankIsEmpty() throws ApplicationException {
        click.elementBy(Keyclickbank);
        Wait.forSeconds(2);
        click.elementBy(Keyclickaccnum);
        verify.elementIsPresent(Keybankrequiredmsg);
    }

    public void verifyAccNumberIsEmpty() throws ApplicationException {
        WAIT.forSecondsUsingFluentWAIT(3,Keyclickaccname);
        click.elementBy(Keyclickaccname);
        verify.elementIsPresent(Keyaccnumrequiredmsg);

    }

    public void verifyAccnameIsEmpty() throws ApplicationException {
        click.elementBy(Keyclickaccname);
        click.elementBy(Keyclickaccnum);
        verify.elementIsPresent(Keyaccnamerequiredmsg);

    }

    public void enterMessageText(String itext) throws ApplicationException {
        swipe.swipeVertical(2, 0.8, 0.4, 5);
        swipe.swipeVertical(2, 0.8, 0.4, 5);

        if (itext.length() <= 256) {
            type.data(Keytransfertomessagetxtbox, itext);
        } else if (itext.length() == 256) {
            type.data(Keytransfertomessagetxtbox, itext);
        } else if (itext.length() >= 256) {
            type.data(Keytransfertomessagetxtbox, itext);
        } else {
            new ApplicationException("input remark message is not less than 256 characters");
        }
    }

    public void enterMessageTextIOS(String itext) throws ApplicationException {
        Wait.forSeconds(3);
        driver.findElementByXPath("//XCUIElementTypeButton[@name='Done']").click();
        Wait.forSeconds(3);
        if (itext.length() <= 256) {
            type.data(Keytransfertomessagetxtbox, itext);
        } else if (itext.length() == 256) {
            type.data(Keytransfertomessagetxtbox, itext);
        } else if (itext.length() >= 256) {
            type.data(Keytransfertomessagetxtbox, itext);
        } else {
            new ApplicationException("input remark message is not less than 256 characters");
        }
    }

    public void enterRecipientEmail(String email) throws ApplicationException {
        type.sensitiveData(Keytransfertoemailtxtbox, email);

    }

    public void enterRecipientEmailIOS(String email) throws ApplicationException {

        driver.findElementByXPath("//XCUIElementTypeButton[@name='Done']").click();
        Wait.waituntillElementVisibleMob(Keytransfertoemailtxtbox,2);
        type.sensitiveData(Keytransfertoemailtxtbox, email);
    }

    public void verifyMessageText(int msglength) throws Throwable {

        itext = get.elementBy(Keytransfertomessagetxtbox).getText();
        if (itext.length() == msglength) {
            verify.elementIsPresent(Keytransfertomessagetxtbox);
        } else {
            new ApplicationException("input message is not more than 256 characters");
        }
    }

    public void verifyMessageTextIOS(int msglength) throws Throwable {

        itext = get.elementBy(KeytransfertomessagetxtboxIOS).getText();
        if (itext.length() == msglength) {
            verify.elementIsPresent(KeytransfertomessagetxtboxIOS);
        } else {
            new ApplicationException("input message is not more than 256 characters");
        }
    }

    public void verifyAccountNameIsBlank(String expectedval) throws ApplicationException, InterruptedException {

        verify.elementTextMatching(Keyaccnamerequiredmsg, expectedval);
    }

    public void enterEmailid(String valuetoenter) throws ApplicationException, InterruptedException {

        type.data(Keytransfertoemailtxtbox,valuetoenter);
    }

    public void clickFavouritelinkreceipientsearch() throws ApplicationException {
        click.elementBy(Keytopagefavouritetab);

    }

    public void entertheRecipientdetails(String keyunitno,String keybuilding,String Keyvillage,String Keyprovince,String Keycity)throws ApplicationException {

        type.data(Keytransfertounitnotxt,keyunitno);
        type.data(Keytransfertobuildingtxt,keybuilding);
        type.data(Keytransfertovillagetxt,Keyvillage);
        click.elementBy(Keytransfertoprovincelst);
        //swipe.scrollDownToTextandClick(Keyprovince);
        click.elementBy(MetroManila);
        Wait.waituntillElementVisibleMob(Keytransfertocitylst,3);
        swipe.swipeVertical(2, 0.8, 0.4, 5);
        click.elementBy(Keytransfertocitylst);
        click.elementBy(Manila);
        Wait.forSeconds(5);
        //swipe.scrollDownToTextandClick(Keycity);
    }


    public void enterremmitancetransferamountandacccountdetails(String Amount,String purpose,String Accountnumber) throws ApplicationException{

        type.data(Keyremittancetxtamount,Amount);
        type.data(Keyremittancetxtpurpose,purpose);
        click.elementBy(Keyremittancebtntaptoselect);
        Wait.waituntillElementVisibleMob(Keyremittancebtnfromaccount1,3);
        //click.elementBy(Keyfrompagetranferaccount,Accountnumber);
       click.elementBy(Keyremittancebtnfromaccount1);
    }

    public void clicnexttnremittancecenter() throws ApplicationException{
        Wait.waituntillElementVisibleMob(Keyremittancenext,4);
        click.elementBy(Keyremittancenext);
    }
    public void verifyServiceTitle(String ititle) throws ApplicationException {
        //verify.elementTextMatching(Keyremittancelblservivefeetiltle, ititle);
        verify.elementIsPresent(Keyremittancelblservivefeetiltle);
    }
    public void clickproccedwithtransferremittance() throws ApplicationException {
        WAIT.forSecondsUsingFluentWAIT(2,Keyremittancebtnproceedwithtransfer);
        click.elementBy(Keyremittancebtnproceedwithtransfer);
    }

    public void clickproccedremittance() throws ApplicationException {
        click.elementBy(Keyremittancebtnproceed);
    }
    public void enterAccountName(String accountname) throws Throwable {
        type.data(KeyEnterAccountName, accountname);
    }
}