package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import gherkin.lexer.Th;
import helper.PropertyReader;


public class TransactionControlsPage extends OnlinePage {
    String SelectCard= "onlineBanking.CardControl.selectCard";
    String LockUnlockoption= "onlineBanking.CardControl.Lock/unlockOption";
    String UnlockMyCard= "onlineBanking.CardControl.UnlockMyCard";
    String Maybelater= "onlineBanking.CardControl.MayBeLater";
    String PopUpMsg= "onlineBanking.CardControl.PopUpMsg";
    String LabelMsg= "onlineBanking.CardControl.LabelMsg";
    String ToggleBtn= "onlineBanking.CardControl.LockToggleBtn";
    String LockMyCard= "onlineBanking.CardControl.lockMyCard";

    public void clickCreditCard()throws Throwable{
        WAIT.forSecondsUsingFluentWAIT(4,SelectCard);
        click.elementBy(SelectCard);
    }
    public void verifyLockUnlockOption()throws Throwable{
        Wait.forSeconds(2);
        verify.IfElementExists(LockUnlockoption);

    }
    public void clickToggleOnBtn()throws Throwable{
        WAIT.forSecondsUsingFluentWAIT(2,ToggleBtn);
        click.elementBy(ToggleBtn);
    }
    public void verifyLockcardHeader()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(PopUpMsg);
    }
    public void verifyProhibitionMsg()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(LabelMsg);
    }
    public void clickLockCard()throws Throwable{
        WAIT.forSecondsUsingFluentWAIT(2,LockMyCard);
        click.elementBy(LockMyCard);
    }
    public void clickUnlockCard()throws Throwable{
        WAIT.forSecondsUsingFluentWAIT(3,UnlockMyCard);
        click.elementBy(UnlockMyCard);
    }
    public void clickMayBelater()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(Maybelater);
    }
}


//    String KeyToggleBtn = "convergent.TransactionControls.Togglebtn";
//    String KeySpendLimitToggleBtn = "convergent.Online.ToggleSwitchTransaction";
//    String KeylockBtn = "convergent.TransactionControls.lockbtn";
//    String KeyunlockBtn = "convergent.TransactionControls.unlockbtn";
//    String KeyTransactionControlcardstatus = "convergent.TransactionControls.cardstatus";
//    String KeyTransactionControlLockedcardstatus = "convergent.accountdetails.lableCardStatusLocked";
//    String KeyTransactionControlPageTitle = "convergent.TransactionControls.TransactionCrtlPagetitle";
//    String KeyClickOnlineTransaction = "convergent.TransactionControls.ClickOnlineTransactions";
//    String KeyClickInternationalTransaction = "convergent.TransactionControls.ClickInternationalTransactions";
//    String KeyClickLocalTransaction = "convergent.TransactionControls.ClickLocalTransactions";
//    String KeyTransactionStatus = "convergent.TransactionControls.TransactionStatus";
//    String KeyOnTransactionStatus = "convergent.TransactionControls.OnlineTransactionStatus";
//    String KeySpendLimitStatus = "convergent.Online.SpendLimit";
//    String KeyEnterSpendlimit = "convergent.Online.EnterSpendLimit";
//    String KeySpendlimitErrorMsg = "convergent.TransactionControls.SpendLimitErrorMsg";
//    String KeySetTimeToggleBtn = "convergent.Online.ToggleSwitchDuration";
//    String KeyLockCardbtnLock = "convergent.LockCard.btnLock";
//    String KeyTransactionControlPageTitleIOS = "convergent.TransactionControls.TransactionCrtlPagetitleIOS";
//    String KeyTransactionControlcardLockstatus = "convergent.accountdetails.lableCardStatusLocked";
//    String KeyEnbaledTransactionStatus = "convergent.TransactionControls.EnabledTransactionStatus";
//    String KeyOnlineDeclinedTransactionstatus = "convergent.TransactionControls.OnlineDeclinedstatus";
//    String KeyInternationalDeclinedTransactionstatus = "convergent.TransactionControls.InternationslDeclinedstatus";
//    String KeyLocalDeclinedTransactionstatus = "convergent.TransactionControls.LocalDeclinedstatus";
//    String KeyDeclinedToggleBtn = "convergent.TransactionControls.btnDeclinedToggled";
//    String KeyclearSpendlimit = "convergent.TransactionControls.clearSpentlimit";
//
//
//    private String cardstatus;
//    private String spendlimit;
//    private String transactionstatus1 = "Control is Disabled";
//    private String transactionstatus2 = "Control is Enabled";
//    private String transactionstatus3 = "Card is Unlocked";
//    private String transactionstatus4 = "Card is Locked";
//
//    private String currenttransactionstatus;

//    public void verifyTransactionControlsPageTitle(String ititle) throws Throwable {
//        verify.elementTextMatching(KeyTransactionControlPageTitle, ititle);
//    }
//
//    public void verifyTransactionControlsPageTitleIOS(String ititle) throws Throwable {
//        verify.elementTextMatching(KeyTransactionControlPageTitleIOS, ititle);
//    }
//
//    public void verifyToggleBtnStatus() throws Throwable {
//        Wait.forSeconds(3);
//        click.elementBy(KeyToggleBtn);
//    }
//
//    public void selectCardSwitchBtn() throws Throwable {
//        click.elementBy(KeyunlockBtn);
//    }
//
//    public void selectCardSwitchBtnIOS() throws Throwable {
//        click.elementBy(KeyunlockBtn);
//        Wait.forSeconds(3);
//        click.elementBy(KeyLockCardbtnLock);
//    }
//
//    public void selectCardlockBtn() throws Throwable {
//        click.elementBy(KeylockBtn);
//    }
//
//    public void verfiyCardStatus(String cardstatus) throws Throwable {
//        verify.elementTextMatching(KeyTransactionControlcardstatus, cardstatus);
//    }
//
//    public void selectDeclineOnlinePurchaseToggleBtn() throws Throwable {
//        Wait.forSeconds(3);
//        click.elementBy(KeyToggleBtn);
//    }
//
//    public void selectDeclineOnlinePurchaseToggleBtnIOS() throws Throwable {
//        Wait.forSeconds(3);
//        click.elementBy(KeyDeclinedToggleBtn);
//    }
//
//    public void selectDeclineInternationalPurchaseToggleBtn() throws Throwable {
//        Wait.forSeconds(3);
//        click.elementBy(KeyToggleBtn);
//    }
//
//    public void selectDeclineLocalPurchaseToggleBtn() throws Throwable {
//        Wait.forSeconds(3);
//        click.elementBy(KeyToggleBtn);
//    }
//
//
//    public void selectSetTimeToggleBtn() throws Throwable {
//        click.elementBy(KeySetTimeToggleBtn);
//    }
//
//    public void selectSpendLimitToggleBtn(String amt) throws Throwable {
//        Wait.forSeconds(5);
//        click.elementBy(KeySpendLimitToggleBtn);
//        type.data(KeyEnterSpendlimit, amt);
//    }
//
//    public void selectSpendLimitToggleBtnInternationalIOS(String amt) throws Throwable {
//        Wait.forSeconds(5);
//        click.elementBy(KeyenableInternationalToggleBtn);
//        type.data(KeyEnterSpendlimit, amt);
//    }
//
//    public void verifyAmountFiled() throws Throwable {
//        Wait.forSeconds(5);
//        get.elementBy(KeyEnterSpendlimit).clear();
//        Wait.forSeconds(5);
//    }
//
//    public void verifyAmountFiledIOS() throws Throwable {
//        Wait.forSeconds(5);
//        get.elementBy(KeyclearSpendlimit).clear();
//        Wait.forSeconds(5);
//        type.data(KeyEnterSpendlimit, "0");
//    }
//
//    public void verifySpendLimitErrorMsg() throws Throwable {
//        verify.elementIsPresent(KeySpendlimitErrorMsg);
//    }
//
//
//    public String verifyCardStatusInTransactionControl(String CardStatus) throws Throwable {
//
//        cardstatus = get.elementBy(KeyTransactionControlcardstatus).getText();
//        if (cardstatus.length() == CardStatus.length()) {
//            verifyCardStatusInTransactionControls(CardStatus);
//        } else {
//            verifyToggleBtnStatus();
//            selectCardSwitchBtn();
//            Wait.forSeconds(40);
//            //verifyCardStatusInTransactionControls(CardStatus);
//            //verifyCardStatusInTransactionControlsLockIOS(CardStatus);
//            verifyCardStatusInTransactionControls(CardStatus);
//        }
//        return CardStatus;
//    }
//
//    public String verifyCardStatusInTransactionControlLocalIOS(String CardStatus) throws Throwable {
//
//        cardstatus = get.elementBy(KeyTransactionControlcardstatus).getText();
//        //String Status = "Locked";
//
////        if (CardStatus.length() == cardstatus.length()) {
////            cardstatus = get.elementBy(KeyTransactionControlcardstatus).getText();
////        } else {
////            cardstatus = get.elementBy(KeyTransactionControlLockedcardstatus).getText();
////        }
//
//        if (cardstatus.length() == CardStatus.length()) {
//            verifyCardStatusInTransactionControls(CardStatus);
//        } else {
//            //verifyToggleBtnStatus();
//            //selectCardSwitchBtn();
//            selectCardSwitchBtnIOS();
//            Wait.forSeconds(7);
//            //verifyCardStatusInTransactionControls(CardStatus);
//            verifyCardStatusInTransactionControlsLockIOS(CardStatus);
//        }
//        return CardStatus;
//    }
//
//    public String verifyCardStatusInTransactionControlIOS(String CardStatus) throws Throwable {
//        cardstatus = get.elementBy(KeyTransactionControlcardstatus).getText();
//
//        if (CardStatus.length() == CardStatus.length()) {
//            cardstatus = get.elementBy(KeyTransactionControlcardstatus).getText();
//        } else {
//            cardstatus = get.elementBy(KeyTransactionControlLockedcardstatus).getText();
//        }
//
//        if (cardstatus.length() == CardStatus.length()) {
//            verifyCardStatusInTransactionControls(CardStatus);
//        } else {
//            verifyToggleBtnStatus();
//            //selectCardSwitchBtn();
//            selectCardSwitchBtnIOS();
//            Wait.forSeconds(7);
//            //verifyCardStatusInTransactionControls(CardStatus);
//            verifyCardStatusInTransactionControlsLockIOS(CardStatus);
//        }
//        return CardStatus;
//    }
//
//    public void clickOnlineTransaction() throws Throwable {
//        click.elementBy(KeyClickOnlineTransaction);
//    }
//
//    public void clickInternationalTransaction() throws Throwable {
//        click.elementBy(KeyClickInternationalTransaction);
//    }
//
//    public void verifyCardStatusInTransactionControls(String ititle) throws Throwable {
//        verify.elementTextMatching(KeyTransactionControlcardstatus, ititle);
//    }
//
//    public void verifyCardStatusInTransactionControlsLockIOS(String ititle) throws Throwable {
//        verify.elementTextMatching(KeyTransactionControlcardLockstatus, ititle);
//    }
//
//    public void verifyTransactionDeclinedStatus(String TStatus) throws Throwable {
//        verify.elementTextMatching(KeyTransactionStatus, TStatus);
//    }
//
//    public void verifyOnlineTransactionDeclinedStatusIOS(String TStatus) throws Throwable {
//        verify.elementTextMatching(KeyOnlineDeclinedTransactionstatus, TStatus);
//    }
//
//    public void verifyInternationalTransactionDeclinedStatusIOS(String TStatus) throws Throwable {
//        verify.elementTextMatching(KeyInternationalDeclinedTransactionstatus, TStatus);
//    }
//
//    public void verifyLocalTransactionDeclinedStatusIOS(String TStatus) throws Throwable {
//        verify.elementTextMatching(KeyLocalDeclinedTransactionstatus, TStatus);
//    }
//
//    public void VerifyOnlineTransactionStatus(String arg1, String arg2) throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickOnlineTransaction();
//            enableOnlinePurchases();
//            Wait.forSeconds(30);
//            clickSavebtn();
//            Wait.forSeconds(3);
//            verifyTransactionControlsPageTitle(arg2);
//            verifyTransactionDeclinedStatus(arg1);
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifyTransactionDeclinedStatus(arg1);
//
//        }
//    }
//
//    public void VerifyOnlineTransactionStatusIOS(String arg1, String arg2) throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyEnbaledTransactionStatus).getText();
//
//        /*if (currenttransactionstatus.length() == currenttransactionstatus.length()) {
//            currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText(); }
//        else {
//            cardstatus = get.elementBy(KeyEnbaledTransactionStatus).getText();
//        }*/
//
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickOnlineTransaction();
//            enableOnlinePurchases();
//            clickSavebtn();
//            Wait.forSeconds(3);
//            verifyTransactionControlsPageTitle(arg2);
//            verifyTransactionDeclinedStatus(arg1);
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifyOnlineTransactionDeclinedStatusIOS(arg1);
//
//        }
//    }
//
//    public void VerifyInternationalTransactionStatus(String arg1, String arg2) throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickInternationalTransaction();
//            enableOnlinePurchases();
//            clickSavebtn();
//            Wait.forSeconds(3);
//            verifyTransactionControlsPageTitle(arg2);
//            verifyTransactionDeclinedStatus(arg1);
//            //clickInternationalTransaction();
//            //EnableOnlinePurchases();
//            //clickSavebtn();
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifyTransactionDeclinedStatus(arg1);
//
//        }
//    }
//
//    public void VerifyInternationalTransactionStatusIOS(String arg1, String arg2) throws Throwable {
//        //currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//
//        currenttransactionstatus = get.elementBy(KeyEnbaledTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickInternationalTransaction();
//            enableOnlinePurchases();
//            clickSavebtn();
//            Wait.forSeconds(3);
//            verifyTransactionControlsPageTitle(arg2);
//            verifyTransactionDeclinedStatus(arg1);
//            //clickInternationalTransaction();
//            //EnableOnlinePurchases();
//            //clickSavebtn();
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifyInternationalDeclinedStatus(arg1);
//        }
//    }
//
//    public void VerifyLocalTransactionStatus(String arg1, String arg2) throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickLocalTransaction();
//            enableOnlinePurchases();
//            clickSavebtn();
//            Wait.forSeconds(3);
//            verifyTransactionControlsPageTitle(arg2);
//            verifyTransactionDeclinedStatus(arg1);
//            //clickLocalTransaction();
//            //EnableOnlinePurchases();
//            //clickSavebtn();
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifyTransactionDeclinedStatus(arg1);
//        }
//    }
//
//    public void VerifyLocalTransactionStatusIOS(String arg1, String arg2) throws Throwable {
//        //currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//
//        currenttransactionstatus = get.elementBy(KeyEnbaledTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickLocalTransaction();
//            enableOnlinePurchases();
//            clickSavebtn();
//            Wait.forSeconds(3);
//            verifyTransactionControlsPageTitle(arg2);
//            verifyTransactionDeclinedStatus(arg1);
//            //clickLocalTransaction();
//            //EnableOnlinePurchases();
//            //clickSavebtn();
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifyLocalTransactionDeclinedStatusIOS(arg1);
//        }
//    }
//
//    public void clickLocalTransaction() throws Throwable {
//        click.elementBy(KeyClickLocalTransaction);
//    }
//
//    public void verifyOnlineDeclinedStatus(String TStatus) throws Throwable {
//        verify.elementTextMatching(KeyTransactionStatus, TStatus);
//    }
//
//    public void verifyInternationalDeclinedStatus(String TStatus) throws Throwable {
//        verify.elementTextMatching(KeyTransactionStatus, TStatus);
//    }
//
//    public void verifyLocalDeclinedStatus(String TStatus) throws Throwable {
//        verify.elementTextMatching(KeyTransactionStatus, TStatus);
//    }
//
//    public void verifySpendLimitIsUpdated(String spendlimit) throws Throwable {
//        spendlimit = get.elementBy(KeySpendLimitStatus).getText().trim();
//        if (spendlimit.length() == spendlimit.length()) {
//            verify.elementIsPresent(KeySpendLimitStatus);
//        }
//
//    }
//
//    public void unblockTransactions() throws Throwable {
//        clickOnlineTransaction();
//        enableOnlinePurchases();
//        clickSavebtn();
//        clickInternationalTransaction();
//        enableOnlinePurchases();
//        clickSavebtn();
//        clickLocalTransaction();
//        enableOnlinePurchases();
//        clickSavebtn();
//    }
//
//    public void unblockOnlineSpendLimit() throws Throwable {
//        clickOnlineTransaction();
//        enableSpendLimitToggleBtn();
//        clickSavebtn();
//    }
//
//    public void unblockOnlineSpendLimitIOS() throws Throwable {
//        clickOnlineTransaction();
//        enableSpendLimitToggleBtn();
//        clickSavebtnIOS();
//    }
//
//    public void unblockInternationalSpendLimit() throws Throwable {
//        clickInternationalTransaction();
//        enableSpendLimitToggleBtn();
//        clickSavebtn();
//    }
//
//    public void unblockInternationalSpendLimitIOS() throws Throwable {
//        clickInternationalTransaction();
//        enableSpendLimitToggleBtn();
//        clickSavebtnIOS();
//    }
//
//    public void unblockLocalSpendLimit() throws Throwable {
//        clickLocalTransaction();
//        enableSpendLimitToggleBtn();
//        clickSavebtn();
//    }
//
//    public void unblockLocalSpendLimitIOS() throws Throwable {
//        clickLocalTransaction();
//        enableSpendLimitToggleBtn();
//        clickSavebtnIOS();
//    }
//
//    public void enterGreaterSpendLimitInOnline() throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickOnlineTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("greater_than_CreditLimit"));
//        }
//    }
//
//    public void enterGreaterSpendLimitInOnlineIOS() throws Throwable {
//        //currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//
//        clickOnlineTransaction();
//        enableSpendLimitToggleBtn();
//        clickSpendLimit();
//        enterSpendLimit(PropertyReader.testDataOf("greater_than_CreditLimit"));
//
//
//       /* if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickOnlineTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("greater_than_CreditLimit"));
//        }*/
//
//    }
//
//    public void enterLowerCreditLimitInOnline() throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickOnlineTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("lower_than_credit_limit"));
//            clickSavebtn();
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_lower_limit"));
//            unblockOnlineSpendLimit();
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_lower_limit"));
//            unblockOnlineSpendLimit();
//        }
//
//    }
//
//    public void enterLowerCreditLimitInOnlineIOS() throws Throwable {
//        //currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        //if (currenttransactionstatus.length() == transactionstatus3.length()) {
//        clickOnlineTransaction();
//        enableSpendLimitToggleBtn();
//        clickSpendLimit();
//        enterSpendLimit(PropertyReader.testDataOf("lower_than_credit_limit"));
//        clickSavebtn();
//        verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_lower_limit"));
//        unblockOnlineSpendLimitIOS();
//        Wait.forSeconds(7);
//        /*} else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_lower_limit"));
//            unblockOnlineSpendLimit();
//        } */
//
//    }
//
//    public void enterEqualCreditLimitInOnline() throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickOnlineTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("equal_to_credit_limit"));
//            clickSavebtn();
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_credit_limit"));
//            unblockOnlineSpendLimit();
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_credit_limit"));
//            unblockOnlineSpendLimit();
//        }
//    }
//
//    public void enterEqualCreditLimitInOnlineIOS() throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickOnlineTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("equal_to_credit_limit"));
//            clickSavebtn();
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_credit_limit"));
//            unblockOnlineSpendLimitIOS();
//            Wait.forSeconds(7);
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_credit_limit"));
//            unblockOnlineSpendLimitIOS();
//            Wait.forSeconds(7);
//        }
//    }
//
//    public void enterGreaterSpendLimitInInternational() throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickInternationalTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("greater_than_CreditLimit"));
//        }
//    }
//
//    public void enterGreaterSpendLimitInInternationalIOS() throws Throwable {
//
//        clickInternationalTransaction();
//        Wait.forSeconds(3);
//        enableInternationalSpendLimitIOS();
//        clickSpendLimit();
//        enterSpendLimit(PropertyReader.testDataOf("greater_than_CreditLimit"));
//    }
//
//    public void enterLowerCreditLimitInInternational() throws Throwable {
//
//        /*if (currenttransactionstatus.length() == currenttransactionstatus.length()) {
//            currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText(); }
//        else {
//            cardstatus = get.elementBy(KeyEnbaledTransactionStatus).getText();
//        }*/
//
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickInternationalTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("lower_than_credit_limit"));
//            clickSavebtn();
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_lower_limit"));
//            unblockInternationalSpendLimit();
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_lower_limit"));
//            unblockInternationalSpendLimit();
//        }
//    }
//
//    public void enterLowerCreditLimitInInternationalIOS() throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickInternationalTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("lower_than_credit_limit"));
//            clickSavebtn();
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_lower_limit"));
//            unblockInternationalSpendLimitIOS();
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_lower_limit"));
//            unblockInternationalSpendLimitIOS();
//        }
//    }
//
//    public void enterEqualCreditLimitInInternational() throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickInternationalTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("equal_to_credit_limit"));
//            clickSavebtn();
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_credit_limit"));
//            unblockInternationalSpendLimit();
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_credit_limit"));
//            unblockInternationalSpendLimit();
//        }
//    }
//
//    public void enterEqualCreditLimitInInternationalIOS() throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickInternationalTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("equal_to_credit_limit"));
//            clickSavebtn();
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_credit_limit"));
//            unblockInternationalSpendLimitIOS();
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_credit_limit"));
//            unblockInternationalSpendLimitIOS();
//        }
//    }
//
//    public void enterGreaterSpendLimitInLocal() throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickLocalTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("greater_than_CreditLimit"));
//        }
//    }
//
//    public void enterGreaterSpendLimitInLocalIOS() throws Throwable {
//
//        clickLocalTransaction();
//        enableSpendLimitToggleBtn();
//        clickSpendLimit();
//        enterSpendLimit(PropertyReader.testDataOf("greater_than_CreditLimit"));
//    }
//
//    public void enterLowerCreditLimitInLocal() throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickLocalTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("lower_than_credit_limit"));
//            clickSavebtn();
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_lower_limit"));
//            unblockLocalSpendLimit();
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_lower_limit"));
//            unblockLocalSpendLimit();
//        }
//    }
//
//    public void enterLowerCreditLimitInLocalIOS() throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickLocalTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("lower_than_credit_limit"));
//            clickSavebtn();
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_lower_limit"));
//            unblockLocalSpendLimitIOS();
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_lower_limit"));
//            unblockLocalSpendLimitIOS();
//        }
//    }
//
//    public void enterEqualCreditLimitInLocal() throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickLocalTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("equal_to_credit_limit"));
//            clickSavebtn();
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_credit_limit"));
//            unblockLocalSpendLimit();
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_credit_limit"));
//            unblockLocalSpendLimit();
//        }
//    }
//
//    public void enterEqualCreditLimitInLocalIOS() throws Throwable {
//        currenttransactionstatus = get.elementBy(KeyOnTransactionStatus).getText();
//        if (currenttransactionstatus.length() == transactionstatus3.length()) {
//            clickLocalTransaction();
//            enableSpendLimitToggleBtn();
//            clickSpendLimit();
//            enterSpendLimit(PropertyReader.testDataOf("equal_to_credit_limit"));
//            clickSavebtn();
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_credit_limit"));
//            unblockLocalSpendLimitIOS();
//        } else if (currenttransactionstatus.length() == transactionstatus4.length()) {
//            verifySpendLimitIsUpdated(PropertyReader.testDataOf("updated_credit_limit"));
//            unblockLocalSpendLimitIOS();
//        }
//    }
//
//    public void VerifyOnlineTransaction(String arg1, String arg2) throws Throwable {
//
//        clickOnlineTransaction();
//        enableOnlinePurchases();
//
//
//    }
//}
//
