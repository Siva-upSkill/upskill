package pages;

import actions.Wait;
import base.Keywords;
import cucumber.api.java.cs.A;
import exceptions.ApplicationException;
import runners.ConvergentTestRunner;


public class WesternUnionPage extends Keywords {

    private HomePage home = new HomePage();
    private UITFPage uitfPage = new UITFPage();
    private SendRequestPage sendrequest = new SendRequestPage();

    private String WesternUnion = "convergent.WesternUnion.WesternUnion";
    private String otherPartners = "convergent.WesternUnion.otherPartners";
    private String keyGetStartedBtn="convergent.UITF.getStartedBtn";
    private String KeySendRequestTab = "convergent.home.tabFundTransfer";
    private String ReceiveMoneyFromTitle = "convergent.WesternUnion.WesternUnion.ReceiveMoneyFromTitle";
    private String WesternUnionTitle =  "convergent.WesternUnion.WesternUnion.WesternUnionTitle";

    private String InvalidAmount ="onlineBanking.WesternUnion.InvalidAmount";
    private String MTCNCode ="onlineBanking.WesternUnion.MTCNCode";
    private String Amount ="onlineBanking.WesternUnion.Amount";
    private String MTCNCodeLessthan10digitErrMsg ="onlineBanking.WesternUnion.MTCNCodeLessthan10digitErrMsg";
    private String InvalidMTCNCODEErrMsg ="onlineBanking.WesternUnion.InvalidMTCNCODEErrMsg";
    private String Purpose ="onlineBanking.WesternUnion.Purpose";
    private String RelationShip ="onlineBanking.WesternUnion.RelationShip";
    private String WUAccount ="onlineBanking.WesternUnion.WUAccount";
    private String MTCNAlreadyClaimedErrMsg ="onlineBanking.WesternUnion.MTCNAlreadyClaimedErrMsg";
    private String PurposeGift ="onlineBanking.WesternUnion.PurposeGift";
    private String GonzalesAccount ="onlineBanking.WesternUnion.GonzalesAccount";
    private String RelationShipFamily ="onlineBanking.WesternUnion.RelationShipFamily";
    private String getStartedBtn = "onlineBanking.WesternUnion.GetStartedBtn";
    private String SelectAccount = "onlineBanking.WesternUnion.SelectAccount";


    ConvergentTestRunner Devicename=new ConvergentTestRunner();


    public void clickWesternUnion() throws ApplicationException {
        Wait.forSeconds(10);
        home.gotoSendRequestTab();
        Wait.forSeconds(4);
        sendrequest.gotoRequestTab();
        Wait.forSeconds(4);
        verify.IfElementExists(otherPartners);
        click.elementBy(otherPartners);
        Wait.waituntillElementVisibleMob(keyGetStartedBtn,3);
        click.elementBy(keyGetStartedBtn);
        Wait.waituntillElementVisibleMob(WesternUnion,3);
        click.elementBy(WesternUnion);
        Wait.forSeconds(3);
        uitfPage.clickNextBtn();
    }

    public void verifyHeader() throws ApplicationException {
        verify.elementIsPresent(ReceiveMoneyFromTitle);
        verify.elementIsPresent(WesternUnionTitle);
    }

    public void enterMTCNCode(String code) throws ApplicationException {
        Wait.waituntillElementVisibleMob(MTCNCode,3);
        type.data(MTCNCode,code);
    }

    public void verifyMTCNCode(String code) throws ApplicationException{
        Wait.waituntillElementVisibleMob(MTCNCode,3);
        //verify.ElementTextByAttribute(MTCNCode,code,"value");
        verify.elementTextMatching(MTCNCode,code);
    }

    public void verifyErrMsg_Lessthan10Digits() throws ApplicationException {
        verify.elementIsPresent(MTCNCodeLessthan10digitErrMsg);
    }

    public void enterMTCNAmt(String amount) throws ApplicationException{
        type.data(Amount,amount);
    }

    public void verifyInvalidAmtErrMsg() throws ApplicationException {
        verify.elementIsPresent(InvalidAmount);
    }

    public void verifySendReceive()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(KeySendRequestTab);
    }
    public void enterOtherDetails_WU() throws ApplicationException {
        click.elementBy(SelectAccount);
        Wait.waituntillElementVisibleMob(WUAccount,3);
        click.elementBy(WUAccount);
        click.elementBy(Purpose);
        click.elementBy(PurposeGift);
        click.elementBy(RelationShip);
        verify.IfElementExists(RelationShipFamily);
        click.elementBy(RelationShipFamily);
        Wait.forSeconds(5);
    }

}