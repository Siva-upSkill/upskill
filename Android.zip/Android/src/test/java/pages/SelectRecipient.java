package pages;

import base.Keywords;
import exceptions.ApplicationException;

public class SelectRecipient extends Keywords {

    String KeySearchParticipant = "";
    String KeyDone = "convergent.request_payment_addparticipant.btnDone";
    String KeyPageTitle = "convergent.request_payment_addparticipant.labelPageTitle";
    String KeyAddNewContact= "convergent.request_payment_addparticipant.btnAddContact";
    String KeyGoBack = "convergent.request_payment_addparticipant.btnBack";
    String KeyFirstRecipient = "convergent.request_payment_addparticipant.checkboxFirstContact";

    public void verifyPageTitle(String expectedPageTitle) throws ApplicationException {
        verify.elementText(KeyPageTitle,expectedPageTitle);
    }

    public void searchParticipant(String participantName) throws ApplicationException {
        click.elementBy(KeyFirstRecipient);
    }

    public void selectFirstContact() throws ApplicationException {
        click.elementBy(KeyFirstRecipient);
    }

    public void clickDone() throws ApplicationException {
        click.elementBy(KeyDone);
    }

    public void clickAddContact() throws ApplicationException {
        click.elementBy(KeyAddNewContact);
    }

    public void clickGoBack() throws ApplicationException {
        click.elementBy(KeyGoBack);
    }

    public void selectRecipients(int howMany) throws ApplicationException {
        for(int i=1;i<=howMany;i++){
            click.elementBy(KeyFirstRecipient,i);
        }
    }
}
