package pages;

import actions.Wait;
import base.Keywords;
import helper.PropertyReader;
import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class EasyTransferBTOPage extends Keywords {

    private String ClickBlueCreditCard= "onlineBanking.EasyTransfer.BlueCards";
    private String clickOrangeCreditCard= "onlineBanking.EasyTransfer.OrangeCards";
    private String Installments= "onlineBanking.EasyTransfer.Installments";
    private String GetStarted="onlineBanking.EasyTransfer.GetStarted";
    private String TurnMessage="onlineBanking.EasyTransfer.TurnMessage";
    private String EasyTransfer="onlineBanking.EasyTransfer.EasyTransferLabel";
    private String LabelMessage="onlineBanking.EasyTransfer.LabelMessage";
    private String RemainderMsg="onlineBanking.EasyTransfer.RemainderMsg";
    private String EditOpion="onlineBanking.EasyTransfer.EditOption";
    private String EnterPhpAmount="onlineBanking.EasyTransfer.EnterPHPAmount";
    private String SelectPaymentPlan="onlineBanking.EasyTransfer.SelectPaymentPlan";
    private String SelectPlan="onlineBanking.EasyTransfer.SelectPlan";
    private String NextBtn="onlineBanking.EasyTransfer.NextBtn";
    private String CreditCardDetails="onlineBanking.EasyTransfer.CreditCardDetails";
    private String CreditLabelDescription="onlineBanking.EasyTransfer.CreditCardLabelDescription";
    private String CreditNumberTxtBox="onlineBanking.EasyTransfer.EnterCreditCardNumber";
    private String EasyTransferSummaryHeader="onlineBanking.EasyTransfer.EasyTransferSummaryHeader";
    private String EasyTransferLabelMessage="onlineBanking.EasyTransfer.EasyTransferLabelMessage";
    private String TransferBalanceFrom="onlineBanking.EasyTransfer.TransferBalanceFrom";
    private String TransferBalanceTo="onlineBanking.EasyTransfer.TransferBalanceTo";
    private String PrincipalAmount="onlineBanking.EasyTransfer.PrincipalAmount";
    private String MonthlyInstallments="onlineBanking.EasyTransfer.MonthlyInstallments";
    private String Term ="onlineBanking.EasyTransfer.Term";
    private String FactorRate="onlineBanking.EasyTransfer.FactorRate";
    private String EffectiveInterestRate="onlineBanking.EasyTransfer.EffectiveInterestRate";
    private String ProcessingFee="onlineBanking.EasyTransfer.ProcessingFee";
    private String Remainders="onlineBanking.EasyTransfer.Remainders";
    private String TermsConditions="onlineBanking.EasyTransfer.Termsconditions";
    private String TermsConditionsHeader="onlineBanking.EasyTransfer.TermsConditionsText";
    private String AgreeButton="onlineBanking.EasyTransfer.AgreeButton";
    private String RequestButton="onlineBanking.EasyTransfer.RequestButton";
    private String SuccessMessage="onlineBanking.EasyTransfer.SuccessMessage";
    private String Okay="onlineBanking.EasyTransfer.Okay";
    private String InvalidBankMsg="onlineBanking.EasyTransfer.InvalidBankMessage";
    private String Gotit="onlineBanking.EasyTransfer.GotIt";
    private String EditCreditCard="onlineBanking.EasyTransfer.CreditCardEditOption";
    private String MinimumErrorMsg="onlineBanking.EasyTransfer.MinimumAmountInlineMessage";
    private String MaximumErrorMsg="onlineBanking.EasyTransferMaximumErrormsg";
    private String PaymentPlanHeader = "onlineBanking.EasyTransfer.PaymentPlanHeader";
    private String MaskedFromCardNumber = "onlineBanking.EasyTransfer.FromCardDetailsMasked";
    private String MaskedToCardNumber = "onlineBanking.EasyTransfer.ToCardDetailsMasked";


    public void ClickCard() throws Throwable {
        Wait.forSeconds(5);
        click.elementBy(ClickBlueCreditCard);
//        AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.widget.TextView[@text=\"9528\"]");
//        element.click();
    }

    public void ClickInstallments() throws Throwable {
        Wait.forSeconds(5);
        click.elementBy(Installments);}

    public void clickGetstarted()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(GetStarted);
        click.elementBy(NextBtn);
        click.elementBy(NextBtn);
        click.elementBy(NextBtn);
        Wait.forSeconds(1);
        click.elementBy(Gotit);
    }
     public void verifyTurnOnMessage()throws Throwable{
        Wait.forSeconds(1);
        verify.elementIsPresent(TurnMessage);
     }
//    public void ClickSkip() throws Throwable {
//        Wait.forSeconds(2);
//        click.elementBy(Skip);
//    }

    public void VerifyEasyTransferOption() throws Throwable {
        Wait.forSeconds(5);
        verify.elementIsPresent(EasyTransfer);
    }
    public void verifyEasyTransferRemainderMsg()throws Throwable{
        Wait.forSeconds(1);
        swipe.swipeVertical(2, 0.6, .2, 2);
        click.elementBy(Remainders);
    }
    public void clickEasyTransferOption() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(EasyTransfer);
    }
    public void verifyEasyTransferlabelMsg()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(LabelMessage);
    }
    public void verifyRemainderMsg()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(RemainderMsg);
    }
    public void verifyCardDetailsLabelMsg()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(CreditLabelDescription);
    }
    public void ClickAmountEditOption() throws Throwable {
        Wait.forSeconds(3);
        click.elementBy(EditOpion);
    }

//    public void ClickAmount() throws Throwable {
//        Wait.forSeconds(2);
////        click.elementBy(EnterPhpAmount);
////        get.elementBy(EnterPhpAmount).clear();
//        type.data(EnterPhpAmount, PropertyReader.testDataOf("BTOAmount"));
//    }
    public void click_Slider() throws Throwable {
        Wait.forSeconds(2);
        WebElement slider = driver.findElement(By.id("com.unionbankph.online.qat:id/range_slider"));
        Actions move = new Actions(driver);
        move.moveToElement(slider).clickAndHold().moveByOffset(0, 100).release().perform();
        move.moveToElement(slider).clickAndHold().moveByOffset(-500, 0).release().perform();
    }
    public void EnterMaximumAmount() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(EnterPhpAmount);
        type.data(EnterPhpAmount, PropertyReader.testDataOf("BTOAmountMaximum"));
    }

    public void EnterMinimumAmount() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(EnterPhpAmount);
        type.data(EnterPhpAmount, PropertyReader.testDataOf("BTOAmountMinimum"));
    }
    public void verifyMinimumMsg()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(MinimumErrorMsg);
    }
    public void verifyMaximumMsg()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(MaximumErrorMsg);
    }

    public void VerifyPaymentPlanHeader() throws Throwable {
        Wait.forSeconds(2);
        verify.elementIsPresent(PaymentPlanHeader);

    }

    public void ClickPaymentPlan() throws Throwable {
        Wait.forSeconds(2);
        verify.elementIsPresent(SelectPlan);
        Wait.forSeconds(3);
        click.elementBy(SelectPlan);
    }

    public void VerifyAndClickNext() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(NextBtn);
    }

    public void VerifyCreditCardHeader() throws Throwable {
        Wait.forSeconds(2);
        verify.elementIsPresent(CreditCardDetails);
    }
    public void VerifyMaskedFromCardDetails() throws Throwable {
        Wait.forSeconds(2);
        verify.elementTextContains(MaskedFromCardNumber, PropertyReader.testDataOf("BTOMaskedFromCardnumber").trim());
    }
    public void VerifyMaskedToCardDetails() throws Throwable{
        Wait.forSeconds(2);
        verify.elementTextContains(MaskedToCardNumber, PropertyReader.testDataOf("BTOMaskedToCardNumber").trim());
    }
    public void EnterCardNumber() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(CreditNumberTxtBox);
        type.data(CreditNumberTxtBox, PropertyReader.testDataOf("BTOCardNumber"));
    }
    public void EnterCardNumber_Edit() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(CreditNumberTxtBox);
        type.data(CreditNumberTxtBox, PropertyReader.testDataOf("BTOCardNumber_Edit"));
    }

    public void verifyEasyTransferHeader() throws Throwable {
        Wait.forSeconds(5);
        verify.elementIsPresent(EasyTransferSummaryHeader);
    }
    public void verifyCreditcardDetails()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(TransferBalanceFrom);
        verify.elementIsPresent(TransferBalanceTo);
        verify.elementIsPresent(PrincipalAmount);
        verify.elementIsPresent(MonthlyInstallments);
        swipe.swipeVertical(2, 0.6, .2, 2);
        verify.elementIsPresent(Term);
        verify.elementIsPresent(FactorRate);
        verify.elementIsPresent(EffectiveInterestRate);
        verify.elementIsPresent(ProcessingFee);
    }

    public void ClickTermsAndConditions() throws Throwable {
        Wait.forSeconds(1);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        Wait.forSeconds(1);
        click.elementBy(TermsConditions);
    }

    public void TermsAndConditionsLink() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(TermsConditionsHeader);
    }

    public void IAgreeButton() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(AgreeButton);
    }

    public void ClickRequestForEasyTransfer() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(RequestButton);
    }

    public void VerifySuccessMessage() throws Throwable {
        Wait.forSeconds(6);
        verify.elementIsPresent(SuccessMessage);
    }

    public void ClickOkay() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(Okay);
    }

    public void VerifyInvalidCardNumberErrorMessage() throws Throwable {
        Wait.forSeconds(2);
        verify.elementTextMatching(InvalidBankMsg,PropertyReader.testDataOf("BTOCreditcardValidationMessage"));

    }
    public void ClickGotItButton() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(Gotit);
    }

    public void ClickToEasyTransferPage() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(EasyTransfer);
    }
    public void verifyLabelMessage()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(EasyTransferLabelMessage);
    }
    public void EnterInvalidCardNumber() throws Throwable {
        Wait.forSeconds(2);
        type.data(CreditNumberTxtBox, PropertyReader.testDataOf("BTOInvalidCardNumber"));
    }
    public void ClickEditInCreditCardDetails() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(EditCreditCard);
    }
//    public void ClickEditInEasyTransferDetails() throws Throwable {
//        Wait.forSeconds(2);
//        click.elementBy(EasyTransferDetailEdit);
//    }
    public void ClickNewAmount() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(EnterPhpAmount);
        type.data(EnterPhpAmount, PropertyReader.testDataOf("BTONewAmount"));
    }
}


