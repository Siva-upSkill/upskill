package pages;

import actions.Swipe;
import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;
import runners.ConvergentTestRunner;

public class HomePage extends Keywords {

    private String KeyRegisterDevicePopup = "convergent.home.titleRegisterDevice";
    private String SendText="convergent.fundtransfer.Send";
    private String ReceiveText="convergent.fundtransfer.Receive";
    private String KeyRegisterDeviceText1 = "convergent.home.labelRegisterDeviceText1";
    private String KeyRegisterDeviceText2 = "convergent.home.labelRegisterDeviceText2";
    private String KeyRegisterDeviceNotNow = "convergent.home.btnRegisterDeviceNotNow";
    private String KeyGotoDashBoard = "convergent.home.KeyGotoDashBoard";

    private String KeyHomePageTitle = "convergent.home.labelPageTitle";
    private String KeyHomePageSendRequestTab = "convergent.home.tabFundTransfer";
    private String KeyWelcomeUnionBankOnline = "convergent.home.welcomeonunionbank";
    private String KeyBtnNotNow="convergent.home.btncontinue";
    private String keyNotNow="convergent.home.btnNotnow";

    private String KeySubscribeOtpNotNow = "convergent.home.btntrustnotnow";
    private String KeySubscribeToAppOtpNotNow = "convergent.home.btncontinue";
    private String KeyNotNowToNotification = "convergent.home.btncontinue";
    private String KeySuccessPage = "com.unionbankph.online.qat:id/button_dashboard";
    private String KeyRequestPaymentLink = "convergent.request.linkRequestPayment";
    private String KeyRequestTab = "convergent.send.linkRequestTab";
    private String KeyDashboard = "convergent.home.btnDashboard";
    private String KeyDashboardPageTitle = "convergent.home.labelDashboardTitle";
    private String KeyNotNowToNotificationfingerprint = "convergent.home.btnfingerprintDeviceNotNow";
    private String KeyBtnmore = "convergent.home.tabMore";

    private String keyBackbutton = "convergent.home.InsurancepageBackbtn";

    private String cybersecurepopup = "onlineBanking.Dashboard.Cybersecure.Gotthis";
    ConvergentTestRunner Devicename = new ConvergentTestRunner();

    // Only available in Bala's machine
    private String KeySendRequestTab = "convergent.home.tabFundTransfer";


    //    private String cybersecurepopup = "onlineBanking.Dashboard.MayBelater1";
    private String insurancepopup = "onlineBanking.Dashboard.MayBelater2";


    public void verifyIfRegisterDevicePopup(String expectedMessage) throws ApplicationException {
        verify.elementTextMatching(KeyRegisterDevicePopup, expectedMessage);
    }

    public void closeRegisterDevicePopup() throws ApplicationException {
        ////ResourceBase.PERFORM.clickIfExists(KeyRegisterDeviceNotNow,5);
        verify.IfElementExists(KeyRegisterDeviceNotNow);
        click.elementBy(KeyRegisterDeviceNotNow);
    }

    public void verifyIfDashboardIsDisplayed(String expectedTitle) throws ApplicationException {
        Wait.forSeconds(2);
        verify.elementTextMatching(KeyHomePageTitle, expectedTitle);

    }

    public void gotoSendRequestTabIOS() throws ApplicationException {
        click.elementBy(KeySendRequestTab);
    }

    public void clickRequestPaymentLinkIOS() throws ApplicationException {
        click.elementBy(KeyRequestPaymentLink);
    }

    public void gotoSendRequestTab() throws ApplicationException {
       WAIT.forSecondsUsingFluentWAIT(4,KeySendRequestTab);
//        verify.elementIsPresent(SendText);
//        verify.IfElementExists(ReceiveText);
        click.elementBy(KeySendRequestTab);
//        MobileElement mobileElement = (MobileElement) driver.findElementById("com.unionbankph.online.qat:id/nav_button_transfer_fund");
//
//        mobileElement.click();
    }

    public void clickContinue() throws ApplicationException {
        Wait.forSeconds(1);
        if (verify.IfElementExistsboolean(KeySubscribeToAppOtpNotNow)) {
            click.elementBy(KeyWelcomeUnionBankOnline);
        }

    }

    public void clickNotNowtoSubscribe() throws ApplicationException {
        Wait.forSeconds(1);
        if (verify.IfElementExistsboolean(KeySubscribeToAppOtpNotNow)) {
            click.elementBy(KeySubscribeToAppOtpNotNow);
        }
    }

    public void clickSubscribeToAppOtpNotNow() throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeySubscribeOtpNotNow,3);
        if (verify.IfElementExistsboolean(KeySubscribeOtpNotNow)) {
            click.elementBy(KeySubscribeOtpNotNow);
        }
    }

    public void clickBtnmore() throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyBtnmore,2);
        click.elementBy(KeyBtnmore);
    }

    public void clickNotNowToTurnOnNotification() throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyNotNowToNotification,3);
        if (verify.IfElementExistsboolean(KeyNotNowToNotification)) {
            click.elementBy(KeyNotNowToNotification);
        }
//        if(verify.IfElementExistsboolean(keyBackbutton)) {
//            click.elementBy(keyBackbutton);
//        }

    }

    public void clickNotNowfingerprintNotification() throws ApplicationException {
       Wait.waituntillElementVisibleMob(KeyNotNowToNotificationfingerprint,2);
        click.elementBy(KeyNotNowToNotificationfingerprint);
    }

    public void clickGotoDashBoard() throws ApplicationException {
        WAIT.forSecondsUsingFluentWAIT(4,KeyGotoDashBoard);
        if (verify.IfElementExistsboolean(KeyGotoDashBoard)) {
            click.elementBy(KeyGotoDashBoard);
        }else
            Wait.waituntillElementVisibleMob(cybersecurepopup,3);
        if (verify.IfElementExistsboolean(cybersecurepopup)) {
            click.elementBy(cybersecurepopup);
        }else
            Wait.waituntillElementVisibleMob(keyNotNow,2);
        if(verify.IfElementExistsboolean(keyNotNow)){
                click.elementBy(keyNotNow);
            }

        // OTP generate Message

//         if (Devicename.currentdevicename.equalsIgnoreCase("Samsung")) {
//            Wait.forSeconds(3);
//            actions.Touch.pressByCoordinates(514, 1795, 8);
//         } else if (Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
//            Wait.forSeconds(3);
//            actions.Touch.pressByCoordinates(551, 1881, 8);
//        }
        //Wait.forSeconds(8);
//        MobileElement mobileElement = (MobileElement) driver.findElementByXPath("//android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/androidx.viewpager.widget.ViewPager/android.view.ViewGroup/android.widget.Button");
//        mobileElement.click();
//        click.elementBy(KeyGotoDashBoard);
        //For insurance pop up in dashboard - pls give if insurance pop up is seen

//        try {
//
//            if (Devicename.currentdevicename.equalsIgnoreCase("Samsung")) {
//                Wait.forSeconds(10);
//                actions.Touch.pressByCoordinates(517, 1795, 8);
//            } else if (Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
//                Wait.forSeconds(10);
//                actions.Touch.pressByCoordinates(586, 1862, 8);
////                Wait.forSeconds(10);
////                actions.Touch.pressByCoordinates(568, 1857, 8);
////                Wait.forSeconds(10);
//            }
//        }
//        catch (Exception e)
//        {
//            System.out.println();
//        }
//
//

        // Below code is used when "Cybersecurepop" and its next buttons are displayed. But now its removed.


//        if(verify.IfElementExistsboolean(cybersecurepopup)) {
//            click.elementBy(cybersecurepopup);
//        }


//        driver.findElementByXPath("//android.widget.Button[@text=\"Let's Begin\"]").click();
//        Wait.forSeconds(2);
//        driver.findElementByXPath("//android.widget.Button[@text=\"Next\"]").click();
//        Wait.forSeconds(2);
//        driver.findElementByXPath("//android.widget.Button[@text=\"Next\"]").click();
//        Wait.forSeconds(2);
//        driver.findElementByXPath("//android.widget.Button[@text=\"Next\"]").click();
//        Wait.forSeconds(2);
//        driver.findElementByXPath("//android.widget.Button[@text=\"Next\"]").click();
//        Wait.forSeconds(2);
//        driver.findElementByXPath("//android.widget.Button[@text=\"Next\"]").click();
//        Wait.forSeconds(2);
//        driver.findElementByXPath("//android.widget.Button[@text=\"Next\"]").click();
//        Wait.forSeconds(2);
//        driver.findElementByXPath("//android.widget.Button[@text=\"Yes, I Understand\"]").click();
//        Wait.forSeconds(8);


//        if(verify.IfElementExistsboolean(insurancepopup)) {
//            click.elementBy(insurancepopup);
//
//        }
//
//        Wait.forSeconds(10);
    }

    public void clickGotoDashBoardIOS() throws ApplicationException {
        click.elementBy(KeyDashboard);
    }

    //TBD
    /*public void clickSendRequestTab() throws ApplicationException, InterruptedException {
        ResourceBase.PERFORM.click(KeyHomePageSendRequestTab);
        //ResourceBase.PERFORM.clickIfExists(KeyHomePageSendRequestTab, 10);

    }*/
    public void clickCreditCard(String accnum) throws Throwable {
        //WAIT.forSeconds(4);
        //swipe.scrollDownToTextandClick(accnum);
        //swipe.swipeVertical(2, .8, .1, 5);
        WAIT.forSeconds(45);
        //swipe.swipeVertical(2, .8, .2, 5);
        //swipe.swipeVertical(2, .8, .2, 5);
        //swipe.swipeVertical(2, .8, .2, 5);
        //swipe.swipeVertical(2, .8, .2, 5);
        //swipe.swipeVertical(2, .8, .2, 5);
        //swipe.swipeVertical(2, .8, .2, 5);

        // swipe.swipeVertical(2, .8, .1, 5);
        //swipe.scrollDownToTextandClick(accnum);

        // click.elementBy(By.xpath("//android.widget.TextView[@text='Platinum Visa']"));
        click.elementBy(By.xpath("(//android.widget.TextView[@text='*6389'])"));
    }

    public void clickCreditCardIOS(String accnum) throws Throwable {
        //WAIT.forSeconds(4);
        //swipe.scrollDownToTextandClick(accnum);
        //swipe.swipeVertical(2, .8, .1, 5);
        //swipe.swipeVertical(2, .2, .8, 5);
//        swipe.swipeVertical(2, .2, .8, 5);
//        swipe.swipeVertical(2, .2, .8, 5);
//        swipe.swipeVertical(2, .2, .8, 5);
//        swipe.swipeVertical(2, .2, .8, 5);
        WAIT.forSeconds(25);
        //   swipe.swipeVertical(2, .8, .2, 5);
        //swipe.swipeVertical(2, .8, .1, 5);
        //swipe.scrollDownToTextandClick(accnum);

        //click.elementBy(By.xpath("((//XCUIElementTypeStaticText[@name='Test Card Visa'])[1]/preceding-sibling::*/preceding-sibling::*)[4]"));
        click.elementBy(By.xpath("((//XCUIElementTypeStaticText[@name='Classic Visa'])[1]/preceding-sibling::*/preceding-sibling::*)[4]"));
    }

    public void clickSuccessPageGotoDashBoard() throws ApplicationException {
        click.elementBy(KeySuccessPage);
    }

    public void clickRequestTabIOS() throws ApplicationException {
        click.elementBy(KeyRequestTab);
    }

    public void verifyDashBoardPageTitleIOS(String expectedTitle) throws ApplicationException {
        verify.elementTextMatching(KeyDashboardPageTitle, expectedTitle);
    }

    public void verifyIfDashboardIsDisplayedIOS(String expectedTitle) throws ApplicationException {
        //driver.swipe(SwipeElementDirection.UP, 100, 500);

        verify.elementTextMatching(KeyDashboardPageTitle, expectedTitle);
    }}

