package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import helper.Tools;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import runners.ConvergentTestRunner;


public class FAQPage extends Keywords {

    private HomePage home = new HomePage();
    private UITFPage uitfPage = new UITFPage();
    private SendRequestPage sendrequest = new SendRequestPage();


    ConvergentTestRunner Devicename=new ConvergentTestRunner();


    private String faqLink = "onlineBanking.FAQ.faqLink";
    private String moreBtn = "onlineBanking.FAQ.MoreBtn";
    private String ViewFAQListScreen = "onlineBanking.FAQ.ViewFAQListScreen";
    private String ViewSearchbar = "onlineBanking.FAQ.ViewSearchbar";
    private String ViewRelatedFAQTitle = "onlineBanking.FAQ.ViewRelatedFAQTitle";
    private String ViewFAQDescription = "onlineBanking.FAQ.ViewFAQDescription";
    private String editSearchBar = "onlineBanking.FAQ.editSearchBar";
    private String faq = "onlineBanking.FAQ.faq";

    public void clickFAQ() throws Throwable {
        Wait.waituntillElementVisibleMob(moreBtn,3);
        click.elementBy(moreBtn);
        swipe.swipeVertical(2, 0.6, .2, 2);
        Wait.waituntillElementVisibleMob(faqLink,3);
        click.elementBy(faqLink);
    }
    public void viewFQAListScreen() throws Throwable {
        Wait.waituntillElementVisibleMob(ViewFAQListScreen,3);
        verify.elementIsPresent(ViewFAQListScreen);

    }
    public void viewSearchBar() throws ApplicationException {
        verify.elementIsPresent(ViewSearchbar);

    }
    public void enterCharacterSearchbar(String name) throws ApplicationException {
        click.elementBy(ViewSearchbar);
       // actions.Touch.pressByCoordinates(377, 63, 5);
        type.data(editSearchBar, name);
        //actions.Touch.pressByCoordinates(375, 187, 5);
    }
    public void viewRelatedFAQList() throws Throwable {
        Wait.waituntillElementVisibleMob(faq,3);
        verify.elementIsPresent(faq);

    }
    public void viewFAQDescription() throws Throwable {
        Wait.waituntillElementVisibleMob(faq,3);
        click.elementBy(faq);
        Wait.waituntillElementVisibleMob(ViewRelatedFAQTitle,3);
        verify.elementIsPresent(ViewRelatedFAQTitle);
        //verify.elementIsPresent(ViewFAQDescription);

    }
}