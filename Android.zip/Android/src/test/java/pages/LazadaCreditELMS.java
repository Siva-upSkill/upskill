package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import helper.PropertyReader;

import static helper.PropertyReader.testDataOf;

public class LazadaCreditELMS extends Keywords {


    private String LazadaCreditELMSCard = "onlineBanking.LazadaELMS.SelectCard";
    private String LazadaCreditELMSCardData = testDataOf("LazadaELMS_Card");
    private String LazadaDebittELMSCardData = testDataOf("LazadaDebitELMS_Card");
    private String TransferCredits = "onlineBanking.LazadaELMS.TransferCredits";
    private String ReminderSection = "onlineBanking.LazadaELMS.ReminderSection";
    private String NextButton = "onlineBanking.EasyCash.NextButton";
//    private String NextBtn = "onlineBanking.LazadaELMS.NextBtn";
    private String MobileNoTxtBox = "onlineBanking.LazadaELMS.MobileNoTextBox";
    private String VerifyDetailSection = "onlineBanking.LazadaELMS.VerifyDetailsSection";
    private String YesTheseAreCorrectBtn = "onlineBanking.LazadaELMS.YesTheseAreCorrectBtn";
    private String AmountTxtBox = "onlineBanking.LazadaELMS.AmountTxtBox";
    private String RequestTransferBtn = "onlineBanking.LazadaELMS.RequestTransferBtn";
    private String SuccessMsg = "onlineBanking.LazadaELMS.SuccessMsg";
    private String OkBtn = "onlineBanking.LazadaELMS.OkBtn";
    private String PlusSign="onlineBanking.LazadaELMS.AmountTxtBox.Plus";
    private String CloseBtnAdd = "convergent.login.PopUpClose";
    private String InvalidOTpError = "onlineBanking.LazadaELMS.OTPErrorMessage";
    private String InvalidMobileNumberError = "onlineBanking.LazadaELMS.InvalidMobileNumberErrorMsg";
    private String InvalidAmountInlineError = "onlineBanking.LazadaELMS.InvalidAmountInlineMessage";
    private String EditBtn = "onlineBanking.LazadaELMS.EditBtn";



    public void ClickLazadaCreditCard() throws Throwable{
        Wait.forSeconds(5);
//        try{
//            if(CloseBtnAdd == CloseBtnAdd)
//            {
//               click.elementBy(CloseBtnAdd);
//            }
//        }
//        catch (ApplicationException e) {
//            e.printStackTrace();
//        }
        click.elementBy(LazadaCreditELMSCard,LazadaCreditELMSCardData);

    }
    public void ClickTransferDetails() throws Throwable{
        swipe.swipeVertical(2, 0.8, 0.4, 5);
        swipe.swipeVertical(2, 0.8, 0.4, 5);
        click.elementBy(TransferCredits);
    }
    public void VerifyReminderSectionAndClickNext() throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(ReminderSection);
        click.elementBy(NextButton);
    }
    public void EnterMobileNumber() throws Throwable{
        Wait.waituntillElementVisibleMob(MobileNoTxtBox,3);
        type.data(MobileNoTxtBox, PropertyReader.testDataOf("LazadaELMS_Number"));
//        click.elementBy(NextBtn);

    }
    public void VerifyDetailSection() throws Throwable{
        Wait.waituntillElementVisibleMob(VerifyDetailSection,3);
        verify.elementIsPresent(VerifyDetailSection);
    }
    public void ClickYesTheseAreCorrectButton() throws Throwable{
        Wait.waituntillElementVisibleMob(YesTheseAreCorrectBtn,3);
        click.elementBy(YesTheseAreCorrectBtn);
    }
    public void EnterAmount() throws Throwable{
        Wait.waituntillElementVisibleMob(PlusSign,3);
        click.elementBy(PlusSign);
//        type.data(AmountTxtBox, PropertyReader.testDataOf("LazadaELMS_Amount").trim());
        WAIT.forSecondsUsingFluentWAIT(2,NextButton);
        click.elementBy(NextButton);
    }
    public void ClickRequestTransfer() throws Throwable{
        Wait.waituntillElementVisibleMob(RequestTransferBtn,2);
        click.elementBy(RequestTransferBtn);
    }
    public void VerifySuccessMsg() throws Throwable{
        Wait.waituntillElementVisibleMob(SuccessMsg,3);
        verify.elementIsPresent(SuccessMsg);
        Wait.waituntillElementVisibleMob(OkBtn,2);
        click.elementBy(OkBtn);
    }
    public void InvalidOTPError() throws Throwable{
        Wait.waituntillElementVisibleMob(InvalidOTpError,3);
        verify.elementIsPresent(InvalidOTpError);
    }
    public void InvalidMobileNumberError() throws Throwable{
        Wait.waituntillElementVisibleMob(InvalidMobileNumberError,3);
        verify.elementIsPresent(InvalidMobileNumberError);
    }
    public void InvalidAmountInlineMessage() throws Throwable{
        Wait.waituntillElementVisibleMob(AmountTxtBox,3);
        type.data(AmountTxtBox, PropertyReader.testDataOf("LazadaELMS_InvalidAmount").trim());
        Wait.waituntillElementVisibleMob(InvalidAmountInlineError,3);
        verify.elementIsPresent(InvalidAmountInlineError);

    }
    public void EnterInvalidMobileNumber() throws Throwable {
        Wait.waituntillElementVisibleMob(MobileNoTxtBox,3);
        type.data(MobileNoTxtBox, PropertyReader.testDataOf("LazadaELMS_InvalidNumber").trim());
        click.elementBy(NextButton);
    }
    public void ClickToEdit() throws Throwable{
        Wait.waituntillElementVisibleMob(EditBtn,2);
        click.elementBy(EditBtn);
        type.data(AmountTxtBox, PropertyReader.testDataOf("LazadaELMS_UpdatedAmount").trim());
        Wait.waituntillElementVisibleMob(NextButton,2);
        click.elementBy(NextButton);


    }
    public void ClickLazadaDebitCard() throws Throwable{
        click.elementBy(LazadaCreditELMSCard,LazadaDebittELMSCardData);
        Wait.waituntillElementVisibleMob(LazadaCreditELMSCard,3);
//        try{
//            if(CloseBtnAdd == CloseBtnAdd)
//            {
//               click.elementBy(CloseBtnAdd);
//            }
//        }
//        catch (ApplicationException e) {
//            e.printStackTrace();
//        }
        click.elementBy(LazadaCreditELMSCard,LazadaDebittELMSCardData);

    }

}
