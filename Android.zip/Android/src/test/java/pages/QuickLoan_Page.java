package pages;

import actions.Swipe;
import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;

public class QuickLoan_Page extends Keywords {

    private String QuickLoanHeader="onlineBanking.QuickLoan.QuickLoanHeader";
    private String LoanDetailsHeader="onlineBanking.QuickLoan.LoanDetailsHeader";
    private String SelectAmount="onlineBanking.QuickLoan.SelectAmount";
    private String SelectPurpose="onlineBanking.QuickLoan.SelectPurpose";
    private String SelectPHPAmount1="onlineBanking.QuickLoan.PHPAmount1";
    private String SelectPHPAmount2="onlineBanking.QuickLoan.PHPAmount2";
    private String SelectPHPAmount3="onlineBanking.QuickLoan.PHPAmount3";
    private String Purposename="onlineBanking.QuickLoan.Purpose";
    private String Nextbtn="onlineBanking.QuickLoan.NextBtn";
    private String LoanPaymentDetails="onlineBanking.QuickLoan.LoanPaymentDetails";
    private String Monthtopay="onlineBanking.QuickLoan.Monthtopay";
    private String ImportantPopup="onlineBanking.QuickLoan.ImportantPopup";
    private String Coninue="onlineBanking.QuickLoan.Continue";
    private String EditBtn4="onlineBanking.QuickLoan.EditBtn4";
    private String Cancel="onlineBanking.QuickLoan.Cancel";
    private String CustomerInformation="onlineBanking.QuickLoan.CustomerInformation";
    private String YourProfile="onlineBanking.QuickLoan.YourProfile";
    private String PersonalInformation="onlineBanking.QuickLoan.PersonalInformation";
    private String Address="onlineBanking.QuickLoan.Address";
    private String FinancialInformation="onlineBanking.QuickLoan.FinancialInformation";
    private String EditBtn1="onlineBanking.QuickLoan.EditBtn1";
    private String EditBtn2="onlineBanking.QuickLoan.EditBtn2";
    private String EditBtn3="onlineBanking.QuickLoan.EditBtn3";
    private String UpdateInformation="onlineBanking.QuickLoan.UpdateInformation";
    private String FirstName="onlineBanking.QuickLoan.FirstName";
    private String LastName="onlineBanking.QuickLoan.LastName";
    private String Done="onlineBanking.QuickLoan.Done";
    private String CheckBox1="onlineBanking.QuickLoan.CheckBox1";
    private String CheckBox2="onlineBanking.QuickLoan.CheckBox2";
    private String Civilstatus="onlineBanking.QuickLoan.Civilstatus";
    private String Married="onlineBanking.QuickLoan.Married";
    private String Single="onlineBanking.QuickLoan.Single";
    private String HouseNo="onlineBanking.QuickLoan.HouseNo";
    private String Village="onlineBanking.QuickLoan.Village";
    private String Province="onlineBanking.QuickLoan.Province";
    private String ProvinceAddress="onlineBanking.QuickLoan.ProvinceAddress";
    private String City="onlineBanking.QuickLoan.City";
    private String CityAddress="onlineBanking.QuickLoan.CityAddress";
    private String EmploymentStatus="onlineBanking.QuickLoan.EmploymentStatus";
    private String Employed="onlineBanking.QuickLoan.Employed";
    private String Sourceoffunds="onlineBanking.QuickLoan.Sourceoffunds";
    private String Salary="onlineBanking.QuickLoan.Salary";
    private String Pension="onlineBanking.QuickLoan.Pension";
    private String ErrorMsg="onlineBanking.QuickLoan.ErrorMsg";
    private String BusinessIndustry="onlineBanking.QuickLoan.BusinessIndustry";
    private String Electricity="onlineBanking.QuickLoan.Electricity";
    private String Education="onlineBanking.QuickLoan.Education";
    private String Natureofwork="onlineBanking.QuickLoan.Natureofwrk";
    private String Agriculture="onlineBanking.QuickLoan.Agriculture";
    private String Construction="onlineBanking.QuickLoan.Construction";
    private String Occupation="onlineBanking.QuickLoan.Occupation";
    private String AssistantOccupation="onlineBanking.QuickLoan.AssistantOccupation";
    private String AtheleteOccupation="onlineBanking.QuickLoan.AtheleteOccupation";
    private String TIN="onlineBanking.QuickLoan.TIN";
    private String LoanSummaryHeaeder="onlineBanking.QuickLoan.LoanSummaryHeader";
    private String EDIT="onlineBanking.QuickLoan.EditBtn";
    private String LoanPaymentHeader="onlineBanking.QuickLoan.LoanPaymentHeader";
    private String LoanCheckBox2="onlineBanking.QuickLoan.LoanSummary.Checkbox2";
    private String LoanCgeckBox1="onlineBanking.QuickLoan.LoanSummary.CheckBox1";
    private String Submit="onlineBanking.QuickLoan.Submit";


   public void verify_QuickLoan()throws Throwable{
       Wait.forSeconds(2);
       Swipe.swipe.swipeVertical(2,0.8,0.2,5);
       Swipe.swipe.swipeVertical(2,0.8,0.2,5);
       verify.elementIsPresent(QuickLoanHeader);
   }
   public void click_QuickLoan()throws Throwable{
       Wait.forSeconds(1);
       click.elementBy(QuickLoanHeader);
   }
   public void verify_Headers()throws Throwable{
       Wait.forSeconds(2);
       verify.elementIsPresent(LoanDetailsHeader);
       verify.elementIsPresent(SelectAmount);
       verify.elementIsPresent(SelectPurpose);
   }

   public void Verify_InlineErrormsg()throws Throwable{
       Wait.forSeconds(2);
       click.elementBy(Monthtopay);
       verify.elementIsPresent(ErrorMsg);
   }
   public void click_SelectAmount()throws Throwable{
       Wait.forSeconds(1);
       click.elementBy(SelectAmount);
       click.elementBy(SelectPHPAmount1);
       Wait.forSeconds(1);
   }
    public void click_SelectPurpose()throws Throwable{
       Wait.forSeconds(2);
       click.elementBy(SelectPurpose);
       click.elementBy(Purposename);
    }
    public void verify_LoanPaymentHeader()throws Throwable{
       Wait.forSeconds(1);
       verify.elementIsPresent(LoanPaymentDetails);
       click.elementBy(Nextbtn);
    }
    public void VerifyPopUp()throws Throwable{
       Wait.forSeconds(1);
       verify.elementIsPresent(ImportantPopup);
    }
    public void click_Continue()throws Throwable{
       Wait.forSeconds(1);
       click.elementBy(Coninue);
    }
    public void verify_CustomerInformationHeader()throws Throwable{
       Wait.forSeconds(1);
       verify.elementIsPresent(CustomerInformation);
    }
    public void verfy_FieldsHeader()throws Throwable{
       Wait.forSeconds(1);
       verify.elementIsPresent(YourProfile);
       verify.elementIsPresent(PersonalInformation);
       verify.elementIsPresent(Address);
//       Swipe.swipe.swipeVertical(2,0.8,0.2,5);
//       verify.elementIsPresent(FinancialInformation);
   }
   public void click_Edit1()throws Throwable{
       Wait.forSeconds(2);
       click.elementBy(EditBtn1);
       click.elementBy(FirstName);
       type.data(FirstName,"R");
       Wait.forSeconds(1);
       click.elementBy(LastName);
       type.data(LastName,"Test");
       click.elementBy(Done);
   }
   public void click_Edit2() throws  ApplicationException {
       Wait.forSeconds(1);
       click.elementBy(EditBtn2);
       click.elementBy(Civilstatus);
       click.elementBy(Married);
       click.elementBy(Done);
   }
   public void click_Edit3()throws Throwable{
       Wait.forSeconds(2);
       click.elementBy(EditBtn3);
       click.elementBy(HouseNo);
       type.data(HouseNo,"4");
       click.elementBy(Village);
       type.data(Village,"Test");
       click.elementBy(Province);
       click.elementBy(ProvinceAddress);
       click.elementBy(City);
       click.elementBy(CityAddress);
       click.elementBy(Done);
   }
   public void click_Edit4()throws Throwable{
       Wait.forSeconds(1);
       Swipe.swipe.swipeVertical(2,0.8,0.2,5);
       click.elementBy(EditBtn4);
       verify.elementIsPresent(UpdateInformation);
       Wait.forSeconds(1);
       click.elementBy(EmploymentStatus);
       click.elementBy(Employed);
       Wait.forSeconds(1);
       click.elementBy(Sourceoffunds);
       click.elementBy(Salary);
       Wait.forSeconds(1);
       click.elementBy(BusinessIndustry);
       click.elementBy(Electricity);
       Wait.forSeconds(1);
       click.elementBy(Natureofwork);
       click.elementBy(Agriculture);
       Wait.forSeconds(1);
       click.elementBy(Occupation);
       click.elementBy(AssistantOccupation);
       Wait.forSeconds(1);
       click.elementBy(TIN);
       type.data(TIN,"245787897");
       click.elementBy(Done);
   }
   public void click_chekboxes()throws ApplicationException{
       Wait.forSeconds(1);
       Swipe.swipe.swipeVertical(2,0.8,0.2,5);
       click.elementBy(CheckBox1);
       click.elementBy(CheckBox2);
       click.elementBy(Nextbtn);
   }
   public void verify_LoanDetailsPage()throws Throwable{
       Wait.forSeconds(2);
       verify.elementIsPresent(LoanPaymentHeader);
       verify.elementIsPresent(LoanSummaryHeaeder);
   }
   public void Click_EditLoanSummary()throws Throwable{
       Wait.forSeconds(2);
       click.elementBy(EDIT);
       click.elementBy(SelectAmount);
       click.elementBy(SelectPHPAmount2);
       click.elementBy(Done);
}

   public void clickContinue()throws Throwable{
       Wait.forSeconds(1);
       click.elementBy(Coninue);
   }

   public void click_LoansummaryCheckBox()throws Throwable{
       Wait.forSeconds(2);
       Swipe.swipe.swipeVertical(2,0.8,0.2,5);
       click.elementBy(LoanCheckBox2);
       click.elementBy(LoanCgeckBox1);
       click.elementBy(Submit);
   }
   public void clickCancel()throws Throwable{
       Wait.forSeconds(1);
       click.elementBy(Cancel);
   }
}
