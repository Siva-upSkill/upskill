package pages;

import actions.Wait;
import base.Keywords;

import static helper.PropertyReader.testDataOf;

public class VirtualCardPage extends Keywords {

    private String SelectCard = "onlineBanking.VirtualCards.SelectCard";
    private String SelectCardData = testDataOf("VirtualCards_Card");
    private String AccountDetailsPage = "onlineBanking.VirtualCards.AccountDetailsPage";
    private String CardSettingsOption = "onlineBanking.VirtualCards.CardSettingsOption";

    private String CardNumber = "onlineBanking.VirtualCards.CardNumber";
    private String ValidThru = "onlineBanking.VirtualCards.ValidThruDetails";
    private String CVVDetails = "onlineBanking.VirtualCards.CVVDetails";


    public void ClickCard() throws Throwable{
        Wait.waituntillElementVisibleMob(SelectCard,2);
        click.elementBy(SelectCard, SelectCardData);
    }
    public void VerifyAccountDetailPage() throws Throwable{
        Wait.waituntillElementVisibleMob(AccountDetailsPage,3);
        verify.elementIsPresent(AccountDetailsPage);
    }
    public void ClickCardSettings() throws Throwable{
        Wait.waituntillElementVisibleMob(CardSettingsOption,2);
        click.elementBy(CardSettingsOption);
    }
    public void VerifyCardNumber() throws Throwable{
        Wait.waituntillElementVisibleMob(CardNumber,2);
        verify.elementIsPresent(CardNumber);
    }
    public void VerifyValidThruDetails() throws Throwable{
        Wait.waituntillElementVisibleMob(ValidThru,2);
        verify.elementIsPresent(ValidThru);
    }
    public void VerifyCVVDetails() throws Throwable{
       Wait.waituntillElementVisibleMob(CVVDetails,2);
        verify.elementIsPresent(CVVDetails);

    }

}

