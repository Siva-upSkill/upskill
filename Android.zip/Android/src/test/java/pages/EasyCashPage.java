package pages;

import actions.Swipe;
import actions.Touch;
import actions.Wait;
import base.Keywords;
import helper.PropertyReader;
import io.appium.java_client.android.AndroidElement;
import org.apache.tools.ant.taskdefs.Delete;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class EasyCashPage extends Keywords {

	private String GetCashLink = "onlineBanking.EasyCash.GetCashLink";
	private String CashAdvanceCreditCard="onlineBanking.EasyCash.EasyCashCard";
	private String InstallmentBlueCard="onlineBanking.EasyCashInstallment.BlueCard";
	private String EasyCashOption="onlineBanking.EasyCashOption";
	private String EasycashHeader="onlineBanking.EasyCashInstallment.EasyCashHeader";
	private  String EasycashEdit="onlineBanking.EasyCashInstallment.EditOption";
	private String EnterInstallmentAmount="onlineBanking.EasyCashInstallment.EnterAmount";
	private String MinimumAmount="onlineBanking.EasyCashInstallment.MinimumAmount";
	private String SelectAccount="onlineBanking.EasyCashInstallment.SelectAcc";
	private String MaximumAmount="onlineBanking.EasyCashInstallment.MaximumAmount";
	private String EasyCashFrom="onlineBanking.EasyCashInstallment.EasyCashFrom";
	private String MonthlyStatement="onlineBanking.EasyCashInstallment.MonthlyStatement";
	private String RequestedAmount="onlineBanking.EasyCashInstallment.RequestedAmount";
	private String Term="onlineBanking.EasyCashInstallment.term";
	private String EasyCashStatementsHeader="onlineBanking.Easycash.StatementsHeader";
	private String EasyCashInstallmentHeader="onlineBanking.EasyCash.InstallmentsHeader";
	private String CardSettingsHeader="onlineBanking.EasyCash.CardSettingsHeader";
	private String RewardsHeader="onlineBanking.EasyCash.RewardsHeader";
	private String RecentTransactionHeader="onlineBanking.Easycash.RecentTransactionHeader";
	private String SelectAccountDeposit = "onlineBanking.EasyCash.SelectAccountDeposit";

	private String EditBtn="onlineBanking.Easycash.EditBtn";

	private String Reminder="onlineBanking.Easycash.Reminder";
	private String NextButton = "onlineBanking.EasyCash.NextButton";

	private String AmountEdit="onlineBanking.Easycash.AmountEdit";


	private String SkipButton = "onlineBanking.EasyCashInstallment.SkipButton";
	private String keySelectAcc = "onlineBanking.EasyCash.SelectAccLbl";
	private String EasyCashEditButton = "onlineBanking.EasyCash.EasyCashEditButton";
	private String EnterAmount = "onlineBanking.EasyCash.EnterAmount";
	private String Checkbox = "onlineBanking.EasyCash.Checkbox";

	private String Sucessmsg="onlineBanking.EasyCash.SuccessMsg";
	private String CheckboxTerms = "onlineBanking.EasyCash.CheckboxTerms";
	private String ValidationErrorMessage = "onlineBanking.EasyCash.ValidationErrorMessage";
	private String EasyCashStraightSummaryHeader = "onlineBanking.EasyCash.EasyCashStraightSummaryHeader";
	private String RequestforEasyCashButton = "onlineBanking.EasyCashInstallment.RequestforEasyCashButton";
	private String RequestforEasyCashStraightButton = "onlineBanking.EasyCash.RequestforEasyCashStraightButton";
	private String GotitButton = "onlineBanking.EasyCash.GotitButton";
	private String NextButton_Ins = "onlineBanking.EasyCashInstallment.NextButton";

	private String GetStarted_Ins = "onlineBanking.Installments.GetStarted";
	private String NextButton_Installments = "onlineBanking.Installments.NextButton";

	private String CashAdvance="onlineBanking.Easycash.CashAdavnce";

	private String OTP="onlineBanking.EasyCash.Otp";

	private String GetStartedButton= "onlineBanking.EasyCashInstallment.GetStartedButton";
	private String OTPHeader = "onlineBanking.EasyCash.OTPHeader";
	private String EasyCashInstallmentsHeader = "onlineBanking.EasyCashInstallment.EasyCashInstallmentsHeader";
	private String EasyCashInstallments = "onlineBanking.EasyCashInstallment.EasyCashInstallments";
	private String InstallmentDetails = "onlineBanking.EasyCashInstallment.InstallmentDetails";
	private String ReferenceNumber = "onlineBanking.EasyCashInstallment.ReferenceNumber";
	private String TransferStatus = "onlineBanking.EasyCashInstallment.TransferStatus";
//	private String RequestedAmount = "onlineBanking.EasyCashInstallment.RequestedAmount";
	private String MonthlyPayment = "onlineBanking.EasyCashInstallment.MonthlyPayment";
	private String ProcessingFee = "onlineBanking.EasyCashInstallment.ProcessingFee";
	private String ConvertedMonthlyFactorRate = "onlineBanking.EasyCashInstallment.ConvertedMonthlyFactorRate";
	private String EffectiveInterestRate = "onlineBanking.EasyCashInstallment.EffectiveInterestRate";
	private String Transfertomyaccount = "onlineBanking.EasyCashInstallment.Transfertomyaccount";
	private String Transfertootherbanks="onlineBanking.EasyCashInstallment.TransfertootherBanks";
	private String SelectBank="onlineBanking.EasyCashInstallment.SelectBank";
	private String AccountNumberTextBox="onlineBanking.EasyCashInstallment.AccountNumberTextBox";
	private String BDONetwork="onlineBanking.EasyCashInstallment.BDONetwork";
	private String Update="onlineBanking.EasyCashInstallment.Update";
	private String InstallmentHistoryHeader="onlineBanking.EasyCasInstallment.InstallmentHistory";
	private String Installments = "onlineBanking.Installments.Installments";
	private String TurnToInstallments = "onlineBanking.Installments.TurnToInstallments";
	private String Viewall = "onlineBanking.Installments.ViewAll";
	private String EasyCashIntallmentTransaction = "onlineBanking.Installments.EasyCashIntallmentTransaction";
	private String ViewPaymentPlan = "onlineBanking.Installments.ViewPaymentPlan";
	private String PaymentPlan = "onlineBanking.Installments.PaymentPlan";


//	public void clickOnEasyCashCard() throws Throwable {
//		Wait.forSeconds(5);
////		click.elementBy(EasyCashCard);
//		AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.widget.TextView[@text=\"*8074\"]");
//		element.click();
//	}
	public void clickOnCreditCard()throws Throwable{
		Wait.waituntillElementVisibleMob(InstallmentBlueCard,4);
		click.elementBy(InstallmentBlueCard);
	}
	public void clickOnCashAdvanceCard()throws Throwable{
		WAIT.forSecondsUsingFluentWAIT(5,CashAdvanceCreditCard);
		click.elementBy(CashAdvanceCreditCard);
	}

	public void verifyHeaders()throws Throwable{
		Wait.forSeconds(2);
//		swipe.swipeVertical(2, 0.3, 0.8, 5);
		verify.elementIsPresent(EasyCashStatementsHeader);
		verify.elementIsPresent(EasyCashInstallmentHeader);
		verify.elementIsPresent(CardSettingsHeader);
//		WAIT.forSecondsUsingFluentWAIT(2,RewardsHeader);
//		verify.elementIsPresent(RewardsHeader);
//		Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
//		verify.elementIsPresent(RecentTransactionHeader);
	}

	//	public void clickOnEasyCashInstallmentCard() throws Throwable {
//		Wait.forSeconds(4);
//		AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.widget.TextView[@text=\"*8074\"]");
//		element.click();
//	}
    public void clickonEasyCashOption()throws Throwable{
		WAIT.forSecondsUsingFluentWAIT(3,EasyCashOption);
		click.elementBy(EasyCashOption);
	}
	public void clickOnGetCashOption() throws Throwable {
		Wait.forSeconds(2);
		swipe.swipeHorizontal(2,0.85,0.35,1);
		click.elementBy(GetCashLink);
	}
	public void clickEditOption()throws Throwable{
		Wait.forSeconds(2);
		click.elementBy(EasycashEdit);
		get.elementBy(EnterInstallmentAmount).clear();
		type.data(EnterInstallmentAmount,"1000");
	}
   public void verifyInlineErrorMsg()throws Throwable{
		Wait.forSeconds(2);
		verify.elementIsPresent(MinimumAmount);
   }
    public void MaximumAmount()throws Throwable{
		Wait.forSeconds(2);
		click.elementBy(EasycashEdit);
		click.elementBy(EnterInstallmentAmount);
		type.data(EnterInstallmentAmount,"50,555555");
	}
	public void verifyMaximumInlineErrormsg()throws Throwable{
		Wait.forSeconds(1);
		verify.elementIsPresent(MaximumAmount);
	}
	public void verifyHeadersonSummaryPage()throws Throwable{
		Wait.forSeconds(6);
		verify.elementIsPresent(EasyCashFrom);
		verify.elementIsPresent(RequestedAmount);
		verify.elementIsPresent(ProcessingFee);
		verify.elementIsPresent(MonthlyStatement);
	}

	public void clickCashAdvanceOption()throws Throwable{
		Wait.waituntillElementVisibleMob(CashAdvance,4);
		click.elementBy(CashAdvance);
	}

//	public void clickEditAndEnterAmount()throws Throwable{
//		Wait.waituntillElementVisibleMob(EditBtn,3);
//		click.elementBy(EditBtn);
//		Wait.forSeconds(2);
//		get.elementBy(AmountEdit).clear();
//		//		click.elementBy(AmountEdit);
//		type.data(AmountEdit,PropertyReader.testDataOf("EasyCash_Amount"));
//	}

	public void click_Slider() throws Throwable {
		Wait.forSeconds(2);
		WebElement slider = driver.findElement(By.id("com.unionbankph.online.qat:id/range_slider"));
		Actions move = new Actions(driver);
		move.moveToElement(slider).clickAndHold().moveByOffset(0, 100).release().perform();
		move.moveToElement(slider).clickAndHold().moveByOffset(-500, 0).release().perform();
	}

	public void clickCashAdvanceEdit()throws Throwable{
		Wait.waituntillElementVisibleMob(EditBtn,3);
		click.elementBy(EditBtn);

	}
	public void clickUpdate()throws Throwable{
		Wait.forSeconds(1);
		click.elementBy(Update);
	}
    public void clickNewAmount()throws Throwable {
		Wait.waituntillElementVisibleMob(AmountEdit,4);
		click.elementBy(AmountEdit);
		type.data(AmountEdit, PropertyReader.testDataOf("EasyCash_NewAmount"));
	}

	public void clickNewAccount()throws Throwable{
		Wait.waituntillElementVisibleMob(AmountEdit,4);
		click.elementBy(keySelectAcc);
		click.elementBy(SelectAccountDeposit,PropertyReader.testDataOf("EasyCashNewAccount"));

	}
	public void clickSelectAccount()throws Throwable{
		Wait.waituntillElementVisibleMob(keySelectAcc,2);
		click.elementBy(keySelectAcc);
	}

	public void clickOwnUnionBank()throws Throwable{
		Wait.forSeconds(2);
		Touch.pressByCoordinates(455,1822,2);
		click.elementBy(NextButton);
	}
	public void clickOtherBanksewallet()throws Throwable{
		Wait.forSeconds(2);
		Touch.pressByCoordinates(385,2090,2);
	}
	public void verifyTransferToOtherbank()throws Throwable{
		Wait.forSeconds(1);
		verify.elementIsPresent(Transfertootherbanks);
	}
	public void clickBankName()throws Throwable{
		Wait.forSeconds(2);
		click.elementBy(SelectBank);
		click.elementBy(BDONetwork);
		click.elementBy(AccountNumberTextBox);
		type.data(AccountNumberTextBox,"1095 6285 3340");
		Wait.forSeconds(1);
		click.elementBy(NextButton);
	}
	public void clickOnSelectaccountoptions() throws Throwable {
		WAIT.forSecondsUsingFluentWAIT(2,SelectAccountDeposit);
		click.elementBy(SelectAccountDeposit,PropertyReader.testDataOf("EasyCashAccount"));
	}

	public void EnterOTP() throws Throwable{
		Wait.waituntillElementVisibleMob(OTP,4);
		type.data(OTP,PropertyReader.testDataOf("EasyCash_OTP"));
	}
	public void verifySucessmsg()throws Throwable{
		Wait.waituntillElementVisibleMob(Sucessmsg,3);
		verify.elementIsPresent(Sucessmsg);
	}
	public void verifyEasycashSummaryPage() throws Throwable {
		Wait.waituntillElementVisibleMob(EasyCashStraightSummaryHeader,4);
		verify.elementIsPresent(EasyCashStraightSummaryHeader);
	}
	public void clickOnCheckbox() throws Throwable {
		Wait.forSeconds(2);
		swipe.swipeVertical(2, 0.6, .2, 2);
		click.elementBy(Checkbox);
		click.elementBy(CheckboxTerms);
	}
	public void clickOnRequestforEasyCashStraightButton() throws Throwable {
		Wait.waituntillElementVisibleMob(RequestforEasyCashStraightButton,3);
		click.elementBy(RequestforEasyCashStraightButton);
	}
	public void clickOnRequestforEasycash() throws Throwable {
		Wait.waituntillElementVisibleMob(RequestforEasyCashButton,4);
		click.elementBy(RequestforEasyCashButton);
	}
	public void clickNextButton() throws Throwable {
		Wait.waituntillElementVisibleMob(NextButton,3);
		click.elementBy(NextButton);
	}
	public void verifyNextButton() throws Throwable {
		verify.elementIsDisabled(NextButton);
	}
	public void verifyReminderPage() throws Throwable {
		Wait.waituntillElementVisibleMob(Reminder,4);
		verify.elementIsPresent(Reminder);
	}
	public void clickOnGotittButton() throws Throwable {
		Wait.waituntillElementVisibleMob(GotitButton,3);
		click.elementBy(GotitButton);
	}
	public void clickOnNextButton() throws Throwable {
		Wait.forSeconds(2);
		click.elementBy(NextButton);
	}
	public void clickOnSkipOrNextButton() throws Throwable {
//		click.elementBy(SkipButton);
		Wait.waituntillElementVisibleMob(NextButton,2);
		click.elementBy(NextButton);
		Wait.forSeconds(2);
		click.elementBy(NextButton);
	    Wait.forSeconds(2);
		click.elementBy(GetStartedButton);
	}
	public void clickonNextButton_Installments() throws Throwable {
		Wait.waituntillElementVisibleMob(GetStarted_Ins,3);
		click.elementBy(GetStarted_Ins);
		Wait.waituntillElementVisibleMob(NextButton_Installments,1);
		click.elementBy(NextButton_Installments);
		click.elementBy(NextButton_Installments);
		click.elementBy(NextButton_Installments);
		click.elementBy(NextButton_Installments);
	}
	public void verifyOtpScreen() throws Throwable {
		Wait.waituntillElementVisibleMob(OTPHeader,3);
		verify.elementIsPresent(OTPHeader);
	}
	public void EnterMinimumAmount_EasyCash() throws Throwable {
		Wait.waituntillElementVisibleMob(EasyCashEditButton,3);
		click.elementBy(EasyCashEditButton);
		type.data(EnterAmount,PropertyReader.testDataOf("Easycash_MinimumAmount").trim());
	}
	public void EnterMaxmumAmount_EasyCash() throws Throwable {
		Wait.waituntillElementVisibleMob(EasyCashEditButton,3);
        click.elementBy(EasyCashEditButton);
		type.data(EnterAmount,PropertyReader.testDataOf("Easycash_MaxmumAmount").trim());
	}
	public void ValidationMinimumErrorMessage() throws Throwable {
		Wait.waituntillElementVisibleMob(ValidationErrorMessage,3);
		verify.elementTextMatching(ValidationErrorMessage, PropertyReader.testDataOf("Easycash_MinimumValidationMessage").trim());
	}
	public void ValidationMaxmumErrorMessage() throws Throwable {
		Wait.waituntillElementVisibleMob(ValidationErrorMessage,3);
		verify.elementTextMatching(ValidationErrorMessage, PropertyReader.testDataOf("Easycash_MaxmumValidationMessage").trim());
	}
	public void ValidationMinimumErrorMessage_Installment() throws Throwable {
		Wait.waituntillElementVisibleMob(ValidationErrorMessage,3);
		verify.elementTextMatching(ValidationErrorMessage, PropertyReader.testDataOf("EasycashInstallment_MinimumValidationMessage").trim());
	}
	public void ValidationMaxmumErrorMessage_Installment() throws Throwable {
		Wait.waituntillElementVisibleMob(ValidationErrorMessage,3);
		verify.elementTextMatching(ValidationErrorMessage, PropertyReader.testDataOf("EasycashInstallment_MaxmumValidationMessage").trim());
	}
	public void verifyEasyCashInstallmentHeader() throws Throwable {
		Wait.waituntillElementVisibleMob(EasyCashInstallmentsHeader,3);
		verify.elementIsPresent(EasyCashInstallmentsHeader);
	}
	public void verifyEasycashInstallmentsSummaryPage() throws Throwable {
		Wait.waituntillElementVisibleMob(RequestedAmount,2);
		verify.elementIsPresent(RequestedAmount);
		verify.elementIsPresent(MonthlyPayment);
		verify.elementIsPresent(Term);
		verify.elementIsPresent(ProcessingFee);
		verify.elementIsPresent(ConvertedMonthlyFactorRate);
		verify.elementIsPresent(EffectiveInterestRate);
//		verify.elementIsPresent(Transfertomyaccount);
		//verify.elementIsPresent(MaximumAmountEligibleforInstallment);
	}
//	public void clickOnEasyCashInstallments() throws Throwable {
//		Wait.forSeconds(2);
//		click.elementBy(EasyCashInstallments);
//	}
	public void EnterAmount_EasyCashInstallment() throws Throwable {
		Wait.waituntillElementVisibleMob(EasyCashEditButton,2);
		click.elementBy(EasyCashEditButton);
		type.data(EnterAmount,PropertyReader.testDataOf("EasycashInstallment_Amount").trim());
	}
	public void EnterAmount_EasyTransfer() throws Throwable {
		Wait.waituntillElementVisibleMob(EasyCashEditButton,3);
		click.elementBy(EasyCashEditButton);
		type.data(EnterAmount,PropertyReader.testDataOf("BTOAmount").trim());
	}
	public void clickOnInstallments() throws Throwable {
		Wait.waituntillElementVisibleMob(Installments,3);
		click.elementBy(Installments);
	}
	public void verifyEasyCashTurntoInstallments() throws Throwable {
		Wait.waituntillElementVisibleMob(TurnToInstallments,3);
		verify.elementIsPresent(TurnToInstallments);
	}
	public void clickOnViewAll() throws Throwable {
		Wait.waituntillElementVisibleMob(Viewall,3);
		click.elementBy(Viewall);
	}
	public void clickOnEasyCashIntallmentTransaction() throws Throwable {
		Wait.waituntillElementVisibleMob(EasyCashIntallmentTransaction,3);
		click.elementBy(EasyCashIntallmentTransaction);
	}
	public void verifyInstallmentsDetailsPage() throws Throwable {
		Wait.waituntillElementVisibleMob(InstallmentDetails,3);
		verify.elementIsPresent(InstallmentDetails);
		verify.elementIsPresent(ReferenceNumber);
		verify.elementIsPresent(TransferStatus);
		verify.elementIsPresent(RequestedAmount);
		verify.elementIsPresent(MonthlyPayment);
		verify.elementIsPresent(Term);
		verify.elementIsPresent(ProcessingFee);
		verify.elementIsPresent(ConvertedMonthlyFactorRate);
		verify.elementIsPresent(EffectiveInterestRate);
		verify.elementIsPresent(Transfertomyaccount);
//		verify.elementIsPresent(MaximumAmountEligibleforInstallment);
	}
	public void clickOnViewPaymentPlan() throws Throwable {
		Wait.waituntillElementVisibleMob(ViewPaymentPlan,3);
		click.elementBy(ViewPaymentPlan);
	}
	public void verifyPaymentPlan() throws Throwable {
		Wait.waituntillElementVisibleMob(PaymentPlan,3);
		verify.elementIsPresent(PaymentPlan);
	}
	public void verifyInstallmentHistory()throws Throwable{
		Wait.forSeconds(2);
		click.elementBy(InstallmentHistoryHeader);
	}
}
