package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import runners.ConvergentTestRunner;


public class LazadaCreditCardPages extends Keywords {

    private HomePage home = new HomePage();
    private UITFPage uitfPage = new UITFPage();
    private SendRequestPage sendrequest = new SendRequestPage();


    ConvergentTestRunner Devicename=new ConvergentTestRunner();

    private String CreditCard = "onlineBanking.RewardsTesting.CreditCard";
    private String ViewStatement = "onlineBanking.RewardsTesting.ViewStatement";
    private String DownloadStatement = "onlineBanking.RewardsTesting.DownloadStatement";
    private String InstallmentHistory = "onlineBanking.RewardsTesting.InstallmentHistory";
    private String GetCash = "onlineBanking.RewardsTesting.GetCash";
    private String ManageCards = "onlineBanking.RewardsTesting.ManageCards";
    private String AccountDetails = "onlineBanking.RewardsTesting.AccountDetails";
    private String LAZADAWALLETCREDIT = "onlineBanking.RewardsTesting.LAZADAWALLETCREDITS";
    private String RECENTTRANSACTIONS = "onlineBanking.RewardsTesting.RECENTTRANSACTIONS";
    private String CardImage = "onlineBanking.RewardsTesting.CardImage";

    private String AboutDescription = "onlineBanking.RewardsTesting.AboutDescription";
    private String LockUnlock = "onlineBanking.RewardsTesting.LockUnlock";
    private String ReportCard = "onlineBanking.RewardsTesting.ReportCard";
    private String TransferCredit = "onlineBanking.RewardsTesting.AccountDetails.TransferCredit";
    private String NextButton_ProceedPage = "onlineBanking.RewardsTesting.NextButton";
    private String Pin = "onlineBanking.RewardsTesting.Pin";
    private String OTP = "onlineBanking.RewardsTesting.OTP";

    private String VerifyDetailsTitle = "onlineBanking.RewardsTesting.VerifyDetailsTitle";
    private String CorrectBtn = "onlineBanking.RewardsTesting.CorrectBtn";

    private String PHPAmountAddBtn = "onlineBanking.RewardsTesting.PHPAmountAddBtn";
    private String PHPAmountSubBtn = "onlineBanking.RewardsTesting.PHPAmountSubBtn";
    private String PHPAmountInput = "onlineBanking.RewardsTesting.PHPInput";

    private String AmountGreaterMessage = "onlineBanking.RewardsTesting.AmountGreaterMessage";
    private String MinimumAmountMessage = "onlineBanking.RewardsTesting.MinimumAmountMessage";
    private String Incrementof100Message = "onlineBanking.RewardsTesting.Incrementof100Message";
    private String NextButton_TransferCreditPage = "onlineBanking.RewardsTesting.TrasferCreditPage.NextButton";
    private String RequestTransferBtn = "onlineBanking.RewardsTesting.RequestTransferBtn";

    private String SuccessMessage = "onlineBanking.RewardsTesting.TransferRequestSubmitted.SuccessMessage";
    private String SuccessText = "onlineBanking.RewardsTesting.SuccessText";
    private String BackToDashboardButton = "onlineBanking.RewardsTesting.BackToDashboardButton";

    private String Dashboard = "convergent.home.tabDashboardbtn";
    private String BackButton = "onlineBanking.RewardsTesting.BackButton";


    public void selectCard() throws ApplicationException {
        swipe.swipeVertical(2, 0.6, .2, 2);
        click.elementBy(CreditCard);
        
    }

    public void verify_AccountDetails() throws ApplicationException {
       verify.IfElementExists(ViewStatement);
       //verify.IfElementExists(DownloadStatement);
        verify.IfElementExists(InstallmentHistory);
        //verify.IfElementExists(GetCash);
        verify.IfElementExists(ManageCards);
        //verify.IfElementExists(AccountDetails);


        //verify.IfElementExists(CardImage);
        //verify.IfElementExists(AboutDescription);
        //verify.IfElementExists(LockUnlock);
        //verify.IfElementExists(ReportCard);

    }

    public void click_TransferCredit() throws ApplicationException{
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        click.elementBy(TransferCredit);
    }

    public void click_Nextbutton_TrasferCreditsPage() throws ApplicationException {
        Wait.waituntillElementVisibleMob(NextButton_TransferCreditPage,5);
        click.elementBy(NextButton_TransferCreditPage);
    }

    public void click_Next_proceedPage() throws ApplicationException {
        Wait.waituntillElementVisibleMob(NextButton_ProceedPage,4);
        click.elementBy(NextButton_ProceedPage);
    }
    public void verify_mobileNumber(String mobileno) throws ApplicationException{
       Wait.waituntillElementVisibleMob(Pin,3);
        type.data(Pin,mobileno);
    }

    public void enter_OTP() throws ApplicationException {
        Wait.forSeconds(5);
        type.data1(OTP,"111111");
        Wait.forSeconds(5);
    }

    public void verifyPage(String pagename) throws ApplicationException {
        Wait.forSeconds(5);
        verify.elementTextMatching(VerifyDetailsTitle,pagename);
    }


    public void enterAmount(String amount) throws ApplicationException {
        Wait.waituntillElementVisibleMob(PHPAmountInput,4);
        type.data1(PHPAmountInput,amount);
    }
    public void verify_AmountGreater_ErrMessgae(String message) throws ApplicationException {
        Wait.waituntillElementVisibleMob(AmountGreaterMessage,4);
        verify.elementTextMatching(AmountGreaterMessage,message);
    }

    public void verify_MimAmount(String message) throws ApplicationException {
        Wait.waituntillElementVisibleMob(MinimumAmountMessage,5);
        verify.elementTextMatching(MinimumAmountMessage,message);
    }

    public void verify_Increment_Message(String message) throws ApplicationException {
        Wait.waituntillElementVisibleMob(Incrementof100Message,3);
        verify.elementTextMatching(Incrementof100Message,message);
    }

    public void verify_SuccessMessage() throws ApplicationException {
        Wait.waituntillElementVisibleMob(SuccessMessage,3);
        verify.IfElementExists(SuccessMessage);
    }

    public void verify_SuccessText()throws ApplicationException {
        Wait.waituntillElementVisibleMob(SuccessText,3);
        verify.IfElementExists(SuccessText);
    }

    public void verify_DashboardPage() throws ApplicationException{
        Wait.waituntillElementVisibleMob(Dashboard,2);
        verify.IfElementExists(Dashboard);

    }

    public void click_BackToDashboard() throws ApplicationException {
        Wait.waituntillElementVisibleMob(BackToDashboardButton,4);
        click.elementBy(BackToDashboardButton);
    }

    public void verifyPage_VerifyDetails(String pagename) throws ApplicationException {
        Wait.waituntillElementVisibleMob(VerifyDetailsTitle,3);
        verify.elementTextMatching(VerifyDetailsTitle,pagename);
    }

    public void verifyPage_TransferLazadaCredits(String pagename) throws ApplicationException {
       // verify.elementTextMatching(,pagename);
    }

    public void verifyPage_ReviewAndRequest(String pagename) throws ApplicationException {

    }

    public void click_YESButton() throws ApplicationException{
        Wait.waituntillElementVisibleMob(CorrectBtn,3);
        click.elementBy(CorrectBtn);
    }

    public void click_RequestTransfer_button() throws ApplicationException {
        Wait.waituntillElementVisibleMob(RequestTransferBtn,4);
        click.elementBy(RequestTransferBtn);
    }

    public void click_BackButton() throws ApplicationException {
        Wait.waituntillElementVisibleMob(BackButton,3);
        click.elementBy(BackButton);
    }
}