package pages;

import actions.Wait;
import base.Keywords;
import helper.PropertyReader;


public class InstallmentHistoryPage extends Keywords {

    private String CreditCard1 = "onlineBanking.InstallmentHistory.CreditCard1";
    private String CreditCard2 = "onlineBanking.InstallmentHistory.CreditCard2";
    private String CreditCard3= "onlineBanking.InstallmentHistory.CreditCard3";
    private String InstallmentHistory = "onlineBanking.InstallmentHistory.InstallmentHistory";
    private String NoInstallmentErrMsg = "onlineBanking.InstallmentHistory.NoInstallmentErrMsg";
    private String FirstInstallment = "onlineBanking.InstallmentHistory.FirstInstallment";
    private String ReferenceNumber = "onlineBanking.InstallmentHistory.ReferenceNumber";
    private String PurchasedOn = "onlineBanking.InstallmentHistory.PurchasedOn";
    private String ProgressBar = "onlineBanking.InstallmentHistory.ProgressBar";
    private String Installments = "onlineBanking.InstallmentHistory.Installments";
    private String InstallmentDetails = "onlineBanking.InstallmentHistory.InstallmentDetails";
    private String Term = "onlineBanking.InstallmentHistory.Term";
    private String ApplicationStatus = "onlineBanking.InstallmentHistory.ApplicationStatus";
    private String RemainingBalance = "onlineBanking.InstallmentHistory.RemainingBalance";
    private String PurchaseAmount = "onlineBanking.InstallmentHistory.PurchaseAmount";
    private String EndDate = "onlineBanking.InstallmentHistory.EndDate";
    private String InstallmentsTitle="onlineBanking.InstallmentHistory.InstallmentsTitle";
    private String InstallmentHistoryTitle = "onlineBanking.InstallmentHistory.InstallmentHistoryTitle";
    private String InstallmentDetailsTitle  = "onlineBanking.InstallmentHistory.InstallmentDetailsTitle";
    private String PurchaseAmountPHP = "onlineBanking.InstallmentHistory.PurchaseAmountPHP";
    private String MerchantName = "onlineBanking.InstallmentHistory.MerchantName";
    private String Reminder  = "onlineBanking.InstallmentHistory.Reminder";
    private String DueDate = "onlineBanking.InstallmentHistory.DueDate";
    private String InstallmentAmt = "onlineBanking.InstallmentHistory.InstallmentAmt";
    private String checkMarkIndicator = "onlineBanking.InstallmentHistory.checkMarkIndicator";
    private String Statements = "onlineBanking.InstallmentHistory.Statements";
    private String ViewStatement = "onlineBanking.InstallmentHistory.ViewStatement";
    private String DownloadStatement = "onlineBanking.InstallmentHistory.DownloadStatement";
    private String DownloadStatementView = "onlineBanking.InstallmentHistory.DownloadStatementView";
    private String ManageCard = "onlineBanking.CC.ManageCard";
    private String ClickMonth = "onlineBanking.InstallmentHistory.ClickMonth";
    private String SelectMonth = "onlineBanking.InstallmentHistory.SelectMonth";
    private String StatementBalance = "onlineBanking.InstallmentHistory.StatementBalance";
    private String MinimumAmountDue = "onlineBanking.InstallmentHistory.MinimumAmountDue";
    private String StatementDate = "onlineBanking.InstallmentHistory.StatementDate";
    private String PreviousBalance = "onlineBanking.InstallmentHistory.PreviousBalance";
    private String PurchasesAdvances = "onlineBanking.InstallmentHistory.PurchasesAdvances";
    private String PaymentsCredits = "onlineBanking.InstallmentHistory.PaymentsCredits";
    private String TotalAmountDue = "onlineBanking.InstallmentHistory.TotalAmountDue";
    private String DownloadPDF = "onlineBanking.InstallmentHistory.DownloadPDF";
    private String DownloadExcel = "onlineBanking.InstallmentHistory.DownloadExcel";
    private String DownloadHeader = "onlineBanking.InstallmentHistory.DownloadHeader";
    private String DownloadSuccessMessage = "onlineBanking.InstallmentHistory.DownloadSuccessMessage";


    private Wait wait;

    public void select_CreditCard2() throws Throwable {
        Wait.waituntillElementVisibleMob(CreditCard2,4);
        click.elementBy(CreditCard2);
    }

    public void select_CreditCard1() throws Throwable {
        Wait.waituntillElementVisibleMob(CreditCard1,3);
        click.elementBy(CreditCard1);
    }

    public void verify_Icons() throws Throwable {
        Wait.waituntillElementVisibleMob(InstallmentHistoryTitle,4);
        verify.elementIsPresent(InstallmentHistoryTitle);
        verify.elementIsPresent(Statements);
        verify.elementIsPresent(ManageCard);
    }

    public void click_InstallmentHistoryIcon() throws Throwable {
        Wait.waituntillElementVisibleMob(InstallmentHistoryTitle,3);
        click.elementBy(InstallmentHistoryTitle);
    }

    public void verify_installemntHistoryScreen() throws Throwable {
       Wait.waituntillElementVisibleMob(InstallmentHistoryTitle,4);
        verify.elementIsPresent(InstallmentHistoryTitle);
    }

    public void select_Transaction() throws Throwable {
        Wait.waituntillElementVisibleMob(FirstInstallment,3);
        click.elementBy(FirstInstallment);
    }

    public void verify_installmentDetailsScreen() throws Throwable {
        Wait.waituntillElementVisibleMob(InstallmentDetailsTitle,3);
        verify.elementIsPresent(InstallmentDetailsTitle);
    }

    public void verify_InstallmentDetails() throws Throwable {
       Wait.waituntillElementVisibleMob(ReferenceNumber,4);
        verify.elementIsPresent(ReferenceNumber);
        verify.elementIsPresent(PurchasedOn);
        verify.elementIsPresent(ApplicationStatus);
//        verify.elementIsPresent(MerchantName);
//        verify.elementIsPresent(ProgressBar);
        verify.elementIsPresent(InstallmentDetails);
        verify.elementIsPresent(Term);
        verify.elementIsPresent(RemainingBalance);
        //verify.elementIsPresent(PurchaseAmount);
        verify.elementIsPresent(EndDate);
    }

    public void verify_NoInstallemntErrMsg() throws Throwable {
        Wait.waituntillElementVisibleMob(NoInstallmentErrMsg,3);
        verify.elementTextMatching(NoInstallmentErrMsg, PropertyReader.testDataOf("Installment_NoInstallmentMessage").trim());
    }

    public void verify_ReminderandBreakDownPayment() throws Throwable {
        Wait.waituntillElementVisibleMob(PurchaseAmountPHP,3);
        verify.elementIsPresent(PurchaseAmountPHP);
        verify.elementIsPresent(Reminder);
        verify.elementIsPresent(DueDate);
        verify.elementIsPresent(InstallmentAmt);
        verify.elementIsPresent(checkMarkIndicator);
    }
    public void clickViewStatement() throws Throwable {
        Wait.waituntillElementVisibleMob(Statements,3);
        click.elementBy(Statements);
    }
    public void verify_ViewStatementDetails() throws Throwable {
        Wait.waituntillElementVisibleMob(StatementBalance,3);
        verify.elementIsPresent(StatementBalance);
        verify.elementIsPresent(MinimumAmountDue);
        verify.elementIsPresent(DueDate);
        verify.elementIsPresent(StatementDate);
        verify.elementIsPresent(PreviousBalance);
        verify.elementIsPresent(PurchasesAdvances);
        verify.elementIsPresent(PaymentsCredits);
        verify.elementIsPresent(TotalAmountDue);
    }
    public void clickMonthYear() throws Throwable {
        Wait.waituntillElementVisibleMob(ClickMonth,4);
        click.elementBy(ClickMonth);
        //jsClick.elementBy(ClickMonth);
    }
    public void selectMonthYear() throws Throwable {
        Wait.waituntillElementVisibleMob(SelectMonth,3);
        swipe.swipeVertical(2, 0.6, .2, 2);
        click.elementBy(SelectMonth);
    }
    public void clickDownloadStatement() throws Throwable {
        Wait.waituntillElementVisibleMob(DownloadStatement,3);
        click.elementBy(DownloadStatement);
    }
    public void clickDownloadStatementView() throws Throwable {
        Wait.waituntillElementVisibleMob(DownloadStatement,3);
        click.elementBy(DownloadStatement);
    }
    public void verifyDownloadStatementPage() throws Throwable {
        Wait.forSeconds(2);
        verify.elementIsPresent(DownloadExcel);
        verify.elementIsPresent(DownloadPDF);
    }
    public void clickDownloadPDF() throws Throwable {
        Wait.waituntillElementVisibleMob(DownloadPDF,3);
        click.elementBy(DownloadPDF);
    }
    public void verifyDownloadStatus() throws Throwable {
        Wait.waituntillElementVisibleMob(DownloadHeader,3);
        verify.IfElementExists(DownloadHeader);
    }
    public void verifyDownloadSuccessMessage() throws Throwable {
        Wait.waituntillElementVisibleMob(DownloadSuccessMessage,3);
        //verify.IfElementExists(DownloadSuccessMessage);
        verify.elementIsPresent(DownloadSuccessMessage);
    }

}
