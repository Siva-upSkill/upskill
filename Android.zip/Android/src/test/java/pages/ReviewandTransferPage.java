package pages;

import actions.*;
import base.Keywords;
import driver.DriverManager;
import exceptions.ApplicationException;
import helper.PropertyReader;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.By;


public class ReviewandTransferPage extends Keywords {

    private String Keyreviewtransfertitle = "convergent.ReviewandTransfer.title";
    private String Keyreviewtransfertitle2 = "convergent.ReviewandTransfer.titleReviewandtransfer";
    private String Keyreviewtransferlabel = "convergent.ReviewandTransfer.labels";
    private String Keyreviewtransferaccname = "convergent.ReviewandTransfer.accname";
    private String Keyreviewtransferaccnumber = "convergent.ReviewandTransfer.accno";
    private String Keyreviewtransferamount = "convergent.ReviewandTransfer.amount";
    private String Keyreviewtransferotherfields = "convergent.ReviewandTransfer.commonfieldlabels";
    private String Keyreviewtransfertransferbtn = "convergent.ReviewandTransfer.transferbtn";
    private String Keyreviewtransfereditlink = "convergent.ReviewandTransfer.editlink";
    private String Keyreviewtransferclosebtn = "convergent.ReviewandTransfer.closebtn";
    private String Keyreviewtransferfromclosebtn="convergent.TransferFrompage.Ownaccountbackbtn";
    private String Keyreviewtransferpopuptitle = "convergent.ReviewandTransfer.popuptitle";
    private String Keyreviewtransferpopupnobtn = "convergent.ReviewandTransfer.popupNObtn";
    private String Keyreviewtransferpopuptransferbtn = "convergent.ReviewandTransfer.popupCANCELbtn";
    private String Keyreviewgotitbtn = "convergent.review.gotit";
    private String Keykeepmeloggedinbtn="convergent.login.keepmeloggedinbtn";
    private String Keyreviewtransfereditfromaccountlink="convergent.ReviewandTransfer.editfromaccount";
    private String Keyreviewtransferedittoaccountlink="convergent.ReviewandTransfer.edittoaccount";
    private String Keyreviewtransfereditamountlink="convergent.ReviewandTransfer.editamount";
    private String Keyreviewhangonlabel = "convergent.review.labelhangon";
    private String Keyreviewtransferpoupwindowtitle="convergent.pddtspddtspage.lblpopuptitlename";
    private String Keyreviewtransferpoupwindowdescr="convergent.pddtspddtspage.lblpopupdescr";
    private String Keyreviewandtransferfromaccount="convergent.pddtsreviewandtransferpage.lblfromaccount";
    private String Keyreviewandtransfertoaccount="convergent.pddtsreviewandtransferpage.lbltoaccount";
    private String Keyreviewandtransferamount="convergent.pddtsreviewandtransferpage.lblamount";
    private String Keyreviewandtransferservicefee="convergent.pddtsreviewandtransferpage.lblfee";
    private String Keyreviewandtransferremittancechk="convergent.Remittanccenterreceipientreview.chktermsandcondition";
    private String Keyreviewandtransferremittancesubmit="convergent.Remittanccenterreceipientreview.btntransfer";
    private String Keyreviewandtransferremittancecancel="convergent.Remittanccentertransferreview.btncancel";
    private String Keyreviewandtransferremittanceamount="convergent.Remittanccentertransferreview.lblAmount";
    private String Keyreviewandtransferremittancefee="convergent.Remittanccentertransferreview.lblFee";
    private String Keyreviewandtransferremittancepurpose="convergent.Remittanccentertransferreview.lblpurpose";
    private String Keyreviewandtransferremittancename="convergent.Remittanccentertransferreview.lblName";
    private String Keyreviewandtransferremittancebirthdate="convergent.Remittanccentertransferreview.lblBirthdate";
    private String Keyreviewandtransferremittancenationality="convergent.Remittanccentertransferreview.lblNationality";
    private String Keyreviewandtransferremittancemobileno="convergent.Remittanccentertransferreview.lblMobileno";
    private String Keyreviewandtransferremittanceaddress="convergent.Remittanccentertransferreview.lblAddress";
    private String Keyreviewandtransferremittanceedit1="convergent.Remittanccentertransferreview.lblEdit1";
    private String Keyreviewandtransferremittanceedit2="convergent.Remittanccentertransferreview.lblEdit2";
    private String Keyreviewandtransferremittanceedit3="convergent.Remittanccentertransferreview.lblEdit3";
    private String Keyreviewandtransferremittancebtndone="convergent.Remittanccentertransferreview.btnDone";


    public void verifyReviewandTransfertitle(String ititle) throws ApplicationException {
        //verify.elementTextMatching(Keyreviewtransfertitle, ititle);
        verify.elementIsPresent(Keyreviewtransfertitle);
    }

    public void clickReviewAndTransfer() throws Throwable
    {
        click.elementBy(Keyreviewtransfertitle);
    }

    public void verifyReviewandTransfertitle2(String ititle) throws ApplicationException {
        //verify.elementTextMatching(Keyreviewtransfertitle, ititle);
        verify.elementIsPresent(Keyreviewtransfertitle);
    }

    public void verifyReviewandTransfertitle1() throws ApplicationException {
        verify.elementIsPresent(Keyreviewtransfertitle);
    }

    public void verifyReviewPagelabel(String iexpectval) throws ApplicationException {
       // verify.elementTextMatching(Keyreviewtransferlabel, iexpectval);
        verify.elementIsPresent(Keyreviewtransferlabel);
    }
	/*
	public void verifyReviewPagedetails(String saccname,String raccname,String saccno,String raccno,String amt,String idate,String ifreq,String iend,String imessage) throws ApplicationException, InterruptedException
	{
		verify.elementTextMatchingText(Keyreviewtransferaccname,1,testdata.propertyValue("Source_Name"));
		click.elementBy(Keyreviewtransferaccnumber, 1);
		verify.elementTextMatchingText(Keyreviewtransferaccname,2,testdata.propertyValue("Recipient_Name"));
		verify.elementTextMatchingText(Keyreviewtransferaccnumber,2,testdata.propertyValue("Recipient_Account"));
		verify.elementTextMatchingText(Keyreviewtransferaccnumber,1,testdata.propertyValue("Source_Account"));
				
		verify.elementTextMatchingText(Keyreviewtransferamount,1,amt);
		verify.elementTextMatchingText(Keyreviewtransferotherfields,1,idate);
		verify.elementTextMatchingText(Keyreviewtransferotherfields,2,ifreq);
		verify.elementTextMatchingText(Keyreviewtransferotherfields,3,iend);
		verify.elementTextMatchingText(Keyreviewtransferotherfields,4,imessage);
		
	}*/

    public void verifyReviewPagedetails(String saccname, String raccname, String saccno, String raccno, String amt, String idate, String ifreq, String iend, String imessage) throws ApplicationException, InterruptedException {
        click.elementBy(Keyreviewtransferaccnumber, 1);
        verify.elementTextMatching(Keyreviewtransferaccname, 1, saccname);
        verify.elementTextMatching(Keyreviewtransferaccnumber, 1, saccno);
        verify.elementTextMatching(Keyreviewtransferaccname, 2, raccname);
        verify.elementTextMatching(Keyreviewtransferaccnumber, 2, raccno);

        verify.elementTextMatching(Keyreviewtransferamount, 1, amt);
        verify.elementTextMatching(Keyreviewtransferotherfields, 1, idate);
        verify.elementTextMatching(Keyreviewtransferotherfields, 2, ifreq);
        verify.elementTextMatching(Keyreviewtransferotherfields, 3, iend);
        verify.elementTextMatching(Keyreviewtransferotherfields, 4, imessage);

    }

    public void clickTransfer() throws ApplicationException {
      Wait.waituntillElementVisibleMob(Keyreviewtransfertransferbtn,4);
      click.elementBy(Keyreviewtransfertransferbtn);
        //click.elementBy(By.id("com.unionbankph.online.qat:id/button_bottom"));
    }

    public void verifyTransferBtn(String iexpectval) throws ApplicationException {

        //Keywords.refreshPage();
        verify.elementTextMatching(Keyreviewtransfertransferbtn, iexpectval);

    }

    public void clickEditlinkFromAccount() throws ApplicationException {
        Wait.waituntillElementVisibleMob(Keyreviewtransfereditfromaccountlink,4);
        click.elementBy(Keyreviewtransfereditfromaccountlink);
    }

    public void clickEditlinkFromAccountios() throws ApplicationException {
        Wait.waituntillElementVisibleMob(Keyreviewtransfereditfromaccountlink,4);
        click.elementBy(Keyreviewtransfereditfromaccountlink);
    }
    public void clickEditlinkToAccount() throws ApplicationException {
        Wait.waituntillElementVisibleMob(Keyreviewtransferedittoaccountlink,4);
        click.elementBy(Keyreviewtransferedittoaccountlink);
    }
    public void clickEditlinkToAccountios() throws ApplicationException {
        click.elementBy(Keyreviewtransferedittoaccountlink);
    }
    public void clickEditlinkAmount() throws ApplicationException {
        click.elementBy(Keyreviewtransfereditamountlink);
    }
    public void clickEditlinkamountios() throws ApplicationException {
        click.elementBy(Keyreviewtransfereditamountlink);
    }

    public void clickGotitButton() throws ApplicationException {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID"))
        {
            try {
                if (verify.IfElementExistsboolean(Keyreviewgotitbtn)) {
                    click.elementBy(Keyreviewgotitbtn);
                    Wait.forSeconds(5);
                }
            }
            catch(Exception e){
                if (verify.IfElementExistsboolean(Keyreviewgotitbtn)) {
                    click.elementBy(Keyreviewgotitbtn);
                    Wait.forSeconds(5);
                }
            }
        }

        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            Wait.forSeconds(4);
            try {
                if (verify.IfElementExistsboolean(Keyreviewgotitbtn)) {
                    click.elementBy(Keyreviewgotitbtn);
                    Wait.forSeconds(5);
                }
            } catch (Exception e)
            {
                if (verify.IfElementExistsboolean(Keykeepmeloggedinbtn)) {
                    Wait.waituntillElementVisibleMob(Keykeepmeloggedinbtn,3);
                    click.elementBy(Keykeepmeloggedinbtn);
                    Wait.forSeconds(5);
                }

            }


        }

    }
	/*
	public void verificationafterfromaccounteditlink() throws ApplicationException
	{
		click.elementBy(Keyreviewtransferaccnumber, 1);
		verify.elementTextMatchingText(Keyreviewtransferaccname,1,testdata.propertyValue("Another_Source_Name"));
		verify.elementTextMatchingText(Keyreviewtransferaccnumber,1,testdata.propertyValue("Another_Source_Account"));
	}

	public void verificationaftertoaccounteditlink() throws ApplicationException
	{
		verify.elementTextMatchingText(Keyreviewtransferaccname,2,testdata.propertyValue("Another_Recipient_Account"));
		verify.elementTextMatchingText(Keyreviewtransferaccnumber,2,testdata.propertyValue("Another_Recipient_Name"));
	}
	*/

    public void verificationafterfromaccounteditlink(String Another_Source_Name, String Another_Source_Account) throws ApplicationException {
        click.elementBy(Keyreviewtransferaccnumber, 1);
        verify.elementTextMatching(Keyreviewtransferaccname, 1, Another_Source_Name);
        verify.elementTextMatching(Keyreviewtransferaccnumber, 1, Another_Source_Account);
    }

    public void verificationaftertoaccounteditlink(String Another_Recipient_Account, String Another_Recipient_Name) throws ApplicationException {
        verify.elementTextMatching(Keyreviewtransferaccname, 2, Another_Recipient_Account);
        verify.elementTextMatching(Keyreviewtransferaccnumber, 2, Another_Recipient_Name);
    }

    public void verificationafteramounteditlink(String amount) throws ApplicationException {
        verify.elementTextMatching(Keyreviewtransferamount, amount);

    }

    public void clickClose() throws ApplicationException {
        click.elementBy(Keyreviewtransferclosebtn);

    }
    public void clickClosetrnsferfrom() throws ApplicationException {
        click.elementBy(Keyreviewtransferfromclosebtn);

    }

    public void verifypopup(String iexpectval, String iNOBtn, String iCancelBtn) throws ApplicationException {

        //verify.elementTextMatching(Keyreviewtransferpopuptitle, iexpectval);
        verify.elementTextMatching(Keyreviewtransferpopupnobtn, iNOBtn);
        verify.elementTextMatching(Keyreviewtransferpopuptransferbtn, iCancelBtn);
    }


    public void clickpopupnobtn() throws ApplicationException {

        click.elementBy(Keyreviewtransferpopupnobtn);
    }

    public void clickpopupcanceltransferbtn() throws ApplicationException {

        click.elementBy(Keyreviewtransferpopuptransferbtn);
    }

    public void clickEditLink() throws Throwable {
        click.elementBy(Keyreviewtransfereditlink);
    }

    public void verifyReviewandTransferpopuptitle(String ititle) throws ApplicationException {

        verify.elementTextMatching(Keyreviewtransferpoupwindowtitle, ititle);
    }

    public void verifyReviewandTransferpopupdecr(String ititle) throws ApplicationException {
        //verify.elementTextMatching(Keyreviewtransferpoupwindowdescr, PropertyReader.testDataOf(ititle));
        verify.elementIsPresent(Keyreviewtransferpoupwindowdescr);
    }

    public void verifyReviewandTransferscreen(String fromaccount,String toaccount,String Amount,String fees) throws ApplicationException {

       // verify.elementTextMatching(Keyreviewandtransferfromaccount, PropertyReader.testDataOf(fromaccount));
       // verify.elementTextMatching(Keyreviewandtransfertoaccount, PropertyReader.testDataOf(toaccount));
        verify.elementIsPresent(Keyreviewandtransfertoaccount);
        //verify.elementTextMatching(Keyreviewandtransferamount, PropertyReader.testDataOf(Amount));
        //verify.elementTextMatching(Keyreviewandtransferservicefee, PropertyReader.testDataOf(fees));
        verify.elementIsPresent(Keyreviewandtransferamount);
        //verify.elementIsPresent(Keyreviewandtransferservicefee);
    }

    public void clickremittancetermsandcondition() throws Throwable {
        click.elementBy(Keyreviewandtransferremittancechk);
    }
    public void clickremittancesubmit() throws Throwable {
        click.elementBy(Keyreviewandtransferremittancesubmit);
    }
    public void clickremittancecancel() throws Throwable {
        click.elementBy(Keyreviewandtransferremittancecancel);
    }
    public void verifyremittancereviewandsenddetails(String Amount,String Fee,String purpose,String Name,String Nationality,String Mobile,String Address) throws Throwable {
        swipe.swipeVertical(2,.2,.8,5);
        verify.elementTextMatching(Keyreviewandtransferremittanceamount,Amount);
       // verify.elementTextMatching(Keyreviewandtransferremittancefee,Fee);
        swipe.swipeVertical(2,.8,.2,5);

        //verify.elementTextMatching(Keyreviewandtransferremittancepurpose,purpose);
        verify.elementTextMatching(Keyreviewandtransferremittancename,Name);
        verify.elementTextMatching(Keyreviewandtransferremittancenationality,Nationality);
        verify.elementTextMatching(Keyreviewandtransferremittancemobileno,Mobile);
        swipe.swipeVertical(2,.8,.2,5);
        verify.elementTextMatching(Keyreviewandtransferremittanceaddress,Address);
        swipe.swipeVertical(2,.2,.8,5);
    }
    public void clickremittancetransferdetailedit() throws Throwable {
        click.elementBy(Keyreviewandtransferremittanceedit1);
    }
    public void clickremittancerecipientdetailedit() throws Throwable {
        click.elementBy(Keyreviewandtransferremittanceedit2);
    }
    public void clickremittancerecipientaddressedit() throws Throwable {
         Wait.forSeconds(2);
         swipe.swipeVertical(2,.8,.2,5);
        swipe.swipeVertical(2,.8,.2,5);
        Wait.forSeconds(2);
        click.elementBy(Keyreviewandtransferremittanceedit3);
    }
    public void clickremittancedone() throws Throwable {
        click.elementBy(Keyreviewandtransferremittancebtndone);
    }
}