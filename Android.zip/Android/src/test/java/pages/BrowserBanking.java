package pages;

import actions.Wait;
import base.Keywords;

public class BrowserBanking extends Keywords {

    private String Moretab ="onlineBanking.BrowserBanking.Moretab";
    private String TransactionLimits="onlineBanking.BrowserBanking.TransactionLimits";
    private String BrowserBankingOption="onlineBanking.BrowserBanking.BrowserBankingoption";
    private String Switch="onlineBanking.BrowserBanking.Switch";
    private String DisablePopup="onlineBanking.BrowserBanking.DisablePopupmsg";
    private String EnablePopup="onlineBanking.BrowserBanking.EnablePopupmsg";
    private String Success="onlineBanking.BrowserBanking.Success";
    private String Okay ="onlineBanking.BrowserBanking.Okay";
    private String selectTransferType="onlineBanking.BrowserBanking.SelectTransactionType";
    private String SelectLimitAmount="onlineBanking.BrowserBanking.SelectLimitAmount";
    private String Save = "onlineBanking.BrowserBanking.Save";
    private String GoToSettings="onlineBanking.BrowserBanking.GoToSettings";
    private String FAQ="onlineBanking.BrowserBanking.FAQ";
    private String Termsconditions="onlineBanking.BrowserBanking.TermsConditions";
    private String Contactus="onlineBanking.BrowserBanking.Contactus";


    public void clickMoreTab()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(Moretab);
    }
    public void verifyBrowserBanking()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(BrowserBankingOption);
    }
    public void clickBrowserBanking()throws Throwable{
        Wait.waituntillElementVisibleMob(BrowserBankingOption,2);
        click.elementBy(BrowserBankingOption);
    }
    public void clickToggleoff()throws Throwable{
        Wait.waituntillElementVisibleMob(Switch,2);
        click.elementBy(Switch);
    }
    public void clickTransactionLimit()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(TransactionLimits);
    }
    public void verifyDisablePopUpMsg()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(DisablePopup);
    }
    public void clickToggleOn()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(Switch);
    }
    public void verifyEnablePopUpMsg()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(EnablePopup);

    }
    public void verifySucessmsg()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(Success);
        click.elementBy(Okay);
    }
    public void clickTransferType()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(selectTransferType);
    }
    public void clickLimitAmount()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(SelectLimitAmount);
    }
    public void clickSave()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(Save);
    }
    public void clickGoToSettings()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(GoToSettings);
    }
    public void verifyMoreInfo()throws Throwable{
        Wait.forSeconds(2);
        swipe.swipeVertical(2, 0.8, 0.4, 5);
        verify.elementIsPresent(FAQ);
        verify.elementIsPresent(Termsconditions);
        verify.elementIsPresent(Contactus);
    }
}
