package pages;

import actions.Wait;
import base.Keywords;
import helper.PropertyReader;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;

public class EasyPayment_Page extends Keywords {

    private String CreditCard = "onlineBanking.EasyPayment.ClickCreditCard";
    private String Okay = "onlineBanking.EasyPayment.OkayButton";
    private String EasyPayment = "onlineBanking.EasyPayment.EasyPaymentTo";

    private String EasyPaymentDetailsScreen = "onlineBanking.EasyPayment.EasyPaymentTo";
    private String PayTo = "onlineBanking.EasyPayment.PayTo";
    private String AccountNumber = "onlineBanking.EasyPayment.AccountNumber";
    private String AccountName = "onlineBanking.EasyPayment.AccountName";
    private String SelectRecipients = "onlineBanking.EasyPayment.SelectRecipients";
    private String UnionBank = "onlineBanking.EasyPayment.UnionBank";
    private String NextButton = "onlineBanking.EasyPayment.NextButton";
    private String EasyPaymentDetailsScreenHeader = "onlineBanking.EasyPayment.EasyPaymentDetailsScreen";
    private String AmountToPay = "onlineBanking.EasyPayment.AmountToPay";
    private String ProcessingFee = "onlineBanking.EasyPayment.ProcessingFee";
    private String Purpose = "onlineBanking.EasyPayment.PurposeDropDown";
    private String AllowedPayments = "onlineBanking.EasyPayment.AllowedPayments";
    private String CreditCardLimit = "onlineBanking.EasyPayment.AllowedCreditLimit";
    private String ReminderMessage = "onlineBanking.EasyPayment.ReminderMessage";
    private String AmountTxtBox = "onlineBanking.EasyPayment.AmountTxtBox";
    private String Drop_down = "onlineBanking.EasyPayment.PurposeDropDown";
    private String ValidationBelowErrorMessage = "onlineBanking.EasyPayment.BelowErrorMessage";
    private String ValidationAboveErrorMessage = "onlineBanking.EasyPayment.AboveErrorMessage";
    private String PhpAmount = "onlineBanking.EasyPayment.PHPAmount";
    private String SchoolOrTraining = "onlineBanking.EasyPayment.SchoolOrTrainingFee";
    private String RentalFee = "onlineBanking.EasyPayment.RentalFee";
    private String MembershipFee = "onlineBanking.EasyPayment.MembershipFee";
    private String ProfessionalFee = "onlineBanking.EasyPayment.ProfessionalFee";
    private String InsuranceFee = "onlineBanking.EasyPayment.InsuranceFee";
    private String Miscellaneous = "onlineBanking.EasyPayment.MiscellaneousFee";
    private String Description = "onlineBanking.EasyPayment.DescriptionField";
    private String FromAccount = "onlineBanking.EasyPayment.FromAccountField";
    private String ToAccount = "onlineBanking.EasyPayment.ToAccountField";
    private String AmountField = "onlineBanking.EasyPayment.AmountField";
    private String ProcessingField = "onlineBanking.EasyPayment.ProcessingField";
    private String DateField = "onlineBanking.EasyPayment.DateField";
    private String PurposeField = "onlineBanking.EasyPayment.PurposeField";
    private String TermsAndCondition = "onlineBanking.EasyPayment.TermsAndCondition";
    private String CloseButton = "onlineBanking.EasyPayment.CancelButton";
    private String PayPhp = "onlineBanking.EasyPayment.PayPhp";
    private String CancelButton = "onlineBanking.EasyPayment.CancelButton";
    private String NoCTA = "onlineBanking.EasyPayment.NoCTA";
    private String YesCTA = "onlineBanking.EasyPayment.YesCTA";
    private String image = "onlineBanking.EasyPayment.image";
    private String GotIt = "onlineBanking.EasyPayment.GotIt";
    private String EditToAccountCTA = "onlineBanking.EasyPayment.EditToAccountCTA";
    private String EditAmountCTA = "onlineBanking.EasyPayment.EditAmountCTA";
    private String TransactionDetailsHeader = "onlineBanking.EasyPayment.TransactionDetailsHeader";
    private String PaymentDetails = "onlineBanking.EasyPayment.PaymentDetails";
    private String PaymentToAccount = "onlineBanking.EasyPayment.PaymentToAccount";
    private String ToAccountNameValue = "onlineBanking.EasyPayment.ToAccountNameValue";
    private String PaymentFromAccount = "onlineBanking.EasyPayment.PaymentFromAccount";
    private String FromAccountNameValue = "onlineBanking.EasyPayment.FromAccountNameValue";
    private String PaymentAmount = "onlineBanking.EasyPayment.PaymentAmount";
    private String PaymentAmountValue = "onlineBanking.EasyPayment.PaymentAmountValue";
    private String PaymentPurpose = "onlineBanking.EasyPayment.PaymentPurpose";
    private String PaymentPurposeValue = "onlineBanking.EasyPayment.PaymentPurposeValue";

    private String Keytopagedonebtn = "convergent.TransferTopage.clickdonebtn";

    private String SendFrom = "onlineBanking.EasyPayment.SendFrom";

    private String AccountNumberTab = "onlineBanking.EasyPayment.AccountNumberTab";
    private String MobileNumber = "onlineBanking.EasyPayment.MobileNumber";
    private String Email = "onlineBanking.EasyPayment.Email";


    public void ClickCreditCard() throws Throwable {
        Wait.forSeconds(10);
        AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.widget.TextView[@text=\"Mastercard Cashback Platinum Credit\"]");
        element.click();
    }

    public void VerifyEasyPayment() throws Throwable {
        Wait.waituntillElementVisibleMob(EasyPayment,3);
        verify.elementIsPresent(EasyPayment);
        click.elementBy(Okay);
    }
    public void VerifyEasyPaymentDetailsHeader() throws Throwable {
        Wait.waituntillElementVisibleMob(EasyPaymentDetailsScreenHeader,2);
        verify.elementIsPresent(EasyPaymentDetailsScreenHeader);

    }

    public void VerifyPayToScreenDetails() throws Throwable {
        Wait.waituntillElementVisibleMob(PayTo,2);
        verify.elementIsPresent(PayTo);
        verify.elementIsPresent(AccountNumberTab);
        verify.elementIsPresent(MobileNumber);
        verify.elementIsPresent(Email);

    }

    public void EnterAccountNumberAndAccountName() throws Throwable {
        Wait.waituntillElementVisibleMob(AccountNumber,2);
        type.data(AccountNumber, PropertyReader.testDataOf("EasyPayment_AccountNumber"));
        type.data(AccountName, PropertyReader.testDataOf("EasyPayment_AccountName"));
    }

    public void ClickSelectRecipients() throws Throwable {
        Wait.waituntillElementVisibleMob(SelectRecipients,3);
        click.elementBy(SelectRecipients);
        click.elementBy(UnionBank);
    }

    public void NextButton() throws Throwable {

        Wait.forSeconds(2);
        swipe.swipeVertical(2, 0.8, 0.2, 5);
        MobileElement el1 = (MobileElement) driver.findElementById("com.unionbankph.online.qat:id/btn_next_credit");
        el1.click();
//        Wait.forSeconds(3);
//        click.elementBy(NextButton);
    }


    public void VerifyPurposeDrop_Down() throws Throwable {
        Wait.waituntillElementVisibleMob(Drop_down,3);
        //click.elementBy(Purpose);
        verify.elementIsPresent(Drop_down);
    }

    public void VerifyAllowedPayments() throws Throwable {
        Wait.waituntillElementVisibleMob(AllowedPayments,2);
        verify.elementIsPresent(AllowedPayments);
    }

    public void VerifyCardLimit() throws Throwable {
        Wait.waituntillElementVisibleMob(CreditCardLimit,2);
        verify.elementIsPresent(CreditCardLimit);
    }

    public void VerifyInformationPage() throws Throwable {
        Wait.waituntillElementVisibleMob(image,3);
//        verify.elementIsPresent(ReminderMessage);
        verify.elementIsPresent(image);
        verify.elementIsPresent(GotIt);
        click.elementBy(GotIt);
    }

    public void ClickAmount() throws Throwable {
       WAIT.forSecondsUsingFluentWAIT(4,PhpAmount);
       type.data(AmountTxtBox, PropertyReader.testDataOf("EasyPayment_Amount"));
//        type.data(PhpAmount, PropertyReader.testDataOf("EasyPayment_Amount"));
    }

    public void ValidationMinimumErrorMessage() throws Throwable {
        Wait.waituntillElementVisibleMob(AmountTxtBox,2);
        type.data(AmountTxtBox, PropertyReader.testDataOf("EasyPayment_MinimumAmount"));
        verify.elementTextMatching(ValidationBelowErrorMessage, PropertyReader.testDataOf("EasyPayment_ValidationMessage"));
    }

    public void ValidationMaximumErrorMessage() throws Throwable {
        Wait.waituntillElementVisibleMob(AmountTxtBox,2);
        type.data(AmountTxtBox, PropertyReader.testDataOf("EasyPayment_MaximumAmount"));
        verify.elementTextMatching(ValidationBelowErrorMessage, PropertyReader.testDataOf("EasyPayment_ValidationMessage"));
        //verify.elementTextMatching(ValidationAboveErrorMessage, PropertyReader.testDataOf("EasyPayment_ValidationMessage"));
    }

    public void ClickDrop_Down() throws Throwable {
        Wait.waituntillElementVisibleMob(Purpose,2);
        //jsClick.elementBy(Purpose);
        click.elementBy(Purpose);
        verify.elementIsPresent(SchoolOrTraining);
        verify.elementIsPresent(RentalFee);
        verify.elementIsPresent(MembershipFee);
        verify.elementIsPresent(ProfessionalFee);
        verify.elementIsPresent(InsuranceFee);
        verify.elementIsPresent(Miscellaneous);
    }

    public void VerifyReviewPaymentScreen() throws Throwable {
        Wait.waituntillElementVisibleMob(PurposeField,2);
        //verify.elementIsPresent(Description);
       // verify.elementIsPresent(DateField);
        verify.elementIsPresent(PurposeField);
        verify.elementIsPresent(AmountField);
        verify.elementIsPresent(ToAccount);
        verify.elementIsPresent(ProcessingField);
    }

    public void ClickSchoolFee() throws Throwable {
        Wait.waituntillElementVisibleMob(SchoolOrTraining,2);
        click.elementBy(SchoolOrTraining);
    }

    public void VerifyReminderMessage() throws Throwable {
       Wait.waituntillElementVisibleMob(ReminderMessage,2);
        verify.elementIsPresent(ReminderMessage);
    }

    public void VerifyProcessing() throws Throwable {
        Wait.waituntillElementVisibleMob(ProcessingField,2);
        verify.elementIsPresent(ProcessingField);
    }

    public void VerifyTermsAndCondition() throws Throwable {
        Wait.waituntillElementVisibleMob(TermsAndCondition,2);
        verify.elementIsPresent(TermsAndCondition);

    }

    public void ClickPayPHP() throws Throwable {
        Wait.forSeconds(2);
//        click.elementBy(PayPhp);
        swipe.swipeVertical(2, 0.8, 0.2, 5);
        MobileElement el1 = (MobileElement) driver.findElementById("com.unionbankph.online.qat:id/button_bottom");
        el1.click();
    }

    public void ClickGotIt() throws Throwable {
        Wait.waituntillElementVisibleMob(GotIt,2);
        click.elementBy(GotIt);
    }

    public void ClickCancel() throws Throwable {
        Wait.waituntillElementVisibleMob(CancelButton,2);
        click.elementBy(CancelButton);
    }

    public void VerifyPopUpMessages() throws Throwable {
        Wait.waituntillElementVisibleMob(YesCTA,3);
        verify.elementIsPresent(YesCTA);
        verify.elementIsPresent(NoCTA);
    }

    public void ClickYesCta() throws Throwable {
        Wait.waituntillElementVisibleMob(YesCTA,2);
        click.elementBy(YesCTA);
    }

    public void ClickNoCta() throws Throwable {
        Wait.waituntillElementVisibleMob(NoCTA,2);
        click.elementBy(NoCTA);

    }

    public void EnterPhp() throws Throwable {
        Wait.waituntillElementVisibleMob(AmountTxtBox,3);
        type.data(AmountTxtBox, PropertyReader.testDataOf("EasyPayment_Amount"));
    }

    public void ClickEdit() throws Throwable {
        Wait.waituntillElementVisibleMob(EditAmountCTA,3);
        click.elementBy(EditAmountCTA);
        Wait.waituntillElementVisibleMob(AmountTxtBox,2);
        type.data(AmountTxtBox, PropertyReader.testDataOf("Edit_EasyPayment_Amount"));
        click.elementBy(Purpose);
        Wait.waituntillElementVisibleMob(RentalFee,2);
        click.elementBy(RentalFee);
        Wait.forSeconds(3);
        swipe.swipeVertical(2, 0.8, 0.2, 5);
        MobileElement el1 = (MobileElement) driver.findElementById("com.unionbankph.online.qat:id/btn_next_credit");
        el1.click();
    }
    public void VerifyTransactionPaymentDetailsPage() throws Throwable {
        Wait.waituntillElementVisibleMob(TransactionDetailsHeader,3);
        verify.elementIsPresent(TransactionDetailsHeader);
        verify.elementIsPresent(PaymentDetails);
        verify.elementIsPresent(PaymentToAccount);
        verify.elementIsPresent(PaymentAmount);
        verify.elementIsPresent(PaymentPurpose);
        verify.elementIsPresent(ProcessingField);
    }
    public void VerifyTransactionPaymentDetailsValuesPage() throws Throwable {
        Wait.waituntillElementVisibleMob(FromAccountNameValue,2);
        verify.elementTextMatching(FromAccountNameValue,PropertyReader.testDataOf("EasyPayment_FromAccount"));
        verify.elementTextMatching(ToAccountNameValue,PropertyReader.testDataOf("EasyPayment_ToAccountValue"));
        verify.elementTextMatching(PaymentAmountValue,PropertyReader.testDataOf("EasyPayment_AmountValue"));
        verify.elementTextMatching(PaymentPurposeValue,PropertyReader.testDataOf("EasyPayment_Purpose"));

    }
    public void VerifyTransactionPaymentDetailsValuesPage_Edit() throws Throwable {
        Wait.waituntillElementVisibleMob(FromAccountNameValue,2);
        verify.elementTextMatching(FromAccountNameValue,PropertyReader.testDataOf("EasyPayment_FromAccount"));
        verify.elementTextMatching(ToAccountNameValue,PropertyReader.testDataOf("EasyPayment_ToAccountValue"));
        verify.elementTextMatching(PaymentAmountValue,PropertyReader.testDataOf("EasyPayment_EditAmountValue"));
        verify.elementTextMatching(PaymentPurposeValue,PropertyReader.testDataOf("EasyPayment_EditPurpose"));

    }
}
