package pages;
import actions.Swipe;
import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import helper.PropertyReader;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import runners.ConvergentTestRunner;

import java.util.HashMap;
public class GetCash extends Keywords {

    String Keygetcash = "convergent.Getcash.Getcashmain.labelgetcash";
    String Keygetcashfromyouravailablecredit = "convergent.Getcash.Getcashmain.labelgetcashfromavailablecredit";
    String Keygetcasharrow="convergent.Getcash.Getcashmain.labelgetcasharrow";
    String Keygetcashtitle="convergent.Getcash.Getcashpage.labeltitle";
    String Keygetcashbalance="convergent.Getcash.Getcashpage.labegetcashbalance";
    String Keygetcashselectpaymentterms="convergent.Getcash.Getcashpage.labegetselectpaymentterms";
    String Keygetcashreceivefundsby="convergent.Getcash.Getcashpage.labegetrecivefundsby";
    String KeyRequestedamounttxtfiled="convergent.Getcash.Getcashpage.txtrequestedamount";
    String Keyrequestedamountfielderrormsg="convergent.Getcash.Getcashpage.labelrequestedamounterror";
    String Keyselectpaymentsfield="convergent.Getcash.Getcashpage.lstmonthstopay";
    String Keyselect3months="convergent.Getcash.Getcashpage.lbl3Months";
    String Keyselect6months="convergent.Getcash.Getcashpage.lbl6Months";
    String Keyselect9months="convergent.Getcash.Getcashpage.lbl9Months";
    String Keyselect12months="convergent.Getcash.Getcashpage.lbl12Months";
    String Keyselect14months="convergent.Getcash.Getcashpage.lbl14Months";
    String Keyselect18months="convergent.Getcash.Getcashpage.lbl18Months";
    String Keyselect24months="convergent.Getcash.Getcashpage.lbl24Months";
    String Keyselect36months="convergent.Getcash.Getcashpage.lbl36Months";
    String Keygetcashrate="convergent.Getcash.Getcashpage.lblinterestrate";
    String Keygetcashrepayamount="convergent.Getcash.Getcashpage.lblmonthstopaymentvalue";
    String Keygetcashfundsreceiveby="convergent.Getcash.Getcashpage.lstslecthowtowanttoreceivefnds";
    String Keygetcashfundsreceiveby1="convergent.Getcash.Getcashpage.receivefundsbyoption1";
    String Keygetcashfundsreceiveby2="convergent.Getcash.Getcashpage.receivefundsbyoption2";
    String Keygetcashfundsreceiveby3="convergent.Getcash.Getcashpage.receivefundsbyoption3";
    String Keygetcashtabtoselect="convergent.Getcash.Getcashpage.lstslecthowtowanttoreceivefnds.tabtoselect";
    String Keygetcashselectpickuppoint="convergent.Getcash.Getcashpage.lstslecthowtowanttoreceivefnds.selectpickuppoint";
    String KeygetcashselectpickuppointADBAvenue="convergent.Getcash.Getcashpage.lstslecthowtowanttoreceivefnds.selectpickuppointADBAvenue";
    String KeygetcashselectotherbankAUB="convergent.Getcash.Getcashpage.lstslecthowtowanttoreceivefnds.selectOtherbankAUB";
    String Keygetcashaccountnumber="convergent.Getcash.Getcashpage.lstslecthowtowanttoreceivefnds.otherbankaccountnumber";
    String Keygetcashnext="convergent.Getcash.Getcashpage.btnsave";
    String Keygetcashreviewpagefromacctname="convergent.Getcash.Getcashpagereviewpage.fromaccountname";
    String Keygetcashreviewpagerequestedamount="convergent.Getcash.Getcashpagereviewpage.requestedamount";
    String Keygetcashreviewpagemonthstopay="convergent.Getcash.Getcashpagereviewpage.monthstpoay";
    String Keygetcashreviewpageinerestrate="convergent.Getcash.Getcashpagereviewpage.interestrate";
    String Keygetcashreviewpagemonthludueamount="convergent.Getcash.Getcashpagereviewpage.monthlydueamount";
    String Keygetcashreviewpagereceivefundsby="convergent.Getcash.Getcashpagereviewpage.receivefundsby";
    String Keygetcashreviewpagereceivefundsbytype="convergent.Getcash.Getcashpagereviewpage.receivefundsbytype";
    String Keygetcashreviewpageapplynow="convergent.Getcash.Getcashpagereviewpage.btnApplyNow";
    String Keygetcashreviewpagechkbox="convergent.Getcash.Getcashpagereviewpage.chkboxagree";
    String Keygetcashsuccessmessage="convergent.Getcash.Getcashpagereviewpage.lblThankYou";
    String Keygetcashreviewandapplyedit="convergent.Getcash.Getcashpagereviewpage.btnedit";





    public void verifygetcashelement() throws Throwable {
        Wait.forSeconds(25);
        verify.elementIsPresent(Keygetcash);
    }

    public void verifygetcashelementsubtitle() throws Throwable {
        verify.elementIsPresent(Keygetcashfromyouravailablecredit);
    }

    public void clickGetcasharrow() throws Throwable {
       // verify.elementIsPresent(Keygetcasharrow);
        click.elementBy(Keygetcasharrow);
        Wait.forSeconds(5);
    }

    public void verifyGetcashpageelements() throws Throwable  {

        Wait.forSeconds(5);
        verify.elementIsPresent(Keygetcashtitle);
        verify.elementTextMatching(Keygetcashtitle ,"Get Cash");
        verify.elementIsPresent(Keygetcashbalance);
        verify.elementIsPresent(Keygetcashselectpaymentterms);
        verify.elementIsPresent(Keygetcashreceivefundsby);

    }

    public void validateAmountfield(String errormsg1,String amount,String errormsg2) throws Throwable  {

        Wait.forSeconds(5);
        type.data(KeyRequestedamounttxtfiled,amount);
        verify.elementTextMatching(Keyrequestedamountfielderrormsg,errormsg1);
        type.data(KeyRequestedamounttxtfiled,"");
        verify.elementTextMatching(Keyrequestedamountfielderrormsg,errormsg2);
    }
    public void validateAmountfield(String errormsg1) throws Throwable  {

        Wait.forSeconds(5);

        verify.elementTextMatching(Keyrequestedamountfielderrormsg,errormsg1);

    }
    public void validatepaymenttermsfield() throws Throwable  {

        Wait.forSeconds(5);
        click.elementBy(Keyselectpaymentsfield);
        Wait.forSeconds(5);
        click.elementBy(Keyselect3months);
        Wait.forSeconds(5);
        verify.elementTextMatching(Keyselectpaymentsfield,"3 Months");
        Wait.forSeconds(5);
        click.elementBy(Keyselectpaymentsfield);
        Wait.forSeconds(5);
        click.elementBy(Keyselect6months);
        Wait.forSeconds(5);
        verify.elementTextMatching(Keyselectpaymentsfield,"6 Months");
        Wait.forSeconds(5);
        click.elementBy(Keyselectpaymentsfield);
        Wait.forSeconds(5);
        click.elementBy(Keyselect9months);
        Wait.forSeconds(5);
        verify.elementTextMatching(Keyselectpaymentsfield,"9 Months");
        Wait.forSeconds(5);
        click.elementBy(Keyselectpaymentsfield);
        Wait.forSeconds(5);
        click.elementBy(Keyselect12months);
        Wait.forSeconds(5);
        verify.elementTextMatching(Keyselectpaymentsfield,"12 Months");
        Wait.forSeconds(5);
        click.elementBy(Keyselectpaymentsfield);
        Wait.forSeconds(5);
        click.elementBy(Keyselect14months);
        Wait.forSeconds(5);
        verify.elementTextMatching(Keyselectpaymentsfield,"14 Months");
        Wait.forSeconds(5);
        click.elementBy(Keyselectpaymentsfield);
        Wait.forSeconds(5);
        click.elementBy(Keyselect18months);
        Wait.forSeconds(5);
        verify.elementTextMatching(Keyselectpaymentsfield,"18 Months");
        Wait.forSeconds(5);
        click.elementBy(Keyselectpaymentsfield);
        Wait.forSeconds(5);
        click.elementBy(Keyselect24months);
        Wait.forSeconds(5);
        verify.elementTextMatching(Keyselectpaymentsfield,"24 Months");
        Wait.forSeconds(5);
        click.elementBy(Keyselectpaymentsfield);
        Wait.forSeconds(5);
        click.elementBy(Keyselect36months);
        Wait.forSeconds(5);
        verify.elementTextMatching(Keyselectpaymentsfield,"36 Months");



    }



    public void enterRequestamountandselectpaymentterms(String amount) throws Throwable  {

        Wait.forSeconds(10);
        type.data(KeyRequestedamounttxtfiled,amount);
        Wait.forSeconds(5);
        click.elementBy(Keyselectpaymentsfield);
        Wait.forSeconds(5);
        click.elementBy(Keyselect3months);
        Wait.forSeconds(5);

    }

    public void verifyGetcashrateandrepayamount(String rate,String repayamount) throws Throwable  {

        Wait.forSeconds(10);
        verify.elementTextMatching(Keygetcashrate,rate);
        verify.elementTextMatching(Keygetcashrepayamount,repayamount);

    }


    public void selectandverifyFundsreceiveby() throws Throwable  {

        Wait.forSeconds(5);
        click.elementBy(Keygetcashfundsreceiveby);
        Wait.forSeconds(5);
        click.elementBy(Keygetcashfundsreceiveby1);
        Wait.forSeconds(5);
        verify.elementTextMatching(Keygetcashfundsreceiveby,"Depositing to my UnionBank Account");
        Wait.forSeconds(5);
        click.elementBy(Keygetcashfundsreceiveby);
        Wait.forSeconds(5);
        click.elementBy(Keygetcashfundsreceiveby2);
        Wait.forSeconds(5);
        verify.elementTextMatching(Keygetcashfundsreceiveby,"Issuing a UnionBank Manager’s Check");
        Wait.forSeconds(5);
        click.elementBy(Keygetcashfundsreceiveby);
        Wait.forSeconds(5);
        click.elementBy(Keygetcashfundsreceiveby3);
        Wait.forSeconds(5);
        verify.elementTextMatching(Keygetcashfundsreceiveby,"Depositing to my account with another bank");

    }



    public void selectandverifyFundsreceiveby1(String fundsreceiveby) throws Throwable  {


        if(fundsreceiveby.equalsIgnoreCase("Depositing to my UnionBank Account")) {
            Wait.forSeconds(5);
            click.elementBy(Keygetcashfundsreceiveby);
            Wait.forSeconds(5);
            click.elementBy(Keygetcashfundsreceiveby1);
            Wait.forSeconds(5);
            verify.elementTextMatching(Keygetcashfundsreceiveby, fundsreceiveby);
        }
        else if(fundsreceiveby.equalsIgnoreCase("Issuing a UnionBank Manager’s Check")) {
            Wait.forSeconds(5);
            click.elementBy(Keygetcashfundsreceiveby);
            Wait.forSeconds(5);
            click.elementBy(Keygetcashfundsreceiveby2);
            Wait.forSeconds(5);
            verify.elementTextMatching(Keygetcashfundsreceiveby, fundsreceiveby);
        }
        else if(fundsreceiveby.equalsIgnoreCase("Depositing to my account with another bank")) {
            Wait.forSeconds(5);
            click.elementBy(Keygetcashfundsreceiveby);
            Wait.forSeconds(5);
            click.elementBy(Keygetcashfundsreceiveby3);
            Wait.forSeconds(5);
            verify.elementTextMatching(Keygetcashfundsreceiveby, fundsreceiveby);
        }
    }


    public void selectAccountnumber() throws Throwable  {
        Wait.forSeconds(5);

        click.elementBy(Keygetcashtabtoselect);
        try {
            driver.findElement(By.xpath("//android.widget.TextView[@text='1012 7000 6467']/parent::*/parent::*")).click();
        }
        catch(Exception e) {

            driver.findElement(By.xpath("//android.widget.TextView[@text='AVA JEAN E ENCINAREAL']")).click();
        }
    }

    public void selectPickuppoint() throws Throwable  {
        Wait.forSeconds(5);
        click.elementBy(Keygetcashselectpickuppoint);
        click.elementBy(KeygetcashselectpickuppointADBAvenue);
        Wait.forSeconds(5);
        verify.elementTextMatching(Keygetcashselectpickuppoint,"ADB Avenue");

    }

    public void selectOtherbankdeatils() throws Throwable  {
        Wait.forSeconds(5);
        click.elementBy(Keygetcashselectpickuppoint);
        click.elementBy(KeygetcashselectotherbankAUB);
        Wait.forSeconds(5);
        //verify.elementTextMatching(Keygetcashselectpickuppoint,"ADB Avenue");
        type.data(Keygetcashaccountnumber,"000467891234");

    }


    public void pickupBrancherrormessagevalidation(String errormsg1) throws Throwable  {

        Wait.forSeconds(5);

        verify.elementTextMatching(Keyrequestedamountfielderrormsg,errormsg1);

    }

    public void selectBankandchangerequestedamount() throws Throwable  {
        Wait.forSeconds(5);
        click.elementBy(Keygetcashselectpickuppoint);
        click.elementBy(KeygetcashselectotherbankAUB);
        Wait.forSeconds(5);
        //verify.elementTextMatching(Keygetcashselectpickuppoint,"ADB Avenue");
        click.elementBy(Keygetcashaccountnumber);
        type.data(KeyRequestedamounttxtfiled,"10000");
        click.elementBy(KeyRequestedamounttxtfiled);
        }

    public void clickNextbutton() throws Throwable  {

        Wait.forSeconds(5);
        click.elementBy(Keygetcashnext);
    }

    public void verifyGetcashReviewpage(String title,String fromaccountnumber,String Requestedamt,String Monthstopay,String intrate,String dueamt,String receicefromaccount) throws Throwable  {

        Wait.forSeconds(5);
        verify.elementTextMatching(Keygetcashtitle,title);
        verify.elementTextMatching(Keygetcashreviewpagefromacctname,fromaccountnumber);
        verify.elementTextMatching(Keygetcashreviewpagerequestedamount,Requestedamt);
        verify.elementTextMatching(Keygetcashreviewpagemonthstopay,Monthstopay);
        verify.elementTextMatching(Keygetcashreviewpageinerestrate,intrate);
        verify.elementTextMatching(Keygetcashreviewpagemonthludueamount,dueamt);
        verify.elementTextMatching(Keygetcashreviewpagereceivefundsby,receicefromaccount);



    }

    public void verifyGetcashReviewandsubmitgetcash(String title) throws Throwable  {

        Wait.forSeconds(5);
        verify.elementTextMatching(Keygetcashtitle,title);
        swipe.swipeVertical(2,.8,.2,5);
        swipe.swipeVertical(2,.8,.2,5);
        click.elementBy(Keygetcashreviewpagechkbox);
        click.elementBy(Keygetcashreviewpageapplynow);

    }
    public void verifySuccessmessaeingetcash(String successmsg) throws Throwable  {

        Wait.forSeconds(5);
        verify.elementTextMatching(Keygetcashsuccessmessage,successmsg);


    }
    public void clicktheEditbuttoningetcash() throws Throwable  {

        Wait.forSeconds(5);
        click.elementBy(Keygetcashreviewandapplyedit);
    }
    public void modifythevalesingetcashEditpage(String Requestedamt,String title) throws Throwable  {


        Wait.forSeconds(5);
        verify.elementTextMatching(Keygetcashtitle,title);
        type.data(KeyRequestedamounttxtfiled,Requestedamt);
        click.elementBy(Keygetcashnext);
        Requestedamt="PHP"+" "+"20,000.00";
        verify.elementTextMatching(Keygetcashreviewpagerequestedamount,Requestedamt);


    }

}
