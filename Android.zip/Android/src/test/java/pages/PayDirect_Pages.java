package pages;

import actions.Wait;
import base.Keywords;
import gherkin.lexer.Th;
import helper.PropertyReader;
import io.appium.java_client.MobileElement;

import static helper.PropertyReader.testDataOf;

public class PayDirect_Pages extends Keywords {

    private String CreditCard = "onlineBanking.PayDirect.ClickCreditCard";
    private String CreditCardData = testDataOf("PayDirect_CreditCard");
    private String Reminders = "onlineBanking.PayDirect.Reminders";
    private String GotItBtn = "onlineBanking.PayDirect.GotITBtn";
    private String AccountNumberTxtBox = "onlineBanking.PayDirect.AccountNumberTxtBox";
    private String NameTxtBox = "onlineBanking.PayDirect.NameTxtBox";
    private String NextBtn = "onlineBanking.PayDirect.NextBtn";
    private String BackBtn="onlineBanking.PayDirect.BackBtnReviewAndPay";
    private String NoContinuepayment="onlineBankig.PayDirect.No";
    private String YesCancelPayment="onlineBanking.PayDirect.Yes";
    private String StartDate="onlineBanking.PayDirect.StartDate";
    private String Today="onlineBanking.PayDirect.Today";
    private String SelectDate="onlineBanking.PayDirect.SelctDate";
    private String PickDate="onlineBanking.PayDirect.Date";
    private String PayBtn = "onlineBanking.PayDirect.PayBtn";
    private String SelectPurposeDropDown = "onlineBanking.Payall.SelectPurposeDrpDown";
    private String SelectPurpose = "onlineBanking.Payall.SelectPurpose";
    private String SelectBank="onlineBanking.PayDirect.BankName";
    private String SelectBankDropdown="onlineBanking.PayDirect.BankTxtBox";
    private String TransactionStatus="onlineBanking.PayDirect.TransactiondetailsStatus";
    private String TransactionRequestDate="onlineBanking.PayDirect.TransactionDetails.RequstDate";
    private String TransactionDetailsFromAcc="onlineBanking.PayDirect.TransactionDetails.FromAcc";
    private String TransactionDetailsToAcc="onlineBanking.PayDirect.TransactionDetails.ToAcc";
    private String Keytopagedonebtn = "convergent.TransferTopage.clickdonebtn";
    private String MessageTxtBox="onlineBanking.PayDirect.Message";
    private String MobileNumberTxtBox="onlineBanking.PayDirect.MobileNumberTxtBox";
//    private String DropDown = "onlineBanking.PayDirect.SelectPurposeDropDown";
    private String AmountTxtBox = "onlineBanking.EasyPayment.AmountTxtBox";
    private String InvalidAmountInlineError = "onlineBanking.PayDirect.InvalidAmountInlineError";
    private String InvalidAccInlineError = "onlineBanking.PayDirect.InvalidAccInlineError";
    private String ok="onlineBanking.PayDirect.Ok";

    public void ClickCreditCard() throws Throwable{
        Wait.forSeconds(7);
        MobileElement element=(MobileElement) driver.findElementById("com.unionbankph.online.qat:id/ctl_container");
        element.click();
//        click.elementBy(CreditCard,CreditCardData);
    }
    public void VerifyRemindersSection() throws Throwable{
        Wait.waituntillElementVisibleMob(Reminders,3);
        verify.elementIsPresent(Reminders);
        swipe.swipeVertical(2, 0.8, 0.4, 5);
        click.elementBy(GotItBtn);

    }
    public void EnterAccNumAndName() throws Throwable{
        Wait.waituntillElementVisibleMob(AccountNumberTxtBox,3);
        type.data(AccountNumberTxtBox, PropertyReader.testDataOf("Paydirect_AccNum"));
        Wait.waituntillElementVisibleMob(NameTxtBox,3);
        type.data(NameTxtBox, PropertyReader.testDataOf("Paydirect_Name"));
        Wait.forSeconds(2);
    }
    public void ClickNext() throws Throwable {
        click.elementBy(NextBtn);
    }
    public void ClickPayBtn() throws Throwable{
        Wait.waituntillElementVisibleMob(PayBtn,3);
        click.elementBy(PayBtn);
    }
    public void ClickSelectPurposeDropDown() throws Throwable{
        click.elementBy(StartDate);
        WAIT.forSecondsUsingFluentWAIT(2,StartDate);
        click.elementBy(SelectDate);
        click.elementBy(PickDate);
        click.elementBy(ok);
        click.elementBy(SelectPurposeDropDown);
        click.elementBy(SelectPurpose);

    }
    public void ProhibitedMsgUb1()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(MessageTxtBox);
        click.elementBy(MobileNumberTxtBox);
        type.data(MobileNumberTxtBox,"6857787777");
        WAIT.forSecondsUsingFluentWAIT(2,MessageTxtBox);
        click.elementBy(MessageTxtBox);
        type.data(MessageTxtBox,"Mortage");
        click.elementBy(NextBtn);
    }
    public void ProhibitedMsgUb2()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(MessageTxtBox);
        click.elementBy(MobileNumberTxtBox);
        type.data(MobileNumberTxtBox,"6857787777");
        WAIT.forSecondsUsingFluentWAIT(2,MessageTxtBox);
        click.elementBy(MessageTxtBox);
        type.data(MessageTxtBox,"Credit Card");
        click.elementBy(NextBtn);
    }
    public void ProhibitedMsgUb3()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(MessageTxtBox);
        click.elementBy(MobileNumberTxtBox);
        type.data(MobileNumberTxtBox,"6857787777");
        WAIT.forSecondsUsingFluentWAIT(2,MessageTxtBox);
        click.elementBy(MessageTxtBox);
        type.data(MessageTxtBox,"loan");
        click.elementBy(NextBtn);
    }
    public void ProhibitedMsgUb4()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(MessageTxtBox);
        click.elementBy(MobileNumberTxtBox);
        type.data(MobileNumberTxtBox,"6857787777");
        WAIT.forSecondsUsingFluentWAIT(2,MessageTxtBox);
        click.elementBy(MessageTxtBox);
        type.data(MessageTxtBox,"Bank");
        click.elementBy(NextBtn);
    }
    public void ProhibitedMsgUb5()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(MessageTxtBox);
        click.elementBy(MobileNumberTxtBox);
        type.data(MobileNumberTxtBox,"6857787777");
        WAIT.forSecondsUsingFluentWAIT(2,MessageTxtBox);
        click.elementBy(MessageTxtBox);
        type.data(MessageTxtBox,"Fund");
        click.elementBy(NextBtn);
    }
    public void ProhibitedMsgUb6()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(MessageTxtBox);
        click.elementBy(MobileNumberTxtBox);
        type.data(MobileNumberTxtBox,"6857787777");
        WAIT.forSecondsUsingFluentWAIT(2,MessageTxtBox);
        click.elementBy(MessageTxtBox);
        type.data(MessageTxtBox,"Crypto");
        click.elementBy(NextBtn);
    }
    public void ProhibitedMsgUb7()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(MessageTxtBox);
        click.elementBy(MobileNumberTxtBox);
        type.data(MobileNumberTxtBox,"6857787777");
        WAIT.forSecondsUsingFluentWAIT(2,MessageTxtBox);
        click.elementBy(MessageTxtBox);
        type.data(MessageTxtBox,"Investments");
        click.elementBy(NextBtn);
    }
    public void ProhibitedMsgUb8()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(MessageTxtBox);
        click.elementBy(MobileNumberTxtBox);
        type.data(MobileNumberTxtBox,"6857787777");
        WAIT.forSecondsUsingFluentWAIT(2,MessageTxtBox);
        click.elementBy(MessageTxtBox);
        type.data(MessageTxtBox,"Gambling");
        click.elementBy(NextBtn);
    }
    public void ProhibitedMsgUb9()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(MessageTxtBox);
        click.elementBy(MobileNumberTxtBox);
        type.data(MobileNumberTxtBox,"6857787777");
        WAIT.forSecondsUsingFluentWAIT(2,MessageTxtBox);
        click.elementBy(MessageTxtBox);
        type.data(MessageTxtBox,"casino");
        click.elementBy(NextBtn);
    }
    public void ProhibitedMsgUb10()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(MessageTxtBox);
        click.elementBy(MobileNumberTxtBox);
        type.data(MobileNumberTxtBox,"6857787777");
        WAIT.forSecondsUsingFluentWAIT(2,MessageTxtBox);
        click.elementBy(MessageTxtBox);
        type.data(MessageTxtBox,"Repayment");
        click.elementBy(NextBtn);
    }
    public void ProhibitedMsgUb11()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(MessageTxtBox);
        click.elementBy(MobileNumberTxtBox);
        type.data(MobileNumberTxtBox,"6857787777");
        WAIT.forSecondsUsingFluentWAIT(2,MessageTxtBox);
        click.elementBy(MessageTxtBox);
        type.data(MessageTxtBox,"FinanceHouse");
        click.elementBy(NextBtn);
    }
    public void clickBackBtnReviewandpay()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(BackBtn);
    }
    public void clickYesCancelPayment()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(YesCancelPayment);
    }
    public void clickNoContinuePayment()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(NoContinuepayment);
    }
    public void verifyTransactionDetails()throws Throwable{
        Wait.forSeconds(1);
        verify.elementIsPresent(TransactionStatus);
        verify.elementIsPresent(TransactionDetailsFromAcc);
        verify.elementIsPresent(TransactionDetailsToAcc);
        verify.elementIsPresent(TransactionRequestDate);
    }

    public void clickBankDropdown()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(SelectBankDropdown);
        click.elementBy(SelectBank);
    }

    public void InvalidAmount() throws Throwable{
        Wait.waituntillElementVisibleMob(AmountTxtBox,3);
        type.data(AmountTxtBox, PropertyReader.testDataOf("Paydirect_Invalidamount1"));
    }
    public void VerifyInvalidAmountInline() throws Throwable{
        Wait.waituntillElementVisibleMob(InvalidAmountInlineError,3);
        verify.elementIsPresent(InvalidAmountInlineError);
    }
    public void EnterInvalidAccNo() throws Throwable{
        Wait.waituntillElementVisibleMob(AccountNumberTxtBox,3);
        type.data(AccountNumberTxtBox, PropertyReader.testDataOf("Paydirect_InvalidAccNum"));
        Wait.waituntillElementVisibleMob(NameTxtBox,3);
        type.data(NameTxtBox, PropertyReader.testDataOf("Paydirect_Name"));

    }
    public void VerifyInvalidAccInline() throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(InvalidAccInlineError);

    }
    public void EnterAccNoAndAlphaNumericName() throws Throwable{
        Wait.waituntillElementVisibleMob(AccountNumberTxtBox,3);
        type.data(AccountNumberTxtBox, PropertyReader.testDataOf("Paydirect_AccNum"));
        Wait.waituntillElementVisibleMob(NameTxtBox,3);
        type.data(NameTxtBox, PropertyReader.testDataOf("Paydirect_AlphaNumericName"));
    }


}


