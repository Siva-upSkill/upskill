package pages;

import actions.Wait;
import base.Keywords;
import gherkin.lexer.Th;


public class AccountDetailsPage extends TransactionControlsPage {

    String KeyViewBalance = "convergent.Pesonet.viewbalance";
    String KeyBackBtn = "convergent.Pesonet.backbutton";
    String KeyViewMoreBtn = "convergent.accountdetails.labelViewMore";
    String KeyPageTitle = "convergent.accountdetails.labelPageTitle";
    String KeyTransferAmt = "convergent.accountdetails.transferAmt";
    String KeyCardStatus = "convergent.accountdetails.lableCardStatus";
    String KeyCardLockStatus = "convergent.accountdetails.lableCardStatusLocked";
    String KeyTransactionControls = "convergent.TransactionControls.TransactionCrtlPagetitle";
    String KeyTransactionStatus = "convergent.TransactionControls.TransactionStatus";
    String KeyCardCtrlStatus = "convergent.TransactionControls.CardControlStatus";
    String KeyEnbaledTransactionStatus = "convergent.TransactionControls.EnabledTransactionStatus";
    String KeyTransactionInternationalDisabledStatus = "convergent.TransactionControls.TransactionInternationalDisabledStatus";
    String KeyTransactionLocalDisabledStatus = "convergent.TransactionControls.TransactionLocalDisabledStatus";
    String KeyTransactionInternationalEnabledStatus = "convergent.TransactionControls.TransactionInternationalenabledStatus";
    String KeyTransactionLocalEnabledStatus = "convergent.TransactionControls.TransactionLocalenabledStatus";
    String KeyHangOnYes = "convergent.online.HandOn.btnYes";

    public String accbalance;
    private String currentbalance;
    private String cardstatus;

    public String getAccountBalance() throws Throwable {
        accbalance = get.elementBy(KeyViewBalance).getText();
        System.out.println(accbalance);
        return accbalance;
    }

    public void clickBackButton() throws Throwable {
        click.elementBy(KeyBackBtn);
        //click.elementBy(KeyHangOnYes);
    }

        public void clickBackButtonIOS() throws Throwable {
            click.elementBy(KeyBackBtn);
            click.elementBy(KeyHangOnYes);
        }

        public void clickViewMore() throws Throwable {
            click.elementBy(KeyViewMoreBtn);
        }

        public void verifyTransactionHistoryPageTitle(String ititle) throws Throwable {
            verify.elementTextMatching(KeyPageTitle, ititle);
        }

        public String getcurrentbalance() throws Throwable {
            currentbalance = get.elementBy(KeyViewBalance).getText();
            System.out.println(currentbalance);
            return currentbalance;

        }

        public void transactionhistory(String amt) throws Throwable {
            getcurrentbalance();
            if (accbalance != currentbalance) {
                verify.elementTextMatching(KeyTransferAmt, amt);
            }
        }

        public void verifyAccountDetailsPageTitle(String ititle) throws Throwable {
            verify.elementTextMatching(KeyPageTitle, ititle);
        }

        public String verifyCardStatus(String CardStatus) throws Throwable {
            cardstatus = get.elementBy(KeyCardStatus).getText();
            if (cardstatus.length() == CardStatus.length()) {
                verifyCurrentCardStatus(CardStatus);
            } else {
                clickTransactionControls();
//                verifyToggleBtnStatus();
//                selectCardSwitchBtn();
                Wait.forSeconds(40);
                clickBackButton();
                verifyCurrentCardStatus(CardStatus);
            }
            return CardStatus;
        }

        public String verifyCardStatusIOS(String CardStatus) throws Throwable {
            cardstatus = get.elementBy(KeyCardStatus).getText();
           // if (cardstatus.length() == CardStatus.length())
            if(cardstatus.equalsIgnoreCase(CardStatus))
            {
                verifyCurrentCardStatus(CardStatus);
            } else {
                clickTransactionControls();
                //verifyToggleBtnStatus();
//                selectCardSwitchBtnIOS();
                Wait.forSeconds(7);
                clickBackButton();
                //verifyCurrentCardStatus(CardStatus);
                Wait.forSeconds(15);
                verifyCurrentLockCardStatus(CardStatus);
            }
            return CardStatus;
        }

        public void verifyCurrentCardStatus(String ititle) throws Throwable {
            verify.elementTextMatching(KeyCardStatus, ititle);
        }

        public void verifyCurrentLockCardStatus(String ititle) throws Throwable {
            verify.elementTextMatching(KeyCardLockStatus, ititle);
        }

        public void clickTransactionControls() throws Throwable {
            Wait.waituntillElementVisibleMob(KeyTransactionControls,3);
            click.elementBy(KeyTransactionControls);
        }

        public void verifyOnlineTransactionStatus() throws Throwable {
            verify.elementIsPresent(KeyTransactionStatus);
        }

        public void verifyOnlineTransactionStatusEnabledIOS() throws Throwable {
            verify.elementIsPresent(KeyEnbaledTransactionStatus);
        }

        public void verifyInternationalTransactionStatus() throws Throwable {
            verify.elementIsPresent(KeyTransactionStatus);
        }

        public void verifyInternationalTransactionStatusEnabledIOS() throws Throwable {
            verify.elementIsPresent(KeyTransactionInternationalEnabledStatus);
        }

        public void verifyInternationalTransactionStatusIOS() throws Throwable {
            verify.elementIsPresent(KeyTransactionInternationalDisabledStatus);
        }

        public void verifyLocalTransactionStatus() throws Throwable {
            verify.elementIsPresent(KeyTransactionStatus);
        }

        public void verifyLocalTransactionEnabledStatusIOS() throws Throwable {
            verify.elementIsPresent(KeyTransactionLocalEnabledStatus);
        }

        public void verifyLocalTransactionStatusIOS() throws Throwable {
            verify.elementIsPresent(KeyTransactionLocalDisabledStatus);
        }

        public void verifyEnabledOnlineTransactionStatus() throws Throwable {
            verify.elementIsPresent(KeyEnbaledTransactionStatus);
        }

        public void verifyEnabledInternationalTransactionStatus() throws Throwable {
            verify.elementIsPresent(KeyEnbaledTransactionStatus);
        }

        public void verifyEnabledLocalTransactionStatus() throws Throwable {
            verify.elementIsPresent(KeyEnbaledTransactionStatus);
        }


        public void verifyCardCtrlStatus() throws Throwable {
            verify.elementIsPresent(KeyCardCtrlStatus);
        }

        public void verifyOnlineTransactionStatus1() throws Throwable {
            verify.elementIsDisabled(KeyTransactionStatus);
        }

        public String verifyCardStatusForDisabledTransactions(String CardStatus, String ititle) throws Throwable {
            cardstatus = get.elementBy(KeyCardStatus).getText();
            if (cardstatus.length() == CardStatus.length()) {
                clickTransactionControls();
//                verifyTransactionControlsPageTitle(ititle);
                verifyOnlineTransactionStatus();
                verifyInternationalTransactionStatus();
                verifyLocalTransactionStatus();

            } else {
                clickTransactionControls();
//                verifyToggleBtnStatus();
//                selectCardSwitchBtn();
                Wait.forSeconds(40);
                verifyOnlineTransactionStatus();
                verifyInternationalTransactionStatus();
                verifyLocalTransactionStatus();
                Wait.forSeconds(7);
                clickBackButton();
                verifyCurrentCardStatus(CardStatus);
                Wait.forSeconds(7);
                clickBackButton();
                verifyCardCtrlStatus();
            }
            return CardStatus;
        }

        public String verifyCardStatusForDisabledTransactionsIOS(String CardStatus, String ititle) throws Throwable {
            Wait.forSeconds(5);

            if (CardStatus.length() == CardStatus.length()) {
                cardstatus = get.elementBy(KeyCardStatus).getText(); }
            else {
                cardstatus = get.elementBy(KeyCardLockStatus).getText();
            }

            if (cardstatus.length() == CardStatus.length()) {
                clickTransactionControls();
//                verifyTransactionControlsPageTitleIOS(ititle);
                verifyOnlineTransactionStatus();
                verifyInternationalTransactionStatusIOS();
                verifyLocalTransactionStatusIOS();

            } else {
                Wait.forSeconds(5);
                clickTransactionControls();
//                verifyToggleBtnStatus();
//                selectCardSwitchBtnIOS();
                Wait.forSeconds(5);
                verifyOnlineTransactionStatus();
                verifyInternationalTransactionStatusIOS();
                verifyLocalTransactionStatusIOS();
                Wait.forSeconds(7);
                clickBackButton();
                verifyCurrentCardStatus(CardStatus);
                Wait.forSeconds(7);
                clickBackButton();
                verifyCardCtrlStatus();
            }
            return CardStatus;
        }

        public String verifyCardStatusForaEnabledTransactions(String CardStatus, String ititle) throws Throwable {
            cardstatus = get.elementBy(KeyCardStatus).getText();
            if (cardstatus.length() == CardStatus.length()) {
                clickTransactionControls();
//                verifyTransactionControlsPageTitle(ititle);
                verifyEnabledOnlineTransactionStatus();
                verifyEnabledInternationalTransactionStatus();
                verifyEnabledLocalTransactionStatus();

            } else {
                clickTransactionControls();
//                verifyToggleBtnStatus();
//                selectCardSwitchBtn();
                verifyEnabledOnlineTransactionStatus();
                verifyEnabledInternationalTransactionStatus();
                verifyEnabledLocalTransactionStatus();
                clickBackButton();
                verifyCurrentCardStatus(CardStatus);
            }
            return CardStatus;
        }

        public String verifyCardStatusForaEnabledTransactionsIOS(String CardStatus, String ititle) throws Throwable {
            //cardstatus = get.elementBy(KeyCardStatus).getText();

            Wait.forSeconds(5);

            if (CardStatus.length() == CardStatus.length()) {
                cardstatus = get.elementBy(KeyCardLockStatus).getText();
            } else {
                cardstatus = get.elementBy(KeyCardStatus).getText();
            }

            if (cardstatus.length() == CardStatus.length()) {
                clickTransactionControls();
//                verifyTransactionControlsPageTitleIOS(ititle);
                verifyOnlineTransactionStatusEnabledIOS();
                verifyInternationalTransactionStatusEnabledIOS();
                verifyLocalTransactionEnabledStatusIOS();

            } else {
                Wait.forSeconds(5);
                clickTransactionControls();
//                verifyToggleBtnStatus();
//                selectCardSwitchBtnIOS();
                Wait.forSeconds(5);
                verifyOnlineTransactionStatus();
                verifyInternationalTransactionStatusIOS();
                verifyLocalTransactionStatusIOS();
                Wait.forSeconds(7);
                clickBackButton();
                verifyCurrentCardStatus(CardStatus);
                Wait.forSeconds(7);
                clickBackButton();
                verifyCardCtrlStatus();
            }
            return CardStatus;

        }
    }