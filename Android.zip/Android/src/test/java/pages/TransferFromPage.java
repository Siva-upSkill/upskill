package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import org.openqa.selenium.By;
import io.appium.java_client.MobileElement;

public class TransferFromPage extends Keywords {
	private String Keyfrompagetitle = "convergent.TransferFrompage.verifytitle";
	private String Keytopagetitle = "convergent.TransferTopage.verifytitle";
	private String Keyfrompagetranferaccount = "convergent.TransferFrompage.selectaccount";
	private String Keyfrompagebackbtn = "convergent.TransferFrompage.backbtn";
	private String KeyBackGroundColor = "convergent.TransferFromPage.backgroundcolor";
	private String Keyfrompageclosebtn = "convergent.TransferFromPage.btnclose";
	private String Keytransferdetailpagetitle = "convergent.TransferDetails.title";
	private String Keyfrompagetranferaccountusd="convergent.pddtspddtspage.labelUSDAccount";


	public void verifyTransferFromPageTitle(String ititle) throws ApplicationException
	{
//		verify.elementTextMatching(Keyfrompagetitle,ititle);
		verify.elementIsPresent(Keyfrompagetitle);
		Wait.forSeconds(2);
	}
	public void verifyTransferdetailsTitle(String ititle) throws ApplicationException
	{
//		WAIT.forSeconds(4);
		Wait.waituntillElementVisibleMob(Keytransferdetailpagetitle,3);
		verify.elementTextMatching(Keytransferdetailpagetitle, ititle);
//		WAIT.forSeconds(2);
	}
	public void verifyTransferToPageTitle(String ititle) throws ApplicationException
	{
		Wait.waituntillElementVisibleMob(Keytopagetitle,2);
		verify.elementTextMatching(Keytopagetitle,ititle);
	}

	public void chooseTranferFromAccount(String fromacc) throws ApplicationException
	{
		Wait.waituntillElementVisibleMob(Keyfrompagetranferaccount,3);
		click.elementBy(Keyfrompagetranferaccount);
	}

	public void chooseTranferFromAccountios() throws ApplicationException {
		//ResourceBase.PERFORM.click(Keychoosetranferfromaccount);
		WAIT.forSeconds(9);
		//	click.elementBy(By.xpath("//XCUIElementTypeStaticText[@name='1005 9024 9040']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther"));
		try {
			click.elementBy(By.xpath("//XCUIElementTypeStaticText[@name='1022 2002 1750']/parent::*/parent::*/parent::*/preceeding-sibling::XCUIElementTypeButton"));
		}
		catch(Exception e){

			click.elementBy(By.xpath("(//XCUIElementTypeStaticText[@name='1022 2002 1750']/parent::*/parent::*/parent::*/parent::*/parent::*/parent::*)[1]"));

		}
	}
	public void chooseTranferFromeditAccountios() throws ApplicationException {
		//ResourceBase.PERFORM.click(Keychoosetranferfromaccount);
		WAIT.forSeconds(9);
		//	click.elementBy(By.xpath("//XCUIElementTypeStaticText[@name='1005 9024 9040']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther"));
       try {
		   click.elementBy(By.xpath("(//XCUIElementTypeStaticText[@name='1022 2002 1750']/parent::*/parent::*/parent::*/parent::*/parent::*/parent::*)[2]"));
	   }
	   catch(Exception e){

		   click.elementBy(By.xpath("(//XCUIElementTypeStaticText[@name='1022 2002 1750']/parent::*/parent::*/parent::*/parent::*/parent::*/parent::*)[1]"));

	   }
	}

	public void chooseTranferFromAccountiosInstapay() throws ApplicationException {
		WAIT.forSeconds(2);
		MobileElement el1 = (MobileElement) driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"UBP QAT\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[7]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton");
		el1.click();
	}

		public void chooseTranferDormantToAccountios() throws ApplicationException
		{

			//ResourceBase.PERFORM.click(Keychoosetranferfromaccount);
			WAIT.forSeconds(7);
			//	click.elementBy(By.xpath("//XCUIElementTypeStaticText[@name='1005 9024 9040']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther"));

			click.elementBy(By.xpath("//XCUIElementTypeStaticText[@name='1005 9025 8751']/parent::*/parent::*/parent::*/parent::*/parent::*/parent::*"));

		}
		public void chooseTranferToAccountios() throws ApplicationException
		{

			try {
				//ResourceBase.PERFORM.click(Keychoosetranferfromaccount);
				WAIT.forSeconds(5);
				//	click.elementBy(By.xpath("//XCUIElementTypeStaticText[@name='1005 9024 9040']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther"));
				click.elementBy(By.xpath("(//XCUIElementTypeStaticText[@name='1023 1001 1756'])[2]/parent::*/parent::*/parent::*/parent::*/parent::*/parent::*"));
				//XCUIElementTypeCollectionView/XCUIElementTypeCell[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton
			}
			catch(Exception e){
				click.elementBy(By.xpath("(//XCUIElementTypeStaticText[@name='1023 1001 1756'])[1]/parent::*/parent::*/parent::*/parent::*/parent::*/parent::*"));

		}

		}
	public void chooseTransferinactiveAccountios() throws ApplicationException
	{

		//ResourceBase.PERFORM.click(Keychoosetranferfromaccount);
		WAIT.forSeconds(6);
		//	click.elementBy(By.xpath("//XCUIElementTypeStaticText[@name='1005 9024 9040']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther"));

		click.elementBy(By.xpath("//XCUIElementTypeStaticText[@name='1005 9025 8740']/parent::*/parent::*/parent::*/parent::*/parent::*/parent::*"));

	}
	public void chooseTranfereditToAccountios() throws ApplicationException
	{

		//ResourceBase.PERFORM.click(Keychoosetranferfromaccount);
		WAIT.forSeconds(5);
		//	click.elementBy(By.xpath("//XCUIElementTypeStaticText[@name='1005 9024 9040']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther"));
		click.elementBy(By.xpath("(//XCUIElementTypeStaticText[@name='1023 1001 1756'])[2]/parent::*/parent::*/parent::*/parent::*/parent::*/parent::*"));
		//XCUIElementTypeCollectionView/XCUIElementTypeCell[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton
	}

	public void chooseTranferPesonetios() throws ApplicationException
		{
			//ResourceBase.PERFORM.click(Keychoosetranferfromaccount);
			//WAIT.forSeconds(5);
			//	click.elementBy(By.xpath("//XCUIElementTypeStaticText[@name='1005 9024 9040']/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther/parent::XCUIElementTypeOther"));

			//click.elementBy(By.xpath("//XCUIElementTypeStaticText[@name='1064 0000 1643']"));
			actions.Touch.pressByCoordinates(250,250,5);
		}
		public void clickBackBtn() throws ApplicationException
		{
			click.elementBy(Keyfrompagebackbtn);
		}

		public void clickcloseBtnInTransferFromIOS() throws ApplicationException
		{
			click.elementBy(Keyfrompageclosebtn);
		}

		public void verifyBackGroundColor() throws ApplicationException {
//			Wait.forSeconds(5);
			Wait.waituntillElementVisibleMob(KeyBackGroundColor,3);
		    verify.elementIsPresent(KeyBackGroundColor);
	}

	public void chooseTranferFromAccountUSD(String fromacc) throws ApplicationException
	{
		Wait.waituntillElementVisibleMob(Keyfrompagetranferaccountusd,3);
//		WAIT.forSeconds(5);
		click.elementBy(Keyfrompagetranferaccountusd);
	}
}
