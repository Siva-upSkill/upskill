package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import io.appium.java_client.android.AndroidElement;
import runners.ConvergentTestRunner;

public class ReportCardPage extends Keywords {

    private HomePage home = new HomePage();
    private UITFPage uitfPage = new UITFPage();
    private SendRequestPage sendrequest = new SendRequestPage();

    ConvergentTestRunner Devicename=new ConvergentTestRunner();
    OTPPage otp = new OTPPage();

    private String PlayeverydayCreditCard = "onlineBanking.ReportCard.PlayeverydayCreditCard";
    private String ManageCard = "onlineBanking.CC.ManageCards";
    private String ReportCard = "onlineBanking.ReportCard.ReportCardLost";
    private String LockYourCardPopup = "onlineBanking.ReportCard.LockYourCardPopup";
    private String GoBackButton = "onlineBanking.ReportCard.GoBackButton";
    private String LandmarkTextBox="onlineBanking.ReportCard.LandmarkTxtBox";
    private String LockMyCardButton = "onlineBanking.ReportCard.LockMyCardButton";
    private String CardUnlocked = "onlineBanking.ReportCard.CardIsUnlocked";
    private String CardLocked = "onlineBanking.ReportCard.CardIsLocked";
    private String SwitchButton= "onlineBanking.ReportCard.SwitchButton";
    private String UnlockMyCardButton = "onlineBanking.ReportCard.UnlockMyCardButton";
    private String YourCardIsLockedTitle ="onlineBanking.ReportCard.YourCardIsLockedTitle";
    private String MaybeLaterButton = "onlineBanking.ReportCard.MaybeLaterButton";
    private String ProceedToCardReportingButton = "onlineBanking.ReportCard.ProceedToCardReportingButton";
    private String CardReplacementDetails= "onlineBanking.ReportCard.CardReplacementDetails";
    private String Reminder= "onlineBanking.ReportCard.Reminder";
    private String DeliverTo= "onlineBanking.ReportCard.DeliverTo";
    private String HomeAddress= "onlineBanking.ReportCard.HomeAddress";
    private String WorkAddress= "onlineBanking.ReportCard.WorkAddress";
    private String UpdateAddress= "onlineBanking.ReportCard.UpdateAddress";
    private String Landmark = "onlineBanking.ReportCard.Landmark";
    private String DeliveryAddress= "onlineBanking.ReportCard.DeliveryAddress";
    private String WorkAddressMessage= "onlineBanking.ReportCard.WorkAddressMessage";
    private String UpdateMyAddress= "onlineBanking.ReportCard.UpdateMyAddress";
    private String EmailCustomerService= "onlineBanking.ReportCard.EmailCustomerService";
    private String CallNowButton= "onlineBanking.ReportCard.CallNowButton";
    private String ReportCardTitle= "onlineBanking.ReportCard.ReportCardTitle";
    private String ILostMyCard= "onlineBanking.ReportCard.ILostMyCard";
    private String ReportLostCardTitle= "onlineBanking.ReportCard.ReportLostCardTitle";
    private String MyCardGotStolen = "onlineBanking.ReportCard.MyCardGotStolen";
    private String LocationTitle= "onlineBanking.ReportCard.LocationTitle";
    private String DateTimeTitle= "onlineBanking.ReportCard.DateTimeTitle";
    private String LocationInput= "onlineBanking.ReportCard.LocationInput";
    private String SelectDate="onlineBanking.ReportCard.SelectDate";
    private String ReportMyLostCard= "onlineBanking.ReportCard.ReportMyLostCard";
    private String CardReplacementConfirmation= "onlineBanking.ReportCard.CardReplacementConfirmation";
    private String Type= "onlineBanking.ReportCard.Type";
    private String CardName= "onlineBanking.ReportCard.CardName";
    private String DeliverToAddress= "onlineBanking.ReportCard.DeliverToAddress";
    private String CardFee= "onlineBanking.ReportCard.CardFee";

    private String Edit="onlineBanking.ReportCard.Edit";

    public void select_PlatinumCreditCard() throws Throwable {
        Wait.forSeconds(6);
        AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.widget.TextView[@text=\"*6389\"]");
        element.click();
    }

    public void clickManageCard() throws Throwable {
//        Wait.waituntillElementVisibleMob(ManageCard,4);
        Wait.forSeconds(5);
        click.elementBy(ManageCard);
    }
    public void verifyReportCard() throws Throwable {
        Wait.forSeconds(2);
        verify.elementIsPresent(ReportCard);
    }
    public void clickReportCard() throws Throwable {
        if(verify.IfElementExistsboolean(CardUnlocked))
        {
            click.elementBy(ReportCard);
        }
        else
        {
            click.elementBy(SwitchButton);
            click.elementBy(UnlockMyCardButton);
            Wait.forSeconds(3);
            otp.enterOTP("111111");
            Wait.waituntillElementVisibleMob(ReportCard,4);
            click.elementBy(ReportCard);
        }
    }
    public void verify_LockYourCallPopup() throws Throwable {
        Wait.waituntillElementVisibleMob(LockYourCardPopup,3);
        verify.elementIsPresent(LockYourCardPopup);
    }
    public void verify_PopupButtons(String goBack, String lockMyCard) throws Throwable {
        Wait.waituntillElementVisibleMob(GoBackButton,4);
        verify.elementTextMatching(GoBackButton,goBack);
        verify.elementTextMatching(LockMyCardButton,lockMyCard);
    }
    public void clickLockMyCard() throws Throwable {
        Wait.waituntillElementVisibleMob(LockMyCardButton,2);
        click.elementBy(LockMyCardButton);
    }
    public void verify_LockedSuccessPage() throws Throwable {
        Wait.waituntillElementVisibleMob(YourCardIsLockedTitle,3);
        verify.elementIsPresent(YourCardIsLockedTitle);
    }
    public void verify_CardisLockedButtons(String MaybeLater, String CardReporting) throws Throwable {
        Wait.waituntillElementVisibleMob(MaybeLaterButton,3);
        verify.elementTextMatching(MaybeLaterButton,MaybeLater);
        verify.elementTextMatching(ProceedToCardReportingButton,CardReporting);
    }
    public void clickGoBack() throws Throwable {
        Wait.waituntillElementVisibleMob(GoBackButton,2);
        click.elementBy(GoBackButton);
    }
    public void verify_CardisUnlocked() throws Throwable {
        verify.elementIsPresent(CardUnlocked);
        //verify.IfElementExistsboolean(CardUnlocked)
    }
    public void verify_CardisLocked() throws Throwable {
        verify.elementIsPresent(CardLocked);
        //verify.IfElementExistsboolean(CardLocked)
    }
    public void clickMaybeLater() throws Throwable {
        Wait.waituntillElementVisibleMob(MaybeLaterButton,3);
        click.elementBy(MaybeLaterButton);
    }
    public void clickProceedToCardReporting() throws Throwable {
        Wait.waituntillElementVisibleMob(ProceedToCardReportingButton,3);
        click.elementBy(ProceedToCardReportingButton);
    }
    public void verify_CardReplacementDetailsHeader() throws Throwable {
        Wait.waituntillElementVisibleMob(CardReplacementDetails,3);
        verify.elementIsPresent(CardReplacementDetails);
    }
    public void clickLandmarktxtbox()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(LandmarkTextBox);
        type.data(LandmarkTextBox,"school");
    }
    public void clickOnGobackButton() throws Throwable {
        Wait.waituntillElementVisibleMob(GoBackButton,2);
        click.elementBy(GoBackButton);

    }
    public void verify_ViewTheCardReplacement() throws Throwable {
        verify.elementIsPresent(Reminder);
        verify.elementIsPresent(DeliverTo);
        verify.elementIsPresent(HomeAddress);
        verify.elementIsPresent(WorkAddress);
        verify.elementIsPresent(UpdateAddress);
        verify.elementIsPresent(Landmark);
        swipe.swipeVertical(2, 0.6, .2, 2);
        Wait.waituntillElementVisibleMob(DeliveryAddress,2);
        verify.elementIsPresent(DeliveryAddress);

    }
    public void clickWorkAddress() throws ApplicationException {
        Wait.waituntillElementVisibleMob(WorkAddress,1);
        click.elementBy(WorkAddress);
    }
    public void verify_NoWorkAddressMessage() throws Throwable {
        Wait.waituntillElementVisibleMob(WorkAddressMessage,3);
        verify.elementIsPresent(WorkAddressMessage);
    }
    public void clickUpdateAddress() throws ApplicationException {
        Wait.waituntillElementVisibleMob(UpdateAddress,2);
        click.elementBy(UpdateAddress);
    }
    public void verify_UpdateAddressPopupsection() throws Throwable {
        Wait.waituntillElementVisibleMob(GoBackButton,2);
        verify.elementIsPresent(GoBackButton);
        verify.elementIsPresent(UpdateMyAddress);
    }
    public void clickUpdateMyaddress() throws Throwable {
        Wait.waituntillElementVisibleMob(UpdateMyAddress,3);
        click.elementBy(UpdateMyAddress);
    }
    public void verify_UpdateMyAddressPopupsection() throws Throwable {
        Wait.waituntillElementVisibleMob(MaybeLaterButton,3);
        //verify.elementIsPresent(GoBackButton);
        verify.elementIsPresent(MaybeLaterButton);
        verify.elementIsPresent(CallNowButton);
    }
    public void clickConfirmDeliveryaddress() throws Throwable {
        Wait.forSeconds(1);
        swipe.swipeVertical(2, 0.6, .2, 2);
        click.elementBy(DeliveryAddress);
    }
    public void verify_ReportCardPage() throws Throwable {
        Wait.waituntillElementVisibleMob(ReportCardTitle,2);
        verify.elementIsPresent(ReportCardTitle);
    }
    public void verify_ReportCardPageOptions() throws Throwable {
        Wait.waituntillElementVisibleMob(ILostMyCard,2);
        verify.elementIsPresent(ILostMyCard);
        verify.elementIsPresent(MyCardGotStolen);
    }
    public void clickLostMyCard() throws Throwable {
        Wait.waituntillElementVisibleMob(ILostMyCard,2);
        click.elementBy(ILostMyCard);
    }
    public void verify_ReportLostCardDetailsPage() throws Throwable {
        Wait.waituntillElementVisibleMob(ReportLostCardTitle,2);
        verify.elementIsPresent(ReportLostCardTitle);
        verify.elementIsPresent(LocationTitle);
        verify.elementIsPresent(DateTimeTitle);
    }
    public void EnterDetais_ReportLostCardDetailsPage()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(LocationInput);
        type.data(LocationInput,"school");
        Wait.forSeconds(2);
        click.elementBy(DateTimeTitle);
        click.elementBy(SelectDate);
    }
    public void clickReportMyLostCard()throws Throwable{
        WAIT.forSecondsUsingFluentWAIT(2,ReportMyLostCard);
        click.elementBy(ReportMyLostCard);
    }
     public void verifyCardReplacement_Header()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(CardReplacementConfirmation);
     }
     public void verifyHeaderDetails()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(Type);
        verify.elementIsPresent(CardName);
        verify.elementIsPresent(DeliverToAddress);
        verify.elementIsPresent(CardFee);
     }
     public void clickEdit()throws Throwable{
        WAIT.forSecondsUsingFluentWAIT(2,Edit);
        click.elementBy(Edit);
        click.elementBy(UpdateMyAddress);
     }

}