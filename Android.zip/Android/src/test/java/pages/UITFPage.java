package pages;

import actions.Wait;
import base.Keywords;
import com.github.javafaker.App;
import cucumber.api.java.cs.A;
import exceptions.ApplicationException;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import runners.ConvergentTestRunner;

import java.awt.Robot;


public class UITFPage extends Keywords {

    private String keyExistingAccountBtn="convergent.SingUPPage.SignUPButton";
    private String keyAcceptTandC="convergent.SingUPPage.AcceptTandCButton";
    private String keyUITFButtoninSignupPage="convergent.SignUPPage.UITFButton";
    private String keySubscribeBtn="convergent.AccountDetailsPage.UITFAcc.SubscribeBtn";
    private String keyRedeemBtn="convergent.AccountDetailsPage.UITFAcc.RedeemBtn";
    private String keySelectAccountForUITF="convergent.UITF.SelectAccount";
    private String keyTapToSelectAccount ="convergent.DetailsPage.TapToSelectAccount";
    private String keyDetailsNxtBtn="convergent.UITFPage.NextBtn";
    private String keySubscribePHPBtn="convergent.UITF.ReviewandSubscribe.SubscribePHPButton";
    private String keyRedeemUnitsBtn="convergent.UITF.ReviewandRedeem.RedeemBtn";
    private String keyOrederReceivedTitle="convergent.UITFConfirmationPageTitle";
    private String keyConfirmPageSubsTxt="convergent.UITFConfirmationPage.SubsText";
    private String keyConfirmPageRedeemText="convergent.UITFConfirmationPage.RedemptionText";
    private String keyConfirmPageSubsAmt="convergent.UITFconfirmationPage.SubsAmount";
    private String keyConfirmPageRedeemAmt="convergent.UITFconfirmationPage.RedemAmount";
    private String keyProceedBtn="convergent.UITF.ProceedBtn";
    private String keyEnterAmountTxt="convergent.Details.EnterAmount";
    private String AccountsManageBtn="convergent.Dashboard.AccountsManageBtn";
    private String AddAccountsBtn ="convergent.Dashboard.AddAccountsBtn";
    private String keyAccountNoText="convergent.UITFAccountNumberTxt";
    private String keyNextBtn="convergent.UITFPage.NextBtn";
    private String keyErrLbl="convergent.UITFPage.ErrorLbl";
    private String keyErrContent="convergent.UITFPage.ErrorContent";
    private String keyErrOKBtn="convergent.UITFPage.ErrorOKBtn";
    private String keyUITFBtn="convergent.Dashboard.UITFButton";
    private String keyGetStartedBtn="convergent.UITF.getStartedBtn";
    private String keyAllBtn="convergent.UITF.AllBtn";
    private String keyPHPFixIncomeBtn="convergent.UITF.PHPFixedIncomeBtn";
    private String keyPHPFixedIncomeContent="convergent.UITF.PHPFixIncomeContent";
    private String keyFixIncomePageTitle="convergent.UITF.PHPFixedIncomePageTitle";
    private String key1WBtn="convergent.UITF.1WBtn";
    private String key1MBtn="convergent.UITF.1MBtn";
    private String key3MBtn="convergent.UITF.3MBtn";
    private String key6MBtn="convergent.UITF.6MBtn";
    private String key1YBtn="convergent.UITF.1YBtn";
    private String keyInvestmentObj="convergent.UITF.InvestmentObjBtn";
    private String keyUITFQn="convergent.UITF.Qn";
    private String AddExistingAccount = "convergent.UITF.AddExistingAccount";
    private String AddAccount_UITFBtn = "convergent.UITF.AddAccount.UITFBtn";
    private String UITFAccount1 = "convergent.UITF.UITFAccount1";
    private String recentTransactionLbl = "convergent.UITF.RecentTransaction";
    private String ViewMoreBtn = "convergent.UITF.ViewMoreBtn";
    private String TransactionHistoryTitle = "convergent.UITF.TransactionHistoryTitle";
    private String SusbscriptionsBtn = "convergent.UITF.SusbscriptionsBtn";
    private String RedemptionBtn = "convergent.UITF.RedemptionBtn";

    private String SubscriptionProduct = "convergent.UITF.SubscriptionProduct";
    private String ReferenceNumber = "convergent.UITF.ReferenceNumber";
    private String TransactionDate = "convergent.UITF.TransactionDate";
    private String Description = "convergent.UITF.Description";
    private String SubscriptionAmt = "convergent.UITF.SubscriptionAmt";
    private String ExpectedSettlementDate = "convergent.UITF.ExpectedSettlementDate";
    private String FromAcc = "convergent.UITF.FromAcc";
    private String ToAcc = "convergent.UITF.ToAcc";
    private String ViewAllBtn = "convergent.UITF.ViewAllBtn";
    private String Dashboard_UITFBtn  = "convergent.UITF.Dashboard.UITFBtn";

    ConvergentTestRunner Devicename=new ConvergentTestRunner();

    public void verifyPHPFixedPageValidations() throws ApplicationException {
        verify.elementIsPresent(keyFixIncomePageTitle);
        verify.elementIsPresent(key1WBtn);
        verify.elementIsPresent(key1MBtn);
        verify.elementIsPresent(key3MBtn);
        verify.elementIsPresent(key6MBtn);
        verify.elementIsPresent(key1YBtn);
        //verify.elementIsPresent(keyInvestmentObj);
        verify.elementIsPresent(keyUITFQn);

        click.elementBy(key1MBtn);
        click.elementBy(key3MBtn);
        click.elementBy(key6MBtn);
        click.elementBy(key1YBtn);
    }

    public void clickUITFAccount() throws ApplicationException {
        Wait.forSeconds(10);
        click.elementBy(UITFAccount1);
    }

    public void clickSubscribeBtn() throws ApplicationException {
        click.elementBy(keySubscribeBtn);
    }

    public void clickRedeemBtn() throws ApplicationException {
       Wait.forSeconds(5);
        click.elementBy(keyRedeemBtn);
    }

    public void enterAmountTxt(String arg1) throws ApplicationException {
        Wait.forSeconds(5);
        swipe.swipeVertical(2, 0.6, .2, 2);
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2128")) {
            actions.Touch.pressByCoordinates(626, 365, 5);//for samsung galaxy J7
        }
        driver.findElementByXPath("//android.view.ViewGroup/android.widget.EditText").sendKeys(arg1);
    }

    public void selectAccountforUITF() throws ApplicationException {
        click.elementBy(keyTapToSelectAccount);
        click.elementBy(keySelectAccountForUITF);
    }

    public void clickNextBtn() throws ApplicationException {
        Wait.forSeconds(2);
        click.elementBy(keyDetailsNxtBtn);
    }

    public void clickSubcribePHPBtn() throws ApplicationException {
        click.elementBy(keySubscribePHPBtn);
    }

    public void clickRedeemUnits() throws ApplicationException {
        click.elementBy(keyRedeemUnitsBtn);
    }

    public void verifyOrderReceivedTitle() throws ApplicationException {
        verify.elementIsPresent(keyOrederReceivedTitle);
    }

    public void verifySubsciptionTxt() throws ApplicationException {
        verify.elementIsPresent(keyConfirmPageSubsTxt);
    }

    public void verifyRedemptionTxt() throws ApplicationException {
        verify.elementIsPresent(keyConfirmPageRedeemText);
    }

    public void verifySubscriptionAmt() throws ApplicationException {
        verify.elementIsPresent(keyConfirmPageSubsAmt);
    }

    public void verifyRedemptionAmt() throws ApplicationException {
        verify.elementIsPresent(keyConfirmPageRedeemAmt);
    }

    public void clickProceedBtn() throws ApplicationException {
       Wait.forSeconds(2);
        click.elementBy(keyProceedBtn);
    }

    public void clickAddAccountsBtn() throws ApplicationException {
        click.elementBy(AccountsManageBtn);
        click.elementBy(AddAccountsBtn);
        click.elementBy(AddExistingAccount);

    }

    public void clickUITFBtn_AddAccounts() throws ApplicationException {
        verify.IfElementExists(AddAccount_UITFBtn);
        click.elementBy(AddAccount_UITFBtn);
        /*
        //WebElement text = driver.findElementByXPath("//android.widget.TextView[@text='Scroll up for more options']");
        //Robot b11 = new Robot();
        //b11.mouseMove(text);
        Wait.forSeconds(5);
        Boolean result = false;
        int i=0;
        while (result == false) {
            try {
                if (result == false && i<=10) {
                    swipe.swipeVertical(2, 0.6, .2, 2);

                    if (verify.IfElementExistsboolean(keyUITFBtn))
                    {
                        swipe.swipeVertical(2, 0.6, .2, 2);
                        verify.IfElementExists(keyUITFBtn);
                        click.elementBy(keyUITFBtn);
                        result = true;
                    }

                }
                //result = true;
            } catch (Exception e) {

            }
            i=i++;
        }
    */
    }

    public void enterUITFAccountNumber(String arg1) throws ApplicationException {
//        type.clearvalue(keyAccountNoText);
        get.elementBy(keyAccountNoText).clear();
        type.data1(keyAccountNoText,arg1);
    }

    public void verifyNextButtonDisabled() throws ApplicationException {
        verify.elementIsDisabled(keyNextBtn);
    }

    public void verifyUITFAccountNoTxt(String str1) throws ApplicationException {
        keyAccountNoText.isEmpty();
        // verify.elementTextMatching(keyAccountNoText,str1);
    }

    public void verifyErrMsgAndOk() throws ApplicationException {
        verify.elementIsPresent(keyErrLbl);
        verify.elementIsPresent(keyErrContent);
        click.elementBy(keyErrOKBtn);
    }

    public void verifyNextButtonEnabled() throws ApplicationException {
        verify.elementIsEnabled(keyNextBtn);
    }

    public void verifyUITFPageValidations() throws ApplicationException {
        Wait.waituntillElementVisibleMob(keyAllBtn,3);
        verify.elementIsPresent(keyAllBtn);
        verify.elementIsPresent(keyPHPFixIncomeBtn);
        verify.elementIsPresent(keyPHPFixedIncomeContent);
    }

    public void clickPHPFixedContent() throws ApplicationException {
        click.elementBy(keyPHPFixedIncomeContent);
    }

    public void clickUITFBtnSignuppage() throws ApplicationException {
        swipe.swipeVertical(2, 0.6, .2, 2);
        click.elementBy(keyUITFButtoninSignupPage);
    }

    public void clickExistingAccountBtn() throws ApplicationException {
        click.elementBy(keyExistingAccountBtn);
        click.elementBy(keyAcceptTandC);
    }

    public void verifyRecentTransacLbl_ViewMoreBtn() throws ApplicationException {
        Wait.waituntillElementVisibleMob(recentTransactionLbl,3);
        verify.elementIsEnabled(recentTransactionLbl);
        verify.elementIsEnabled(ViewMoreBtn);
    }

    public void verifyOtherBtns_UITF() throws ApplicationException{
        Wait.waituntillElementVisibleMob(ViewMoreBtn,4);
        click.elementBy(ViewMoreBtn);
        verify.elementIsEnabled(keyAllBtn);
        verify.elementIsEnabled(SusbscriptionsBtn);
        verify.elementIsEnabled(RedemptionBtn);
    }

    public void clickSubsProduct() throws ApplicationException {
        Wait.waituntillElementVisibleMob(SubscriptionProduct,3);
        click.elementBy(SubscriptionProduct);
    }

    public void verifySubsDetails() throws ApplicationException {
        verify.elementIsPresent(ReferenceNumber);
        verify.elementIsPresent(TransactionDate);
        verify.elementIsPresent(Description);
        verify.elementIsPresent(SubscriptionAmt);
        verify.elementIsPresent(ExpectedSettlementDate);
        verify.elementIsPresent(FromAcc);
        verify.elementIsPresent(ToAcc);
    }

    public void clickUITFBtn_Dashboard() throws ApplicationException {
        Wait.forSeconds(10);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);

        click.elementBy(ViewAllBtn);
        Wait.waituntillElementVisibleMob(Dashboard_UITFBtn,3);
        click.elementBy(Dashboard_UITFBtn);
        Wait.waituntillElementVisibleMob(keyGetStartedBtn,3);
        click.elementBy(keyGetStartedBtn);
    }
}