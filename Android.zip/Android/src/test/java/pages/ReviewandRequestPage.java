package pages;

import base.Keywords;
import exceptions.ApplicationException;


public class ReviewandRequestPage extends Keywords {

    private String KeyBtnBack = "convergent.ReviewandRequest.BtnBack";
    private String KeyPagetitle = "convergent.ReviewandRequest.PageTitle";

    public void clickBackBtn() throws Throwable {
        click.elementBy(KeyBtnBack);
    }
}

