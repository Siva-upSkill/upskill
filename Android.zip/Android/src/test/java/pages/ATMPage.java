package pages;
import actions.Swipe;
import actions.Wait;
import base.Keywords;

public class ATMPage extends Keywords {

    private String viewall= "onlineBanking.ATMBranch.Viewall";
    private String ATMBranchLocator= "onlineBanking.ATMBranch.ATM&BranchLocator";
    private String BranchTab= "onlineBanking.ATMBranch.BranchTab";
    private String ATMTab= "onlineBanking.ATMBranch.ATMTab";
    private String SearchIcon="onlineBanking.ATMBranch.SearchIcon";
    private String BranchSearch ="onlineBanking.ATMBranch.SearchBranchLocation";
    private String SearchresultBranch="onlineBanking.ATMBranch.BranchSearchResult";
    private String ViewLocationOnAtmScreen="onlineBanking.ATMBranch.BranchLocation" ;
    private String DisplayATMLocation="onlineBanking.ATMBranch.ATMSearchResult";
    private String DisplayBranchLocation="onlineBanking.ATMBranch.BranchResult";
    private String FindNearestATM="onlineBanking.ATMBranch.FindNearestATM";
    private String Allow="onlineBanking.ATMBranch.AllowTab";
    private String NotNow="onlineBanking.ATMBranch.NotNowTab";

    public void clickViewAll()throws Throwable{
        Wait.waituntillElementVisibleMob(viewall,2);
        Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
        click.elementBy(viewall);
    }
    public void verifyFindATMTxt()throws Throwable{
        Wait.forSeconds(1);
        verify.elementIsPresent(FindNearestATM);
    }
    public void verifyOptionsOnPopUpscreen()throws Throwable{
        Wait.forSeconds(1);
        verify.elementIsPresent(Allow);
        verify.elementIsPresent(NotNow);
    }
    public void clickATMBranch()throws Throwable{
        Wait.waituntillElementVisibleMob(ATMBranchLocator,2);
        click.elementBy(ATMBranchLocator);
    }
    public void verifyTabOnATMScreen()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(BranchTab);
        verify.elementIsPresent(ATMTab);
    }
    public void BranchSearchIcon()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(SearchIcon);
        WAIT.forSecondsUsingFluentWAIT(4,BranchSearch);
        type.data(BranchSearch,"26th Street");
        WAIT.forSecondsUsingFluentWAIT(4,SearchresultBranch);
        click.elementBy(SearchresultBranch);
    }
    public void verifyBranchATMScreen()throws Throwable{
        Wait.forSeconds(4);
        verify.elementIsPresent(ViewLocationOnAtmScreen);
    }
    public void ATMsSearchIcon()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(ATMTab);
        WAIT.forSecondsUsingFluentWAIT(2,SearchIcon);
        click.elementBy(SearchIcon);
        Wait.forSeconds(2);
        click.elementBy(ATMTab);
        click.elementBy(SearchIcon);
        type.data(SearchIcon,"2nd Avenue");
        click.elementBy(ATMBranchLocator);
    }
    public void verifyATMLocation()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(DisplayATMLocation);
    }
    public void verifyBranchLocation()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(DisplayBranchLocation);
    }

}
