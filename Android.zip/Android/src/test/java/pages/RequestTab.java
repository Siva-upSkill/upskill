package pages;

import base.Keywords;
import exceptions.ApplicationException;


public class RequestTab extends Keywords {

    String KeyRequestPayment = "convergent.request.linkRequestPayment";


    public void clickRequestPayment() throws ApplicationException {
        click.elementBy(KeyRequestPayment);
    }
}
