package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import exceptions.EnvironmentException;

public class LoginPage extends Keywords {

	private String KeyBack = "convergent.login.btnBack";
	private String KeyPageTitle = "convergent.login.labelPagetitle";
	private String KeySignUpNow = "convergent.login.btnSignupNow";
	private String KeyUsername = "convergent.login.textboxUsername";
	private String KeyPassword = "convergent.login.textboxPassword";
	private String KeyPasswordVisibilityToggle = "convergent.login.togglePasswordVisibility";
	private String KeyLogin = "convergent.login.btnLogin";
	private String KeyForgotPassword = "convergent.login.btnForgotPassword";
	private String KeyAppVersion = "convergent.login.labelAppVersion";
	private String KeyInvalidUserIdorPassword="convergent.login.labelInvalidUserIDorPassword";
	private String KeyCloseErrorMessage = "convergent.login.btnCloseErrorMessage";
	private String KeyAccountBlocked = "convergent.login.labelAccountBlockedPopup";
	private String InvalidOTPBlocked = "convergent.login.OTPBlockedPopup";
	private String KeyNotTrust = "convergent.home.btntrustnotnow";

	public void checkIfBackButtonExists() throws ApplicationException {
		verify.IfElementExists(KeyBack);
	}

	public void verifyPageTitle(String expectedTitle) throws ApplicationException {
		verify.elementTextMatching(KeyPageTitle,expectedTitle);
	}

	public void checkIfSignupNowButtonExists() throws ApplicationException {
		verify.IfElementExists(KeySignUpNow);
	}

	public void checkIfUsernameTextboxExists() throws ApplicationException {
		verify.IfElementExists(KeyUsername);
	}

	public void checkIfPasswordTextboxExists() throws ApplicationException {
		verify.IfElementExists(KeyPassword);
	}

	public void checkIfLoginButtonExits() throws ApplicationException {
		verify.IfElementExists(KeyLogin);
	}

	public void checkIfForgotPasswordLinkExists() throws ApplicationException {
		verify.IfElementExists(KeyForgotPassword);
	}

	public void checkIfPasswordVisibilityToggleExists() throws ApplicationException {
		verify.IfElementExists(KeyPasswordVisibilityToggle);
	}

	public void checkIfAppVersionIsDisplayed(String expectedAppVersionText) throws ApplicationException {
		verify.elementTextMatching(KeyAppVersion,expectedAppVersionText);
	}

	public void enterPassword(String password) throws ApplicationException {
		type.sensitiveData(KeyPassword,password);

	}

	public void enterUsername(String userID) throws ApplicationException {
		type.data(KeyUsername,userID);
	}

	public void checkIfLoginIsDisabled() throws ApplicationException {
		verify.elementIsDisabled(KeyLogin);
	}

	public void verifyInvalidLoginErrorMessage(String expectedErrorMessage) throws ApplicationException {
		Wait.waituntillElementVisibleMob(KeyInvalidUserIdorPassword,5);
//		Wait.forSeconds(3);
		verify.elementTextMatching(KeyInvalidUserIdorPassword,expectedErrorMessage);
	}

	public void verifyAccountBlockedErrorMessage(String expectedErrorMessage) throws ApplicationException {
		Wait.forSeconds(3);
		verify.elementTextMatching(KeyAccountBlocked,expectedErrorMessage);
	}

	public void verifyInvalidOTPErrorMessage(String expectedErrorMessage) throws ApplicationException {
		Wait.forSeconds(3);
		verify.elementTextMatching(InvalidOTPBlocked,expectedErrorMessage);
	}

	public void clickLogin() throws ApplicationException {
		click.elementBy(KeyLogin);
	}

	public void clicknottrust() throws ApplicationException {
		click.elementBy(KeyNotTrust);
	}
	public void closeErrorMessage() throws ApplicationException {
		click.elementBy(KeyCloseErrorMessage);
	}


	public void closeloggedapplication() throws ApplicationException {

		closeApplication();

	}

	public void launchnewapplication() throws ApplicationException, EnvironmentException {

		launchApplication();

	}

	public void veriftheBanknameisnotExist(String value,String yesorno) throws ApplicationException {

		swipe.scrollDownToTextandVerify(value,yesorno);

	}

}
