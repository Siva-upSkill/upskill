package pages;

import actions.Wait;
import base.Keywords;
import gherkin.lexer.Th;


public class OnlinePage extends Keywords {
    String KeySwitchTogglebtn = "convergent.Online.ToggleSwitchLock";
    String KeyClickSavebtn = "convergent.Online.SaveBtn";
    String KeyEnableOnlineCtrlBtn = "convergent.Online.EnableOnlineControl";
    String KeyEnableSpendLimitToggleBtn = "convergent.Online.ToggleSwitchTransaction";
    String KeyEnterSpendLimit = "convergent.Online.EnterSpendLimit";
    String KeyEnableSwitchDurationToggleBtn = "convergent.Online.ToggleSwitchDuration";
    String KeySpendLimitErrorMsg = "convergent.TransactionControls.SpendLimitErrorMsg";
    String KeyOnlinePageTitle = "convergent.Online.Pagetitle";
    String KeyAllowOnlineCtrlBtn = "convergent.Online.AllowOnlineControl";
    String KeyInternationalEnterSpendLimit = "convergent.International.btnspendlimittoggleInternational";
    String KeyenableInternationalToggleBtn = "convergent.International.btnspendlimittoggleInternational";

    public void enableOnlinePurchases() throws Throwable {
        click.elementBy(KeySwitchTogglebtn);
    }

    public void clickSavebtn() throws Throwable {
        click.elementBy(KeyClickSavebtn);
        Wait.forSeconds(2);
        clickEnableOnlineControlsBtn();
        Wait.forSeconds(10);
    }

    public void clickSavebtnIOS() throws Throwable {
        click.elementBy(KeyClickSavebtn);
        Wait.forSeconds(2);
        clickAllowOnlineControlsBtnIOS();
    }

    public void verifySavebtnIsEnabled() throws Throwable {
        Wait.forSeconds(5);
        verify.elementIsEnabled(KeyClickSavebtn);
    }

    public void verifySavebtnIsDisabled() throws Throwable {
        Wait.forSeconds(5);
        verify.elementIsDisabled(KeyClickSavebtn);
    }

    public void clickEnableOnlineControlsBtn() throws Throwable {
        click.elementBy(KeyEnableOnlineCtrlBtn);
    }

    public void clickAllowOnlineControlsBtnIOS() throws Throwable {
        click.elementBy(KeyAllowOnlineCtrlBtn);
    }

    public void enableSpendLimitToggleBtn() throws Throwable {
        click.elementBy(KeyEnableSpendLimitToggleBtn);
    }

    public void clickSpendLimit() throws Throwable {
        click.elementBy(KeyEnterSpendLimit);
    }

    public void enableInternationalSpendLimitIOS() throws Throwable {
        click.elementBy(KeyenableInternationalToggleBtn);
    }

    public void clickInternationalSpendLimitIOS() throws Throwable {
        click.elementBy(KeyInternationalEnterSpendLimit);
    }

    public void enterSpendLimit(String Amt) throws Throwable {

        type.data(KeyEnterSpendLimit, Amt);
    }

    public void enableSwitchDurationToggleBtn() throws Throwable {
        click.elementBy(KeyEnableSwitchDurationToggleBtn);
    }

    public void spendLimitErrorMsg(String errmsg) throws Throwable {
        verify.elementTextMatching(KeySpendLimitErrorMsg, errmsg);
    }

    public void verifyOnlinePagetitle(String arg1) throws Throwable {
        verify.elementIsPresent(KeyOnlinePageTitle);
    }

}