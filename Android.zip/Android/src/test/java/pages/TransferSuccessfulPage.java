package pages;

import actions.Wait;
import base.Keywords;
import driver.DriverManager;
import exceptions.ApplicationException;
import org.openqa.selenium.By;


public class TransferSuccessfulPage extends Keywords {
	
	private String Keytransfersuccessfultitle="convergent.transfersuccessful.title";
	private String Keytransfersuccessfulreferencenumlabel="convergent.transfersuccessful.referencenumlabel";
	private String Keytransfersuccessfulreferencenum="convergent.transfersuccessful.referencenumvalue";
	private String Keytransfersuccessfultransactiondatelabel="convergent.transfersuccessful.transactiondatelabel";
	private String Keytransfersuccessfultransactiondatevalue="convergent.transfersuccessful.transactiondatevalue";
	private String Keytransfersuccessfulfromaccountlabel="convergent.transfersuccessful.fromaccountlabel";
	private String Keytransfersuccessfultoaccountlabel="convergent.transfersuccessful.toaccountlabel";
	private String Keytransfersuccessfulamountlabel="convergent.transfersuccessful.amountlabel";
	private String Keytransfersuccessfuldatelabel="convergent.transfersuccessful.datelabel";
	private String Keytransfersuccessfulsharetool="convergent.transfersuccessful.sharetool";
	private String Keytransfersuccessfulaccname="convergent.transfersuccessful.accname";
	private String Keytransfersuccessfulaccnumber="convergent.transfersuccessful.accnumber";
	private String Keytransfersuccessfulamount="convergent.transfersuccessful.amount";
	private String Keytransfersuccessfuldate="convergent.transfersuccessful.date";
	private String Keytransfersuccessfulgotodashboardbtn="convergent.transfersuccessful.gotodashboardbtn";
	private String Keytransfersuccessfulnewtransactionbtn="convergent.transfersuccessful.newtransactionbtn";
	private String Keytransfersuccessfulclosebtn="convergent.transfersuccessful.closebtn";
	
	public void verifyTransferSuccessfultitle(String ititle) throws ApplicationException
	{
		//verify.elementTextMatching(Keytransfersuccessfultitle, ititle);
		verify.elementIsPresent(Keytransfersuccessfultitle);
	}
	
	public void verifyTransferSuccessfulfieldlabels(String referno,String trandate,String fromacc,
			String toacc,String amt,String date) throws ApplicationException
	{
		//verify.elementIsPresent(Keytransfersuccessfulclosebtn);
		verify.elementTextMatching(Keytransfersuccessfulreferencenumlabel,referno);
		verify.elementTextMatching(Keytransfersuccessfultransactiondatelabel,trandate);
		verify.elementTextMatching(Keytransfersuccessfulfromaccountlabel,fromacc);
		verify.elementTextMatching(Keytransfersuccessfultoaccountlabel,toacc);
		verify.elementTextMatching(Keytransfersuccessfulamountlabel,amt);
		//verify.elementTextMatching(Keytransfersuccessfuldatelabel,date);
		verify.elementIsPresent(Keytransfersuccessfulsharetool);
		
	}
	
	public void verifyTransferSuccessfulpagebuttons() throws ApplicationException
	{
		swipe.swipeVertical(2,0.90,0.10,1);			
		verify.elementIsPresent(Keytransfersuccessfulgotodashboardbtn);
		verify.elementIsPresent(Keytransfersuccessfulnewtransactionbtn);		
		swipe.swipeVertical(2,0.10,0.90,1);
	}
	
	
	public void verifyTransferSuccessfulPageBasicDetails(String saccname,String raccname,String saccno,
	String raccno,String amt,String idate,String ifreq,String iend,String imessage) throws ApplicationException, InterruptedException
	{
				
		click.elementBy(Keytransfersuccessfulaccnumber,2);
		verify.elementTextMatching(Keytransfersuccessfulaccname,1,saccname);			
		verify.elementTextMatching(Keytransfersuccessfulaccname,2,raccname);
		verify.elementTextMatching(Keytransfersuccessfulaccnumber,3,raccno);
		verify.elementTextMatching(Keytransfersuccessfulaccnumber,2,saccno);
					
		verify.elementTextMatching(Keytransfersuccessfulamount,amt);
		
		verify.elementTextMatching(Keytransfersuccessfuldate,1,idate);
		verify.elementTextMatching(Keytransfersuccessfuldate,2,ifreq);
		verify.elementTextMatching(Keytransfersuccessfuldate,3,iend);
		verify.elementTextMatching(Keytransfersuccessfuldate,4,imessage);
		
				
	}
	

	public void clickGoToDashboard() throws ApplicationException
	{
		swipe.swipeVertical(2,0.8,0.2,5);
		Wait.forSeconds(2);
		click.elementBy(Keytransfersuccessfulgotodashboardbtn);
		
	}
	
	public void clickNewTransaction() throws ApplicationException
	{
		swipe.swipeVertical(2,0.9,0.3,1);
		swipe.swipeVertical(2,0.9,0.3,1);
		click.elementBy(Keytransfersuccessfulnewtransactionbtn);
		
	}
	
	public void clickCloseBtn() throws ApplicationException
	{
		click.elementBy(Keytransfersuccessfulclosebtn);
	}
	
	/*public String getRefernenceNumber() throws ApplicationException
	{
		get.elementBy(Keytransfersuccessfulreferencenum, 1);
	}*/


			
       public void storetheTransferRefNo() throws ApplicationException {



		   if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

			   TransferDetailsPage.ReferenceNo = driver.findElement(By.xpath("(//android.widget.TextView[@index=2])[1]")).getText();
			   //System.out.println(ref);
			   //	TransferDetailsPage.ReferenceNo=get.elementgetTextBy("Keytransfersuccessfulreferencenum");
			   Wait.forSeconds(5);

		   }

		   else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

			   TransferDetailsPage.ReferenceNo = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name='Reference Number']/following-sibling::XCUIElementTypeStaticText")).getText();
			   Wait.forSeconds(5);
		   }
	}



}

