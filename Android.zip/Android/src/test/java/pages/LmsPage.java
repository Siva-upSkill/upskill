package pages;

import actions.Wait;
import base.Keywords;
import helper.PropertyReader;

import static helper.PropertyReader.testDataOf;

public class LmsPage extends Keywords {


    private String SelectCard = "onlineBanking.LMS.SelectCard";
    private String SelectCardData = testDataOf("LMS_Card");
    private String AccountDetailsPage = "onlineBanking.LMS.AccountDetailsPage";
    private String RedeemOption = "onlineBanking.LMS.RedeemOption";
    private String AmountTxtBox = "onlineBanking.LMS.AmountTxtBox";
    private String IncrementInlineMessage = "onlineBanking.LMS.IncrementInlineMessage";
    private String NextBtn = "onlineBanking.LMS.NextBtn";
    private String RedeemButton = "onlineBanking.LMS.RedeemButton";
    private String ReviewAndRedeemPage = "onlineBanking.LMS.ReviewAndRedeemPage";
    private String SuccessMessage = "onlineBanking.LMS.SuccessMessage";
    private String BackToDashboard = "onlineBanking.LMS.BackToDashBoard";
    private String MinimumAmountErrorMessage = "onlineBanking.LMS.MinimumAmountErrorMessage";
    private String EditBtn = "onlineBanking.LMS.EditButton";
    private String CancelBtn = "onlineBanking.LMS.CancelButton";
    private String CancelRedemptionBtn = "onlineBanking.LMS.CancelRedemptionButton";


    public void SelectCard() throws Throwable {
        Wait.forSeconds(5);
       // click.elementBy(SelectCard,SelectCardData);
        click.elementBy(SelectCard);
    }

    public void ClickRedeem() throws Throwable {
        Wait.forSeconds(3);
        verify.elementIsPresent(AccountDetailsPage);
        Wait.forSeconds(7);
        swipe.scrollDownToTextandClick("Redeem");

        //click.elementBy(RedeemOption);
    }

    public void EnterAmount() throws Throwable {
        Wait.forSeconds(3);
        type.data(AmountTxtBox, PropertyReader.testDataOf("LMS_Amount"));
    }

    public void ClickNext() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(NextBtn);

    }

    public void VerifyNavigationToReviewPage() throws Throwable {
        Wait.forSeconds(3);
        verify.elementIsPresent(ReviewAndRedeemPage);
    }
    public void ClickRedeemBtn() throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(RedeemButton);

    }
    public void VerifySuccessMessage() throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(SuccessMessage);
    }
    public void ClickBackToDashBoard() throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(BackToDashboard);
    }
    public void VerifyIncrementInlineMessage() throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(IncrementInlineMessage);
    }
    public void EnterInvalidAmount() throws Throwable{
        Wait.forSeconds(7);
        type.data(AmountTxtBox, PropertyReader.testDataOf("LMS_InvalidAmount"));

    }
    public void VerifyErrorMessage() throws Throwable{
        Wait.forSeconds(7);
        verify.elementIsPresent(MinimumAmountErrorMessage);

    }
    public void ClickEdit() throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(EditBtn);
    }
    public void EnterNewAmount() throws Throwable{
        Wait.forSeconds(2);
        type.data(AmountTxtBox, PropertyReader.testDataOf("LMS_NewAmount"));
    }
    public void ClickCancel() throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(CancelBtn);
    }
    public void ClickCancelRedemption() throws Throwable{
        Wait.forSeconds(3);
        click.elementBy(CancelRedemptionBtn);
    }

}


