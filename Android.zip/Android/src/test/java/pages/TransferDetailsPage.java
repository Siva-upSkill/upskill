package pages;

import actions.*;
import driver.DriverManager;
import helper.PropertyReader;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import base.Keywords;
import exceptions.ApplicationException;

import java.text.ParseException;


public class TransferDetailsPage extends Keywords {
    private static Logger log=Logger.getLogger(Verify.class);

    private String Keytransferdetailpagetitle = "convergent.TransferDetails.title";
    private String Keytransferdetailenteramt = "convergent.TransferDetails.enteramt";
    private String Keytransferdetailenteramtedit = "convergent.TransferDetails.enteramtedit";
    private String Keytransferdetaildefaultamtval = "convergent.TransferDetails.enteramtdefaultvalue";
    private String Keytransferdetailrepeatmsgbox = "convergent.TransferDetails.repeattxtbox";
    private String Keytransferdetailamterrormsg = "convergent.TransferDetails.amterrormsg";
    private String Keytransferdetailpurposeerrormsg = "convergent.TransferDetails.purposeerrormsg";
    private String Keytransferdetailtooglebtn = "convergent.TransferDetails.togglebtn";
    private String Keytransferdetailselectfrequency = "convergent.TransferDetails.selectfrequency";
    private String SelectDateWeekly="convergent.TransferDetails.SelectDateWeekly";
    private String Keytransferdetailselectendrepeat = "convergent.TransferDetails.selectendrepeat";
    private String Keytransferdetailselectfrequencyoption = "convergent.TransferDetails.selectfrequencyoption";

    private String selectfrequencyoptionEvery6Months = "convergent.TransferDetails.selectfrequencyoptionEvery6Months";
    private String selectfrequencyoptionQuarterly = "convergent.TransferDetails.selectfrequencyoptionQuarterly";

    private String selectfrequencyoptionMonthly = "convergent.TransferDetails.selectfrequencyoptionMonthly";

    private String selectfrequencyoptionAnnually = "convergent.TransferDetails.selectfrequencyoptionAnnually";

    private String Keytransferdetailreviewmessagetxtbox = "convergent.TransferDetails.remarkmessagetext";
    private String Keytransferdetailnextbtn = "convergent.TransferDetails.nextbtn";
    private String Keytransferdetaildonebtn = "convergent.TransferDetails.donebtn";
    private String Keytransferdetailbackbtn = "convergent.TransferDetails.backbtn";
    private String Keytransferdetaildate = "convergent.TransferDetails.transactiondate";
    private String Keytransferdetaildatepicker = "convergent.TransferDetails.datepickerlayout";
    private String KeytransferdetaildatepickerOkBtn = "convergent.TransferDetails.datepickerokBtn";
    private String KeytransferdetaildatepickerCancelBtn = "convergent.TransferDetails.datepickercancelBtn";
    private String Keytransferdetailleavepurposetxt = "convergent.TransferDetails.leaveapurposetxt";
    private String Keytransferdetailselectpurpose = "convergent.TransferDetails.selectpurpose";
    private String Keytransactiondateyear = "convergent.TransferFromPage.transactiondateyear";
    private String Keytransferdetaildateval="convergent.TransferDetails.transactiondatevalue";
    private String Keytransferdetailselectpurposeinstapay="convergent.TransferDetails.selectpurposeinstapay";
    private String Keydashboradviewmoreirstelement="convergent.Dashboard.viewmore.firstelement";
    private String Keydashboradviewmore="convergent.Dashboard.viewmore";
    private String KeyTxnhistory1stelement="convergent.Dashboard.Txnhistory1stelement";
    private String KeydashboradEndingbalance="convergent.Dashboard.Endingbalance";
    private String Keydashboradcloseicon="convergent.Dashboard.closeicon";
    private String Keydashboraddescription="convergent.Dashboard.Description";
    private String Keydashboradreferencenumber= "convergent.Dashboard.ReferenceNumber";
    private String Keydashboradtransferamount="convergent.Dashboard.Transferamount";
    private String Keytransferdetailsdone="convergent.TransferDetails.done";
    private String KeyAmountError="convergent.TransferDetails.AmountError";
    private String KeyAmountisgreaterthanbalanceError="convergent.pddtspddtspage.lblerrormessageamountisgreater";
    private String Keycommonerrormsg="convergent.request_payment_amount.labelAmountExceedsLimit";
    private String KeyremittanceFname="convergent.Remittanccenterreceipientpage.txtfname";
    private String KeyremittanceLname="convergent.Remittanccenterreceipientpage.txtlname";
    private String Keyremittanceemail="convergent.Remittanccenterreceipientpage.txtemailid";
    private String KeyremittanceFnameerror="convergent.Remittanccentertransfersendnoneypage.lblFirstnameerror";
    private String KeyremittanceLnameerror="convergent.Remittanccentertransfersendnoneypage.lblLastnameerror";
    private String Keyremittanceburthdate="convergent.Remittanccenterreceipientpage.btnbirthdate";
    private String Keyremittanceburthdateok="convergent.Remittanccenterreceipientpage.btnbirthdateok";
    private String Keyremittancenationality="convergent.Remittanccenterreceipientpage.txtnantionality";
    private String Keyremittancemobile="convergent.Remittanccenterreceipientpage.txtmobilenumber";
    private String Keyremittancefilipno="convergent.Remittanccenterreceipientpage.lblfilipno";
    private String Keytransfertounitnotxt="convergent.pddts.pddtspage.txtunithouseno";
    private String Keytransfertobuildingtxt="convergent.pddts.pddtspage.txtbuilding";
    private String Keytransfertovillagetxt="convergent.pddts.pddtspage.txtvillage";
    private String Keytransfertounitnolblerror="convergent.Remittanccentertransfersendnoneypage.lblunitnoerror";
    private String Keytransfertobuildinglblerror= "convergent.Remittanccentertransfersendnoneypage.lblStreetnameerror";
    private String Keytransfertovillagelblerror="convergent.Remittanccentertransfersendnoneypage.lblVillageerror";
    private String Keyremittancecenterlblinprocess="convergent.Remittanccentertransactiondetail.lblinprocess";
    private String Keyremittancecenterlblfailed="convergent.Remittanccentertransactiondetail.lblfailed";
    private String Keyremittancecenterlblamount="convergent.Remittanccentertransactiondetail.lblAmount";
    private String KeyremittancecenterlblFee="convergent.Remittanccentertransactiondetail.lblFee";
    private String Keyremittancecenterlblpurpose="convergent.Remittanccentertransactiondetail.lblpurpose";
    private String Keyremittancecenterlblname="convergent.Remittanccentertransactiondetail.lblName";
    private String KeyremittancecenterlblNationality="convergent.Remittanccentertransactiondetail.lblNationality";
    private String Keyremittancecenterlblmobileno="convergent.Remittanccentertransactiondetail.lblMobileno";
    private String Keyremittancecenterlblmailid="convergent.Remittanccentertransactiondetail.lblEmailid";
    private String KeyremittancecenterlblAddress="convergent.Remittanccentertransactiondetail.lblAddress";
    private String KeyBtnNext3 ="convergent.TransferTopageinstapay2.BtnNext";
    String KeyNext = "convergent.Pesonet.btnnext";

    private String selectfrequencyoptionEvery2Weeks="convergent.TransferDetails.selectfrequencyoptionEvery2weeks";

    public static String Balance;
    public static String ReferenceNo;
    public double temp;
    public String temp2;

    public void verifyTransferDetailsPageTile(String ititle) throws ApplicationException {
        //verify.elementTextMatching(Keytransferdetailpagetitle, ititle);
        Wait.forSeconds(4);
        verify.elementIsPresent(Keytransferdetailpagetitle);
    }
    public void enterTransferAmt(String idata) throws ApplicationException, InterruptedException {
        //verify.elementTextMatching(Keytransferdetailenteramt, idata);
        Wait.forSeconds(3);
//        Wait.waituntillElementVisibleMob(Keytransferdetailenteramt,3);
        click.elementBy(Keytransferdetailenteramt);
        type.data1(Keytransferdetailenteramt, idata);
        //get.elementBy(Keytransferdetailenteramt).sendKeys(Keys.TAB);
    }

    public void verifyAmterrorInTransferDetails(String idata) throws ApplicationException {
        verify.elementTextMatching(KeyAmountError, idata);
    }

    public void enterTransferAmtEditIOS(String idata) throws ApplicationException {
        //verify.elementTextMatching(Keytransferdetailenteramt, idata);
        type.data(Keytransferdetailenteramtedit, idata);
    }

    public void entereditTransferAmt(String idata) throws ApplicationException {
        //verify.elementTextMatching(Keytransferdetailenteramt, idata);
        //click.elementBy(By.id("Amount (PHP)*"));

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            type.data(Keytransferdetailenteramt, idata);
        }
        if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name='Amount (PHP)*']/parent::*/following-sibling::XCUIElementTypeTextField")).click();
            driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name='Amount (PHP)*']/parent::*/following-sibling::XCUIElementTypeTextField")).clear();
            type.data(By.xpath("//XCUIElementTypeStaticText[@name='Amount (PHP)*']/parent::*/following-sibling::XCUIElementTypeTextField"),idata);
            //driver.findElement(By.xpath("(//XCUIElementTypeTextField)[1]")).click();
            //type.data(Keytransferdetailenteramt, idata);
        }
    }
    public void checkDefaultTransferAmtval() throws ApplicationException {
        verify.ElementTextByAttribute(Keytransferdetaildefaultamtval, "0.00*", "text");
    }

    public void clickRepeatMsgbox() throws ApplicationException {
        click.elementBy(Keytransferdetailrepeatmsgbox);
    }

    public void verifyAmtErrorMsg(String ierror) throws ApplicationException {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            verify.elementTextMatching(Keytransferdetailamterrormsg, ierror);
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            verify.elementIsPresent(Keytransferdetailamterrormsg);

        }


    }

    public void turnONToggleBtn() throws ApplicationException {
        Wait.forSeconds(1);
        click.elementBy(Keytransferdetailtooglebtn);
    }

    public void verifyFrequencyElement(String ifrequency) throws ApplicationException {
        verify.elementTextMatching(Keytransferdetailselectfrequency, ifrequency);
    }

    public void verifyEndRepeatElement(String iend) throws ApplicationException {
        verify.elementTextMatching(Keytransferdetailselectendrepeat, iend);
    }
    public void ClickEndDate() throws ApplicationException {
        click.elementBy(Keytransferdetailselectendrepeat);
    }


    public void clickFrequencyElement() throws ApplicationException {
//        Wait.forSeconds(2);
        Wait.waituntillElementVisibleMob(Keytransferdetailselectfrequency,2);
        click.elementBy(Keytransferdetailselectfrequency);
    }
    public void SelectDateWeekly() throws ApplicationException {
        click.elementBy(SelectDateWeekly);
    }

    public void chooseSelectFrequency() throws ApplicationException {
        click.elementBy(Keytransferdetailselectfrequencyoption);
    }
    public void chooseSelectFrequencyEvery6Months() throws ApplicationException {

        click.elementBy(selectfrequencyoptionEvery6Months);
    }
    public void chooseSelectFrequencyMonth() throws ApplicationException {

        click.elementBy(selectfrequencyoptionMonthly);
    }
    public void chooseSelectFrequencyQuarterly() throws ApplicationException {

        click.elementBy(selectfrequencyoptionQuarterly);
    }
    public void chooseSelectFrequencyAnnually() throws ApplicationException {
        Wait.waituntillElementVisibleMob(selectfrequencyoptionAnnually,2);
        click.elementBy(selectfrequencyoptionAnnually);
    }
    public void chooseSelectFrequencyEvery2weeks() throws ApplicationException {

        Wait.waituntillElementVisibleMob(selectfrequencyoptionEvery2Weeks,2);
        click.elementBy(selectfrequencyoptionEvery2Weeks);
    }
    public void chooseSelectFrequencyios(String ifrequency) throws ApplicationException {

        if(ifrequency.equalsIgnoreCase("weekly")) {
            Touch.pressByCoordinates(385, 564, 5);
        }
        else if(ifrequency.equalsIgnoreCase("every 2 weeks")) {
            Touch.pressByCoordinates(385, 595, 5);
        }
        else if(ifrequency.equalsIgnoreCase("monthly")) {
            Touch.pressByCoordinates(385, 564, 5);
            Touch.pressByCoordinates(385, 595, 5);
        }
        else if(ifrequency.equalsIgnoreCase("quarterly")) {
            Touch.pressByCoordinates(385, 564, 5);
            Touch.pressByCoordinates(385, 564, 5);
            Touch.pressByCoordinates(385, 595, 5);
        }
        else if(ifrequency.equalsIgnoreCase("semi-annually")) {
            Touch.pressByCoordinates(385, 564, 5);
            Touch.pressByCoordinates(385, 564, 5);
            Touch.pressByCoordinates(385, 564, 5);
            Touch.pressByCoordinates(385, 595, 5);
        }
        else if(ifrequency.equalsIgnoreCase("annually")) {
            Touch.pressByCoordinates(385, 564, 5);
            Touch.pressByCoordinates(385, 564, 5);
            Touch.pressByCoordinates(385, 564, 5);
            Touch.pressByCoordinates(385, 564, 5);
            Touch.pressByCoordinates(385, 595, 5);
        }
    }
    public void enterRemarkMessageText(String itext) throws ApplicationException {
        swipe.swipeVertical(2, 0.8, 0.2, 5);
        if (itext.length() <= 256) {
            type.data(Keytransferdetailreviewmessagetxtbox, itext);
        } else if (itext.length() == 256) {
            type.data(Keytransferdetailreviewmessagetxtbox, itext);
        } else if (itext.length() >= 256) {
            type.data(Keytransferdetailreviewmessagetxtbox, itext);
        } else {
            new ApplicationException("input remark message is not less than 256 characters");
        }
    }

    public void verifyRemarkMessageText(String itextvalue) throws ApplicationException {
        verify.elementTextMatching(Keytransferdetailreviewmessagetxtbox, itextvalue);
    }

    public void clickNextBtn() throws ApplicationException, InterruptedException {
        Wait.waituntillElementVisibleMob(Keytransferdetailnextbtn,2);
        click.elementBy(Keytransferdetailnextbtn);
    }

    public void clickDoneBtn() throws ApplicationException, InterruptedException {
        //Thread.sleep(200);
        click.elementBy(Keytransferdetaildonebtn);
    }

    public void verifyDoneBtn(String expectedval) throws ApplicationException, InterruptedException {

        verify.elementTextMatching(Keytransferdetaildonebtn, expectedval);
    }

    public void clickBackBtn() throws ApplicationException {
        Wait.forSeconds(1);
        click.elementBy(Keytransferdetailbackbtn);
    }

    public void checkNextButtonDisabled() throws ApplicationException {
        try {
            verify.elementIsDisabled(Keytransferdetailnextbtn);
        }
        catch(Exception e){
            verify.elementIsDisabled(KeyBtnNext3);


        }
    }

    public void checkNextButtonDisabledIOS() throws ApplicationException {
        verify.elementIsDisabled(KeyNext);
    }
    /////////////////////////////

    public void clickTransactionDate() throws ApplicationException, InterruptedException {
        //click.elementBy(Keytransferdetaildate);

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            click.elementBy(Keytransferdetaildate);
        }
        if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            Touch.pressByCoordinates(325, 215, 5);
            Wait.forSeconds(10);
        }

    }

    public void choosetransactiondate(String date) throws ApplicationException {
        //verify.verifyTransactionDate(year, month, day);
        //click.chooseTransactionDate(year, month, day);
        click.pickdatefromcalendar(date);

    }

    public void clickDatePickerOkBtn() throws ApplicationException, InterruptedException {
        click.elementBy(KeytransferdetaildatepickerOkBtn);

    }

    public void verifyDatePicker() throws ApplicationException, InterruptedException {
        verify.elementIsPresent(Keytransferdetaildatepicker);
        verify.elementIsPresent(KeytransferdetaildatepickerCancelBtn);
        verify.elementIsPresent(KeytransferdetaildatepickerOkBtn);
    }

    public void verifyTransactionDate(String idate) throws ApplicationException, InterruptedException,ParseException {

        /*
        String idatenew=helper.Tools.gettodaysDateInFormat();
        idatenew=idatenew.substring(Math.max(0,idatenew.length()-4));
        //idatenew=idatenew+idate;

         */
        String data = get.elementgetTextBy(Keytransferdetaildate);
        String year[] = data.split(",");
        String actualYear = year[1].trim();
        if(DriverManager.OS.equalsIgnoreCase("ANDROID"))
        {
           try
           {
               verify.isMatching(idate,actualYear);
           }
           catch (Exception ex){
               log.error(ex);
               throw new ApplicationException(ex.getMessage());
           }

        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS"))
        {
          //  verify.elementTextMatching(Keytransferdetaildateval, idatenew.trim());
        }

    }


    public void verifyleavepurposetxt() throws ApplicationException, InterruptedException {
        verify.elementIsPresent(Keytransferdetailleavepurposetxt);
    }

    public void verifypurposeerrormsg(String purposeerr) throws ApplicationException, InterruptedException {
        verify.elementTextMatching(Keytransferdetailpurposeerrormsg, purposeerr);
    }

    public void verifyamterrormsg(String amterr) throws ApplicationException, InterruptedException {
        verify.elementTextMatching(Keytransferdetailpurposeerrormsg, amterr);
    }

    public void clicktransferpurpose() throws ApplicationException, InterruptedException {
        click.elementBy(Keytransferdetailselectpurpose);
    }
    public void clicktransferpurposeinstpay() throws ApplicationException, InterruptedException {
        click.elementBy(Keytransferdetailselectpurposeinstapay);
    }
    public void clicktransferpurposeIOS() throws ApplicationException, InterruptedException {
        //click.elementBy(Keytransferdetailselectpurpose);
        actions.Touch.pressByCoordinates(170, 250, 5);
    }

    public void clickTransferAmt() throws ApplicationException {
        click.elementBy(Keytransferdetailenteramt);
    }

    public void verifyTransactionfutureDate(String idate) throws ApplicationException {
        //DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        verify.elementTextContains(Keytransferdetaildate, idate);
        //elementTextMatching(Keytransferdetaildate, idate);

    }

    public void choosefuturetransctiondate(String year) throws ApplicationException {
        Wait.waituntillElementVisibleMob(Keytransactiondateyear,2);
        click.elementBy(Keytransactiondateyear);
        swipe.scrollDownToTextandClick(year);
    }

    public void choosetransactiondate(String year, String month, String day) throws ApplicationException {
        //verify.verifyTransactionDate(year, month, day);
        click.chooseTransactionDate(year, month, day);
    }

	/*
	public void verifyRemarkMessageTextlessthan256() throws ApplicationException
	{
		ResourceBase.PERFORM.verifyElementText(Keytransferdetailreviewmessagetxtbox, testdata.propertyValue("less_than_256_characters"));
	}

	public void verifyRemarkMessageTextequal256() throws ApplicationException
	{
		ResourceBase.PERFORM.verifyElementText(Keytransferdetailreviewmessagetxtbox, testdata.propertyValue("equal_to_256_characters"));
	}

	public void verifyRemarkMessageTextgreaterthan256() throws ApplicationException
	{

		ResourceBase.PERFORM.verifyElementText(Keytransferdetailreviewmessagetxtbox, testdata.propertyValue("greater_than_256_characters").substring(0,256));
	}
	 */


    public void storetheEndbalance() throws ApplicationException {

        Wait.forSeconds(5);
        swipe.scrollDownToTextandClick(PropertyReader.testDataOf("Other_Recipient_AccountTxnhistory"));
        Wait.forSeconds(5);
        Swipe.swipe.swipeVertical(2,.8,.2,5);
        Wait.forSeconds(6);
        click.elementBy(Keydashboradviewmore);
        Wait.waituntillElementVisibleMob(Keydashboradviewmoreirstelement,3);
        //swipe.scrollDownToTextandClick(PropertyReader.testDataOf("Other_Recipient_AmounTxnhistory"));
        click.elementBy(Keydashboradviewmoreirstelement);
        Wait.waituntillElementVisibleMob(KeydashboradEndingbalance,4);
        Balance=get.elementgetTextBy(KeydashboradEndingbalance);
        Wait.waituntillElementVisibleMob(Keydashboradcloseicon,3);
        click.elementBy(Keydashboradcloseicon);
        click.elementBy(Keydashboradcloseicon);
        click.elementBy(Keydashboradcloseicon);

    }

    public void verifyinTxnhistory(double transferamount,String fundtransfertype) throws ApplicationException {

        Wait.forSeconds(10);
        temp2=Double.toString(transferamount);
        Balance=Balance.replace("PHP","");
        Balance=Balance.replace(",","");
        Balance= Balance.trim();
        temp = Double.parseDouble(Balance);
        temp=temp-transferamount;
        if(fundtransfertype.equalsIgnoreCase("OWNACCOUNT")) {
            temp = temp - 0.00;
        }
        if(fundtransfertype.equalsIgnoreCase("EONACCOUNT")) {
            temp = temp - 0.00;
        }
        if(fundtransfertype.equalsIgnoreCase("UBPACCOUNT")) {
            temp = temp - 0.00;
        }
        Balance=Double.toString(temp);
        temp2=Double.toString(transferamount);
        swipe.scrollDownToTextandClick(PropertyReader.testDataOf("Other_Recipient_AccountTxnhistory"));
        Wait.forSeconds(10);
        Swipe.swipe.swipeVertical(2,.8,.2,5);
        click.elementBy(Keydashboradviewmore);
        Wait.waituntillElementVisibleMob(Keydashboradviewmoreirstelement,10);
        //swipe.scrollDownToTextandClick(PropertyReader.testDataOf("Other_Recipient_AmounTxnhistory"));
        click.elementBy(Keydashboradviewmoreirstelement);
        Wait.waituntillElementVisibleMob(Keydashboradreferencenumber,3);

        verify.elementTextContains(Keydashboradreferencenumber,ReferenceNo);
        //verify.elementtrimTextContains(KeydashboradEndingbalance,Balance);
        //verify.elementTextContains(Keydashboradtransferamount,temp2);
        //verify.elementTextContains(Keydashboraddescription,PropertyReader.testDataOf("Txn_Description"));
        //click.elementBy(Keydashboradcloseicon);
        //click.elementBy(Keydashboradcloseicon);
        //click.elementBy(Keydashboradcloseicon);
    }
    public void clickTransferfrequencydone() throws ApplicationException, InterruptedException {
        click.elementBy(Keytransferdetailsdone);
    }

    public void verifyAmtisgreaterthanaccountbalanceErrorMsg(String ierror) throws ApplicationException {

        //verify.elementTextMatching(KeyAmountisgreaterthanbalanceError, ierror);
        verify.elementIsPresent(KeyAmountisgreaterthanbalanceError);
    }

    public void verifytransferdetailsErrorMsg(String ierror) throws ApplicationException {

        //verify.elementTextMatching(Keycommonerrormsg, ierror);
        verify.elementIsPresent(Keycommonerrormsg);
    }
    public void blankremittancerecipientdetails() throws ApplicationException {

        click.elementBy(KeyremittanceFname);
        click.elementBy(KeyremittanceLname);
        click.elementBy(KeyremittanceFname);
    }

    public void verifyRemittanccenterrecpientnameErrorMsg(String Fname,String Lname) throws ApplicationException {

        //verify.elementTextMatching(KeyremittanceFnameerror, Fname);
        //verify.elementTextMatching(KeyremittanceLnameerror, Lname);
        verify.elementIsPresent(KeyremittanceFnameerror);
        verify.elementIsPresent(KeyremittanceLnameerror);
    }
    public void enteremittanccenterrecpientdetails(String Fname,String Lname,String nationality) throws ApplicationException {

        type.data(KeyremittanceFname,Fname);
        type.data(KeyremittanceLname,Lname);
        click.elementBy(Keyremittanceburthdate);
        click.elementBy(Keyremittanceburthdateok);
        click.elementBy(Keyremittancenationality);
        click.elementBy(Keyremittancefilipno);
        //swipe.scrollDownToTextandClick(nationality);
    }

    public void enteremittanccenterrecpientdetailsmobileandenail(String mobile,String email) throws ApplicationException {

        type.data(Keyremittancemobile,mobile);
        //type.data(Keyremittanceemail,email);

    }

    public void blankremittancerecipientaddressdetails() throws ApplicationException {

        click.elementBy(Keytransfertounitnotxt);
        click.elementBy(Keytransfertobuildingtxt);
        click.elementBy(Keytransfertovillagetxt);
        click.elementBy(Keytransfertounitnotxt);
    }
    public void verifyRemittanccenterrecpientaddressErrorMsg(String unitno,String Streetname,String Village) throws ApplicationException {

        //verify.elementTextMatching(Keytransfertounitnolblerror, unitno);
        verify.elementIsPresent(Keytransfertounitnolblerror);
        //verify.elementTextMatching(Keytransfertobuildinglblerror, Streetname);
        verify.elementIsPresent(Keytransfertobuildinglblerror);
        //verify.elementTextMatching(Keytransfertovillagelblerror, Village);
        verify.elementIsPresent(Keytransfertovillagelblerror);
    }
    public void verifyRemittanccenterHistorysection(String inprocess,String failed) throws ApplicationException {

       Wait.waituntillElementVisibleMob(Keyremittancecenterlblfailed,5);
        //verify.elementTextMatching(Keyremittancecenterlblinprocess, inprocess);
        //verify.elementIsPresent(Keyremittancecenterlblinprocess);
        //verify.elementTextMatching(Keyremittancecenterlblfailed, failed);
        verify.elementIsPresent(Keyremittancecenterlblfailed);
    }
    public void blankremittanceinprocess() throws ApplicationException {
        click.elementBy(Keyremittancecenterlblinprocess);
    }

    public void blankremittancefailed() throws ApplicationException {
        click.elementBy(Keyremittancecenterlblfailed);
    }

    public void verifyremittancetransactiondetails(String Amount,String Fee,String purpose,String Name,String Nationality,String Mobile,String Email,String Address) throws Throwable {
        swipe.swipeVertical(2,.2,.8,5);
       /*
        verify.elementTextMatching(Keyremittancecenterlblamount,Amount);
        verify.elementTextMatching(KeyremittancecenterlblFee,Fee);
        verify.elementTextMatching(Keyremittancecenterlblpurpose,purpose);
        verify.elementTextMatching(Keyremittancecenterlblname,Name);
        verify.elementTextMatching(KeyremittancecenterlblNationality,Nationality);
        verify.elementTextMatching(Keyremittancecenterlblmobileno,Mobile);
        */
        verify.elementIsPresent(Keyremittancecenterlblamount);
        swipe.swipeVertical(2,.2,.8,5);

        swipe.swipeVertical(2,.2,.8,5);

        swipe.swipeVertical(2,.2,.8,5);


        swipe.swipeVertical(2,.2,.8,5);

        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        //verify.elementIsPresent(KeyremittancecenterlblFee);
        verify.elementIsPresent(Keyremittancecenterlblpurpose);
        //verify.elementIsPresent(Keyremittancecenterlblname);
        //verify.elementIsPresent(KeyremittancecenterlblNationality);
        //verify.elementIsPresent(Keyremittancecenterlblmobileno);
       // swipe.swipeVertical(2,.8,.2,5);
        //verify.elementTextMatching(Keyremittancecenterlblmailid,Email);
        //verify.elementTextMatching(KeyremittancecenterlblAddress,Address);
       // swipe.swipeVertical(2,.2,.8,5);
    }

}