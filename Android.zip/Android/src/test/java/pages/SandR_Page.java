package pages;

import actions.Touch;
import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import helper.PropertyReader;

import static helper.PropertyReader.testDataOf;

public class SandR_Page extends Keywords {
    private String SandRCard  = "onlineBanking.S&R.SelectCard";
    private String SandRCardData = testDataOf("SandR_Card");
    private String RedeemBtn = "onlineBanking.S&R.RedeemBtn";
    private String MembershipShopping = "onlineBanking.S&R.MembershipShopping";
    private String ContinueBtn = "onlineBanking.S&R.ContinueBtn";
    private String ProceedWithRedemption = "onlineBanking.S&R.ProceedWithRedemption";
    private String SuccessMsg = "onlineBanking.S&R.SuccessMsg";
    private String BackToDashBoard = "onlineBanking.S&R.BackToDashboardBtn";
    private String BackBtn="onlineBanking.S&R.BackBtn";
    private String ViewAll="onlineBanking.S&R.Viewall";
    private String ViewVoucherWallet = "onlineBanking.S&R.ViewVoucherwalletLink";
    private String AvailableOption = "onlineBanking.S&R.Available";
    private String ArrowDown = "onlineBanking.S&R.ArrowDown";
    private String OpenGiftBtn = "onlineBanking.S&R.OpenGiftBtn";
    private String Congratulations = "onlineBanking.S&R.CongratulationsMessage";
    private String TermsAndConditions = "onlineBanking.S&R.TermsAndConditions";
    private String SelectVoucher = "onlineBanking.S&R.SelectVoucher";
    private String CloseBtn = "onlineBanking.S&R.CloseBtn";
    private String AddIcon = "onlineBanking.S&R.AddIcon";
    private String QuantityTxtBox = "onlineBanking.S&R.QuantityTextBox";
    private String CancelBt = "onlineBanking.S&R.CancelBtn";
    private String Edit = "onlineBanking.S&R.EditBtn";

    private String CloseBtnAdd = "convergent.login.PopUpClose";

    public void ClickSandRCard() throws Throwable{
        Wait.waituntillElementVisibleMob(SandRCard,2);
//        try{
//            if(CloseBtnAdd == CloseBtnAdd)
//            {
//                click.elementBy(CloseBtnAdd);
//            }
//        }
//        catch (ApplicationException e) {
//            e.printStackTrace();
//        }
        click.elementBy(SandRCard,SandRCardData);
    }
    public void ClickRedeemBtn() throws Throwable{
        Wait.waituntillElementVisibleMob(RedeemBtn,2);
        swipe.swipeVertical(2, 0.8, 0.4, 5);
        swipe.swipeVertical(2, 0.8, 0.4, 5);
        click.elementBy(RedeemBtn);
    }
    public void ClickMemberShoppingBtn() throws Throwable{
        Wait.waituntillElementVisibleMob(MembershipShopping,3);
        click.elementBy(MembershipShopping);
    }
    public void ClickToVoucher() throws Throwable{
        Wait.waituntillElementVisibleMob(SelectVoucher,3);
        click.elementBy(SelectVoucher);

    }
    public void ClickContinue() throws Throwable{
        Wait.waituntillElementVisibleMob(ContinueBtn,3);
        click.elementBy(ContinueBtn);
    }
    public void ClickProccedWithRedeem() throws Throwable{
        Wait.waituntillElementVisibleMob(ProceedWithRedemption,3);
        click.elementBy(ProceedWithRedemption);
    }
    public void VerifySuccessMsg() throws Throwable{
        Wait.waituntillElementVisibleMob(SuccessMsg,3);
        verify.elementIsPresent(SuccessMsg);
        click.elementBy(BackToDashBoard);
        Wait.waituntillElementVisibleMob(BackBtn,3);
        click.elementBy(BackBtn);
    }
    public void VoucherWalletInDashBoard() throws Throwable{
        Wait.waituntillElementVisibleMob(ViewAll,3);
        click.elementBy(ViewAll);
        Wait.waituntillElementVisibleMob(ViewVoucherWallet,3);
        click.elementBy(ViewVoucherWallet);
        click.elementBy(AvailableOption);
    }
    public void ClickToDownArrowAndPressOpenGift() throws Throwable{
        Wait.waituntillElementVisibleMob(ArrowDown,3);
        click.elementBy(ArrowDown);
        click.elementBy(OpenGiftBtn);
        Wait.waituntillElementVisibleMob(OpenGiftBtn,3);
        click.elementBy(OpenGiftBtn);

    }
    public void VerifyCongratulationsMessageAndTermsAndConditions() throws Throwable{
       Wait.waituntillElementVisibleMob(Congratulations,3);
        verify.elementIsPresent(Congratulations);
        verify.elementIsPresent(TermsAndConditions);
    }
    public void CloseBtn() throws Throwable{
     Wait.forSeconds(2);
     click.elementBy(CloseBtn);
    }
    public void ClickAddIcon() throws Throwable{
        Wait.forSeconds(2);
        actions.Touch.pressByCoordinates(311, 1884, 5);
//        click.elementBy(AddIcon);
//        click.elementBy(AddIcon);
    }
    public void EnterQuantity() throws Throwable{
        Wait.waituntillElementVisibleMob(QuantityTxtBox,3);
        type.data(QuantityTxtBox, PropertyReader.testDataOf("SandR_Quantity").trim());
    }
    public void ClickCancelBtn() throws Throwable{
        Wait.waituntillElementVisibleMob(CancelBt,3);
        click.elementBy(CancelBt);
    }
    public void ClickEditBtn() throws Throwable{
        Wait.waituntillElementVisibleMob(Edit,3);
        click.elementBy(Edit);
    }
}
