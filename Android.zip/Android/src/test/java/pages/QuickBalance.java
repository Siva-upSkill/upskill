package pages;

import base.Keywords;
import actions.Wait;
import exceptions.ApplicationException;


public class QuickBalance  extends Keywords {

    private String QuickBalance="onlineBanking.Dashboard.Quickbalance";
    private String Togglebtn="onlineBanking.QuickBalance.ToggleMsg";
    private String Switchbtn="onlineBanking.QuickBalance.SwitchBtn";
    private String PopupMsg="onlineBanking.QuickBalance.PopUpMsg";
    private String Yesbtn="onlineBanking.QuickBalance.YesBtn" ;
    private String Nobtn="onlineBanking.QuickBalance.NoBtn";
    private String  savebtn="onlineBanking.QuickBalance.SaveBtn";
    private String Offbtn="onlineBanking.QuickBalance.OffBtn";
    private String onbtn="onlineBanking.QuickBalance.OnBtn";
    private String Gotosettings="onlineBanking.QuickBalance.GoToSettings";
    private String viewDashboard="onlineBanking.QuickBalance.ViewDashboard";
    private String homeQuickbalance="onlineBanking.Homescreen.QuickBalance";
    private String FeatureOn="onlineBanking.QuickBalance.Featureon";
    private String EnabledFeatures="onlineBanking.quickBalance.EnabledFeatures";
    private String BackBtn="onlineBanking.QuickBalance.BackBtn";
    private String VerifyMessage="onlineBanking.QuickBalance.VerifyMessage";


    public void Click_QuickBalance()throws Throwable {
        Wait.waituntillElementVisibleMob(QuickBalance,2);
        click.elementBy(QuickBalance);

    }
    public void verify_ToggleMsg() throws ApplicationException {
        Wait.waituntillElementVisibleMob(Togglebtn,2);
        verify.elementIsPresent(Togglebtn);
    }

    public void Click_SwitchBtn()throws Throwable {
        Wait.waituntillElementVisibleMob(Switchbtn,2);
        click.elementBy(Switchbtn);
    }
     public void verify_FeaturesEnabled()throws Throwable{
        Wait.waituntillElementVisibleMob(EnabledFeatures,2);
        verify.elementIsPresent(EnabledFeatures);
    }
    public void verify_HomequickBalance()throws Throwable{
        Wait.waituntillElementVisibleMob(homeQuickbalance,2);
        verify.elementIsPresent(homeQuickbalance);
    }
    public void verify_PopupMsg()throws Throwable{
        Wait.waituntillElementVisibleMob(PopupMsg,2);
        verify.elementIsPresent(PopupMsg);
    }
    public void Click_Yesbtn()throws Throwable{
        Wait.waituntillElementVisibleMob(Yesbtn,2);
        click.elementBy(Yesbtn);
    }
    public void Click_TurnOnFeature()throws Throwable{
        Wait.waituntillElementVisibleMob(FeatureOn,2);
        click.elementBy(FeatureOn);
    }
    public void verify_Savebtn()throws Throwable{
        Wait.waituntillElementVisibleMob(savebtn,2);
        verify.elementIsDisabled(savebtn);
    }
    public void Click_Savebtn()throws Throwable{
        Wait.waituntillElementVisibleMob(savebtn,2);
        click.elementBy(savebtn);
    }

    public void Click_Onbtn()throws Throwable{
        Wait.waituntillElementVisibleMob(onbtn,3);
        click.elementBy(onbtn);
    }
    public void verify_Toggleoffbtn()throws Throwable{
        Wait.waituntillElementVisibleMob(Offbtn,3);
        verify.elementIsPresent(Offbtn);
    }
    public void Click_Offbtn()throws Throwable{
        Wait.waituntillElementVisibleMob(Offbtn,3);
        click.elementBy(Offbtn);
        click.elementBy(savebtn);
    }
    public void verify_Options()throws Throwable{
        Wait.waituntillElementVisibleMob(viewDashboard,3);
       // verify.elementIsPresent(Gotosettings);
        verify.elementIsPresent(viewDashboard);
    }
    public void Click_nobtn()throws Throwable{
        Wait.waituntillElementVisibleMob(Nobtn,3);
        click.elementBy(Nobtn);
    }
    public void Click_GoSettings()throws Throwable{
    Wait.waituntillElementVisibleMob(Gotosettings,4);
    click.elementBy(Gotosettings);
    }

    public void Click_Backbtn()throws Throwable{
        Wait.waituntillElementVisibleMob(BackBtn,3);
        click.elementBy(BackBtn);
    }

     public void Click_Dashboard()throws Throwable{
        Wait.forSeconds(4);
         click.elementBy(viewDashboard);
    }
    public void Verify_Dashboard()throws Throwable {
        Wait.forSeconds(4);
        verify.elementIsPresent(viewDashboard);
    }
    public void Verify_Message()throws Throwable {
        Wait.waituntillElementVisibleMob(VerifyMessage,3);
        verify.elementIsPresent(VerifyMessage);
    }
}


