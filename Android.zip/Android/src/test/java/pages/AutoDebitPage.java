package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import static helper.PropertyReader.testDataOf;

public class AutoDebitPage extends Keywords {
    private String PlatinumCreditcard = "onlineBanking.ADA.PlatinumCreditcard";
    private String PlatinumCreditcard_View = "onlineBanking.ADA.PlatinumCreditcard_View";
    private String PayButton = "onlineBanking.ADA.PayButton";
    private String LastStatementBalance = "onlineBanking.ADA.LastStatementBalance";
    private String MinimumAmountDue = "onlineBanking.ADA.MinimumAmountDue";
    private String EnterCustomAmount = "onlineBanking.ADA.EnterCustomAmount";
    private String SetupAutoDebit = "onlineBanking.ADA.SetupAutoDebit";
    private String NextButton = "onlineBanking.ADA.NextButton";
    private String LastStatementBalanceLabel = "onlineBanking.ADA.LastStatementBalanceLabel";
    private String MinimumAmountDueLabel = "onlineBanking.ADA.MinimumAmountDueLabel";

    private String PayFromWhichAccount ="onlineBanking.ADA.PayFromWhichAccount";
    private String Reminder = "onlineBanking.ADA.Reminder";
    private String BillInformation = "onlineBanking.ADA.BillInformation";
    private String PayFrom = "onlineBanking.ADA.PayFrom";
    private String PaymentDetails = "onlineBanking.ADA.PaymentDetails";
    private String AcceptAndContinueCheckbox = "onlineBanking.ADA.Checkbox";

    private String ReminderReviewPage = "onlineBanking.ADA.ReminderReviewPage";
    private String SetupAutoDebitArrangement = "onlineBanking.ADA.SetupAutoDebitArrangement";
    private String ReceiveOTPViaSMS = "onlineBanking.ADA.ReceiveOTPViaSMS";
    private String OTPMessage = "onlineBanking.ADA.OTPMessage";
    private String ViewAutoDebit = "onlineBanking.ADA.ViewAutoDebit";
    private String AutoDebitDetails = "onlineBanking.ADA.AutoDebitDetails";
    private String UnionBankCard = "onlineBanking.ADA.UnionBankCard";
    private String MastercardCashbackPlatinumCredit = "onlineBanking.ADA.MastercardCashbackPlatinumCredit";
    private String PesoSavingsAccount = "onlineBanking.ADA.PesoSavingsAccount";

    public void clickOnPlatinumCredit() throws Throwable {
        Wait.forSeconds(5);
        AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.widget.TextView[@text=\"*6500\"]");
        element.click();
        //click.elementBy(PlatinumCreditcard);
    }
    public void clickOnPlatinumCredit_View() throws Throwable {
        Wait.forSeconds(4);
        AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.widget.TextView[@text=\"*9905\"]");
        element.click();
//        click.elementBy(PlatinumCreditcard_View);
    }
    public void verifyPayButton() throws Throwable {
        Wait.waituntillElementVisibleMob(PayButton,3);
        verify.IfElementExists(PayButton);
    }
    public void clickOnPayButton() throws Throwable {
        Wait.waituntillElementVisibleMob(PayButton,3);
//        AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.widget.Button[@text=\"PAY\"]");
//        element.click();
        swipe.swipeVertical(2, 0.3, 0.8, 5);
        swipe.swipeVertical(2, 0.6, .2, 2);
        click.elementBy(PayButton);

    }

    public void verifyAmountPayScreen() throws Throwable {
        Wait.waituntillElementVisibleMob(LastStatementBalance,3);
        verify.elementIsPresent(LastStatementBalance);
        verify.elementIsPresent(MinimumAmountDue);
        verify.elementIsPresent(EnterCustomAmount);
        verify.elementIsPresent(SetupAutoDebit);
    }
    public void verifyPaymentDetails() throws Throwable {
        Wait.waituntillElementVisibleMob(LastStatementBalanceLabel,3);
        verify.elementIsPresent(LastStatementBalanceLabel);
        verify.elementIsPresent(MinimumAmountDueLabel);
        //verify.elementIsPresent(Reminder);
    }
    public void clickOnSetupAutoDebit() throws Throwable {
        Wait.waituntillElementVisibleMob(SetupAutoDebit,4);
        click.elementBy(SetupAutoDebit);
    }
    public void verifyNextButton() throws Throwable {
        Wait.waituntillElementVisibleMob(NextButton,3);
        verify.elementIsDisabled(NextButton);
    }
    public void ClickNextButton() throws Throwable {
        Wait.waituntillElementVisibleMob(NextButton,4);
        click.elementBy(NextButton);
    }
    public void clickOnMinimumAmountDue() throws Throwable {
        Wait.waituntillElementVisibleMob(MinimumAmountDueLabel,3);
        click.elementBy(MinimumAmountDueLabel);
    }
    public void clickOnPayFromAccount() throws Throwable {
     Wait.waituntillElementVisibleMob(PayFromWhichAccount,4);
        click.elementBy(PayFromWhichAccount);
    }
    public void verifyReviewandRequestPage() throws Throwable {
        Wait.waituntillElementVisibleMob(BillInformation,4);
        verify.elementIsPresent(BillInformation);
        verify.elementIsPresent(PayFrom);
        verify.elementIsPresent(PaymentDetails);
        Wait.forSeconds(2);
        swipe.swipeVertical(2, 0.8, 0.2, 5);
        verify.elementIsPresent(ReminderReviewPage);
        verify.elementIsPresent(AcceptAndContinueCheckbox);
    }
    public void verifySetupAutoDebitArrangementButton() throws Throwable {
        Wait.waituntillElementVisibleMob(SetupAutoDebitArrangement,4);
        verify.elementIsDisabled(SetupAutoDebitArrangement);
    }
    public void clickOnAcceptAndContinue() throws Throwable {
        Wait.waituntillElementVisibleMob(AcceptAndContinueCheckbox,5);
        click.elementBy(AcceptAndContinueCheckbox);
    }
    public void clickOnSetupAutoDebitArrangementButton() throws Throwable {
        Wait.waituntillElementVisibleMob(SetupAutoDebitArrangement,4);
        click.elementBy(SetupAutoDebitArrangement);
    }
    public void verifyOtpScreen() throws Throwable {
        Wait.waituntillElementVisibleMob(OTPMessage,4);
        verify.elementIsPresent(OTPMessage);
    }
    public void verifyViewAutoDebit() throws Throwable {
        Wait.waituntillElementVisibleMob(ViewAutoDebit,4);
        verify.elementIsPresent(ViewAutoDebit);
    }
    public void clickViewAutoDebit() throws Throwable {
        Wait.waituntillElementVisibleMob(ViewAutoDebit,4);
        click.elementBy(ViewAutoDebit);
    }
    public void verifyAutoDebitDetailsPage() throws Throwable {
        Wait.waituntillElementVisibleMob(AutoDebitDetails,4);
        verify.elementIsPresent(AutoDebitDetails);
        verify.elementIsPresent(UnionBankCard);
        verify.elementIsPresent(BillInformation);
        verify.elementIsPresent(MastercardCashbackPlatinumCredit);
        verify.elementIsPresent(PesoSavingsAccount);
        verify.elementIsPresent(PaymentDetails);
        verify.elementIsPresent(Reminder);
    }
}
