package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import runners.ConvergentTestRunner;


public class CreditLimitIncreasePage extends Keywords {

    private HomePage home = new HomePage();
    private UITFPage uitfPage = new UITFPage();
    private SendRequestPage sendrequest = new SendRequestPage();


    private String CreditcardAccount  = "onlineBanking.CreditLimit.CreditcardAccount";
    private String RequestIncreaseButton  = "onlineBanking.CreditLimit.RequestIncreaseButton";
    private String RIPopupMessage  = "onlineBanking.CreditLimit.RIPopupMessage";
    private String CurrentLimitMessage  = "onlineBanking.CreditLimit.CurrentLimitMessage";
    private String CreditAmount ="onlineBanking.CreditLimit.CreditAmount";
    private String CreditLimitAmount  = "onlineBanking.CreditLimit.CurrentCreditLimitAmount";
    private String MaximumAllowedMessage ="onlineBanking.CreditLimit.MaximumAllowedMessage";
    private String IncrementMessage ="onlineBanking.CreditLimit.IncrementMessage";
    private String GotITBtn = "onlineBanking.CreditLimit.GotITBtn";

    ConvergentTestRunner Devicename=new ConvergentTestRunner();

    public void click_CreditCardAccount() throws Throwable {
        Wait.forSeconds(6);
        //swipe.swipeVertical(2, 0.6, .2, 2);
        //click.elementBy(CreditcardAccount);
        AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.widget.TextView[@text=\"*9905\"]");
        element.click();
    }
    public void click_RequestIncrease() throws Throwable {
        Wait.waituntillElementVisibleMob(RequestIncreaseButton,4);
        click.elementBy(RequestIncreaseButton);
    }
    public void Verify_RIPopupMessage() throws Throwable {
        Wait.waituntillElementVisibleMob(RIPopupMessage,3);
        verify.elementIsPresent(RIPopupMessage);
    }
    public void click_GotIt() throws Throwable {
        Wait.waituntillElementVisibleMob(GotITBtn,4);
        click.elementBy(GotITBtn);
    }
    public void click_Slider() throws Throwable {
        Wait.forSeconds(2);
        WebElement slider = driver.findElement(By.id("com.unionbankph.online.qat:id/range_slider"));
        Actions move = new Actions(driver);
        move.moveToElement(slider).clickAndHold().moveByOffset(0, 100).release().perform();
        move.moveToElement(slider).clickAndHold().moveByOffset(-500, 0).release().perform();
    }
    public void Verify_CurrentLimitMessage() throws Throwable {
        Wait.waituntillElementVisibleMob(CurrentLimitMessage,4);
        verify.elementIsPresent(CurrentLimitMessage);
    }
    public void Verify_MaximumAllowedMessage() throws Throwable {
        Wait.waituntillElementVisibleMob(MaximumAllowedMessage,4);
        verify.elementIsPresent(MaximumAllowedMessage);
    }
    public void Verify_IncrementMessage() throws Throwable {
        Wait.waituntillElementVisibleMob(IncrementMessage,4);
        verify.elementIsPresent(IncrementMessage);
    }
    public void creditLimitAmount(String Amt) throws Throwable {
        Wait.waituntillElementVisibleMob(CreditLimitAmount,3);
        click.elementBy(CreditLimitAmount);
        type.data(CreditLimitAmount,Amt);
    }
}