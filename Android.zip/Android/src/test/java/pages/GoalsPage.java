package pages;

import actions.Swipe;
import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import freemarker.ext.jsp.TaglibFactory;
import gherkin.lexer.Th;
import helper.PropertyReader;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.JavascriptExecutor;
import runners.ConvergentTestRunner;

import java.util.HashMap;
import java.lang.Boolean;


public class GoalsPage extends Keywords {

    String KeyAddGoalsInDashboard = "convergent.Dashboard.Goals.btnAdd";
    String KeyGoalsCardInDashBoard = "convergent.Dashboard.Goals.GoalsCardIOS";
    String KeyGoalsPageTitle = "convergent.Goals.labelGoalsDetailPageTitle";
    String KeyGoalNameInMyGoals = "convergent.Goals.MyGoal.txtGoalName";
    String KeyAdditionInMyGoals = "convergent.Goals.MyGoal.btnAddition";
    String KeySubstationInMyGoals = "convergent.Goals.MyGoal.btnSubstation";
    String KeyNextInMyGoals = "convergent.Goals.MyGoal.btnNext";
    String KeyWeeklyInMyGoals = "convergent.Goals.MyGoal.btnWeekly";
    String KeyTopUpPHP100InReviewAndTopUpGoal = "convergent.Goals.ReviewAndTopUpGoal.btnTopUpPHP100";
    String KeyTopUpPHP200InReviewAndTopUpGoal ="convergent.Goals.ReviewAndTopUpGoal.btnTopUpPHP200";
    String KeyMonthlyInMyGoals = "convergent.Goals.MyGoal.btnMonthly";
    String KeySaveStartDate="convergent.Goals.MyGoal.SelectStartDate.btnSAVE";
    String KeyQuarterlyInMyGoals = "convergent.Goals.MyGoal.btnQuaeterly";
    String KeyStartDate = "convergent.Goals.MyGoal.SelectStartDate.btnDate";
    String KeyOkDate = "convergent.Goals.MyGoal.btnOk";
    String KeyTapToSelectAccount = "convergent.Goals.MyGoal.btnTapToSelectAccount";
    String KeyTopUpAmountDone  ="convergent.Goals.TopUpGoal.TopUpGoalSelectAmount";
    String KeySelectAccountOther="convergent.Goals.SelectAnotherAccount";
    String KeyGetFundsFrom="convergent.Goals.MyGoal.btnGetFundsFrom";
    String KeySelectAccountPageTitle = "convergent.Goals.MyGoal.labelSelectAccountPageTitle";

    String KeyGoals="convergent.Goals.TestGoal";
    String KeySelectAccountTopUpPageTitle ="convergent.Goals.GoalDetails.btnTopUp.labelSelectAccountPageTitle";
    String KeySelectAccountTopUpPageTitle2 ="convergent.Goals.GoalDetails.btnTopUp.labelSelectAccountPageTitle2";
    //String KeyAccount = "convergent.Goals.MyGoal.Accounts";
    String KeyAccount = "Convergent.Goals.Account";
    String KeyCancel = "convergent.Goals.MyGoal.btnCancel";
    String GoalSuccessTitle ="convergent.Goals.MyGoal.SuccessMessage.labelGoalSet";
    String KeyLetsKickStartYourGoalPageTitle = "convergent.Goals.MyGoal.labelKickStartYourGoalPageTitle";
    String KeyOkDepositPHP500 = "convergent.Goals.MyGoal.btnOkDepositPHP500";
    String KeyReviewAndSetGoalPageTitle = "convergent.Goals.MyGoal.ReviewandSetGoal.labelReviewandSetGoalPageTitle";
    String KeyIAgreeInReviewAndSetGoal = "convergent.Goals.MyGoal.ReviewandSetGoal.btnIAgree";
    String KeyStartSavingInReviewAndSetGoal = "convergent.Goals.MyGoal.ReviewandSetGoal.btnStartSaving";
    String keyMaybeLater = "convergent.Goals.MyGoal.btnMaybeLater";
    String KeyBackInReviewAndSetGoal = "convergent.Goals.MyGoal.ReviewandSetGoal.btnback";
    String KeyHandOnYes = "convergent.Goals.MyGoal.ReviewandSetGoal.HandOn.btnYes";
    String KeyGoalNameEditInReviewAndSetGoal = "convergent.Goals.MyGoal.ReviewandSetGoal.btnGoalNameEdit";
    String KeyEditGoalName = "convergent.Goals.MyGoal.ReviewandSetGoal.EditGoal.btnGoalname";
    String KeyEditingGoalName = "convergent.Goals.MyGoal.ReviewandSetGoal.EditGoal.btnGoalname2";
    String KeyEditGoalNamePageTitle = "convergent.Goals.MyGoal.ReviewandSetGoal.EditGoal.labelEditGoalNamePageTitle";
    String KeyEditGoalNameSave = "convergent.Goals.MyGoal.ReviewandSetGoal.EditGoal.btnSave";
    String KeyEditTargetAmountPageTitle = "convergent.Goals.MyGoal.ReviewandSetGoal.EditTargetAmount.labelEditTargetAmountPageTitle";
    String KeyAdditionInEditTargetAmount = "convergent.Goals.MyGoal.ReviewandSetGoal.EditTargetAmount.btnAddition";
    String KeySubstrationInEditTargetAmount = "convergent.Goals.MyGoal.ReviewandSetGoal.EditTargetAmount.btnSubstation";
    String KeySaveInEditTargetAmount = "convergent.Goals.MyGoal.ReviewandSetGoal.EditGoal.btnSave";
    String KeyEditTargetAmountInReviewandSetGoal = "convergent.Goals.MyGoal.ReviewandSetGoal.btnTargetAmountEdit";
    String KeyEditFromAmountInReviewandSetGoal = "convergent.Goals.MyGoal.ReviewandSetGoal.btnFromAccountEdit";
    String KeyEditTargetAmountlabelInReviewAndSetGoal = "convergent.Goals.MyGoal.ReviewandSetGoal.labelTargetAmount";
    String KeyEditAccount = "convergent.Goals.MyGoal.ReviewandSetGoal.EditSelectAccount.btnaccount";
    String KeylabelFromAccountInReviewAndSetGoal = "convergent.Goals.MyGoal.ReviewandSetGoal.labelFromAccount2";
    String KeySaveBtn="convergent.Goals.ReviewAndTopUpGoal.labelAmountSaved";
    String KeyGoalCardInDashboard = "convergent.Dashboard.Goals.Goalscard";
    String KeyGoalDetailsPageTitle = "convergent.Goals.GoalDetails.labelGoalDetailsPageTitle";
    String KeyTopUpInGoalDetails = "convergent.Goals.GoalDetails.btnTopUp";
    String KeyTopUpGoalPageTitle = "convergent.Goals.TopUpGoal.labelTopUpGoalPageTitle";
    String KeyTopUpAmountInTopupGoal = "convergent.Goals.TopUpGoal.txtTopUpAmounttextbox";
    String KeyNextInTopUpGoal = "convergent.Goals.TopUpGoal.btnNext";
    String KeyTopupAmountErrorMessage = "convergent.Goals.TopUpGoal.txtTopUpAmountError";
    String KeySuccessMsg="convergent.Goals.TopUpSuccess.labelGoalDetailsPageTitle";

    String KeyMinusTopUpBtn="convergent.Goals.TopUpGoal.btnTopUpAmountMinus";
    String KeyReviewAndTopUpGoalPageTitle = "convergent.Goals.ReviewAndTopUpGoal.labelReviewandTopUpPageTitle";
    String KeyTopUpPHPInReviewAndTopUpGoal = "convergent.Goals.ReviewAndTopUpGoal.btnTopUpPHP";
    String  KeyPlusPHPbtn="convergent.Goals.TopUpGoal.btnTopUpAmountPlus";
    String KeyTopUpSuccessfulInGoals = "convergent.Goals.TopUpSuccess.lableTopUpSuccess";
    String KeyTopUp100SuccessfulInGoals = "convergent.Goals.TopUpSuccess.lableTopUp100Success";
    String KeyTopUp200SuccessfulInGoals = "convergent.Goals.TopUpSuccess.lableTopUp200Success";
    String KeyEditTopUpAmount = "convergent.Goals.ReviewAndTopUpGoal.btnEditTopUpAmount";
    String KeyPauseGoalInGoalDetails = "convergent.Goals.GoalDetails.btnPauseGoal";
    String KeyPauseGoalPageTitle = "convergent.Goals.GoalDetails.PauseGoal.labelPauseGoalPageTitle";
    String KeyPauseGoalButtonInPauseGoal = "convergent.Goals.GoalDetails.PauseGoal.btnPauseGoal";
    String KeyPauseGoalSuccessMessageInPauseGoal = "convergent.Goals.GoalDetails.PauseGoal.labelPauseGoalSuccessfullyPaused";
    String KeyPauseGoalOk = "convergent.Goals.GoalDetails.PauseGoal.brnOk";
    String KeyCloseInSelectAccount = "convergent.Goals.GoalDetails.SelectAccount.btnCloseInSelectAccount";
    String KeyResumeInGoalDetails = "convergent.Goals.GoalDetails.btnResume";
    String KeyWithdrawAmountInWithdrawFunds = "convergent.Goals.WithdrawFunds.labelAmountToWithdraw";
    String KeyWithdrawFundsInWithdrawFundsPageTitle = "convergent.Goals.WithdrawFunds.labelWithdrawFundsPageTitle";
    String KeyNextInWithdrawFunds = "convergent.Goals.WithdrawFunds.btnNext";
    String KeyReviewAndWithdrawPageTitle = "convergent.Goals.ReviewAndWithdraw.labelReviewAndWithdrawPageTitle";
    String KeyWithdrawPHPInWithdrawFunds = "convergent.Goals.ReviewAndWithdraw.btnWithDrawPHP";
    String KeyWithdrawConfirmationPageTitle = "convergent.Goals.ReviewAndWithdraw.WithdrawConfirmation.labelWithdrawConfirmationPageTitle";
    String KeyWithdrawPHPInWithdrawConfirmation = "convergent.Goals.ReviewAndWithdraw.WithdrawConfirmation.btnWithdrawPHP";
    String KeyWithdrawnSuccessfullyMessage = "convergent.Goals.ReviewAndWithdraw.WithdrawConfirmation.labelWithdrawnSuccessfullyMessage";
    String KeyViewGoalInWithdrawnSuccessfully = "convergent.Goals.ReviewAndWithdraw.WithdrawConfirmation.btnViewGoal";
    String KeyWithdrawAndCloseGoalPageTitle = "convergent.Goals.WithdrawAndCloseGoal.labelWithdrawAndCloseGoalPageTitle";
    String KeyWithdrawAndCloseInWithdrawAndCloseGoal = "convergent.Goals.WithdrawAndCloseGoal.btnWithdrawAndCloseGoal";
    String KeySuccessmessageInWithdrawAndCloseGoal = "convergent.Goals.WithdrawAndCloseGoal.labelSuccessmessage";
    String KeySelectThisGoalInMyGoalPage = "convergent.Goals.MyGoal.btnSelectThisGoal";

    String KeyViewHistory="convergent.Goals.ViewHistory";
    String KeyGoalDetailsManageScetion="convergent.Goals.GoalDetails.ManageLabelTitle";
    String KeyResumeGoalPageTitle="convergent.Goals.GoalDetails.ResumeGoalPageTitle";
    String KeyWithdrawFundsInGoalDetails="convergent.Goals.GoalDetails.btnWithdraw";
    String KeyWithdrawFundsSectionInGoalDetails="convergent.Goals.GoalDetails.btnWithdrawFunds";
    String KeyGoalPageTitle="convergent.Dashboard.Goals.labelGoalTitle";
    String KeyGoalsfirdtelement="convergent.Dashboard.Goals.labelGoalFirstelement";
    String KeyGoalamount="convergent.Goals.MyGoal.txtEditamount";
    String GoalNameSuccessmsg="convergent.Goals.NameSuccessMsg";
    String ExistingGoal = "Convergent.Goals.ExistingGoal";
    String ReviewPage_ResumeBtn = "convergent.Goals.ResumeGoal.ReviewAndResumeGoal.btnResume";
    String btnWithdrawFundsGoal = "convergent.Goals.GoalDetails.btnWithdrawFundsGoal";
    String KeyEditBtn= "convergent.Goals.EditBtn";
    String KeyGoalsNameEditBtn="convergent.Goals.GoalsNameEditBtn";

    ConvergentTestRunner Devicename = new ConvergentTestRunner();

    public void clickAddGoalsInDashBoard() throws Throwable {
        Swipe.swipe.scrollDownToTextandClick("GOALS");
        click.elementBy(KeyAddGoalsInDashboard);
    }

    public void clickViewHistory()throws Throwable{
        Wait.waituntillElementVisibleMob(KeyViewHistory,2);
        click.elementBy(KeyViewHistory);
    }

    public void clickGoals()throws Throwable{
        Wait.waituntillElementVisibleMob(KeyGoals,3);
        click.elementBy(KeyGoals);
    }

    public void clickEditBtn()throws Throwable{
        Wait.waituntillElementVisibleMob(KeyEditBtn,3);
        click.elementBy(KeyEditBtn);
    }

    public void verifySuccessmsg()throws Throwable{
        Wait.waituntillElementVisibleMob(KeySuccessMsg,1);
        verify.elementIsPresent(KeySuccessMsg);
    }
    public void clickEditBtn1()throws Throwable{
        Wait.forSeconds(4);
        click.elementBy(KeyGoalsNameEditBtn);
    }

    public void verifyGoalNameSuccessMsg()throws Throwable{
        Wait.waituntillElementVisibleMob(GoalNameSuccessmsg,5);
        verify.elementIsPresent(GoalNameSuccessmsg);
    }
    public void clickGoalNameEdit()throws Throwable{
        Wait.waituntillElementVisibleMob(KeyEditGoalName,4);
        click.elementBy(KeyEditGoalName);
    }
    public void clickMinusTopupBtn()throws Throwable{
        Wait.waituntillElementVisibleMob(KeyMinusTopUpBtn,3);
        click.elementBy(KeyMinusTopUpBtn);
    }
//    public void clickAddGoalsInDashBoardIOS() throws Throwable {
//        //Swipe.swipe.scrollDownToTextandClick("GOALS");
//        Wait.forSeconds(5);
//        Boolean result = false;
//        int i=0;
//        while (result == false)
//        {
//            try {
//                if (result == false && i<=10)
//                {
//                    swipe.swipeVertical(2, 0.6, .2, 2);
//                    if (verify.IfElementExistsboolean(KeyGoalPageTitle))
//                    {
//                        swipe.swipeVertical(2, 0.6, .2, 2);
//                       // verify.IfElementExists(KeyAddGoalsInDashboard);
//                       click.elementBy(ManageBtn);
////                        click.elementBy(KeyAddGoalsInDashboard);
//                        result = true;
//                    }
//                }
//                //result = true;
//            }
//            catch (Exception e) { }
//            i=i++;
//        }
//    }

    public void clickManageButtonInDashBord()throws Throwable{
        Wait.forSeconds(5);
        Boolean result = false;
        int i=0;
        while (result == false)
        {
            try {
                if (result == false && i<=10)
                {
                    swipe.swipeVertical(2, 0.6, .2, 2);
                    if (verify.IfElementExistsboolean(KeyGoalPageTitle))
                    {
                        swipe.swipeVertical(2, 0.6, .2, 2);
                        // verify.IfElementExists(KeyAddGoalsInDashboard);
//                        click.elementBy(ManageBtn);
                        result = true;
                    }
                }
                //result = true;
            }
            catch (Exception e) { }
            i=i++;
        }
    }


    public void clickGoalsCardInDashBoard() throws Throwable {
        //Swipe.swipe.scrollDownToTextandClick("Saves every 3 months");
       // click.elementBy(KeyGoalCardInDashboard);

        Wait.forSeconds(5);
        Boolean result = false;
        int i=0;
        while (result == false)
        {
            try {
                if (result == false && i<=10)
                {
                    swipe.swipeVertical(2, 0.6, .2, 2);
                    if (verify.IfElementExistsboolean(KeyGoalPageTitle))
                    {
                        swipe.swipeVertical(2, 0.6, .2, 2);
                        // verify.IfElementExists(KeyAddGoalsInDashboard);
                        click.elementBy(ExistingGoal);
                        Wait.forSeconds(5);
                       // click.elementBy(KeyGoalCardInDashboard);
                        result = true;
                    }
                }
                //result = true;
            }
            catch (Exception e) { }
            i=i++;
        }
    }

    public void clickGoalsCardInDashBoardIOS() throws Throwable{
        Boolean result = false;
        while (result == false) {
            try {
                if (result == false) {
                    swipe.swipeVertical(2, 0.8, .1, 2);
                    verify.elementIsPresent(KeyAddGoalsInDashboard);
                    click.elementBy(KeyGoalsCardInDashBoard);
                }
                result = true;
            } catch (Exception e) {

            }
        }
    }

    public void verifyAddGoalsIsPresentInDashBoard() throws Throwable
    {
        Wait.forSeconds(10);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        verify.elementIsPresent(KeyGoalPageTitle);
    }


    public void verifyMyGoalsPageTitle(String pagetitle) throws Throwable {
        Wait.forSeconds(2);
        verify.elementTextMatching(KeyGoalsPageTitle, pagetitle);
    }

    public void clickSelectGoals() throws Throwable {
        //actions.Touch.pressByCoordinates(341, 72, 5);
        Wait.waituntillElementVisibleMob(KeySelectThisGoalInMyGoalPage,4);
        click.elementBy(KeySelectThisGoalInMyGoalPage);
    }

    public void enterGoalName(String goalname) throws Throwable {
        type.data(KeyGoalNameInMyGoals,goalname);
    }

    public void clickAdditionInMyGoals() throws Throwable {
        click.elementBy(KeyAdditionInMyGoals);
    }

    public void clickSelectThisGoalInMyGoalPage() throws Throwable {
        click.elementBy(KeySelectThisGoalInMyGoalPage);
    }

    public void clickSubstationInMyGoals() throws Throwable {
        click.elementBy(KeySubstationInMyGoals);
    }

    public void verifySubstationIsDisabledInMyGoals() throws Throwable {
        verify.elementIsDisabled(KeySubstationInMyGoals);
    }

    public void clickSubstationUpTo5000InMyGoalsAndroid() throws Throwable {

       type.data(KeyGoalamount,"6000");
        for (int i=0;i<20;i++) {
           Wait.forSeconds(5);
           click.elementBy(KeySubstationInMyGoals);
       }

    }

    public void clickNextInMyGoals() throws Throwable {
        click.elementBy(KeyNextInMyGoals);
    }

    public void verifyNextButtonIsDisabledInMyGoals() throws Throwable {
        verify.elementIsDisabled(KeyNextInMyGoals);
    }

    public void clickWeeklyInMyGoals() throws Throwable {
        click.elementBy(KeyWeeklyInMyGoals);
    }

    public void clickMonthlyInMyGoals() throws Throwable {
        click.elementBy(KeyMonthlyInMyGoals);
    }

    public void clickQuarterlyInMyGoals() throws Throwable {
        click.elementBy(KeyQuarterlyInMyGoals);
    }
   public void verifyWeeklyInMyGoals()throws Throwable{
        verify.elementIsPresent(KeyWeeklyInMyGoals);
   }
    public void verifyMonthlyInMyGoals() throws Throwable {
        verify.elementIsPresent(KeyMonthlyInMyGoals);
    }

    public void verifyQuarterlyInMyGoals() throws Throwable {
        verify.elementIsPresent(KeyQuarterlyInMyGoals);
    }

    public void clickStartDateInMyGoals() throws Throwable {
        click.elementBy(KeyStartDate);
    }
    public void clickSaveStartDateInMyGoals() throws Throwable {
        click.elementBy(KeySaveStartDate);
    }

    public void clickOkInDate() throws Throwable {
        click.elementBy(KeyOkDate);
    }

    public void clickTapToSelectAccountInMyGoals() throws Throwable {
        //Swipe.swipe.scrollDownToTextandClick("TAP TO SELECT AN ACCOUNT");
            Wait.waituntillElementVisibleMob(KeyGetFundsFrom,3);
            click.elementBy(KeyGetFundsFrom);
            click.elementBy(KeyTapToSelectAccount);
    }
    public void clickSelectAnotherAccount()throws Throwable{
        click.elementBy(KeyTapToSelectAccount);
        Wait.waituntillElementVisibleMob(KeySelectAccountOther,4);
        click.elementBy(KeySelectAccountOther);
        click.elementBy(KeyNextInMyGoals);
        click.elementBy(KeySaveBtn);
    }

    public void clickTapToSelectAccountInMyGoalsIOS() throws Throwable {
        //Swipe.swipe.scrollDownToTextandClick("TAP TO SELECT AN ACCOUNT");
        click.elementBy(KeyTapToSelectAccount);
    }

    public void verifySelectAccountPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeySelectAccountTopUpPageTitle, pagetitle);
    }
    public void verifySelectAccountPageTitle2(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeySelectAccountTopUpPageTitle2, pagetitle);
    }

    public void clickAccountsInMyGoals() throws Throwable {
        Wait.waituntillElementVisibleMob(KeyAccount,4);
        click.elementBy(KeyAccount);
    }

    public void verifyLetsKickStartYourGoalPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyLetsKickStartYourGoalPageTitle, pagetitle);
    }
    public void verifyResumeGoalPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyResumeGoalPageTitle, pagetitle);
    }

    public void clickOkDepositPHP() throws Throwable {
        click.elementBy(KeyOkDepositPHP500);
    }
    public void verifyKickstartOptions()throws Throwable{
        Wait.forSeconds(1);
        verify.elementIsPresent(KeyOkDepositPHP500);
        verify.elementIsPresent(keyMaybeLater);
    }
    public void verifySucessMsg()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(KeySuccessMsg);
    }
    public void clickMaybeLater() throws Throwable {
        click.elementBy(keyMaybeLater);
    }

    public void verifyReviewAndSetGoalPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyReviewAndSetGoalPageTitle, pagetitle);
    }

    public void clickBackInReviewAndSetGoal() throws Throwable {
        click.elementBy(KeyBackInReviewAndSetGoal);
    }

    public void clickYesInHangOn() throws Throwable {
        click.elementBy(KeyHandOnYes);
    }

    public void clickIAgreeInReviewAndSetGoal() throws Throwable {
        //Swipe.swipe.scrollDownToTextandClick("I agree to the terms above. Read the terms and conditions here.");
        click.elementBy(KeyIAgreeInReviewAndSetGoal);
    }

    public void clickStartSavingInReviewAndSetGoal() throws Throwable {
        click.elementBy(KeyStartSavingInReviewAndSetGoal);
    }

    public void clickGoalNameEditInReviewAndSetGoal() throws Throwable {
        click.elementBy(KeyGoalNameEditInReviewAndSetGoal);
    }

    public void verifyEditGoalSuccessfullyMessage(String successmessage) throws Throwable {
        verify.elementTextMatching(GoalSuccessTitle, successmessage);
    }

    public void verifyEditGoalNamePageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyEditGoalNamePageTitle, pagetitle);
    }

    public void enterEditGoalNametextBox(String Editgoalname) throws Throwable {
        Wait.waituntillElementVisibleMob(KeyEditGoalName,4);
        get.elementBy(KeyEditGoalName).clear();
        type.data(KeyEditGoalName,Editgoalname);
    }

    public void clickSaveInEditGoalName() throws Throwable {
        click.elementBy(KeyEditGoalNameSave);
    }

    public void verifyEditTargetAmountPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyEditTargetAmountPageTitle, pagetitle);
    }

    public void clickAdditionInEditTargetAmount() throws Throwable {
        click.elementBy(KeyAdditionInEditTargetAmount);
    }

    public void clickSaveInEditTargetAmounnt() throws Throwable {
        click.elementBy(KeySaveInEditTargetAmount);
    }

    public void clickEditTargetAmountInReviewandSetGoal() throws Throwable {
        click.elementBy(KeyEditTargetAmountInReviewandSetGoal);
    }

    public void clickEditFromAmountInReviewandSetGoal() throws Throwable {
        click.elementBy(KeyEditFromAmountInReviewandSetGoal);
    }

    public void verifyEditTargetAmountlabelInReviewAndSetGoal(String TargetAmount) throws Throwable {
        verify.elementTextMatching(KeyEditTargetAmountlabelInReviewAndSetGoal, TargetAmount);
    }

    public void clickEditAccountInReviewandSetGoal() throws Throwable {
        click.elementBy(KeyEditAccount);
    }

    public void verifylabelFromAccountInReviewAndSetGoal(String FromAccount) throws Throwable {
        verify.elementTextMatching(KeylabelFromAccountInReviewAndSetGoal, FromAccount);
    }

    public void verifyGoalDetailsPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyGoalDetailsPageTitle, pagetitle);
    }

    public void clickTopUpInGoalDetails() throws Throwable {
        click.elementBy(KeyTopUpInGoalDetails);
    }

    public void verifyTopUpGoalPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyTopUpGoalPageTitle, pagetitle);
    }

    public void enterTopUpAmount(String TopupAmount) throws Throwable
    {
        if(Devicename.currentdevicename.equalsIgnoreCase("Samsung")) {
            get.elementBy(KeyTopUpAmountInTopupGoal).clear();
            click.elementBy(KeyTopUpAmountInTopupGoal);
            type.data(KeyTopUpAmountInTopupGoal,TopupAmount);
        }
        else if(Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            get.elementBy(KeyTopUpAmountInTopupGoal).clear();
            Wait.waituntillElementVisibleMob(KeyPlusPHPbtn,4);
            click.elementBy(KeyPlusPHPbtn);}

//            click.elementBy(KeyTopUpAmountInTopupGoal);
//            type.data(KeyTopUpAmountInTopupGoal,TopupAmount);
        }


    public void clickNexyTopUpGoal() throws Throwable {
        swipe.swipeVertical(2, 0.8, .3, 2);
        click.elementBy(KeyNextInTopUpGoal);
    }

    public void verifyTopUpAmountErrorMessage(String TopupAmountErrorMessage) throws Throwable {
        verify.elementTextMatching(KeyTopupAmountErrorMessage,TopupAmountErrorMessage);
    }

    public void verifyReviewAndTopUpGoalPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyReviewAndTopUpGoalPageTitle, pagetitle);
    }

    public void clickTopUpPHPInReviewAndTopUpGoal() throws Throwable {
        click.elementBy(KeyTopUpPHPInReviewAndTopUpGoal);

    }

   /* public void clickTopUpPHP100InReviewAndTopUpGoalIOS() throws Throwable {
        //click.elementBy(KeyTopUpPHPInReviewAndTopUpGoal);
        click.elementBy(KeyTopUpPHP100InReviewAndTopUpGoal);

    }
    public void clickTopUpPHP200InReviewAndTopUpGoalIOS() throws Throwable {
        //click.elementBy(KeyTopUpPHPInReviewAndTopUpGoal);
        click.elementBy(KeyTopUpPHP200InReviewAndTopUpGoal);
    }*/

    public void verifyTopUpSuccessMessage(String TopupSuccessMessage) throws Throwable {
        verify.elementTextMatching(KeyTopUpSuccessfulInGoals,TopupSuccessMessage);
    }

    public void verifyTopUpSuccess200MessageIOS(String TopupSuccessMessage) throws Throwable {
        verify.elementTextMatching(KeyTopUp200SuccessfulInGoals,TopupSuccessMessage);

    }

    public void verifyTopUp100SuccessMessageIOS(String TopupSuccessMessage) throws Throwable {

        verify.elementTextMatching(KeyTopUp100SuccessfulInGoals,TopupSuccessMessage);

    }

    public void clickEditInReviewAndTopUp() throws Throwable {
        click.elementBy(KeyEditTopUpAmount);
    }

    public void clickPauseGoalInGoalDetails() throws Throwable
    {
            Wait.forSeconds(5);
            swipe.swipeVertical(2, 0.8, .3, 2);
            swipe.swipeVertical(2, 0.8, .3, 2);
            swipe.swipeVertical(2, 0.8, .3, 2);
             //verify.IfElementExists(KeyGoalDetailsManageScetion);
            click.elementBy(KeyPauseGoalInGoalDetails);
    }

    public void clickWithdrawFundsInIOSGoalDetails() throws Throwable {
        click.elementBy(KeyWithdrawFundsInGoalDetails);
    }

    public void clickWithdrawFundsInGoalDetails() throws Throwable {
        //Swipe.swipe.scrollDownToTextandClick("Withdraw Funds");
        swipe.swipeVertical(2, 0.8, .3, 2);
        swipe.swipeVertical(2, 0.8, .3, 2);
        click.elementBy(btnWithdrawFundsGoal);
    }
    public void clickWithdrawFundsInGoalDetailsIOS() throws Throwable {
        Wait.forSeconds(10);
        Boolean result = false;
        while (result == false) {
            try {
                if (result == false) {
                    swipe.swipeVertical(2, 0.8, .3, 2);

                    verify.IfElementExists(KeyGoalDetailsManageScetion);
                    click.elementBy(KeyWithdrawFundsSectionInGoalDetails);
                }
                result = true;
            } catch (Exception e) {

            }
        }

    }

    public void verifyPauseGoalPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyPauseGoalPageTitle,pagetitle);
    }

    public void clickPauseGoalButtonInPauseGoal() throws Throwable {
        click.elementBy(KeyPauseGoalButtonInPauseGoal);
    }

    public void verifyPauseGoalSuccessMessage(String PauseSuccessMessage) throws Throwable {
        verify.elementTextMatching(KeyPauseGoalSuccessMessageInPauseGoal,PauseSuccessMessage);
    }

    public void clickPauseGoalOkButtonInPauseGoalp() throws Throwable {
        click.elementBy(KeyPauseGoalOk);
    }

    public void clickCloseInSelectAccount() throws Throwable {
        click.elementBy(KeyCloseInSelectAccount);
    }

    public void clickResumeInGoalDetails() throws Throwable {
        //Swipe.swipe.scrollDownToTextandClick("RESUME");
       // swipe.swipeVertical(2, 0.6, .2, 2);
        click.elementBy(KeyResumeInGoalDetails);
    }

    public void enterWithdrawAmount(String WithdrawAmount) throws Throwable {
       click.elementBy(KeyWithdrawAmountInWithdrawFunds);
        type.data(KeyWithdrawAmountInWithdrawFunds,WithdrawAmount);
    }

    public void enterWithdrawAmountIOS(String WithdrawAmount) throws Throwable {
        get.elementBy(KeyWithdrawAmountInWithdrawFunds).clear();
        type.data(KeyWithdrawAmountInWithdrawFunds,WithdrawAmount);
        click.elementBy(KeyTopUpAmountDone);

    }


    public void verifyWithdrawFundsPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyWithdrawFundsInWithdrawFundsPageTitle,pagetitle);
    }

    public void clickNextInWithdrawFunds() throws Throwable {
        click.elementBy(KeyNextInWithdrawFunds);
    }

    public void verifyReviewAndWithdrawPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyReviewAndWithdrawPageTitle,pagetitle);
    }

    public void clickWithdrawPHPInReviewAndWithdraw() throws Throwable {
        click.elementBy(KeyWithdrawPHPInWithdrawFunds);
    }

    public void verifyWithdrawConfirmationPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyWithdrawConfirmationPageTitle,pagetitle);
    }

    public void clickWithdrawPHPInWithdrawConfirmation() throws Throwable {
        click.elementBy(KeyWithdrawPHPInWithdrawConfirmation);
    }

    public void verifyWithdrawnSuccessfullyMessage(String WithdrawnSuccessfullyMessage) throws Throwable {
        verify.elementTextMatching(KeyWithdrawnSuccessfullyMessage,WithdrawnSuccessfullyMessage);
    }

    public void clickViewGoalInWithdrawnSuccessfully() throws Throwable {
        click.elementBy(KeyViewGoalInWithdrawnSuccessfully);
    }

    public void verifyWithdrawAndCloseGoalPageTitle(String PageTitle) throws Throwable {
        verify.elementTextMatching(KeyWithdrawAndCloseGoalPageTitle,PageTitle);
    }

    public void clickWithdrawAndCloseInWithdrawAndCloseGoal() throws Throwable {
        click.elementBy(KeyWithdrawAndCloseInWithdrawAndCloseGoal);
    }

    public void verifySuccessmessageInWithdrawAndCloseGoal(String Successmessage) throws Throwable {
        verify.elementTextMatching(KeySuccessmessageInWithdrawAndCloseGoal,Successmessage);
    }


    public void clickExistingGoalsInDashBoard() throws Throwable
    {
        swipe.swipeVertical(2, 0.8, .3, 2);
        click.elementBy(ExistingGoal);
    }

    public void clickReviewPageResumeBtn() throws Throwable
    {
        Wait.waituntillElementVisibleMob(ReviewPage_ResumeBtn,4);
        click.elementBy(ReviewPage_ResumeBtn);
    }
}
