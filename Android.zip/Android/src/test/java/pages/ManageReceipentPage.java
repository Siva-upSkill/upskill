package pages;

import actions.Touch;
import actions.Wait;
import base.Keywords;
import driver.DriverManager;
import exceptions.ApplicationException;
import helper.Tools;
import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.By;

public class ManageReceipentPage extends Keywords {

    private String KeyManageReceipent = "convergent.Managereceipent.ManageReceipents";
    private String KeySendRequestTab = "convergent.home.tabFundTransfer";
    private String KeyManageReceipenttitle = "convergent.Managereceipent.labelPagetitle";
    private String KeyAddNewReceipent = "convergent.Managereceipent.ManageReceipentsNew";
    private String KeKeyManageReceipentSelectBank = "convergent.Managereceipent.selectbankname";
    private String KeyManageReceipentaccountname = "convergent.Managereceipent.Accountname";
    private String KeyManageReceipentaccountnumber = "convergent.Managereceipent.Accountnumber";
    private String KeyManageReceipentSave = "convergent.Managereceipent.Save";
    private String KeyManageReceipentError = "convergent.Managereceipent.FieldErrormsg";
    private String KeyManageReceipentfav = "convergent.Managereceipent.Favoutiteswitch";
    private String KeyManageReceipentsearch = "convergent.Managereceipent.MangeRecipentSearch";
    private String KeyManageReceipentfavouritemark = "convergent.Managereceipent.Favoutitecheckbox";
    private String KeyManageReceipentsearchresult = "convergent.Managereceipent.SearchReceipentname";
    private String KeyManageReceipentscloseicon = "convergent.Managereceipent.closeicon";
    private String KeyManageReceipentssearchcon = "convergent.Managereceipent.Searchicon";
    private String KeyManageReceipentsback = "convergent.Managereceipent.backbtn";
    private String KeyManageReceipenfavouritelink = "convergent.Managereceipent.tabFavourites";
    private String KeyExistingManageReceipentink = "convergent.Managereceipent.existingmanangerecipent";
    private String KeyEditExistingManageReceipentink = "convergent.Managereceipent.Editexistingmanangerecipent";

    private String KeyDeleteExistingManageReceipentink = "convergent.Managereceipent.Deleteexistingmanangerecipent";
    private String KeyManageReceipentaccountnumberedit = "convergent.Managereceipent.Accountnumberedit";
    private String KeyManageReceipentaccountnumberupdate = "convergent.Managereceipent.Accountnumber";
    private String KeyManageReceipentdeleteYes = "convergent.Managereceipent.deleteYes";
    private String KeyManageReceipentaccountnumberdelete = "convergent.Managereceipent.accountnumberdelete";
    private String KeyManageEditReceipentupdate = "convergent.Managereceipent.accoutdetailsupdate";
    private String KeyManageRecipentsearchicon = "convergent.Managereceipent.MangeRecipentSearchICON";
    private String KeyManageRecipentsearchresultname = "convergent.Managereceipent.MangeRecipentSearchresultname";
    private String KeyManageRecipentsearchresultnumber = "convergent.Managereceipent.MangeRecipentSearchresultnunber";
    private String KeyManageRecipentSucessMsg = "convergent.Managereceipent.SuccessMsg";


    Tools tools = new Tools();

    public void clickManagereceipent() throws ApplicationException {
        Wait.forSeconds(3);
//        click.elementBy(By.xpath("//android.widget.TextView[@text='Manage Recipients"));

        AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.widget.TextView[@text='Manage Recipients']");
        element.click();
    }

    public void addNewManagereceipent() throws ApplicationException {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.waituntillElementVisibleMob(KeyAddNewReceipent,5);
            click.elementBy(KeyAddNewReceipent);
            Wait.waituntillElementVisibleMob(KeKeyManageReceipentSelectBank,4);
            click.elementBy(KeKeyManageReceipentSelectBank);
            Wait.waituntillElementVisibleMob(KeyManageReceipentaccountnumber,4);
            //click.elementBy(By.xpath("//android.view.ViewGroup/android.support.v7.widget.RecyclerView/android.view.ViewGroup[3]"));
            //click.elementBy(By.xpath("//android.widget.TextView[@text()='ASIA UNITED  BANK']/parent::*"));
            //click.elementBy(KeKeyManageReceipentSelectBank,"ASIA UNITED BANK");
            swipe.scrollDownToTextandClick("Asia United Bank");
            type.data(KeyManageReceipentaccountnumber, tools.RANDOMTEXT("RANDOMNUMBER", 12));
            Wait.waituntillElementVisibleMob(KeyManageReceipentaccountname,4);
            type.data(KeyManageReceipentaccountname, tools.RANDOMTEXT("RANDOMSTRING", 10));
            click.elementBy(KeyManageReceipentSave);

        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            Wait.forSeconds(15);
            click.elementBy(KeyAddNewReceipent);
            Wait.forSeconds(10);
            click.elementBy(KeKeyManageReceipentSelectBank);
            //click.elementBy(KeKeyManageReceipentSelectBank,"PSBank");
            //swipe.scrollDownToTextandClick("ASIA UNITED BANK");
            click.elementBy(By.xpath("//XCUIElementTypeOther[5]/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[2]"));
            type.data(KeyManageReceipentaccountnumber, tools.RANDOMTEXT("RANDOMNUMBER", 8));
            Wait.forSeconds(5);
            type.data(KeyManageReceipentaccountname, tools.RANDOMTEXT("RANDOMSTRING", 10));
            click.elementBy(KeyManageReceipentSave);
            Wait.forSeconds(3);
        }
    }

    public void selecttheReceipentBank() throws ApplicationException {

        click.elementBy(KeKeyManageReceipentSelectBank);
        swipe.scrollDownToTextandClick("PSBank");
    }

    public void entertheAccountNumber(int accountnumlength) throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyManageReceipentaccountnumber,4);
        type.data(KeyManageReceipentaccountnumber, tools.RANDOMTEXT("RANDOMNUMBER", accountnumlength));
    }

    public void entertheAccountName(int stringlength) throws ApplicationException {
       Wait.waituntillElementVisibleMob(KeyManageReceipentaccountname,5);
        type.data(KeyManageReceipentaccountname, tools.RANDOMTEXT("RANDOMSTRING", stringlength));
    }


    public void verifyManageReciepentaccountnamefieldErrorMsg(String ierror) throws ApplicationException {

        click.elementBy(KeyManageReceipentaccountnumber);
        verify.elementTextMatching(KeyManageReceipentError, ierror);
    }

    public void addNewManagereceipentbutton() throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyAddNewReceipent,3);
        click.elementBy(KeyAddNewReceipent);

    }

    public void verifyManageReciepentaccountnumberfieldErrorMsg(String ierror) throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyManageReceipentaccountname,4);
        click.elementBy(KeyManageReceipentaccountname);
        Wait.waituntillElementVisibleMob(KeyManageReceipentError,3);
        verify.elementTextMatching(KeyManageReceipentError, ierror);
    }

    public void addNewManagereceipentFav() throws ApplicationException {

        click.elementBy(KeyAddNewReceipent);
        Wait.waituntillElementVisibleMob(KeKeyManageReceipentSelectBank,3);
        click.elementBy(KeKeyManageReceipentSelectBank);
        //click.elementBy(KeKeyManageReceipentSelectBank,"PSBank");
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            swipe.scrollDownToTextandClick("UnionDigital Bank");
        }
        if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            click.elementBy(By.xpath("//XCUIElementTypeOther[5]/XCUIElementTypeOther/XCUIElementTypeTable/XCUIElementTypeCell[2]"));
        }
        type.data(KeyManageReceipentaccountnumber, tools.RANDOMTEXT("RANDOMNUMBER", 12));
        Wait.forSeconds(5);
        type.data(KeyManageReceipentaccountname, tools.RANDOMTEXT("RANDOMSTRING", 10));
        click.elementBy(KeyManageReceipentfav);

        click.elementBy(KeyManageReceipentSave);
        Wait.forSeconds(3);


    }

    public void searchManagereceipent() throws ApplicationException {

        click.elementBy(KeyManageReceipentssearchcon);

    }

    public void searchManagereceipentandfavourite(String receipentname) throws ApplicationException {
        //click.elementBy(KeyManageReceipentsearch);
        Wait.waituntillElementVisibleMob(KeyManageReceipentsearch,3);
        //driver.getKeyboard().pressKey("test");
        //type.data(KeyManageReceipentsearch,receipentname);
        //type.data(receipentname);
        type.data(KeyManageReceipentsearch, receipentname);
        //swipe.scrollDownToTextandClick(receipentname);
        click.elementBy(KeyManageReceipentfavouritemark);
        click.elementBy(KeyManageReceipentsback);

    }

    public void verifythereceipentfavouritepage(String receipentname) throws ApplicationException {
        click.elementBy(KeyManageReceipenfavouritelink);
        type.data(KeyManageReceipentsearch, receipentname);
        verify.elementTextMatching(KeyManageReceipentsearchresult, receipentname);

    }

    public void clicktheexistingmanagereceipent() throws ApplicationException {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

            click.elementBy(KeyExistingManageReceipentink);
        }

        else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            click.elementBy(KeyExistingManageReceipentink);
        }
    }

    public void clicktheeditingmanagereceipent() throws ApplicationException {
        click.elementBy(KeyEditExistingManageReceipentink);
        //WAIT.forSeconds(5);
    }

    public void clicktheeditingmanagereceipentandmarkfavourite() throws ApplicationException {
        //click.elementBy(KeyEditExistingManageReceipentink);
        /*
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //Wait.forSeconds(5);
            Touch.touchLongPress(0, 50, 0, 500);
            //swipe.swipeVertical(2,0.8,0.2,5);
        }

         */

        type.data(KeyManageReceipentaccountname,tools.RANDOMTEXT("RANDOMSTRING",14));
        click.elementBy(KeyManageReceipentfav);
        click.elementBy(KeyManageEditReceipentupdate);

    }

    public void entertheeditrecipientnumber() throws ApplicationException {
        /*
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //Wait.forSeconds(5);
            Touch.touchLongPress(0, 50, 0, 500);
            //swipe.swipeVertical(2,0.8,0.2,5);
        }

         */
        type.data1(KeyManageReceipentaccountnumber,tools.RANDOMTEXT("RANDOMNUMBER",10));
        click.elementBy(KeyManageReceipentaccountnumberupdate);
    }

    public void entertheeditrecipientname() throws ApplicationException {

        /*
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //Wait.forSeconds(5);
            Touch.touchLongPress(0, 50, 0, 500);
            //swipe.swipeVertical(2,0.8,0.2,5);
        }

         */
        type.data(KeyManageReceipentaccountname,tools.RANDOMTEXT("RANDOMSTRING",10));
        click.elementBy(KeyManageReceipentaccountnumberupdate);
    }

    public void deletetheecipient() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            Wait.forSeconds(5);
            click.elementBy(By.xpath("//android.widget.TextView[@text='Delete']"));
            //click.elementBy(KeyDeleteExistingManageReceipentink);
            //click.elementBy(KeyManageReceipentdeleteYes);
            click.elementBy(By.xpath("//android.widget.TextView[@text='YES']"));
        }
        else if (DriverManager.OS.equalsIgnoreCase("IOS")){

            click.elementBy(KeyDeleteExistingManageReceipentink);
            click.elementBy(KeyManageReceipentdeleteYes);
            click.elementBy(KeyManageReceipentdeleteYes);
        }
    }

    public void verifytheFavouriterecipient(String Receipentname) throws ApplicationException {
        Wait.forSeconds(2);
        swipe.scrollDownToTextandClick(Receipentname);
    }

    public void clickSearchicon() throws ApplicationException {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

        }
        if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            Wait.forSeconds(5);
            click.elementBy(KeyManageRecipentsearchicon);
        }


    }

    public void enterinSearchtextfield(String receipientname) throws ApplicationException {


        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

        }
        if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            //Wait.forSeconds(5);
            type.data(KeyManageReceipentsearch, receipientname);
        }
    }


    public void enterinSearchtextfieldmanagerec(String receipientname) throws ApplicationException {


        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

            String managerecipient="//android.widget.TextView[@text='" +receipientname+ "']/following-sibling::android.widget.LinearLayout//android.widget.ImageButton";
            Boolean result = false;
            int i=1;
            while (result == false && i <=60 ) {
                try {
                    if(i==1) {
                        //swipe.swipeVertical(2, .2, .8, 5);
                        driver.findElement(By.xpath(managerecipient)).click();
                    }
                    else {
                        swipe.swipeVertical(2, .8, .2, 5);
                        driver.findElement(By.xpath(managerecipient)).click();
                    }

                    result = true;
                }
                catch(Exception e){

                }
                i=i+1;

            }

        }
        if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            //Wait.forSeconds(5);
            type.data(KeyManageReceipentsearch, receipientname);
        }
    }

    public void clicktheeditingmanagereceipent( String Receipientname,String Receipientnumber) throws ApplicationException {
        //click.elementBy(KeyEditExistingManageReceipentink);
       /*
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            //Wait.forSeconds(5);
            Touch.touchLongPress(0, 50, 0, 500);
            //swipe.swipeVertical(2,0.8,0.2,5);
        }

        */

        type.data(KeyManageReceipentaccountname,Receipientname);
        type.data(KeyManageReceipentaccountnumber,Receipientnumber);
        click.elementBy(KeyManageEditReceipentupdate);

    }

    public void verifytheeditingmanagereceipent(String Receipentname,String Receipentnumber) throws ApplicationException {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {

        }
        if(DriverManager.OS.equalsIgnoreCase("IOS")) {
            verify.elementTextMatching(KeyManageRecipentsearchresultname, Receipentname);
            verify.elementTextMatching(KeyManageRecipentsearchresultnumber, Receipentnumber);
        }


    }
    public void markasfavourite() throws ApplicationException {

        click.elementBy(KeyManageReceipentfav);

    }
    public void verifySuccessMsg() throws ApplicationException{
        verify.elementIsPresent(KeyManageRecipentSucessMsg);
    }

    public void clickUpdatebutton() throws ApplicationException {

        click.elementBy(KeyManageEditReceipentupdate);

    }
    public void clickFavouritelink() throws ApplicationException {

        click.elementBy(KeyManageReceipenfavouritelink);

    }

    public void verifyPageTitleinManageRecepient(String expectedTitle) throws ApplicationException {
        verify.elementTextMatching(KeyManageReceipent,expectedTitle);
    }

}





















































