package pages;

import actions.Verify;
import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import runners.ConvergentTestRunner;

public class WelcomePage extends Keywords {

    private String KeyNext = "convergent.welcome.btnNext";
    private String KeyGetStarted = "convergent.welcome.btnGetStarted";
    private String KeyLogin = "convergent.welcome.btnLogin";
    private String KeySignup = "convergent.welcome.btnSignup";
    private String Gotit_Biometrics = "convergent.welcome.Biometric";

    ConvergentTestRunner Devicename=new ConvergentTestRunner();


    public void clickLogin() throws ApplicationException {
        click.elementBy(KeyLogin);

    }

    public void clickSignup() throws ApplicationException {
    	click.elementBy(KeySignup);
    }

    public void clickGetStarted() throws ApplicationException {
    	click.elementBy(KeyGetStarted);
    }

    public void clickNext() throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyNext,5);
//        Wait.forSeconds(4);
   	    click.elementBy(KeyNext);
//        MobileElement mobileElement = (MobileElement) driver.findElement(By.xpath("//android.widget.Button[@text='NEXT']"));
//        mobileElement.click();
    }
    public void closeWelcomeMessages() throws ApplicationException {
        clickNext();
        clickNext();
        clickNext();
        clickNext();
        clickGetStarted();
        clickLogin();
    }
    public void clickGotITBtn_Biometrics() throws ApplicationException {
       if(Verify.verify.IfElementExistsboolean(Gotit_Biometrics))
       {
           click.elementBy(Gotit_Biometrics);
       }
//        Wait.forSeconds(2);
    }
}
