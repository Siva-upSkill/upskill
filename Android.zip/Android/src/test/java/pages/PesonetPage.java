package pages;

import actions.Wait;
import base.Keywords;
import driver.DriverManager;
import exceptions.ApplicationException;
import io.appium.java_client.MobileElement;
import org.opencv.imgproc.CLAHE;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import runners.ConvergentTestRunner;

public class PesonetPage extends Keywords {

    String KeyOtherBanks = "convergent.Pesonet.otherbanklink";
    String KeyOtherBankPesonet = "convergent.Pesonet.selectpesonet";
    String KeySelectAccount = "convergent.TransferFrompage.selectaccount";
    String KeyClickBank = "convergent.Pesonet.clickbanktab";
    String KeyActionSearch = "convergent.Pesonet.clickactionsearchbtn";
    String KeyEnterBankName = "convergent.Pesonet.searchtxtbox";
    String KeySelectBank = "convergent.Pesonet.selectbankfromlist";
    String KeySearchBank="onlineBanking.BuyLoad.btnSearchicon";
    String RemainingLimitEwallet= "convergent.Pesonet.RemainingLimitEwallet";
    String RemainderMessage= "convergent.TransferDetails.RemainderSection";
    String RemainderPopup="convergent.ReviewandTransfer.RemainderPopup";
    String DailyLimitEwallet= "convergent.Pesonet.DailyLimitEwallet";
    String MinimumErrormessage = "convergent.Pesonet.MinimumErrormessage";
    String MaximumLimitErrormessage = "convergent.Pesonet.MaximumLimitErrormessage";
    String selectbankfromPesonet = "convergent.Pesonet.selectbankfromPesonet";
    String KeyEnterAccountNumber = "convergent.Pesonet.enteraccountnumber";

    String KeyEnterMobilenumberNumber = "convergent.Pesonet.entermobilenumber";
    String KeyEnterAccountNumberEdit = "convergent.Pesonet.enteraccountnumberEdit";
    String KeyEnterAccountName = "convergent.Pesonet.enteraccountname";
    String KeyEnterAccountName1 = "convergent.Pesonet.enteraccountname1";
    String KeySelectBankName="onlineBanking.BuyLoad.SelectBankName";
    String KeyVerifyTranferToPageTitle = "convergent.Pesonet.verifypagetitle";
    String KeyNext = "convergent.Pesonet.btnnext";
    String KeyDone = "convergent.TransferDetails.donebtn";
    String KeyEnterAmt = "convergent.Pesonet.enteramt";
    String KeyClickDate = "convergent.Pesonet.transactiondate";
    String KeyBtnOk = "convergent.Pesonet.btnok";
    String KeyPurpose = "convergent.Pesonet.selectpurpose";
    String KeyEnterPurpose = "convergent.Pesonet.searchtxtbox";
    String KeyClickPurpose = "convergent.Pesonet.clickpurpose";
    String KeyClickTransfer = "convergent.Pesonet.transferbtn";
    String KeyVerifyTitle = "convergent.Pesonet.verifypagetitle1";
    String KeyBtnProceed = "convergent.Pesonet.proceedwithtransferbtn";
    String KeyErrorMsg = "convergent.Pesonet.errormsg";
    String KeyErrorMsg1 = "convergent.Pesonet.errormsg1";
    String KeyOtherBankAmtErrorMsg = "convergent.Pesonet.FieldErrormsg";
    String KeyOtpErrorMsg = "convergent.Pesonet.otperrormsg";
    String KeyNewTransaction = "convergent.Pesonet.newtransactionbtn";
    String KeySelectFromRecipient = "convergent.Pesonet.selectfromrecipients";
    String KeySelectFromRecipientinstapay= "convergent.Pesonet.selectfromrecipientsinstapay";
    String KeySearchRecipient = "convergent.Pesonet.searchrecipient";
    String KeyEnterAccountNameToSearch = "convergent.Pesonet.enteracccountnameinsearch";
    String KeySelectBankName1 = "convergent.Pesonet.selectbank1";
    String KeyAmtErrorMsg = "convergent.TransferDetails.amterrormsg";
    String KeySelectPurposeOthers = "convergent.Pesonet.selectpurposeasothers";
    String KeyLeaveaPurposetext = "convergent.TransferDetails.leaveapurposetxt";
    String KeySelectAccountToViewBalance = "convergent.Dashboard.selectaccount";
    String KeySelectAccountToTransfer = "convergent.Pesonet.selectaccounttotransfer";
    String KeySelectAccount1 = "convergent.Dashboard.selectaccount1";
    String keySelectFromFavourites = "convergent.Pesonet.selectfromfavourites";
    String KeySelectAccFromFavoutite = "convergent.TransferTopage.selectrecipient";
    String KeyListAccount = "convergent.Pesonet.listaccounts";
    String KeyEnterAccountNumberError = "convergent.Pesonet.enteraccountnumbererror";
    String KeyEnterAccountNameError="convergent.TransferTopage.accnameerrormsg";
    String KeyPurpose2 = "convergent.TransferDetails.selectpurpose2";
    String KeyErrorMsg2 = "convergent.Pesonet.errormsg2";
    String KeyPDDTSaccountno="convergent.pddtsrecipientaccountnumber.lblaccount";
    String keyNextInstapay= "convergent.TransferTopageinstapay2.BtnNext";
    String RemainingTransactionmsg="convergent.pddts.pddtspage.RemainingTransactionLimit";
    String TransactionLimit="convergent.pddts.TransferDetails.TransactionLimit";
    String EDITFromAccount="convergent.pddts.Reviewandtransfer.FromAccountEDIT";
    String EDITToAccount="convergent.pddts.Reviewandtransfer.ToEDIT";
    String EDITAmount="convergent.pddts.Reviewandtransfer.AmountEDIT";
    String SelectAccount="convergent.pddts.Reviewandtransfer.SelectAccount";
    String SelectDropdown="convergent.pddts.SelectBankDropdown";
    String SelectBank="convergent.pddts.SelectBank";
    String Done="convergent.pddts.Done";
    String EnterAmount="convergent.pddts.EnterUSDAmount";

    String ProceedwithTransfer="convergent.pddts.Proceedwithtransfer";
    String Cancel="convergent.pddts.Cancel";
    String CancelTransfer="convergent.pddts.CancelTransferBtn";
    String NoBtn="convergent.pddts.NoBtn";
    String Backbtn="convergent.pddts.backbtn";
    String Instapay="convergent.pddts.Instapay";
    String PDDTS="convergent.pddts.PDDTS";
    String Pesonet="convergent.pddts.Pesonet";
    String Selectecipients="convergent.TransferTo.SelectRecipients";
    String AddNew="convergent.SelectRecipient.AddNew";
    String BankTxtBox="convergent.AddNewRecipient.BankTxtBox";
    String SelectBank1="convergent.AddNewRecipient.SelectBank1";
//    String EnterAccountNumber="convergent.AddNewRecipient.AccoutNumber";
//    String EnterAccountName="convergent.AddNewRecipient.AccountName";
    String SaveasFavourite="convergent.AddNewRecipient.Saveasfavourite";
//    String Save ="convergent.AddNewRecipient.Save";
    String FromAccount="convergent.ReviewTransfer.FromAccount";
    String ToAccount="convergent.ReviewTransfer.ToAccount";
    String Amount="convergent.ReviewTransfer.Amount";

    ConvergentTestRunner Devicename=new ConvergentTestRunner();

    public void clickOtherBanks() throws Throwable {
        click.elementBy(KeyOtherBanks);
    }
    public void clickSelectRecipients()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(Selectecipients);
    }
    public void clickAddNew()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(AddNew);
    }
    public void clickBank_Name()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(BankTxtBox);
        click.elementBy(SelectBank1);
    }
    public void clickFavourite()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(SaveasFavourite);
    }
    public void verifyReviewTransferPage()throws Throwable{
        Wait.forSeconds(1);
        verify.elementIsPresent(FromAccount);
        verify.elementIsPresent(ToAccount);
        verify.elementIsPresent(Amount);
    }
//    public void verifyOptions_SendMoney()throws Throwable{
//        Wait.forSeconds(1);
//        verify.elementIsPresent(Instapay);
//        verify.elementIsPresent(PDDTS);
//        verify.elementIsPresent(Pesonet);
//    }
    public void verifyRemainingTransactionlimit()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(RemainingTransactionmsg);
    }
    public void verifyTransactionLimit()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(TransactionLimit);
    }
    public void clickBackbtn()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(Backbtn);
        verify.elementIsPresent(NoBtn);
        verify.elementIsPresent(CancelTransfer);
    }
    public void clickFromEditbtn()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(EDITFromAccount);
        click.elementBy(SelectAccount);
    }
    public void clickNoBtn()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(NoBtn);
    }
    public void clickToEditBtn()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(EDITToAccount);
        click.elementBy(SelectDropdown);
        click.elementBy(SelectBank);
        click.elementBy(Done);
    }
    public void clickAmtEditBtn()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(EDITAmount);
        click.elementBy(EnterAmount);
        click.elementBy(Done);
    }
    public void verifyPopUp()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(Cancel);
        verify.elementIsPresent(ProceedwithTransfer);
    }
    public void selectSendMoneyViaPesonet() throws Throwable {
        click.elementBy(KeyOtherBankPesonet);
    }

    public void selectAccountFromList(String accnum) throws Throwable {
       Wait.waituntillElementVisibleMob(KeySelectAccount,9);
        click.elementBy(KeySelectAccount);
        //swipe.scrollDownToTextandClick("Regular Checking");
    }

    public void selectAccountFromListIOS(String accnum) throws Throwable {
         driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"UBP QAT\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[3]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton").click();
        //swipe.scrollDownToTextandClick("Regular Checking");
    }

    public void selectAccountFromList1(String AccountNumber) throws Throwable {
        click.elementBy(KeySelectAccount, AccountNumber);

    }

    public void clickBankInstapay() throws Throwable {
        Wait.forSeconds(10);

        if(Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            actions.Touch.pressByCoordinates(969, 489, 5);
        }
        else if(Devicename.currentdevicename.equalsIgnoreCase("Samsung")){
            actions.Touch.pressByCoordinates(980, 453, 5);

        }
        else {
            actions.Touch.pressByCoordinates(400, 530, 5);
        }
        Wait.forSeconds(10);

    }

    public void clickBankPesonet() throws Throwable {
        Wait.forSeconds(7);
        if (Devicename.currentdevicename.equalsIgnoreCase("Samsung"))
        {
            actions.Touch.pressByCoordinates(332, 714, 5);
            actions.Touch.pressByCoordinates(332, 714, 5);
        }
        else if(Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30"))
        {
            actions.Touch.pressByCoordinates(969, 757, 5);
            actions.Touch.pressByCoordinates(969, 757, 5);
        }
        else {
            actions.Touch.pressByCoordinates(235, 709, 5);

        }
    }
        public void clickBankPDDTS() throws Throwable {
            Wait.forSeconds(10);
            if(Devicename.currentdevicename.equalsIgnoreCase("Samsung"))
            {
                actions.Touch.pressByCoordinates(983, 612, 5);
                actions.Touch.pressByCoordinates(983, 612, 5);
            }
            else if(Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30"))
            {
                actions.Touch.pressByCoordinates(966, 711, 5);
                actions.Touch.pressByCoordinates(966, 711, 5);
            }
            else {
                actions.Touch.pressByCoordinates(983, 612, 5);

            }
    }


    public void clickBankIOS() throws Throwable {
        Wait.waituntillElementVisibleMob(KeyClickBank,2);
        click.elementBy(KeyClickBank);
        //MobileElement el3 = (MobileElement) driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"UBP QAT\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[4]/XCUIElementTypeOther/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeButton");
        //el3.click();
        //Thread.sleep(1000);
        //MobileElement el1 = (MobileElement) driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"UBP QAT\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[4]/XCUIElementTypeOther/XCUIElementTypeScrollView/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[4]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton");
        //el1.click();

        //actions.Touch.pressByCoordinates(333, 290, 2);

    }

    public void clickActionSearch() throws Throwable {
        Wait.waituntillElementVisibleMob(KeyActionSearch,3);
        click.elementBy(KeyActionSearch);

    }

    public void enterBankName(String bank) throws Throwable {
        type.data(KeyEnterBankName, bank);
    }

    public void clickAccNum(String accnum) throws Throwable {
        WAIT.forSeconds(4);
        swipe.scrollDownToTextandClick(accnum);

    }

    public void clickAccNumselect(String accnum) throws Throwable {
        Wait.waituntillElementVisibleMob(KeyPDDTSaccountno,3);
        click.elementBy(KeyPDDTSaccountno);

    }


    public void verifyAccoutNumberFilled(String accnum) throws Throwable {
        verify.elementTextMatching(KeyListAccount, accnum);
    }


    public void verifyAccoutNumberFilledIOS(String accnum) throws Throwable {
        verify.elementTextMatching(KeyEnterAccountNumberEdit, accnum);
    }
    public void selectBankName_EwalletPeso() throws Throwable {
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        click.elementBy(selectbankfromPesonet);
    }
    public void selectBankName() throws Throwable {
        click.elementBy(KeySelectBank);
//        click.elementBy(KeySearchBank);
       // click.elementBy(KeySelectBankName1);
    }

    public void enterAccountNumber(String accountnum) throws Throwable {
        WAIT.forSecondsUsingFluentWAIT(2,KeyEnterAccountNumber);
        type.data(KeyEnterAccountNumber, accountnum);
    }
    public void enterMobileNumber(String mobilenum) throws Throwable {
        Wait.waituntillElementVisibleMob(KeyEnterMobilenumberNumber,3);
        type.data(KeyEnterMobilenumberNumber, mobilenum);

    }

    public void clickAccountNumber() throws Throwable {
        click.elementBy(KeyEnterAccountNumber);
    }

    public void enterAccountNumberIOS(String accountnum) throws Throwable {
        Wait.waituntillElementVisibleMob(KeyEnterAccountNumberError,3);
        type.data(KeyEnterAccountNumberError, accountnum);
    }

    public void clickAccountNumberPageToIOS() throws Throwable {
        Wait.waituntillElementVisibleMob(KeyEnterAccountNumber,3);
        click.elementBy(KeyEnterAccountNumber);
        //click.elementBy(KeyEnterAccountNameError);

    }
    public void clickAccountNumberPageToIOS2() throws Throwable {
        Wait.waituntillElementVisibleMob(KeyEnterAccountNumberEdit,3);
        click.elementBy(KeyEnterAccountNumberEdit);
        //click.elementBy(KeyEnterAccountNameError);

    }
    public void enterAccountNumberTransferToIOS(String accountnum) throws Throwable {
        Wait.forSeconds(4);
        driver.findElementByXPath("//*[@value='106400001643']").clear();
        Wait.waituntillElementVisibleMob(KeyEnterAccountNumber,4);
        //type.data(KeyEnterAccountNumberEdit, accountnum);
        type.data(KeyEnterAccountNumber, accountnum);
    }

    public void enterAccountName(String accountname) throws Throwable {
        type.data(KeyEnterAccountName, accountname);
    }

    public void verifyAccountNameFieldIsFilled(String accountname) throws Throwable {

        try {

            verify.elementTextMatching(KeyEnterAccountName, accountname);

        }

       catch (Exception e)
       {

           verify.elementTextMatching(KeyEnterAccountName1, accountname);

       }
    }

    public void verifyAccountNameFieldIsFilledIOS(String accountname) throws Throwable {
        verify.elementTextMatching(KeyEnterAccountName1, accountname);
    }

    public void verifyNextEnabled() throws Throwable {
        verify.elementIsEnabled(KeyNext);

    }

    public void clickNext() throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyNext,3);
        click.elementBy(KeyNext);
    }

    public void clickNext_InstaPay() throws ApplicationException {
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        verify.elementIsPresent(keyNextInstapay);
        Wait.waituntillElementVisibleMob(keyNextInstapay,4);
        click.elementBy(keyNextInstapay);

    }

    public void clickDoneIOS() throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyDone,3);
        click.elementBy(KeyDone);

    }

    public void enterTransferAmt(String amount) throws Throwable {
        Wait.forSeconds(2);

        driver.findElementById("com.unionbankph.online.qat:id/text_amount");
        Actions action = new Actions(driver);
        action.sendKeys(amount).perform();
        /*
        if(Devicename.currentdevicename.equalsIgnoreCase("Samsung")){
            type.data(KeyEnterAmt, amount);
        }
        if(Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")){
            type.data1(KeyEnterAmt, amount);
        }
         */
        WAIT.forSeconds(6);
    }

    public void verifyErrorMsg(String Ierror) throws Throwable {
        //verify.elementText(KeyOtherBankAmtErrorMsg, Ierror);

        verify.elementTextMatching(KeyOtherBankAmtErrorMsg,Ierror);
    }

    public void clickDate() throws Throwable {

        click.elementBy(KeyClickDate);
    }

    public void clickOk() throws ApplicationException {
        click.elementBy(KeyBtnOk);
    }

    public void selectPurpose() throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyPurpose,4);
        click.elementBy(KeyPurpose);
//        click.elementBy(KeyPurpose);
//        Wait.forSeconds(15);
////        click.elementBy(By.xpath("//*[@text='PAYMENT']"));
////        click.elementBy(By.xpath("//*[@text='PAYMENT']"));
//        click.elementBy(By.xpath("//*[@text='*OTHERS (Please specify)']"));
//        click.elementBy(By.xpath("//*[@text='*OTHERS (Please specify)']"));
    }
    public void selectPurpose2() throws ApplicationException {
        click.elementBy(KeyPurpose2);
    }
    public void selectPurposepesonet() throws ApplicationException {
        click.elementBy(KeyPurpose);
    }
    public void enterPurpose(String purpose) throws Throwable {
        type.data(KeyEnterPurpose, purpose);
    }

    public void clickPurpose() throws ApplicationException {
        click.elementBy(KeyClickPurpose);
    }

    public void clickTransfer() throws Throwable {
        Wait.waituntillElementVisibleMob(KeyClickTransfer,3);
        click.elementBy(KeyClickTransfer);

    }

    public void clickProceedWithTransfer() throws Throwable {
        if(verify.IfElementExistsboolean(KeyBtnProceed)) {
            Wait.waituntillElementVisibleMob(KeyBtnProceed,3);
            click.elementBy(KeyBtnProceed);
        }
    }

    public void verifyErrorMessage(String expectedDescription) throws ApplicationException {
        verify.elementTextMatching(KeyErrorMsg1, expectedDescription);
    }
    public void verifyErrorMessageBM(String expectedDescription) throws ApplicationException {
        verify.elementTextMatching(KeyErrorMsg2, expectedDescription);
    }
    public void verifyAmtErrorMessage(String expectedDescription) throws ApplicationException {

        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            verify.elementTextMatching(KeyAmtErrorMsg, expectedDescription);
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS")) {

            verify.elementIsPresent(KeyAmtErrorMsg);
        }
    }

    public void verifyReviewAndTransferPageTile(String ititle) throws ApplicationException {
        verify.elementTextMatching(KeyVerifyTitle, ititle);
    }

    public void verifyInvalidOtpErrorMessage(String expectedDescription) throws ApplicationException {
        //verify.elementTextMatching(KeyErrorMsg1, expectedDescription);
        verify.elementIsPresent(KeyErrorMsg1);
    }

    public void clickNewTransaction() throws Throwable {
        Wait.waituntillElementVisibleMob(KeyNewTransaction,4);
        swipe.swipeVertical(2,0.8,.2,5);
        click.elementBy(KeyNewTransaction);

    }

    public void clickSelectFromRecipient() throws Throwable {
        click.elementBy(KeySelectFromRecipient);
    }
    public void clickSelectFromRecipientinstapay() throws Throwable {
        click.elementBy(KeySelectFromRecipientinstapay);
    }
    public void clickSearchActionBtn() throws Throwable {
        click.elementBy(KeySearchRecipient);
    }

    public void enterBankNameToSearch(String accountname) throws Throwable {
        Wait.waituntillElementVisibleMob(KeyEnterAccountNameToSearch,4);
        type.data(KeyEnterAccountNameToSearch, accountname);

    }

    public void clicBankNameToTsransfer() throws Throwable {
        click.elementBy(KeySelectBankName);
    }

    public void clickPurposeOthers() throws Throwable {
        click.elementBy(KeySelectPurposeOthers);
    }

    public void verifyLeaveaPurposeTextBoxExist() throws Throwable {
        verify.IfElementNotExists(KeyLeaveaPurposetext);
    }

    public void verifyLeaveaPurposeTextBoxNotExist() throws Throwable {
        verify.IfElementNotExists(KeyLeaveaPurposetext);
    }

    public void clickAccountToViewBalance(String viewbalance) throws Throwable {
        Wait.waituntillElementVisibleMob(KeySelectAccountToViewBalance,4);
        click.elementBy(KeySelectAccountToViewBalance, viewbalance);

    }

    public void clickAccountToTransfer(String arg1) throws Throwable {
        click.elementBy(KeySelectAccountToTransfer, arg1);
    }

    public void clickAccountToViewBalance1(String viewbalance) throws Throwable {
        Wait.waituntillElementVisibleMob(KeySelectAccount1,3);
        click.elementBy(KeySelectAccount1, viewbalance);
    }

    public void clickFavourites() throws Throwable {
        Wait.waituntillElementVisibleMob(keySelectFromFavourites,4);
        click.elementBy(keySelectFromFavourites);

    }

    public void clickAccountName() throws Throwable {
        click.elementBy(KeyEnterAccountName);
    }

    public void selectPesonet() throws Throwable {
        click.elementBy(KeyOtherBankPesonet);
    }
    public void verifyRemainingFundLimit() throws ApplicationException {
        Wait.waituntillElementVisibleMob(RemainingLimitEwallet,3);
        verify.elementIsPresent(RemainingLimitEwallet);

    }
    public void verifyDailyFundLimit() throws ApplicationException {
        Wait.waituntillElementVisibleMob(DailyLimitEwallet,3);
        verify.elementIsPresent(DailyLimitEwallet);
    }
    public void verifyDailyLimitErrorMessage() throws ApplicationException {
        Wait.waituntillElementVisibleMob(MinimumErrormessage,4);
        verify.elementIsPresent(MinimumErrormessage);

    }
    public void verifyMaximumLimitErrorMessage() throws ApplicationException {
        Wait.waituntillElementVisibleMob(MaximumLimitErrormessage,3);
        verify.elementIsPresent(MaximumLimitErrormessage);

    }
    public void verifyRemainderMessage()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(RemainderMessage);
    }
    public void verifyRemainderPopup()throws Throwable{
        Wait.forSeconds(1);
        verify.elementIsPresent(RemainderPopup);
    }
}