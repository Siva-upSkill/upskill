package pages;

import actions.Wait;
import base.Keywords;
import driver.DriverManager;
import exceptions.ApplicationException;
import gherkin.lexer.Th;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import runners.ConvergentTestRunner;

import java.util.Calendar;
import java.util.Date;

public class PayBillsPage extends Keywords {
    String KeyPayBillsInDashBoard = "convergent.home.labelPaybills";
    String KeyPayBillsPageTitle = "convergent.PayBills.labelPayBillsPageTitle";
    String KeySelectBillerBtn = "convergent.PayBills.btnSelectBiller";

    String KeyRemainderPOPUP="convergent.ReviewandTransfer.RemainderPopup";
    String KeySelectBillerPageTitle = "convergent.PayBills.SelectBiller.labelSelectBillerPageTitle";
    String KeyBackbtnInSelectBillerPage = "convergent.PayBills.SelectBiller.btnBack";
    String KeyBackbtnInSelectBillerPage1 = "convergent.PayBills.SelectBiller.btnBack1";
    String KeyMyBillersTabinSelectBiller = "convergent.PayBills.SelectBiller.MyBillersTab";
    String KeyFavoritesTabinSelectBiller = "convergent.PayBills.SelectBiller.FavoritesTab";
    String KeyBillerListTabinSelectBiller = "convergent.PayBills.SelectBiller.BillerListTab";
    String KeySearchBtnSelectBiller = "convergent.PayBills.SelectBiller.btnSearch";
    String KeySearchTextBoxSelectBiller = "convergent.PayBills.SelectBiller.txtSearch";
    String KeySearchBillerslabel = "convergent.PayBills.SelectBiller.labelSearchBillers";
    String KeySearchBillerslabelFavorites = "convergent.PayBills.SelectBiller.labelSearchBillersFavorites";
    String KeySearchBillerslabelBillerList = "convergent.PayBills.SelectBiller.labelSearchBillersBillerList";
    String KeySearchBillerslabelBillerList1 = "convergent.PayBills.SelectBiller.labelSearchBillersBillerList1";

    String labelSearchBillersBillerList_Ewallet = " convergent.PayBills.SelectBiller.labelSearchBillersBillerList_Ewallet";
    String KeyDoneInSelectFrequency = "convergent.PayBills.SelectBiller.PaymentDetails.SelectFrequecy.btnDone";
    String KeyBtnNextBillerinformation = "convergent.PayBills.SelectBiller.BillerInformation.btnNext";
    String KeyBillerInformationPageTitle = "convergent.PayBills.SelectBiller.BillerInformation.labelBillerInformationPageTitle";
    String KeypayfromWhcichAccountPageTitle = "convergent.PayBills.SelectBiller.PayfromwhichAccount.labelPayfromWhichAccountPageTitle";
    String Keyaccount = "convergent.PayBills.SelectBiller.PayfromwhichAccount.btnaccount";
    String Keyaccountedit = "convergent.PayBills.SelectBiller.PayfromwhichAccount.btnaccountedit";
    String KeyPaymentDetailsPageTitle = "convergent.PayBills.SelectBiller.PaymentDetails.labelPaymentDetailsPageTitle";
    String KeyAmountInPaymentDetails = "convergent.PayBills.SelectBiller.PaymentDetails.txtAmount";
    String KeyReviewAndPayPageTitle = "convergent.PayBills.SelectBiller.ReviewandPay.labelReviewandPayPageTitle";
    String KeyPaybuttonInReviewAndPay = "convergent.PayBills.SelectBiller.ReviewandPay.btnPayPHP";
    String KeyPaymentSuccessfulPageTitle = "convergent.PayBills.SelectBiller.PaymentSuccessful.labelPaymentSuccessfulPageTitle";
    String KeyRepeatBtn = "convergent.PayBills.SelectBiller.PaymentDetails.btnRepeat";
    String KeyAmountGreaterErrorMessage = "convergent.PayBills.SelectBiller.PaymentDetails.Amountgreatererrormessge";
    String KeyCalenderInPaymentDetails = "convergent.PayBills.SelectBiller.PaymentDetails.btnDateIcon";
    String KeyCalenderDone = "convergent.PayBills.SelectBiller.PaymentDetails.SelectFrequecy.btnDone";
    String KeyCloseInReviewAndPayBtn = "convergent.PayBills.SelectBiller.ReviewandPay.btnClose";
    String KeyCancelPaymentInHandOn = "convergent.PayBills.SelectBiller.ReviewandPay.btnCancelPayment";
    String KeyAccountEdit = "convergent.PayBills.SelectBiller.ReviewandPay.linkAccountEdit";
    String KeyBillerEdit = "convergent.PayBills.SelectBiller.ReviewandPay.linkBillerEdit";
    String KeyAmountEdit = "convergent.PayBills.SelectBiller.ReviewandPay.linkAmountEdit";
    String KeyDone = "convergent.PayBills.SelectBiller.BillerInformation.btnDone";
    String KeyAmountEditInPaymentDetails = "convergent.PayBills.SelectBiller.PaymentDetails.txtAmountEdit";
    String KeyUnMaskedInReviewAndPay = "convergent.PayBills.SelectBiller.ReviewandPay.labelUnMaskAccount";
    String KeyMaskedInReviewAndPay = "convergent.PayBills.SelectBiller.ReviewandPay.labelMaskAccount";
    String KeyBackbutton = "convergent.PayBills.SelectBiller.ReviewandPay.btnClose";
    String KeyCloseBtnInBillerInformation = "convergent.PayBills.SelectBiller.BillerInformation.btnClose";
    String KeyFrequencyInPaymentDetails = "convergent.PayBills.SelectBiller.PaymentDetails.Frequency";
    String KeyEndDateInPaymentDetails = "convergent.PayBills.SelectBiller.PaymentDetails.EndDate";
    String KeylabelFrequencyInPaymentDetails = "convergent.PayBills.SelectBiller.PaymentDetails.labelFrequency";
    String KeylabelEndDateInPaymentDetails = "convergent.PayBills.SelectBiller.PaymentDetails.labelEndDate";
    String KeyBillerNumbervalue = "convergent.PayBills.SelectBiller.BillerInformation.BillerNumber";
    String KeyBillerNumber = "convergent.PayBills.SelectBiller.BillerInformation.BillerNumber1";
    String KeybtnDoneKeyboard = "convergent.PayBills.SelectBiller.BillerInformation.KeyboardDone";
    String KeyBillererrormessage = "convergent.PayBills.SelectBiller.BillerInformation.BillerErrormessage";
    String KeyAmountErrorMessage = "convergent.PayBills.SelectBiller.PaymentDetails.Amounterrormessge";
    String KeyCurrentDateInPaymentDetails = "convergent.PayBills.SelectBiller.PaymentDetails.btnCurrentDate";
    String KeyUnMaskedInPaymentSuccessful = "convergent.PayBills.SelectBiller.PaymentSuccessful.labelUnMaskAccount";
    String KeyMaskedInPaymentSuccessful = "convergent.PayBills.SelectBiller.PaymentSuccessful.labelMaskAccount";
    String KeyNewPaymentInPaymentSuccessful = "convergent.PayBills.SelectBiller.PaymentSuccessful.btnNewPayment";
    String KeyGoToDashboardInPaymentSuccessful = "convergent.PayBills.SelectBiller.PaymentSuccessful.btnGoToDashboard";
    String KeyNotificationsPageTitle = "convergent.Notifications.labelNotificationsPageTitle";
    String KeyTransactionsTab = "convergent.Notifications.TransactionsTab";
    String KeyUnMaskedInNotifications = "convergent.Notifications.labelUnMaskAccount";
    String KeyMaskedInNotifications = "convergent.Notifications.labelMaskAccount";
    String KeyMainInDashBoard = "convergent.home.btnMail";
    String KeyBillernameInBillerInformation = "convergent.PayBills.SelectBiller.BillerInformation.labelBillername";
    String KeyManageBillersInPayBills = "convergent.PayBills.Manage.btnManageBillers";
    String KeySearchbtnInManageBills = "convergent.PayBills.ManageBillers.btnSearch";
    String KeySearchtxtInManageBills = "convergent.PayBills.ManageBillers.txtSearch";
    String KeyManageBillsPageTitle = "convergent.PayBills.ManageBillers.labelManageBillersPageTitle";
    String KeyFavoritesTabbtnInManageBills = "convergent.PayBills.ManageBillers.FavoritesTab";
    String KeyFavoritesbtnInManageBills = "convergent.PayBills.ManageBillers.btnFavorites";
    String KeyBackInManageBills = "convergent.PayBills.ManageBillers.btnBack";
    String KeyCloseSearchInManageBills = "convergent.PayBills.ManageBillers.btncloseSearch";
    String KeyBackSearchInManageBills = "convergent.PayBills.ManageBillers.btnBackSearch";
    String KeyTodayCalender = "convergent.PayBills.SelectBiller.PaymentDetails.txtToday";
    String KeyAccountIDInBillerInformation = "convergent.PayBills.SelectBiller.BillerInformation.txtAccountID";
    String KeyAccountIDWithInputInBillerInformation = "convergent.PayBills.SelectBiller.BillerInformation.txtAccountItem";
    String KeySubTitleInBillerInformation = "convergent.PayBills.SelectBiller.BillerInformation.labelSubtitle";
    String Keyunionbankcardnumber="convergent.PauBills.SelectBiller.Unionbankvisacard.txtcardnumber";
    String Keyunionbankcardnumber_CC = "convergent.PauBills.SelectBiller.Unionbankvisacard.txtcardnumber_CC";
    String Keyclosebtn="convergent.ReviewandTransfer.closebtn";
    String closeBtn_ReviewandPay = "convergent.ReviewandPay.closeBtn";
    String Keymanagebillers="convergent.Paybills.linkManagebillers";
    String Keymanagebillersalias="convergent.Paybills.txtbilleralias";
    String Keymanagebillerslst="convergent.Paybills.lstselectbiller";
    String Keymanagebillerbillercard="convergent.Paybills.lblcardnumber";
    String Keymanagebillerbillercardnumber="convergent.Paybills.txtcardnumber";
    String Keyfavouriteon="convergent.Paybills.btnFavouriteoff";
    String Keysave="convergent.Paybills.btnSave";


    String KeyFavouritebiller="convergent.Paybills.lnkfavourite2nd";
    String KeyEditbiller="convergent.Paybills.btnedit";
    String Keyfavouritelnk="convergent.Paybills.lnkFavourite";
    String Keyfavouriteoff="convergent.Paybills.btnFavouriteon";
    String KeyDeletebiller="convergent.Paybills.btndelete";
    String Keypaymentreferenceno="convergent.Paybills.txtpaymentreferenceno";

    String Keypayorsname="convergent.Paybills.txtpayorsname";
    String Keypolicyno="convergent.Paybills.txtpolicyno";
    String KeyUsername="convergent.Paybills.txtUsername";
    String KeyReferenceNumber="convergent.Paybills.txtReferenceNumber";
    String keyVecoUBP="convergent.PayBills.VecoUBP";
    String TaptoSelectAccount = "convergent.payBills.TaptoSelectAccount";

    String PayRefNo = "convergent.PayBillsCC.EnterBillerInfo.PayRefNo";

    String PayorsName = "convergent.PayBillsCC.EnterBillerInfo.PayorsName";
    String SelectAcc = "convergent.PaybillsCC.SelectAcc";
    String CreditCard = "convergent.PayBillsCC.PayFromWhichAcc.Card";
    String Next = "convergent.PayBillsCC.Next";
    String PayBillBtn = "convergent.PayBills.PayBillBtn";
    String GotItBtn = "convergent.PayBills.GotITBtn";
    String PaymentReceivedTitle = "convergent.PayBills.PaymentReceivedTitle";
    String PaymentReceivedText = "convergent.PayBills.PaymentReceivedText";
    String FinalPageGotITBtn = "convergent.PayBills.FinalPageGotITBtn";
    String Biller1 = "convergent.PayBills.SelectBiller.Biller1";
    String ErrorMessage = "convergent.PayBills.SelectBiller.PayfromwhichAccount.ErrorMessage";

    String LimitReminderEwallet = "convergent.PayBills.SelectBiller.PaymentDetails.LimitReminderEwallet";

    String DailyTransactionLimitAmountErrorMsg = "convergent.PayBills.SelectBiller.PaymentDetails.DailyTransactionLimitAmountErrorMsg";
    String RemainingLimitEwallet = "convergent.PayBills.SelectBiller.PaymentDetails.RemainingLimitEwallet";
    String ListOfBillers="convergent.PayBills.ListOFBillers";
    String ListOfAccounts="convergent.PayBills.ListOfAccounts.PayFromAccount";
    String PaymentDetailsPage="convergent.PayBills.SelectBiller.PaymentDetails.labelPaymentDetailsPageTitle";
    String Repeat ="convergent.PayBills.SelectBiller.PaymentDetails.btnRepeat";
    String PayFromAccount="convergent.PayBills.Payfromaccount";
    String Frequency="convergent.PayBills.SelectBiller.PaymentDetails.Frequency";
    String EndDate="convergent.PayBills.SelectBiller.PaymentDetails.EndDate";
    String FromAccount="convergent.PayBills.SelectBiller.ReviewandPay.FromAccount";
    String ToBiller="convergent.PayBills.SelectBiller.ReviewandPay.ToBiller";
    String Amount="convergent.PayBills.SelectBiller.Amount";
    String RecentPayments="convergent.PayBills.Manage.btnRecentPayments";
    String ManageBiller="convergent.PayBills.ManageBillers.ManageBiller";
    String AddNewBiller="convergent.PayBills.AddNewBiller";
    String ScheduledPayments="convergent.PayBills.ScheduledPayments";
    String ScheduledPaymentsDetails="convergent.PayBills.ScheduledPayments.PaymentsDetails";
    String ReferenceNumber="convergent.PayBills.ScheduledPayments.ReferenceNumber";
    String Date="convergent.PayBills.ScheduledPayments.Date";
    String FromAccount1="convergent.PayBills.ScheduledPayments.FromAccount";
    String PaymentStartDate="convergent.PayBills.ScheduledPayments.PaymentStartDate";
    String NextPaymentDATE="convergent.PayBills.ScheduledPayments.NextPaymentDate";


    ConvergentTestRunner Devicename = new ConvergentTestRunner();

    public void clickPayBillsInDashBoard() throws Throwable {
     Wait.forSeconds(10);
        MobileElement element = (MobileElement) driver.findElementByAccessibilityId("PAY BILLS");
     element.click();
       //click.elementBy(KeyPayBillsInDashBoard);
    }
    public void verifyTabs()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(KeyMyBillersTabinSelectBiller);
        verify.elementIsPresent(KeyBillerListTabinSelectBiller);
    }
    public void verifyPaymentDetailsScreen()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(Amount);
        verify.elementIsPresent(Repeat);
        verify.elementIsPresent(PaymentDetailsPage);
        verify.elementIsPresent(PayFromAccount);
    }

    public void verifyToggleOn()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(Repeat);
        verify.elementIsPresent(Frequency);
        verify.elementIsPresent(EndDate);
        click.elementBy(Repeat);
    }
    public void verifyListAccounts()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(TaptoSelectAccount);
        verify.elementIsPresent(ListOfAccounts);
    }
    public void verifyReviewandPay()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(FromAccount);
        verify.elementIsPresent(ToBiller);
        verify.elementIsPresent(Amount);
    }
    public void verifyPayBillsPage()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(RecentPayments);
    }
    public void clickScheduledPayment()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(ScheduledPayments);
    }
    public void clickAnyoneScheduledPayment()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(ScheduledPaymentsDetails);
    }

    public void verifyScheduledPayments()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(ReferenceNumber);
        verify.elementIsPresent(Date);
        verify.elementIsPresent(FromAccount1);
        verify.elementIsPresent(PaymentStartDate);
        verify.elementIsPresent(Frequency);
        verify.elementIsPresent(NextPaymentDATE);
    }


    public void verifyPayBillsPageTitle(String pagetitle) throws Throwable {
        Wait.waituntillElementVisibleMob(KeyPayBillsPageTitle,4);
        verify.elementTextMatching(KeyPayBillsPageTitle, pagetitle);
    }

    public void clickSearchbtnInManageBills() throws Throwable {
        click.elementBy(KeySearchbtnInManageBills);
    }

    public void enterSearchtxtInManageBills(String Biller) throws Throwable {
        Wait.waituntillElementVisibleMob(KeySearchtxtInManageBills,4);
        type.data(KeySearchtxtInManageBills, Biller);

    }

    public void enterSearchtxtInManageBillsAndroid(String Biller) throws Throwable {
        //type.data(KeySearchtxtInManageBills, Biller);

        WAIT.forSeconds(2);
        MobileElement el2 = (MobileElement) driver.findElementById("com.unionbankph.online.qat:id/searchTextView");
        el2.setValue("UnionBank Visa");
        WAIT.forSeconds(5);
    }

    public void enterSearchtxtInManageBillsAndroid1(String Biller) throws Throwable {
        //type.data(KeySearchtxtInManageBills, Biller);

        WAIT.forSeconds(2);
        MobileElement el2 = (MobileElement) driver.findElementById("com.unionbankph.online.qat:id/searchTextView");
        el2.setValue("VECO UNINON BANK OF PHILIPPINES");
        WAIT.forSeconds(5);
    }

    public void clickFavoritesbtnInManageBills() throws Throwable {
        click.elementBy(KeyFavoritesbtnInManageBills);
    }

    public void clickBackInManageBills() throws Throwable {
        click.elementBy(KeyBackInManageBills);
    }

    public void clickCloseSearchInManageBills() throws Throwable {
        click.elementBy(KeyCloseSearchInManageBills);
    }

    public void clickBackSearchInManageBills() throws Throwable {
        click.elementBy(KeyBackSearchInManageBills);
    }

    public void clickSelectBillerBtnInPayBills() throws Throwable {
        click.elementBy(KeySelectBillerBtn);
    }

    public void clickSelectBillerBtnInPayBillsAndroid() throws Throwable {
        //click.elementBy(KeySelectBillerBtn);
        swipe.scrollDownToTextandClick("UNIONBANK VISA");
    }

    public void clickSelectBillerBtnInPayBillsAndroid1() throws Throwable {

        //click.elementBy(KeySelectBillerBtn);
        swipe.swipeVertical(2, 0.8, 0.2, 5);
       // swipe.swipeVertical(2, 0.3, 0.8, 5);
       // swipe.scrollDownToTextandClick("VECO UNINON BANK OF PHILIPPINES");
        click.elementBy(keyVecoUBP);
    }

    public void verifySelectBillerPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeySelectBillerPageTitle, pagetitle);
    }

    public void clickBackBtnInPayBills() throws Throwable {
        click.elementBy(KeyBackbtnInSelectBillerPage1);
    }

    public void clickMyBillersTabinSelectBiller() throws Throwable {
        click.elementBy(KeyMyBillersTabinSelectBiller);
    }

    public void clickFavoritesTabinSelectBiller() throws Throwable {
        click.elementBy(KeyFavoritesTabinSelectBiller);
    }

    public void clickBillerListTabinSelectBiller() throws Throwable {
        click.elementBy(KeyBillerListTabinSelectBiller);
    }

    public void clickSearchBtnSelectBiller() throws Throwable {
        Wait.waituntillElementVisibleMob(KeySearchBtnSelectBiller,3);
        click.elementBy(KeySearchBtnSelectBiller);

    }

    public void selectBillerin_BillerList() throws Throwable {
        click.elementBy(KeySearchBillerslabel);
        WAIT.forSeconds(5);
    }

    public void enterSearchtextboxInSelectBiller(String Biller) throws Throwable {
        Wait.waituntillElementVisibleMob(KeySearchTextBoxSelectBiller,3);
        type.data(KeySearchTextBoxSelectBiller, Biller);

    }

    public void enterSearchtextboxInSelectBillerAndroid(String Biller) throws Throwable {
        swipe.scrollDownToTextandClick("Pause Goal");
        //type.data(KeySearchTextBoxSelectBiller, Biller);
        //WAIT.forSeconds(5);
    }

    public void verifySearchBiller(String searchbiller) throws Throwable {
        verify.elementTextMatching(KeySearchBillerslabel, searchbiller);
    }

    public void verifySearchFavorites(String searchfavorites) throws Throwable {
       // click.elementBy(KeySearchBillerslabelFavorites);
        Wait.waituntillElementVisibleMob(KeySearchBillerslabelFavorites,3);
        verify.elementTextMatching(KeySearchBillerslabelFavorites, searchfavorites);
    }

    public void verifySearchBillerList(String searchbillerList) throws Throwable {
        verify.elementTextMatching(KeySearchBillerslabelBillerList, searchbillerList);
    }

    public void verifySearchBillerList1(String searchbillerList) throws Throwable {
        verify.elementTextMatching(KeySearchBillerslabelBillerList1, searchbillerList);
    }
    public void clickSearchBillerList1() throws Throwable {
        click.elementBy(KeySearchBillerslabelBillerList1);
    }
    public void clickSearchBillerList_Ewallet() throws Throwable {
        click.elementBy(labelSearchBillersBillerList_Ewallet);
    }

    public void chooseBiller() throws Throwable {
        click.elementBy(KeySearchBillerslabelFavorites);
    }

    public void chooseBillerAndroid() throws Throwable {
        click.elementBy(KeySearchBillerslabelBillerList);
    }

    public void verifyBillerInformationPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyBillerInformationPageTitle, pagetitle);
    }

    public void clickNext() throws Throwable {
        click.elementBy(KeyBtnNextBillerinformation);
    }

    public void verifyPayFromAccountPageTitle(String pagetitle) throws Throwable {
       //tap to select
        Wait.waituntillElementVisibleMob(TaptoSelectAccount,3);
        click.elementBy(TaptoSelectAccount);
        Wait.waituntillElementVisibleMob(KeypayfromWhcichAccountPageTitle,3);
        verify.elementIsPresent(KeypayfromWhcichAccountPageTitle);
    }

    public void chooseAccount() throws Throwable {
        click.elementBy(Keyaccount);
    }

    public void chooseAccountedit() throws Throwable {
        click.elementBy(Keyaccountedit);
    }

    public void clickDoneInPaymentDetails() throws Throwable {
        click.elementBy(KeyDoneInSelectFrequency);
    }

    public void chooseWeeklyFrequencyIOS() throws ApplicationException {
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2126")){
            actions.Touch.pressByCoordinates(186, 727, 5); }
    }

    public void verifyPaymentDetailsPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyPaymentDetailsPageTitle, pagetitle);
    }

    public void enterAmountInPaymentDetails(String Biller) throws Throwable {
        Wait.waituntillElementVisibleMob(KeyAmountInPaymentDetails,3);
        click.elementBy(KeyAmountInPaymentDetails);
        type.data1(KeyAmountInPaymentDetails, Biller);

    }

    public void verifyReviewAndPayPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyReviewAndPayPageTitle, pagetitle);
    }

    public void clickPaybuttonInReviewAndPay() throws Throwable {
        click.elementBy(KeyPaybuttonInReviewAndPay);
    }

    public void clickPaybuttonInReviewAndPayAndroid() throws Throwable {
        click.elementBy(KeyPaybuttonInReviewAndPay);
//        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
//            actions.Touch.pressByCoordinates(356, 1020, 5); }
//        if (Devicename.currentdevicename.equalsIgnoreCase("NOKIA7")){
//            actions.Touch.pressByCoordinates(568, 1149, 5); }
//        if (Devicename.currentdevicename.equalsIgnoreCase("NOKIA7")){
//            actions.Touch.pressByCoordinates(568, 1300, 5); }
//        //actions.Touch.pressByCoordinates(356, 1020, 5);

    }


    public void verifyPaymentSuccessfulPageTitle(String pagetitle) throws Throwable
    {
       try {
           verify.elementTextMatching(KeyPaymentSuccessfulPageTitle, pagetitle);
       }
       catch(AssertionError e )
       {
          verify.elementTextMatching(KeyPaymentSuccessfulPageTitle,"Payment Successful");
    }
    }

    public void clickRepeatSwitch() throws Throwable {
        click.elementBy(KeyRepeatBtn);
    }

    public void verifyAmountgreatererrormessage(String errormessge) throws Throwable {
        verify.elementTextMatching(KeyAmountGreaterErrorMessage, errormessge);
    }

    public void verifyAmountgreatererrormessageAndroid(String errormessge) throws Throwable {
        verify.elementTextMatching(KeyAmountGreaterErrorMessage, errormessge);
    }

    public void clickCalender() throws Throwable {
        //click.elementBy(KeyCalenderInPaymentDetails);
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2126")){
            actions.Touch.pressByCoordinates(333, 215, 5); }

        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
            actions.Touch.pressByCoordinates(633, 423, 5); }
    }

    public void clickCalenderAndroid() throws Throwable {
        actions.Touch.pressByCoordinates(633, 423, 5);
    }

    public void chooseFutureDate(String arg1) throws Throwable {
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2126")){
            actions.Touch.pressByCoordinates(67, 727, 5); }
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
            actions.Touch.pressByCoordinates(501, 874, 5); }
            click.elementBy(KeyCalenderDone);


    }

    public void clickTodayCalender() throws Throwable {
        Wait.waituntillElementVisibleMob(KeyTodayCalender,3);
        click.elementBy(KeyTodayCalender);
    }

    public void clickDoneCalender() throws Throwable {
        click.elementBy(KeyCalenderDone);
    }

    public void chooseVisitDate(String date) throws ApplicationException {
        Calendar c = Calendar.getInstance();
        c.setTime(new Date()); // Now use today date.
        c.add(Calendar.DATE, 2); // Adds 15 days
        click.pickdatefromcalendar(date);
    }

    public void clickCloseInReviewAndPay() throws Throwable {
        click.elementBy(KeyCloseInReviewAndPayBtn);
    }

    public void clickCloseInReviewAndPayAndroid() throws Throwable {
        //click.elementBy(KeyCloseInReviewAndPayBtn); // 78 106
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
        actions.Touch.pressByCoordinates(56, 106, 5); }
        else{
            click.elementBy(closeBtn_ReviewandPay);
        }
    }

    public void clickCancelPaymentInHandOn() throws Throwable {
        click.elementBy(KeyCancelPaymentInHandOn);
    }

    public void clickAccountEdit() throws Throwable {
        click.elementBy(KeyAccountEdit);
    }

    public void clickAccountEditAndroid() throws Throwable {
        //click.elementBy(KeyAccountEdit);
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
        actions.Touch.pressByCoordinates(628, 331, 5);} //From Account
        else
        {
            Wait.waituntillElementVisibleMob(KeyAccountEdit,3);
            click.elementBy(KeyAccountEdit);
        }
    }

    public void clickBillerEdit() throws Throwable {
        //click.elementBy(KeyBillerEdit);
        AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.widget.FrameLayout/androidx.recyclerview.widget.RecyclerView/android.view.ViewGroup[4]/android.widget.TextView[4]");
        element.click();
    }

    public void clickBillerEditAndroid() throws Throwable {
        //click.elementBy(KeyBillerEdit);
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
        actions.Touch.pressByCoordinates(630, 476, 5);} //To Biller
        else{
            click.elementBy(KeyBillerEdit);
        }
    }

    public void clickAmountEdit() throws Throwable {
        click.elementBy(KeyAmountEdit);
    }
    public void clickAmountEditAndroid() throws Throwable {
        ///click.elementBy(KeyAmountEdit);
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
        actions.Touch.pressByCoordinates(625, 658, 5);} //Amount

        else
        {
            click.elementBy(KeyAmountEdit);
        }
    }

    public void clickDone() throws Throwable {
        click.elementBy(KeyDone);
    }

    public void enterAmountEditInPaymentDetails(String amount) throws Throwable {
        get.elementBy(KeyAmountEditInPaymentDetails).clear();
        type.data(KeyAmountInPaymentDetails, amount);
    }

    public void clickUnMaskedAccount() throws Throwable {
        click.elementBy(KeyUnMaskedInReviewAndPay);
    }

    public void clickUnMaskedAccountAndroid() throws Throwable {
        click.elementBy(KeyUnMaskedInReviewAndPay);
    }

    public void clickMaskedAccount() throws Throwable {
        click.elementBy(KeyMaskedInReviewAndPay);
    }

    public void verifyMaskedAccount(String account) throws Throwable {
        verify.elementTextMatching(KeyMaskedInReviewAndPay, account);
    }

    public void verifyunMaskedAccount(String account) throws Throwable {
        verify.elementTextMatching(KeyUnMaskedInReviewAndPay, account);
    }

    public void clickbackbutton() throws Throwable {
        click.elementBy(KeyBackbutton);
    }

    public void clickCloseBtnInBillerInformation() throws Throwable {
        click.elementBy(KeyCloseBtnInBillerInformation);
    }

    public void clickDoneBtnInBillerInformationAndroid() throws Throwable {
        click.elementBy(KeyDone);
    }

    public void verifyFrequencyInPaymentDetails() throws ApplicationException {
        verify.elementIsPresent(KeylabelFrequencyInPaymentDetails);
    }

    public void verifyEndDateInPaymentDetails() throws ApplicationException {
        verify.elementIsPresent(KeylabelEndDateInPaymentDetails);
    }

    public void verifyBillererrormessage(String Billererrormessge) throws Throwable {
        get.elementBy(KeyBillerNumbervalue).clear();
        click.elementBy(KeybtnDoneKeyboard);
        verify.elementTextMatching(KeyBillererrormessage, Billererrormessge);
        type.data(KeyBillerNumber, "82028711016");
        clickNext();
    }

    public void verifyBillererrormessageAndroid(String Billererrormessge) throws Throwable {
        //type.data(KeyAccountIDInBillerInformation, "01");
        Wait.waituntillElementVisibleMob(KeyAccountIDWithInputInBillerInformation,3);
        get.elementBy(KeyAccountIDWithInputInBillerInformation).clear();
        click.elementBy(KeySubTitleInBillerInformation);
        verify.elementTextMatching(KeyBillererrormessage, Billererrormessge);
        type.data(KeyBillerNumber, "82028711016");
        clickNext();
    }

    public void enterBillerNumberInBillerInformation(String BillererNumber) throws Throwable {
        type.data(KeyBillerNumber, BillererNumber);
    }

    public void clickAmountInPaymentDetails() throws Throwable {
        click.elementBy(KeyAmountInPaymentDetails);
    }

    public void verifyAmountInPaymentDetailserrormessage(String Amounterrormessge) throws Throwable {
        verify.elementTextMatching(KeyAmountErrorMessage, Amounterrormessge);
    }

    public void verifyAmountInPaymentDetailserrormessageAndroid(String Amounterrormessge) throws Throwable {
        verify.elementTextMatching(KeyAmountErrorMessage, Amounterrormessge);
    }

    public void verifyNextBtnIsDisabled() throws Throwable {
        get.elementBy(KeyBillerNumbervalue).clear();
        click.elementBy(KeybtnDoneKeyboard);
        verify.elementIsDisabled(KeyBtnNextBillerinformation);
        type.data(KeyBillerNumber, "82028711016");
        click.elementBy(KeyBtnNextBillerinformation);
    }
    public void verifyNextBtnIsDisabled1() throws Throwable {
        get.elementBy(KeyBillerNumbervalue).clear();
        //click.elementBy(KeybtnDoneKeyboard);
        verify.elementIsDisabled(KeyBtnNextBillerinformation);
        type.data(KeyBillerNumber, "82028711016");
        click.elementBy(KeyBtnNextBillerinformation);
    }
    public void verifyNextBtnIsDisabledInPaymentDetails() throws Throwable {
        verify.elementIsDisabled(KeyBtnNextBillerinformation);
    }

    public void verifyInvalidCardNumberBillererrormessage(String Billererrormessge) throws Throwable {
        get.elementBy(KeyBillerNumbervalue).clear();
        click.elementBy(KeybtnDoneKeyboard);
        clickNext();
        type.data(KeyBillerNumber, "000000");
        verify.elementTextMatching(KeyBillererrormessage, Billererrormessge);
        clickNext();
    }

    public void verifyInvalidCharacterBillererrormessage(String Billererrormessge) throws Throwable {
        get.elementBy(KeyBillerNumbervalue).clear();
        click.elementBy(KeybtnDoneKeyboard);
        clickNext();
        type.data(KeyBillerNumber, "jfdksfjskf");
        verify.elementTextMatching(KeyBillererrormessage, Billererrormessge);
        clickNext();
    }

    public void verifyCurrentDateInPaymentDetails(String currentdate) throws Throwable {
        verify.elementTextMatching(KeyCurrentDateInPaymentDetails, currentdate);
    }

    public void clickUnMaskedAccountInPaymentSuccessful() throws Throwable {
        click.elementBy(KeyUnMaskedInPaymentSuccessful);
    }

    public void clickMaskedAccountInPaymentSuccessful() throws Throwable {
        click.elementBy(KeyMaskedInPaymentSuccessful);
    }

    public void verifyMaskedAccountInPaymentSuccessful(String account) throws Throwable {
        verify.elementTextMatching(KeyUnMaskedInPaymentSuccessful, account);
    }

    public void clickNewPaymentInPaymentSuccessful() throws Throwable {
        //click.elementBy(KeyNewPaymentInPaymentSuccessful);
        Wait.forSeconds(5);
        swipe.scrollDownToTextandClick("NEW PAYMENT");
    }

    public void clickGoToDashboardInPaymentSuccessful() throws Throwable {
        click.elementBy(KeyGoToDashboardInPaymentSuccessful);
    }

    public void clickMailInDashboard() throws Throwable {
        click.elementBy(KeyMainInDashBoard);
    }

    public void choosePaymentTransactionsNotificationsIOS() throws ApplicationException {
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2126")){
            actions.Touch.pressByCoordinates(170, 194, 5); }

            else{
            actions.Touch.pressByCoordinates(405, 182, 5); }

        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
            actions.Touch.pressByCoordinates(342, 325, 5); }
    }

    public void verifyNotificationsPageTitle(String pagetitle) throws Throwable {
        verify.elementTextMatching(KeyNotificationsPageTitle, pagetitle);
    }

    public void clickTransationsTab() throws Throwable {
        //click.elementBy(KeyTransactionsTab);
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2126")){
            actions.Touch.pressByCoordinates(183, 129, 5); }
            else{
            Wait.forSeconds(10);
            click.elementBy(KeyTransactionsTab);
        }
        if (Devicename.currentdevicename.equalsIgnoreCase("TGSMOB2131")){
            click.elementBy(KeyTransactionsTab); }

    }

    public void clickUnMaskedAccountInNotifications() throws Throwable {
        Wait.waituntillElementVisibleMob(KeyUnMaskedInNotifications,3);
        click.elementBy(KeyUnMaskedInNotifications);
    }

    public void clickMaskedAccountInNotifications() throws Throwable {
        click.elementBy(KeyMaskedInNotifications);
    }

    public void verifyMaskedAccountInNotifications(String account) throws Throwable {
        verify.elementTextMatching(KeyMaskedInNotifications, account);
    }

    public void entercarnumber(String cardnumber) throws Throwable {
        click.elementBy(Keyunionbankcardnumber);
        type.data1(Keyunionbankcardnumber,cardnumber);
    }

    public void entercarnumber_CC(String cardnumber) throws Throwable{
        //click.elementBy(Keyunionbankcardnumber_CC);
        type.data1(Keyunionbankcardnumber_CC,cardnumber);
        MobileElement e1= (MobileElement) driver.findElementById("com.unionbankph.online.qat:id/number_input");
        e1.sendKeys(cardnumber);
    }

    public void verifyBillerNameInBillerInformation(String account) throws Throwable {
        verify.elementTextMatching(KeyBillernameInBillerInformation, account);
    }

    public void clickManageBillersInPayBills() throws Throwable {
        click.elementBy(Keymanagebillers);
    }
    public void clickAddiconManageBillersInPayBills() throws Throwable {
        actions.Touch.pressByCoordinates(930, 2043, 5);
    }

    public void SelectBillersandSaveInPayBills(String Aliasname,String cardnumber) throws Throwable {
        type.data(Keymanagebillersalias, Aliasname);
        click.elementBy(Keymanagebillerslst);
        Wait.waituntillElementVisibleMob(Keymanagebillerbillercard,7);
        click.elementBy(Keymanagebillerbillercard);
        Wait.waituntillElementVisibleMob(Keymanagebillerbillercardnumber,7);
        type.data(Keymanagebillerbillercardnumber, cardnumber);
        click.elementBy(Keyfavouriteon);
        click.elementBy(Keysave);

    }


    public void selectfavouritebiller() throws Throwable {

        //click.elementBy(Keyfavouritelnk);
        click.elementBy(KeyFavouritebiller);
        Wait.waituntillElementVisibleMob(KeyEditbiller,7);
        click.elementBy(KeyEditbiller);
    }
    public void selectunfavouritebilleranssave() throws Throwable {

        click.elementBy(Keyfavouriteoff);
        click.elementBy(Keysave);
    }

    public void Editbillerinmanagebiller() throws Throwable {
        click.elementBy(KeyFavouritebiller);
        click.elementBy(KeyEditbiller);
    }

    public void Changebillernameandsave() throws Throwable {

        type.data(Keymanagebillersalias, "changebiller");
        click.elementBy(Keysave);
    }
    public void Deletetbillerinmanagebiller() throws Throwable {


        click.elementBy(KeyFavouritebiller);
        click.elementBy(KeyDeletebiller);
    }

    public void enterBillerBillerInformation() throws Throwable {

        type.data(Keypaymentreferenceno,"0006992990424204");
        type.data(Keypayorsname,"MANUEL CANAPI SUNGA");
        //type.data(Keypolicyno,"2312001000781");
        //click.elementBy(KeyBtnNextBillerinformation);
    }
    public void enterBillerBillerInformation_Ewallet() throws Throwable {
        Wait.waituntillElementVisibleMob(KeyUsername,2);
        type.data(KeyUsername,"MANUEL CANAPI SUNGA");
        type.data(KeyReferenceNumber,"00069929904242046758");

    }

    public void clickNext_CC() throws Throwable {
        Wait.forSeconds(5);
        swipe.swipeVertical(2, 0.8, 0.2, 5);
        //click.elementBy(Next);
        MobileElement el1 = (MobileElement) driver.findElementById("com.unionbankph.online.qat:id/button_next");
        el1.click();
    }

    public void selectCreditCard() throws Throwable {
        click.elementBy(SelectAcc);
        Wait.waituntillElementVisibleMob(CreditCard,2);
        click.elementBy(CreditCard);
    }

    public void selectAcountOption() throws Throwable {
        click.elementBy(SelectAcc);
    }
    public void enterAmount_CC() throws Throwable {
        type.data(KeyAmountInPaymentDetails,"10");
    }

    public void clickPayBillsBtn() throws Throwable {
        //click.elementBy(PayBillBtn);
        MobileElement e2 = (MobileElement)  driver.findElementById("com.unionbankph.online.qat:id/button_bottom");
        e2.click();
    }

    public void clickGotItBtn() throws Throwable {
//        click.elementBy(GotItBtn);
        Wait.forSeconds(1);
        if(verify.IfElementExistsboolean(GotItBtn)) {
            click.elementBy(GotItBtn);
        }
    }

    public void verifyPaymentRequestSucessMessage() throws Throwable {
        verify.elementIsPresent(PaymentReceivedTitle);
        //verify.elementIsPresent(PaymentReceivedText);

    }

    public void SelectFirstBiller() throws Throwable {
        click.elementBy(Biller1);
    }

    public void VerifyErrorMsg() throws Throwable{
        verify.elementIsPresent(ErrorMessage);
    }
    public void verifyRemainingLimit() throws ApplicationException {
       Wait.waituntillElementVisibleMob(RemainingLimitEwallet,3);
        verify.elementIsPresent(RemainingLimitEwallet);

    }
    public void verifyLimitReminder() throws ApplicationException {
        Wait.waituntillElementVisibleMob(LimitReminderEwallet,3);
        verify.elementIsPresent(LimitReminderEwallet);
    }
    public void VerifyDailyTransactionLimitAmountErrorMsg() throws Throwable{
        Wait.waituntillElementVisibleMob(DailyTransactionLimitAmountErrorMsg,3);
        verify.elementIsPresent(DailyTransactionLimitAmountErrorMsg);
    }
    public void verifyRemainderPopUp()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(KeyRemainderPOPUP);
        click.elementBy(GotItBtn);
    }
}
