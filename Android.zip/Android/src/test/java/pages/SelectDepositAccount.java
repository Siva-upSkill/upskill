package pages;

import base.Keywords;
import exceptions.ApplicationException;


public class SelectDepositAccount extends Keywords {

    String KeyGoBack = "";
    String KeyPageTitle = "";

    public void clickGoBack() throws ApplicationException {
        click.elementBy(KeyGoBack);
    }

    public void verifyPageTitle(String expectedTitle) throws ApplicationException {
        verify.elementTextMatching(KeyPageTitle,expectedTitle);
    }

    public void selectDepositAccount(String accountNumber){

    }
}
