package pages;

import actions.Touch;
import actions.Wait;
import base.Keywords;
import helper.PropertyReader;

public class InstapayWaived_Pages extends Keywords {

    private String keyFromaccount_InstapayWaived = "onlineBanking.FundTransfer.InstaPay.FromAccountNumber";
    private String DataOf_FromAccount_InstapayWaived = PropertyReader.testDataOf("InstapayWaived_FromAccountNumber");
    private String AccountNoTxtBox = "onlineBanking.Instapyawaived.AccNumberTxtBox";
    private String AccountName = "onlineBanking.Instapyawaived.NameTxtBox";
    private String keyAmount="onlineBanking.Fundtransfer.TxtAmount";

    private String ServiceFee ="onlineBanking.Instapyawaived.ServiceFee";
    private String NextBtn = "onlineBanking.Instapyawaived.NextBtn";

    private String InlineMessageAccNo = "onlineBanking.Instapyawaived.InlineMessageAccNo";
    private String MobileNumberTxtBox = "onlineBanking.Instapyawaived.MobileNumTextBox";

    private String MobileNumOption = "onlineBanking.Instapyawaived.MobileNumOption";



    public void FromAccountNumber_Instapay() throws Throwable{
        Wait.forSeconds(6);
        Touch.pressByCoordinates(746 , 793,5);
//        MobileElement ele = (MobileElement) driver.findElementByXPath((keyFromaccount_InstapayWaived));
//        ele.click();
//            click.ElementBy(keyFromaccount_InstapayWaived,DataOf_FromAccount_InstapayWaived);
        }

    public void EnterAccNumAndName() throws Throwable{
        Wait.waituntillElementVisibleMob(AccountNoTxtBox,5);
//        Wait.forSeconds(3);
        type.data(AccountNoTxtBox, PropertyReader.testDataOf("InstapayWaived_AccNumber"));
//        Wait.forSeconds(3);
       Wait.waituntillElementVisibleMob(AccountName,5);
        type.data(AccountName, PropertyReader.testDataOf("InstapayWaived_AccountName"));
    }
    public void enterTheAmount() throws Throwable {
        Wait.waituntillElementVisibleMob(keyAmount,5);
        type.data(keyAmount,PropertyReader.testDataOf("InstapayWaived_EnterUBAmount"));
    }
    public void VerifyServiceFee() throws Throwable{
        Wait.waituntillElementVisibleMob(ServiceFee,5);
        verify.elementIsPresent(ServiceFee);
    }
    public void ClickNext() throws Throwable{
       Wait.waituntillElementVisibleMob(NextBtn,5);
        click.elementBy(NextBtn);

    }
    public void InlineMessageAccNo() throws Throwable{
        Wait.waituntillElementVisibleMob(InlineMessageAccNo,5);
//        Wait.forSeconds(2);
        verify.elementIsPresent(InlineMessageAccNo);
    }
    public void EnterAccNumLessThan8Digit() throws Throwable {
//        Wait.forSeconds(2);
       Wait.waituntillElementVisibleMob(AccountNoTxtBox,5);
        type.data(AccountNoTxtBox, PropertyReader.testDataOf("InstapayWaived_InvalidAccNumber"));
    }
    public void EnterMobileNum() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(MobileNumOption);
        type.data(MobileNumberTxtBox, PropertyReader.testDataOf("InstapayWaived_MobileNumber"));
    }}
