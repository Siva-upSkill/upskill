package pages;

import actions.Swipe;
import actions.Wait;
import base.Keywords;
import helper.PropertyReader;

public class SwiftPage extends Keywords {
    private String Ownaccount="onlineBanking.Swift.ownaccount";
    private String EONAccount="onlineBanking.Swift.EONAccount";
    private String International="onlineBanking.Swift.International";
    private String ReceiveTab="onlineBanking.Swift.ReceiveTab";
    private String SendTab="onlineBanking.Swift.SendTab";

    private String WesternUnion="onlineBanking.Swift.WesternUnion";
    private String ManageTransfers="onlineBanking.Swift.ManageTransfers";
    private String FAQ="onlineBanking.Swift.FAQ";

    private String InternationalButton = "onlineBanking.Swift.InternationalButton";
    private String RemindersHeader = "onlineBanking.Swift.RemindersHeader";
    private String ShowMoreButton = "onlineBanking.Swift.ShowMoreButton";
    private String SwiftLogo = "onlineBanking.Swift.SwiftLogo";
    private String SwiftCodeMessage = "onlineBanking.Swift.SwiftCodeMessage";
    private String GrayscalePopupmessage="onlineBanking.Swift.GrayscalePopupmessage";
    private String Allowance="onlineBanking.Swift.Allowance/familysupport";
    private String TravelExpenses="onlineBanking.Swift.TravelExpenses";
    private String MedicalExpenses="onlineBanking.Swift.MedicalExpenses";
    private String EducationalExpenses="onlineBanking.Swift.EducationalExpenses";
    private String Investments="onlineBanking.Swift.Investments";
    private String Salary="onlineBanking.Swift.Salary";
    private String Pension="onlineBanking.Swift.Pension";
    private String Inheritance="onlineBanking.Swift.Inheritance";
    private String ReceivingBank="onlineBanking.Swift.ReceivingBankCountry";
    private String AccountName="onlineBanking.Swift.AccountName";
    private String AccountNumber="onlineBanking.Swift.AccountNumber";
    private String Relationship="onlineBanking.Swift.Relationshiptorecipient";
    private String Optional="onlineBanking.Swift.Optional";
    private String Learnmore="onlineBanking.Swift.LearnMore";
    private String SwiftCodeDetailsPage="onlineBanking.Swift.SwiftCodeDetails";

    private String CloseOption="onlineBanking.Swift.CloseOption";
    private String OkayButton = "onlineBanking.Swift.OkayButton";

    private String CountrySearchBox = "onlineBanking.Swift.CountrySearchBox";

    private String NewTransaction="onlineBanking.Swift.NewTransaction";
    private String Apartment="onlineBanking.Swift.Apartment";
    private String City="onlineBanking.Swift.City";

    private String SelectCountryAf = "onlineBanking.Swift.SelectCountryAf";
    private String SelectCountryAlgeria="onlineBanking.Swift.SelectCountryAlgeria";
    private String enterCountry = "onlineBanking.Swift.enterCountry";
    private String AmountField = "onlineBanking.Swift.AmountField";
    private String SourceOfFundsDropDown = "onlineBanking.Swift.SourceOfFundsDropDown";
    private String SelectSourceOfFund = "onlineBanking.Swift.SelectSourceOfFund";
    private String PurposeDropDown = "onlineBanking.Swift.PurposeDropDown";
    private String SelectPurpose = "onlineBanking.Swift.SelectPurpose";
    private String NextButton = "onlineBanking.Swift.NextButton";
    private String GotItButton = "onlineBanking.Swift.GotItButton";
    private String SwiftCodeTextBox = "onlineBanking.Swift.SwiftCodeTextBox";
    private String AccountNameTextBox = "onlineBanking.Swift.AccountNameTextBox";
    private String AccountNumberTextBox = "onlineBanking.Swift.AccountNumberTextBox";
    private String RelationshipDropDown = "onlineBanking.Swift.RelationshipToRecipientDropDown";
    private String selectRelationship = "onlineBanking.Swift.SelectRelationship";
    private String CloseButton="onlineBanking.Swift.CloseOption";

    private String ReminderDetails = "onlineBanking.Swift.ReminderDetails";
    private String EmailTextBox = "onlineBanking.Swift.EmailTextBox";
    private String NextButton1 = "onlineBanking.Swift.NextButton1";
    private String CityTextBox = "onlineBanking.Swift.CityTextBox";
    private String UnitNoTextBox = "onlineBanking.Swift.UnitNumberTextBox";
    private String StreetTextBox = "onlineBanking.Swift.StreetTextBox";
    private String ZipcodeTextBox = "onlineBanking.Swift.ZipcodeTextBox";
    private String NextButton2 = "onlineBanking.Swift.NextButton2";
    private String TCCheckBox1 = "onlineBanking.Swift.TCCheckBox1";
    private String TCCheckBox2 = "onlineBanking.Swift.TCCheckBox2";
    private String TCCheckBox3 = "onlineBanking.Swift.TCCheckBox3";
    private String Albania="onlineBanking.Swift.SelectCountryAlbania";
    private String OutwardRemmitanceTC = "onlineBanking.Swift.OutwardRemmitanceTC";
    private String AgreeAndContinue = "onlineBanking.Swift.AgreeAndContinue";
    private String SendButton = "onlineBanking.Swift.SendButton";
    private String ProceedWithTransferButton = "onlineBanking.Swift.ProceedWithTransferButton";
    private String TransactionDetailsHeader = "onlineBanking.Swift.TransactionDetailsHeader";
    private String DestinationCountry = "onlineBanking.Swift.DestinationCountry";
    private String DestinationCountryValue = "onlineBanking.Swift.DestinationCountryValue";

    private String Amount = "onlineBanking.Swift.Amount";
    private String AmountValue = "onlineBanking.Swift.AmountValue";

    private String SwiftCode = "onlineBanking.Swift.SwiftCode";
    private String SwiftCodeValue = "onlineBanking.Swift.SwiftCodeValue";
    private String RecipientDetails = "onlineBanking.Swift.RecipientDetails";
    private String RecipientAddressHeader = "onlineBanking.Swift.RecipientAddressHeader";
    private String ReviewAndSendHeader = "onlineBanking.Swift.ReviewAndSendHeader";
    private String TransactionCutOffMessage = "onlineBanking.Swift.TransactionCutOffMessage";
    private String GetStartedButton = "onlineBanking.Swift.GetStartedButton";
    private String AmountDetailsEditButton = "onlineBanking.Swift.AmountDetailsEditButton";
    private String SaveAndContinueButton = "onlineBanking.Swift.SaveAndContinueButton";
    private String SaveChanges = "onlineBanking.Swift.SaveChangesButton";
    private String SelectNewSourceOfFund = "onlineBanking.Swift.SelectNewSourceOfFund";
    private String SelectNewPurpose = "onlineBanking.Swift.SelectNewPurpose";
    private String TransferDetailsEditButton = "onlineBanking.Swift.TransferDetailsEditButton";
    private String RecipientAddressEditButton = "onlineBanking.Swift.RecipientAddressEditButton";
    private String MaximumAmountErrorMessage = "onlineBanking.Swift.MaximumAmountErrorMessage";
    private String CountryNotEligibleErrorMessage = "onlineBanking.Swift.CountryNotEligibleErrorMessage";

   public void verifySendPage()throws Throwable{
       Wait.forSeconds(2);
       verify.elementIsPresent(Ownaccount);
       verify.elementIsPresent( EONAccount);
       verify.elementIsPresent( International);
   }
   public void verifyReceivePage()throws Throwable{
       Wait.forSeconds(2);
       click.elementBy(ReceiveTab);
       verify.elementIsPresent(WesternUnion);
   }
   public void verifyManageHeaders()throws Throwable{
       Wait.forSeconds(2);
       verify.elementIsPresent(ManageTransfers);
       verify.elementIsPresent(FAQ);
   }
    public void ClickInternationalButton() throws Throwable {
        click.elementBy(SendTab);
        Wait.waituntillElementVisibleMob(InternationalButton,3);
        click.elementBy(InternationalButton);
        Wait.waituntillElementVisibleMob(GetStartedButton,2);
        click.elementBy(GetStartedButton);
    }

    public void VerifyInternationalReminderPage() throws Throwable {
        Wait.forSeconds(3);
//        Wait.waituntillElementVisibleMob(RemindersHeader,2);
        verify.elementIsPresent(RemindersHeader);
    }

    public void ClickShowMoreButton() throws Throwable {
        Wait.waituntillElementVisibleMob(ShowMoreButton,3);
        click.elementBy(ShowMoreButton);
    }

    public void VerifyReminderDetailsSection() throws Throwable {
        Wait.waituntillElementVisibleMob(RemindersHeader,3);
        verify.elementIsPresent(RemindersHeader);
    }

    public void ClickSwift() throws Throwable {
        Wait.waituntillElementVisibleMob(SwiftLogo,2);
        click.elementBy(SwiftLogo);
    }

    public void VerifySwiftCodeRequiredMessage() throws Throwable {
        Wait.forSeconds(2);
        verify.elementIsPresent(SwiftCodeMessage);
        click.elementBy(OkayButton);

    }
    public void verifyGrayscalePopupmsg()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(SelectCountryAf);
        verify.elementIsPresent(GrayscalePopupmessage);
    }
    public void verifySourceFundDropDown()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(Salary);
        verify.elementIsPresent(Pension);
        verify.elementIsPresent(Inheritance);
        WAIT.forSecondsUsingFluentWAIT(2,CloseButton);
        click.elementBy(CloseButton);
    }
    public void verifyPurposeDropDown()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(Allowance);
        verify.elementIsPresent(TravelExpenses);
        verify.elementIsPresent(MedicalExpenses);
        verify.elementIsPresent(EducationalExpenses);
        verify.elementIsPresent(Investments);
    }
    public void verifyHeadersinTransactiondetails()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(ReceivingBank);
        verify.elementIsPresent(AccountName);
        verify.elementIsPresent(AccountNumber);
        verify.elementIsPresent(Relationship);
        Swipe.swipe.swipeVertical(2,0.8,0.2,5);
        verify.elementIsPresent(Optional);
        verify.elementIsPresent( Learnmore);
    }
    public void clickLearnMore()throws Throwable{
        WAIT.forSecondsUsingFluentWAIT(2,Learnmore);
        click.elementBy(Learnmore);
        verify.elementIsPresent(SwiftCodeDetailsPage);
        click.elementBy(CloseOption);
    }

    public void SelectCountry() throws Throwable {
        Wait.waituntillElementVisibleMob(CountrySearchBox,3);
        click.elementBy(CountrySearchBox);
        Wait.waituntillElementVisibleMob(enterCountry,3);
        type.data(enterCountry, PropertyReader.testDataOf("Swift_CountryName"));
        Wait.waituntillElementVisibleMob(SelectCountryAlgeria,2);
        click.elementBy(SelectCountryAlgeria);
    }
    public void verifyHeaderonReviewScreen()throws Throwable{
       Wait.forSeconds(2);
       verify.elementIsPresent(City);
       verify.elementIsPresent(Apartment);
    }

    public void EnterAmountSourceAndPurpose() throws Throwable {
        Wait.waituntillElementVisibleMob(AmountField,2);
        click.elementBy(AmountField);
        type.data(AmountField, PropertyReader.testDataOf("Swift_Amount"));
        Wait.waituntillElementVisibleMob(SourceOfFundsDropDown,2);
        click.elementBy(SourceOfFundsDropDown);
        Wait.waituntillElementVisibleMob(SelectSourceOfFund,2);
        click.elementBy(SelectSourceOfFund);
        swipe.swipeVertical(2, 0.6, .2, 2);
        Wait.waituntillElementVisibleMob(PurposeDropDown,2);
        click.elementBy(PurposeDropDown);
        Wait.waituntillElementVisibleMob(SelectPurpose,2);
        click.elementBy(SelectPurpose);

    }
    public void ClickNext() throws Throwable {
        Wait.waituntillElementVisibleMob((NextButton),2);
        click.elementBy(NextButton);
    }

    public void ClickGotIt() throws Throwable {
        Wait.waituntillElementVisibleMob(GotItButton,1);
        click.elementBy(GotItButton);
    }

    public void EnterTransferDetails() throws Throwable {
        Wait.waituntillElementVisibleMob(SwiftCodeTextBox,1);
        type.data(SwiftCodeTextBox, PropertyReader.testDataOf("Swift_Code"));
        Wait.waituntillElementVisibleMob(AccountNameTextBox,2);
        click.elementBy(AccountNameTextBox);
        Wait.waituntillElementVisibleMob(AccountNameTextBox,2);
        type.data(AccountNameTextBox, PropertyReader.testDataOf("Swift_AccName"));
        Wait.waituntillElementVisibleMob(AccountNumberTextBox,2);
        type.data(AccountNumberTextBox, PropertyReader.testDataOf("Swift_AccNo"));
        swipe.swipeVertical(2, 0.6, .2, 2);
        Wait.waituntillElementVisibleMob(RelationshipDropDown,2);
        click.elementBy(RelationshipDropDown);
        Wait.forSeconds(1);
        click.elementBy(selectRelationship);
        Wait.waituntillElementVisibleMob(EmailTextBox,2);
        type.data(EmailTextBox, PropertyReader.testDataOf("Swift_EmailId"));

    }

    public void ClickNextButton1() throws Throwable {
        Wait.waituntillElementVisibleMob(NextButton1,2);
        click.elementBy(NextButton1);
    }

    public void VerifyRecipientAddressHeader() throws Throwable {
        Wait.waituntillElementVisibleMob(RecipientAddressHeader,2);
        verify.elementIsPresent(RecipientAddressHeader);
    }

    public void EnterAddressDetails() throws Throwable {
        Wait.waituntillElementVisibleMob(CityTextBox,2);
        click.elementBy(CityTextBox);
        type.data(CityTextBox, PropertyReader.testDataOf("Swift_City"));
        Wait.waituntillElementVisibleMob(UnitNoTextBox,2);
        click.elementBy(UnitNoTextBox);
        type.data(UnitNoTextBox, PropertyReader.testDataOf("Swift_UnitNo"));
        Wait.forSeconds(1);
        click.elementBy(StreetTextBox);
        type.data(StreetTextBox, PropertyReader.testDataOf("Swift_Street"));
        Wait.forSeconds(2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        Wait.waituntillElementVisibleMob(ZipcodeTextBox,2);
        click.elementBy(ZipcodeTextBox);
        type.data(ZipcodeTextBox, PropertyReader.testDataOf("Swift_ZipCode"));
    }

    public void ClickNextButton2() throws Throwable {
        Wait.waituntillElementVisibleMob(NextButton2,2);
        click.elementBy(NextButton2);
    }

    public void VerifyReviewAndSendHeader() throws Throwable {
        Wait.waituntillElementVisibleMob(ReviewAndSendHeader,2);
        verify.elementIsPresent(ReviewAndSendHeader);
    }

    public void ClickTermsAndConditions() throws Throwable {
        Wait.forSeconds(2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        Wait.forSeconds(1);
        click.elementBy(TCCheckBox1);
        click.elementBy(TCCheckBox2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        Wait.waituntillElementVisibleMob(TCCheckBox3,2);
        click.elementBy(TCCheckBox3);

    }

    public void ClickSend() throws Throwable {
        Wait.waituntillElementVisibleMob(SendButton,2);
        click.elementBy(SendButton);
    }

    public void VerifyTransactionCutOffMessage() throws Throwable {
        Wait.waituntillElementVisibleMob(TransactionCutOffMessage,2);
        verify.elementIsPresent(TransactionCutOffMessage);

    }

    public void ClickProceed() throws Throwable {
        Wait.waituntillElementVisibleMob(ProceedWithTransferButton,3);
        click.elementBy(ProceedWithTransferButton);
    }

    public void VerifyTransactionDetailsPage() throws Throwable {
        Wait.forSeconds(1);
        verify.elementIsPresent(TransactionDetailsHeader);
        Wait.waituntillElementVisibleMob(DestinationCountry,2);
        verify.elementIsPresent(DestinationCountry);
//        verify.elementTextMatching(DestinationCountryValue,PropertyReader.testDataOf("Swift_VerifyCountryName"));
        verify.elementIsPresent(Amount);
        verify.elementTextMatching(AmountValue,PropertyReader.testDataOf("Swift_VerifyAmount"));
        Wait.forSeconds(2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        verify.elementIsPresent(RecipientDetails);
        verify.elementIsPresent(SwiftCode);
        verify.elementTextMatching(SwiftCodeValue,PropertyReader.testDataOf("Swift_VerifyCode"));
    }
    public void VerifyTransactionDetailsPage_Edit() throws Throwable {
        Wait.forSeconds(1);
        verify.elementIsPresent(TransactionDetailsHeader);
        Wait.waituntillElementVisibleMob(DestinationCountry,2);
        verify.elementIsPresent(DestinationCountry);
//        verify.elementTextMatching(DestinationCountryValue,PropertyReader.testDataOf("Swift_VerifyCountryName"));
        verify.elementIsPresent(Amount);
        verify.elementTextMatching(AmountValue,PropertyReader.testDataOf("Swift_VerifyEditAmount"));
        Wait.forSeconds(2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        verify.elementIsPresent(RecipientDetails);
        verify.elementIsPresent(SwiftCode);
        verify.elementTextMatching(SwiftCodeValue,PropertyReader.testDataOf("Swift_VerifyCode"));
    }

    public void userClickEditButtonInAmountDetailsSection() throws Throwable {
        Wait.waituntillElementVisibleMob(AmountDetailsEditButton,2);
        click.elementBy(AmountDetailsEditButton);
        Wait.waituntillElementVisibleMob(AmountField,3);
        click.elementBy(AmountField);
        type.data(AmountField, PropertyReader.testDataOf("Swift_EditAmount"));
    }

    public void ClickSaveAndContinue() throws Throwable {
        Wait.waituntillElementVisibleMob(SaveAndContinueButton,2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        click.elementBy(SaveAndContinueButton);
    }

    public void ClickSaveChanges() throws Throwable {
        Wait.waituntillElementVisibleMob(SaveChanges,3);
        click.elementBy(SaveChanges);
    }

    public void ClickEditButtonInTransferDetails() throws Throwable {
        Wait.waituntillElementVisibleMob(TransferDetailsEditButton,3);
        click.elementBy(TransferDetailsEditButton);
    }

    public void ClickEditButtonInRecipientDetails() throws Throwable {
        Wait.waituntillElementVisibleMob(RecipientAddressEditButton,2);
        click.elementBy(RecipientAddressEditButton);
    }

    public void VerifyInlineMessageForExceedingAmount() throws Throwable {
        Wait.forSeconds(1);
        verify.elementTextMatching(MaximumAmountErrorMessage,PropertyReader.testDataOf("Swift_AmountValidationMessage"));
    }

    public void EnterInvalidAmount() throws Throwable {
        Wait.waituntillElementVisibleMob(AmountField,3);
        click.elementBy(AmountField);
        type.data(AmountField, PropertyReader.testDataOf("Swift_InvalidAmount"));

    }

    public void SelectCountryThatIsNotEligibleForSwift() throws Throwable {
        Wait.waituntillElementVisibleMob(CountrySearchBox,2);
        click.elementBy(CountrySearchBox);
        Wait.waituntillElementVisibleMob(CountrySearchBox,2);
        type.data(CountrySearchBox, PropertyReader.testDataOf("Swift_InvalidCountryName"));
        Wait.waituntillElementVisibleMob( Albania,2);
        click.elementBy(Albania);
    }
    public void VerifyErrorMessageForCountryNotEligible() throws Throwable{
        Wait.forSeconds(1);
        verify.elementTextMatching(CountryNotEligibleErrorMessage,PropertyReader.testDataOf("CountryNotEligibleErrorMessage"));
        click.elementBy(OkayButton);
    }
    public void clickNewTransaction()throws Throwable{
       Wait.forSeconds(2);
       click.elementBy(NewTransaction);

    }
}







