package pages;

import actions.Swipe;
import actions.Wait;
import base.Keywords;
import driver.DriverManager;
import exceptions.ApplicationException;
import helper.PropertyReader;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import runners.ConvergentTestRunner;

import java.util.HashMap;
import java.util.List;


public class BookVisitInAdvancePage extends Keywords {

    String KeyCurrentDateVisit = "convergent.BookVisitInAdvance.lableCurrentDateVisit";
    String KeyBookVisitBtn = "convergent.BookVisitInAdvance.bookvisitbtn";
    String KeyViewVisitTab = "convergent.BookVisitInAdvance.tabViewVisit";
    String keyUpcomingVisits = "convergent.BookVisitInAdvance.UpcomingVisits";
    String KeyDashboardVisits = "convergent.BookVisitInAdvance.DashboardVisits";
    String KeyPageTitleVisitDetails = "convergent.login.labelPagetitle";
    String KeyReviewAndBookVisitPageTitle = "convergent.BookVisitInAdvance.labelReviewandBookVisitPageTitle";
    String KeyTodayVisit = "convergent.BookVisitInAdvance.btnDate";
    String KeyCancelledBookVisitAdvvance = "convergent.BookVisitInAdvance.btnCancelledDeposit";
    String KeyBtnYes = "convergent.BookVisitInAdvance.btnYes";
    String KeyCashDeposit = "convergent.BookVisitInAdvance.cashdepositlable";
    String KeyEnterAccountNum = "convergent.BookVisitInAdvance.enteraccountnumber";
    String KeyEnterAccountNumCheckNumber = "convergent.BookVisitInAdvance.txtboxCheckNumber";
    String KeyEnterAmount = "convergent.BookVisitInAdvance.enteramt";
    String Branchvisit="convergent.home.titleBranchVisit";
    String KeyEnterAmount1 = "convergent.BookVisitInAdvance.enteramt1";
    String KeyEnterAmount2 = "convergent.BookVisitInAdvance.enteramt2";
    String KeyBtnNext = "convergent.BookVisitInAdvance.btnnext";
    String KeyBookVisit = "convergent.BookVisitInAdvance.bookvisitconfirmbtn";
    String KeyUpdateVisit = "convergent.BookVisitInAdvance.updatevisitconfirmbtn";
    String KeyBookVisitConfirmationMessage = "convergent.BookVisitInAdvance.bookvisitconfirmationtextmessage";
    String KeyViewVisitBtn = "convergent.BookVisitInAdvance.btnViewVisit";
    String KeyVisitDatelable = "convergent.BookVisitInAdvance.btnDate";
    String KeyVisitDatelable1 = "convergent.BooKVisitInAdvance.UpcomingBtnDate";
    String KeyBtnNo = "convergent.BookVisitInAdvance.btnNo";
    String KeyTargetAmountErrorMsg = "convergent.VisitDetails.targetamounterrormsg";
    String KeyInvalidAccountErrorMsg = "convergent.VisitDetails.invalidaccounterrormsg";
    String KeyAccountNumberErrorMsg = "convergent.VisitDetails.accountnumbererrormsg";
    String KeyAmountErrorMsg = "convergent.VisitDetails.amounterrormsg";
    String KeyHangOnErrorMsg = "convergent.BookVisitInAdvance.txtMessageHangOn";
    String KeyHangOnPageTitle = "convergent.BookVisitInAdvance.lableHangOnPopup";
    String KeyBtnAddTransaction = "convergent.BookVisitInAdvance.btnAddTransaction";
    String KeyBtnSelectAccount = "convergent.BookVisitInAdvance.btnSelectAccount";
    String KeyLableNoVisit = "convergent.BookVisitInAdvance.lableNoVisitFound";
    String KeyLableNoUpcomingVisit = "convergent.BookVisitInAdvance.lableNoUpcomingVisitsFound";
    String KeyLableNoHistory = "convergent.BookVisitInAdvance.lableNoVisit";
    String KeyBranchTxtBox = "convergent.BookVisitInAdvance.txtboxBranch";
    String KeyBranchSearch = "convergent.BookVisitInAdvance.searchtxtboxBranch";
    String KeyBranchSelect = "convergent.BookVisitInAdvance.selectBranch";
    String KeySelectDate = "convergent.BookVisitInAdvance.btnDate";
    String KeyCheckDeposit = "convergent.BookVisitInAdvance.CheckDepositlable";
    String KeyCheckNumberTxtBox = "convergent.BookVisitInAdvance.txtboxCheckNumber";
    String KeyCheckNumberErrorMsg = "convergent.Managereceipent.FieldErrormsg";
    String KeySearchBranchBtn = "convergent.BookVisitInAdvance.searchBranchbtn";
    String KeyCashWithdrawalLink = "convergent.BookVisitInAdvance.CashWithdrawallable";
    String KeyCheckNumberTxtBox1 = "convergent.BookVisitInAdvance.txtboxCheckNumber1";
    String KeyCheckNumberTxtBox2 = "convergent.BookVisitInAdvance.txtboxCheckNumber2";
    String Keybranchsearchresult = "convergent.Managereceipent.SearchReceipentname";
    String KeyBranchFavourites = "convergent.BookVisitInAdvance.CheckBoxbtn";
    String KeyBranchBackBtn = "convergent.Pesonet.backbutton";
    String KeyUpcomingViewMoreBtn = "convergent.BookVisitInAdvacne.UpcomingVisits";
    String KeyHistoryViewMoreBtn = "convergent.BookVisitInAdvacne.HistoryVisits";
    String KeyBranchErrorMsg = "convergent.BookVisitInAdvance.NoBranchErr";
    String KeyBranchAddress = "convergent.BookVisitInAdvance.BranchAddress";
    String KeyHistoryVisits = "convergent.BookVisitInAdvance.HistoryVisits";
    String KeyBtnOk = "convergent.BookVisitInAdvance.btnok";
    String KeyDashboard = "convergent.transfersuccessful.gotodashboardbtn";
    String KeySuccessPageDashboardBtn = "convergent.BookVisitInAdvance.SuccesspageDashboardBtn";
    String KeyEnterAcc1 = "convergent.BookVisitInAdvance.EnterAccount1";
    String KeyBookVisitInAdvancePageTitle = "convergent.BookVisitInAdvance.BookVisitInAdvancePageTitle";
    String KeyBookVisitCard = "convergent.home.btnBookVisitCard";
    String KeyLocationNotNow = "convergent.FindTheNearestATMorBranch.btnNotNow";
    String KeyLocationAllow = "convergent.FindTheNearestATMorBranch.btnAllow";
    String KeyCalenderDone = "convergent.BookvisitInAdvance.btnCalenderDone";
    String KeyCancelVisitInAdvance = "convergent.BookVisitInAdvance.btnCancelVisit";
    String KeyBranchTxtBoxCashDeposit = "convergent.CashDeposit.btnBranch";
    String KeyBtnSearchSelectLocation = "convergent.SelectLocation.btnSearch";
    String KeytxtSearchSelectLocation = "convergent.SelectLocation.txtSearch";
    String KeylabelSelectBranch = "convergent.SelectLocation.labelBranch";
    String KeySelectCalenderbtn = "convergent.CashDeposit.btnCalender";
    String KeyDonebtnCashDeposit = "convergent.CashDeposit.btnDone";
    String KeySearchBranchSearchBtn = "convergent.SearchBranch.btnSearch";
    String KeySearchBranchSearchtxt = "convergent.SearchBranch.txtSearch";
    String KeySearchBranchSelectBranch = "convergent.SearchBranch.labelSelectBranch";
    String KeyFavouritesInSelectBrnach = "convergent.SearchBranch.brnFavourite";
    String KeyUnFavouritesInSelectBrnach = "convergent.SearchBranch.brnUnFavourite";
    String KeyBackBtnInSearchBranch = "convergent.SearchBranch.btnBack";
    String KeyBranchNameInSearchBranch = "convergent.SearchBranch.BranchNameasFavourites";
    String KeyAccountNumberInCashWithdrawal = "convergent.CashWithdrawal.AccountNumberSearch";
    String KeyAmountInCashWithdrawal = "convergent.CashWithdrawal.txtAmount";
    String KeyCancelBtn = "convergent.BookVisitInAdvance.btncancel";
    String KeyBtnSelectAccountnumber="convergent.TransferFrompage.selectaccountMBB";
    String Keytabtostart="convergent.home.titleBranchVisittaptostart";
    ConvergentTestRunner Devicename=new ConvergentTestRunner();

    private String upcomingVisit;
    private String currentVisit = "UPCOMING";
    private String date = "08 August 2019 selected";
    private String visitdate = "August 08, 2019";
    private String UpcomingVisitDate = "August 12, 2019";
    private String currentvisitdate = "Today, August 08, 2019";


    private String viewall= "onlineBanking.ATMBranch.Viewall";
    private String ATMBranchLocator= "onlineBanking.ATMBranch.ATM&BranchLocator";
    private String BranchTab= "onlineBanking.ATMBranch.BranchTab";
    private String ATMTab= "onlineBanking.ATMBranch.ATMTab";
    private String SearchIcon="onlineBanking.ATMBranch.SearchIcon";
    private String BranchSearch ="onlineBanking.ATMBranch.SearchBranchLocation";
    private String SearchresultBranch="onlineBanking.ATMBranch.BranchSearchResult";
    private String ViewLocationOnAtmScreen="onlineBanking.ATMBranch.BranchLocation" ;
    private String DisplayATMLocation="onlineBanking.ATMBranch.ATMSearchResult";
    private String DisplayBranchLocation="onlineBanking.ATMBranch.BranchResult";
    private String FindNearestATM="onlineBanking.ATMBranch.FindNearestATM";
    private String Allow="onlineBanking.ATMBranch.AllowTab";
    private String NotNow="onlineBanking.ATMBranch.NotNowTab";

    public void clickViewAll()throws Throwable{
        Wait.waituntillElementVisibleMob(viewall,2);
        Swipe.swipe.swipeVertical(2, 0.8, 0.2, 5);
        click.elementBy(viewall);
    }
    public void verifyFindATMTxt()throws Throwable{
        Wait.forSeconds(1);
        verify.elementIsPresent(FindNearestATM);
    }
    public void verifyOptionsOnPopUpscreen()throws Throwable{
        Wait.forSeconds(1);
        verify.elementIsPresent(Allow);
        verify.elementIsPresent(NotNow);
    }
    public void clickATMBranch()throws Throwable{
        Wait.waituntillElementVisibleMob(ATMBranchLocator,2);
        click.elementBy(ATMBranchLocator);
    }
    public void verifyTabOnATMScreen()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(BranchTab);
        verify.elementIsPresent(ATMTab);
    }
    public void BranchSearchIcon()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(SearchIcon);
        WAIT.forSecondsUsingFluentWAIT(4,BranchSearch);
        type.data(BranchSearch,"26th Street");
        WAIT.forSecondsUsingFluentWAIT(4,SearchresultBranch);
        click.elementBy(SearchresultBranch);
    }
    public void verifyBranchATMScreen()throws Throwable{
        Wait.forSeconds(4);
        verify.elementIsPresent(ViewLocationOnAtmScreen);
    }
    public void ATMsSearchIcon()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(ATMTab);
        WAIT.forSecondsUsingFluentWAIT(2,SearchIcon);
        click.elementBy(SearchIcon);
        Wait.forSeconds(2);
        click.elementBy(ATMTab);
        click.elementBy(SearchIcon);
        type.data(SearchIcon,"2nd Avenue");
        click.elementBy(ATMBranchLocator);
    }
    public void verifyATMLocation()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(DisplayATMLocation);
    }
    public void verifyBranchLocation()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(DisplayBranchLocation);
    }

    private String MultipleTransactionVisitDate;
    private String Date1;
    private String todayvisit;


    public void clickBookVisitBtn() throws Throwable {
        click.elementBy(KeyBookVisitBtn);
    }

    public void clickGoTODashboard() throws Throwable {
        click.elementBy(KeySuccessPageDashboardBtn);
    }

    public void verifyHangOnErrorMsg() throws Throwable {
        verify.elementIsPresent(KeyHangOnErrorMsg);
    }

    public void clickUpdateVisit() throws Throwable {
        click.elementBy(KeyBookVisit);
    }

    public void clickUpdateVisitIOS() throws Throwable {
        //click.elementBy(KeyUpdateVisit);
        Wait.forSeconds(5);
        MobileElement el1 = (MobileElement) driver.findElementByAccessibilityId("UPDATE VISIT");
        el1.click();
    }

    public void verifyHangOnPageTitle(String ititle) throws Throwable {
        verify.elementTextMatching(KeyHangOnPageTitle, ititle);
    }


    public void verifyTargentAmountErrorMsg(String Terror) throws ApplicationException {
        verify.elementTextMatching(KeyTargetAmountErrorMsg, Terror);
    }

    public void verifyInvalidAccountErrorMsg(String Ierror) throws ApplicationException {
        verify.elementTextMatching(KeyInvalidAccountErrorMsg, Ierror);
    }

    public void verifyAccountErrorMsg(String Ierror) throws ApplicationException {
        verify.elementTextMatching(KeyInvalidAccountErrorMsg, Ierror);
    }

    public void verifyAccountNumberIsRequiredErrorMsg(String accnumerror) throws ApplicationException {
        verify.elementTextMatching(KeyAccountNumberErrorMsg, accnumerror);
    }

    public void verifyAmountIsRequiredErrorMsg(String amounterror) throws ApplicationException {
        verify.elementTextMatching(KeyAmountErrorMsg, amounterror);
    }

    public void verifyPageTitle(String expectedTitle) throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyPageTitleVisitDetails,4);
        verify.elementTextMatching(KeyPageTitleVisitDetails, expectedTitle);
    }

    public void verifyReviewAbdBookVisitPageTitle(String expectedTitle) throws ApplicationException {
        verify.elementTextMatching(KeyReviewAndBookVisitPageTitle, expectedTitle);
    }

    public void verifyBookVisitInAdvancePageTitle(String expectedTitle) throws ApplicationException {
        verify.elementTextMatching(KeyBookVisitInAdvancePageTitle, expectedTitle);
    }

    public void goToViewVisitTab() throws ApplicationException {
        click.elementBy(KeyViewVisitTab);

    }

    public void goToViewVisitTabIOS() throws ApplicationException {
        //click.elementBy(KeyViewVisitTab);
        Wait.forSeconds(5);
        MobileElement el1 = (MobileElement) driver.findElementByAccessibilityId("VIEW VISITS");
        el1.click();
        Wait.forSeconds(2);
    }

    public void VerifyVisitPresent(String arg1) throws Throwable {

        if (DriverManager.OS.equalsIgnoreCase("ANDROID")) {
            clickBookVisitBtn();
            Wait.forSeconds(4);
            //chooseVisitDate(date);
            clickOkBtn();
            Wait.forSeconds(4);
            selectCashDeposit();
            enterAccountNumber("029160078588");
            enterAmount("52");
            Wait.forSeconds(2);
            clickNext();
            Wait.forSeconds(4);
            clickBookVisit(PropertyReader.testDataOf("Book_Visit"));
            clickViewVisit();
            Wait.forSeconds(8);
            cancelTodayVisit(arg1);
            Wait.forSeconds(4);
        }
        else if (DriverManager.OS.equalsIgnoreCase("IOS")) {
            Wait.forSeconds(8);
            clickBookVisitBtn();
            Wait.forSeconds(8);
            chooseVisitCalenderDoneIOS();
            selectCashDeposit();
            enterAccountNumber("1023 1001 1756");
            enterAmount("52");
            Wait.forSeconds(2);
            clickNext();
            Wait.forSeconds(4);
            clickBookVisitIOS(PropertyReader.testDataOf("Book_Visit"));
            clickViewVisit();
            Wait.forSeconds(8);
            cancelTodayVisitIfPresentIOS("cancelvisit");
        }
    }

    public void cancelTodayVisitIfPresent(String cancelvisit) throws Throwable {
        Wait.waituntillElementVisibleMob(KeyTodayVisit,5);
        todayvisit = get.elementBy(KeyTodayVisit).getText();
        if (todayvisit.length() == currentvisitdate.length()) {
            click.elementBy(KeyTodayVisit, 1);
            Wait.forSeconds(3);
            //clickCancelVisit(cancelvisit);
            clickCancelVisit();
            clickYesBtn();
        }
    }

    public void cancelTodayVisit(String arg2) throws Throwable {
            Wait.forSeconds(6);
            click.elementBy(By.id("com.unionbankph.online.qat:id/text_branch"));
            Wait.forSeconds(3);
            clickCancelVisit();
            clickYesBtn();

    }

    public void cancelTodayVisits(String arg2) throws Throwable {
        Wait.waituntillElementVisibleMob(KeyTodayVisit,3);
        todayvisit = get.elementBy(KeyTodayVisit).getText();
        if (todayvisit.length() == visitdate.length()) {
            click.elementBy(KeyTodayVisit, 1);
            Wait.forSeconds(5);
            clickCancelVisit(arg2);
            clickYesBtn();
        }
    }

    public void cancelTodayVisitIfPresentIOS(String cancelvisit) throws Throwable {
        Wait.forSeconds(5);
        //todayvisit = get.elementBy(KeyCancelledBookVisitAdvvance).getText();
        actions.Touch.pressByCoordinates(183, 289, 5);
        clickCancelVisitIOS(cancelvisit);
        clickYesBtnIOS();
    }


    public void clickCancelVisit(String cancelvisitBtn) throws ApplicationException {
        swipe.scrollDownToTextandClick(cancelvisitBtn);
    }

    public void clickCancelVisit() throws ApplicationException {

        click.elementBy(KeyCancelBtn);

    }

    public void clickCancelVisitIOS(String cancelvisitBtn) throws ApplicationException {

        click.elementBy(KeyCancelVisitInAdvance);
        //swipe.scrollDownToTextandClick(cancelvisitBtn);
    }

    public void clickCancelVisitIOS1() throws ApplicationException {
        click.elementBy(KeyCancelVisitInAdvance);
    }

    public void chooseVisitDate(String date) throws ApplicationException {
        click.pickdatefromcalendar(date);
    }

    public void chooseVisitCalenderDoneIOS() throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyCalenderDone,4);
        click.elementBy(KeyCalenderDone);
        //actions.Touch.pressByCoordinates(334, 571, 5);  // click calender done button to select current date (Future date co-ordination x:199 Y:757
    }

    public void chooseVisitCalenderFutureDateIOS() throws ApplicationException {
        //click.elementBy(KeyCalenderDone);
        actions.Touch.pressByCoordinates(199, 757, 5);  // click calender done button to select current date (Future date co-ordination x:199 Y:757
    }

    public void selectCashDeposit() throws Throwable {
        click.elementBy(KeyCashDeposit);
    }

    public void choosefuturetransactiondate(String date) throws ApplicationException {
        //swipe.swipeVertical(2, 0.3, 0.8, 5);
        click.pickdatefromcalendar(date);

    }

    public void selectCashWithdrawal() throws Throwable {
        click.elementBy(KeyCashWithdrawalLink);
    }

    public void clickYesBtn() throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyBtnYes,4);
        click.elementBy(KeyBtnYes);

    }

    public void clickYesBtnIOS() throws ApplicationException {
        MobileElement el1 = (MobileElement) driver.findElementByAccessibilityId("YES");
        Wait.forSeconds(3);
        el1.click();
        Wait.forSeconds(5);
        //click.elementBy(KeyBtnYes);
    }

    public void enterAccountNumber(String AccountNumber) throws ApplicationException {
		/* boolean found = false;
        JavascriptExecutor js = driver;
        HashMap scrollObject = new HashMap<>();
        scrollObject.put("predicateString", "value == '" + AccountNumber + "'");
        scrollObject.put("direction", "down");
        int toleranceTime = 50;
        int i = 0;
        Wait.forSeconds(4);
        js.executeScript("mobile: scroll", scrollObject);
        */

        type.data(KeyEnterAccountNum, AccountNumber);

    }

    public void enterAccountNumberCheckDepositIOS(String AccountNumber) throws ApplicationException {

        MobileElement el1 = (MobileElement) driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Done\"]");
        Wait.forSeconds(3);
        el1.click();

        type.data(KeyEnterAccountNumCheckNumber, AccountNumber);
    }

    public void enterAccountNumberCashWithdrawalIOS(String AccountNumber) throws ApplicationException {
        type.data(KeyAccountNumberInCashWithdrawal, AccountNumber);
    }

    public void enterAmountCashWithdrawalIOS(String amt) throws ApplicationException {
        type.data(KeyAmountInCashWithdrawal, amt);
    }


    public void enterAccountNumber1(String AccountNumber) throws ApplicationException {
        type.data(KeyEnterAcc1, AccountNumber);
    }

    public void clickAccountNumber() throws Throwable {
        click.elementBy(KeyEnterAccountNum);
    }

    public void clickAmount(String amt) throws Throwable {
        //click.elementBy(KeyEnterAmount);
        swipe.scrollDownToTextandClick(amt);
    }

    public void clickAmountIOS() throws Throwable {
        click.elementBy(KeyEnterAmount);
        //swipe.scrollDownToTextandClick(amt);
    }

    public void clickAmount1() throws Throwable {
        click.elementBy(KeyEnterAmount);
    }

    public void enterAmount(String Amount) throws ApplicationException {
        if(Devicename.currentdevicename.equalsIgnoreCase("Samsung")) {
            click.elementBy(KeyEnterAmount);
            get.elementBy(KeyEnterAmount).clear();
            type.data1(KeyEnterAmount, Amount);
        }
        else if(Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            click.elementBy(KeyEnterAmount);
            get.elementBy(KeyEnterAmount).clear();
            type.data1(KeyEnterAmount, Amount);
        }


    }

    public void enterAmount1(String Amount) throws ApplicationException {

        type.data(KeyEnterAmount1, Amount);
    }

    public void enterAmountCheckDepositIOS(String Amount) throws ApplicationException {


        MobileElement el1 = (MobileElement) driver.findElementByXPath("//XCUIElementTypeButton[@name=\"Done\"]");
        Wait.forSeconds(3);
        el1.click();
        // type.data(KeyEnterAmountCheckDeposit, Amount);
    }

    public void enterAmount2(String Amount) throws ApplicationException {
        type.data(KeyEnterAmount2, Amount);
    }

    public void enterAmountInvalidIOS(String Amount) throws ApplicationException {
        type.data(KeyEnterAmount, Amount);

    }

    public void clickNext() throws ApplicationException {
        click.elementBy(KeyBtnNext);
    }

    public void clickDonebtnCashDepositIOS() throws ApplicationException {
        click.elementBy(KeyDonebtnCashDeposit);
    }

    public void verifyNextButtonIsEnabled() throws ApplicationException {
        verify.elementIsPresent(KeyBtnNext);
    }

    public void verifyDoneButtonIsEnabledIOS() throws ApplicationException {
        verify.elementIsPresent(KeyDonebtnCashDeposit);
    }

    public void clickBookVisit(String bookvisit) throws ApplicationException {
        click.elementBy(KeyBookVisit);
        //swipe.scrollDownToTextandClick(bookvisit);
    }

    public void clickBookVisitIOS(String bookvisit) throws ApplicationException {
        //click.elementBy(KeyBookVisit);

        //actions.Touch.pressByCoordinates(186, 390, 5);
        //driver.findElementByXPath("//XCUIElementTypeButton[@name=\"BOOK VISIT\"]");

        MobileElement el1 = (MobileElement) driver.findElementByXPath("//XCUIElementTypeButton[@name=\"BOOK VISIT\"]");
        el1.click();

        //MobileElement el1 = (MobileElement) driver.findElementsByAccessibilityId("Book Visit");
        //el1.click();
    }

    public void clickBookVisitAddTransaction(String bookvisit) throws ApplicationException {
        swipe.scrollDownToTextandClick(bookvisit);
    }

    public void clickAddTransaction() throws Throwable {
        click.elementBy(KeyBtnAddTransaction);
    }

    public void selectAccount() throws Throwable {
        click.elementBy(KeyBtnSelectAccount);
        // swipe.scrollDownToTextandClick(accnum);
    }

    public void selectAccountForMultipleTransaction() throws Throwable {
        //swipe.swipeVertical(2, 0.3, 0.8, 5);
        //click.elementBy(KeyBtnSelectAccount);
        swipe.scrollDownToTextandClick("Account Number");
    }

    public void verifyConfirmationMessage(String expectedDescription) throws ApplicationException {
        verify.elementTextMatching(KeyBookVisitConfirmationMessage, expectedDescription);
    }

    public void clickViewVisit() throws ApplicationException {
        click.elementBy(KeyViewVisitBtn);
    }

    public void verifyVisitStatus() throws Throwable {
        verify.elementIsPresent(KeyVisitDatelable);
    }


    public void clickBtnNo() throws Throwable {
        click.elementBy(KeyBtnNo);

    }

    public void verifyUpcomingBookedVisits(String cancel) throws Throwable {
        MultipleTransactionVisitDate = get.elementBy(KeyVisitDatelable).getText();
        if (MultipleTransactionVisitDate.length() == UpcomingVisitDate.length()) {
            click.elementBy(keyUpcomingVisits);
            clickCancelVisit(cancel);
            clickYesBtn();
        }
    }

    public void verifyDashboardVisits(String cancel) throws Throwable {
        MultipleTransactionVisitDate = get.elementBy(KeyVisitDatelable).getText();
        if (MultipleTransactionVisitDate.length() == currentvisitdate.length()) {
            click.elementBy(KeyDashboardVisits);
            clickCancelVisit(cancel);
            clickYesBtn();
        }
    }

    public void clickBtnYes() throws Throwable {
        click.elementBy(KeyBtnYes);
    }

    public void verifyBookedVisits() throws Throwable {
        currentvisitdate = get.elementBy(KeyVisitDatelable).getText();
        if (currentvisitdate.length() == date.length()) {
            verifyVisitStatus();


        }
    }

    public void verifyBookedVisitsIOS() throws Throwable {
        verify.elementIsPresent(KeyVisitDatelable);


    }

    public void verifyNoTodayVisit() throws Throwable {
        verify.elementIsPresent(KeyLableNoVisit);
    }

    public void verifyNoUpcomingVisit() throws Throwable {
        verify.elementIsPresent(KeyLableNoUpcomingVisit);
    }

    public void verifyNoHistoryVisit() throws Throwable {
        verify.elementIsPresent(KeyLableNoHistory);
    }

    public void clickBranchTxtBox() throws Throwable {
        click.elementBy(KeyBranchTxtBox);
    }

    public void clickBranchTxtBoxCashDepositIOS() throws Throwable {
        click.elementBy(KeyBranchTxtBoxCashDeposit);
    }


    public void verifyBranchName(String branchname) throws Throwable {
        verify.elementTextMatching(KeyBranchTxtBox, branchname);
    }

    public void searchBranch(String branch) throws Throwable {
        Wait.waituntillElementVisibleMob(KeyBranchSearch,3);
        type.data(KeyBranchSearch, branch);
    }

    public void clicksearcselectLocationbtnIOS() throws Throwable {
        Wait.waituntillElementVisibleMob(KeyBtnSearchSelectLocation,3);
        click.elementBy(KeyBtnSearchSelectLocation);
    }
    public void clickSearchbtnInSearchBranchIOS() throws Throwable {
        Wait.waituntillElementVisibleMob(KeySearchBranchSearchBtn,3);
        click.elementBy(KeySearchBranchSearchBtn);

    }

    public void searchBranchcashdepositIOS(String branch) throws Throwable {
        Wait.waituntillElementVisibleMob(KeytxtSearchSelectLocation,4);
        type.data(KeytxtSearchSelectLocation, branch);

    }

    public void searchTextInSearchBranchIOS(String branch) throws Throwable {
        Wait.waituntillElementVisibleMob(KeySearchBranchSearchtxt,4);
        type.data(KeySearchBranchSearchtxt, branch);

    }

    public void selectBranchCashDepositIOS() throws Throwable {
        click.elementBy(KeylabelSelectBranch);
    }

    public void selectBranchFavouritesIOS() throws Throwable {
        Wait.waituntillElementVisibleMob(KeyFavouritesInSelectBrnach,4);
        click.elementBy(KeyFavouritesInSelectBrnach);
    }

    public void selectBranchUnFavouritesIOS() throws Throwable {
        click.elementBy(KeyUnFavouritesInSelectBrnach);
    }

    public void selectBranchInSearchBranchIOS() throws Throwable {
        click.elementBy(KeySearchBranchSelectBranch);
    }

    public void clickBackBtnInSearchBranchIOS() throws Throwable {
        click.elementBy(KeyBackBtnInSearchBranch);
    }


    public void selectBranch() throws Throwable {
        click.elementBy(KeyBranchSelect);
    }

    public void selectDate() throws Throwable {
        click.elementBy(KeySelectDate);
    }

    public void selectCalenderCashDepositIOS() throws Throwable {
        click.elementBy(KeySelectCalenderbtn);
    }


    public void verifyCurrentDayVisit(String arg1, String arg2) throws Throwable {
        Date1 = get.elementBy(KeyVisitDatelable).getText().substring(7);
        if (Date1.length() == visitdate.length()) {
            selectDate();
            Wait.forSeconds(2);
            verifyPageTitle(arg2);
            clickCancelVisit(arg1);
            clickYesBtn();
        }
    }

    public void selectCheckDeposit() throws Throwable {
        click.elementBy(KeyCheckDeposit);
    }

    public void enterCheckNumber1(String checknum) throws Throwable {
        type.data(KeyCheckNumberTxtBox1, checknum);
    }
    public void enterCheckNumber2(String checknum) throws Throwable {
        type.data(KeyCheckNumberTxtBox2, checknum);
    }
    public void enterCheckNumber(String checknum) throws Throwable {
        click.elementBy(KeyCheckNumberTxtBox);
        type.data(KeyCheckNumberTxtBox, checknum);
        swipe.swipeVertical(2, 0.3, 0.8, 5);
        click.elementBy(KeyEnterAccountNum);
    }

    public void clickCheckNumberIOS() throws Throwable {
        click.elementBy(KeyCheckNumberTxtBox);
    }

    public void clickCheckNumberMutlipleTransactions(String checknum) throws Throwable {
        swipe.scrollDownToTextandClick(checknum);
    }

    public void clickCheckNumber1() throws Throwable {
        click.elementBy(KeyCheckNumberTxtBox);
    }

    public void clickCheckNumber2(String checknum) throws Throwable {
        //click.elementBy(KeyCheckNumberTxtBox);
        Swipe.swipe.swipeVertical(2,0.8,0.2,5);
        swipe.scrollDownToTextandClick(checknum);
    }

    public void verifyCheckNumberErrorMsg(String expectedDescription) throws ApplicationException {
        verify.elementTextMatching(KeyCheckNumberErrorMsg, expectedDescription);
    }

    public void clickBranchSearchBtn() throws Throwable {
        click.elementBy(KeySearchBranchBtn);
    }

    public void verifytheBranchAddAsFavourite(String branchname) throws Throwable {
        clickBranchSearchBtn();
        verify.elementTextMatching(Keybranchsearchresult, branchname);
    }

    public void verifytheBranchAddAsFavouriteIOS(String branchname) throws Throwable {
        verify.elementTextMatching(KeyBranchNameInSearchBranch, branchname);
    }

    public void searchBranchAndfavourite(String receipentname) throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyBranchSearch,3);
        type.data(KeyBranchSearch, receipentname);
        click.elementBy(KeyBranchFavourites);
        click.elementBy(KeyBranchBackBtn);

    }

    public void searchBranchAndUnfavourite(String receipentname) throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyBranchSearch,5);
        type.data(KeyBranchSearch, receipentname);
        click.elementBy(KeyBranchFavourites);
        click.elementBy(KeyBranchBackBtn);

    }

    public void verifymultipleTransactionInUpcoming(String transactiontype) throws Throwable {
        verify.elementTextMatching(keyUpcomingVisits, transactiontype);
    }

    public void verifymultipleTransactionInDashboard(String transactiontype) throws Throwable {
        verify.elementTextMatching(KeyDashboardVisits, transactiontype);
    }

    public void verifyBranchErrorMsg(String Ierror) throws ApplicationException {
        verify.elementTextMatching(KeyBranchErrorMsg, Ierror);
    }

    public void verifyBranchAddress(String branchaddress) throws ApplicationException {
        verify.elementTextMatching(KeyBranchAddress, branchaddress);
    }


    public void verifyForViewMoreBtnInUpcoming() throws ApplicationException {

        List<WebElement> upcoming = driver.findElements(PropertyReader.locatorOf(keyUpcomingVisits));
        if (upcoming.size() <= 3) {
            verify.IfElementNotExists(KeyUpcomingViewMoreBtn);
        } else {
            new ApplicationException("Upcoming  Visit is more than 3");
        }
    }

    public void verifyForViewMoreBtnInHistory() throws ApplicationException {

        List<WebElement> upcoming = driver.findElements(PropertyReader.locatorOf(KeyHistoryVisits));
        if (upcoming.size() <= 3) {
            verify.IfElementNotExists(KeyHistoryViewMoreBtn);
        } else {
            new ApplicationException("History Visit is more than 3");
        }
    }

    public void clickMbbCard() throws ApplicationException {
        Wait.forSeconds(2);
       boolean result=false;
       int i=1;
        while (result == false && i<=30) {
            try {
                if(result == false) {
                    swipe.swipeVertical(2, .8, .2, 5);
                    swipe.swipeVertical(2, .8, .2, 5);
                    //swipe.swipeVertical(2, .8, .2, 5);
                    verify.IfElementExists(Branchvisit);
                    //click.elementBy(Keytabtostart);
                    click.elementBy(Branchvisit);
                    Wait.forSeconds(15);
                }
                result = true;
            }
            catch(Exception e){

            }

            i=i+1;
        }

    }


    public void clickMbbCardIOS(String searchText) throws ApplicationException {
        //Wait.forSeconds(2);
        //swipe.scrollDownToClickBookVisitIOS(PropertyReader.testDataOf("BookVisit"));
        //click.elementBy(KeyBookVisitCard);
        // driver.findElementByAccessibilityId("Book Visit").click();

        boolean found = false;
        JavascriptExecutor js = driver;
        HashMap scrollObject = new HashMap<>();
        scrollObject.put("predicateString", "value == '" + searchText + "'");
        scrollObject.put("direction", "down");
        int toleranceTime = 50;
        int i = 0;
        Wait.forSeconds(10);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        Wait.forSeconds(8);
        MobileElement el1 = (MobileElement) driver.findElementByXPath("(//XCUIElementTypeStaticText[@name='Book Visit']/preceding-sibling::*/preceding-sibling::*)[4]");
        el1.click();
    }

    public void swipeupandClickMBBCardIOS(String searchText) throws ApplicationException {
        boolean found = false;
        JavascriptExecutor js = driver;
        HashMap scrollObject = new HashMap<>();
        scrollObject.put("predicateString", "value == '" + searchText + "'");
        //scrollObject.put("direction", "down");
        scrollObject.put("direction", "up");
        int toleranceTime = 50;
        int i = 0;
        Wait.forSeconds(10);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);

        actions.Touch.pressByCoordinates(188, 288, 5);
    }

    public void swipeupMBBCardIOS(String searchText) throws ApplicationException {
        boolean found = false;
        JavascriptExecutor js = driver;
        HashMap scrollObject = new HashMap<>();
        scrollObject.put("predicateString", "value == '" + searchText + "'");
        //scrollObject.put("direction", "down");
        scrollObject.put("direction", "down");
        int toleranceTime = 50;
        int i = 0;
        Wait.forSeconds(10);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        //actions.Touch.pressByCoordinates(188, 288, 5);
    }

    public void clickMbbCardIOS1(String searchText) throws ApplicationException {
        //swipe.scrollDownToClickBookVisitIOS(PropertyReader.testDataOf("BookVisit"));
        boolean found = false;
        JavascriptExecutor js = driver;
        HashMap scrollObject = new HashMap<>();
        scrollObject.put("predicateString", "value == '" + searchText + "'");
        scrollObject.put("direction", "down");
        int toleranceTime = 50;
        int i = 0;
        Wait.forSeconds(10);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);
        js.executeScript("mobile: scroll", scrollObject);

        MobileElement el1 = (MobileElement) driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"UnionBank\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell[3]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton");
        el1.click();

       /* while (!( driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"UnionBank\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell[6]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton").isDisplayed() )) {

            i += 1;
            js.executeScript("mobile: scroll", scrollObject);
            if (i > toleranceTime) {
                break;
            }
            if (driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"UnionBank\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell[3]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton").isDisplayed()) {
                MobileElement el2 = (MobileElement) driver.findElementByXPath("//XCUIElementTypeApplication[@name=\"UnionBank\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeCollectionView/XCUIElementTypeCell[3]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeButton");
                el2.click();
            }
                found = true;
                break;
            }*/
    }


    public void clickOkBtn() throws ApplicationException {
        click.elementBy(KeyBtnOk);
    }

    public void clickATMNotNowBtnIOS() throws ApplicationException {
        click.elementBy(KeyLocationNotNow);
    }

    public void clickATMAllowBtnIOS() throws ApplicationException {
        click.elementBy(KeyLocationAllow);
    }


    public void selectAccountaccountnumber() throws Throwable {
        click.elementBy(KeyBtnSelectAccountnumber);

    }
}




