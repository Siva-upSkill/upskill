package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import helper.PropertyReader;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSElement;
import runners.ConvergentTestRunner;

public class CryptoWalletPage  extends Keywords{

    private HomePage home = new HomePage();
    private UITFPage uitfPage = new UITFPage();
    private SendRequestPage sendrequest = new SendRequestPage();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();

    private 	String	CryptoWalet	=	"onlineBanking.Dashboard.CryptoWalet";
    private 	String	Bitcoin	=	"onlineBanking.CryptoWalet.Bitcoin";
    private 	String	BuyBTC	=	"onlineBanking.CryptoWalet.BuyBTC";
    private 	String	SellBTC	=	"onlineBanking.CryptoWalet.SellBTC";
    private 	String	Account	=	"onlineBanking.CryptoWalet.Account";
    private 	String	Amount	=	"onlineBanking.CryptoWalet.Amount";
    private 	String	BuyBTCButton	=	"onlineBanking.CryptoWalet.BuyBTCButton";
    private 	String	SellBTCButton	="onlineBanking.CryptoWalet.SellBTCButton";
//    private 	String	Check1	=	"onlineBanking.CryptoWalet.Check1";
//    private 	String	Check2	=	"onlineBanking.CryptoWalet.Check2";
    private 	String	ConfirmButton	=	"onlineBanking.CryptoWalet.ConfirmButton";
    private 	String	ConfirmationScreenTitle_BuyBTC	=	"onlineBanking.CryptoWalet.ConfirmationScreen.BuyBTCTitle";
    private   String ConfirmationScreenTitle_SellBTC = "onlineBanking.CryptoWalet.ConfirmationScreen.SellBTCTitle";
    private    String ConfirmationScreenText_BuyBTC = "onlineBanking.CryptoWalet.ConfirmationScreen.BuyBTCText";
    private String ConfirmationScreenText_SellBTC = "onlineBanking.CryptoWalet.ConfirmationScreen.SellBTCText";
    private 	String	ConfirmationScreenOkay	=	"onlineBanking.CryptoWalet.ConfirmationScreen.Okay";
    private 	String	TransactionDetailsTitle	=	"onlineBanking.CryptoWalet.TransactionDetails.Title";
    private 	String	TransactionDetailsReferenceNumber	=	"onlineBanking.CryptoWalet.TransactionDetails.ReferenceNumber";
    private 	String	TransactionDetailsStatus	=	"onlineBanking.CryptoWalet.TransactionDetails.Status";
    private 	String	TransactionDetailsSuccessful	=	"onlineBanking.CryptoWalet.TransactionDetails.Successful";
    private 	String	TransactionDetailsFromAccount	=	"onlineBanking.CryptoWalet.TransactionDetails.FromAccount";
    private 	String	TransactionDetailsFromAccountNumber	=	"onlineBanking.CryptoWalet.TransactionDetails.FromAccountNumber";
    private 	String	TransactionDetailsExchangeRate	=	"onlineBanking.CryptoWalet.TransactionDetails.ExchangeRate";
    private 	String	TransactionDetailsExchangeRateNumber	=	"onlineBanking.CryptoWalet.TransactionDetails.ExchangeRateNumber";
    private 	String	TransactionDetailsBuyTitle	=	"onlineBanking.CryptoWalet.TransactionDetails.BuyTitle";
    private 	String	TransactionDetailsSellTitle	=	"onlineBanking.CryptoWalet.TransactionDetails.SellTitle";
    private 	String	TransactionDetailsBuy	=	"onlineBanking.CryptoWalet.TransactionDetails.Buy";
    private 	String	TransactionDetailsSettlementAmountTitle	=	"onlineBanking.CryptoWalet.TransactionDetails.SettlementAmountTitle";
    private 	String	TransactionDetailsSettlementAmount	=	"onlineBanking.CryptoWalet.TransactionDetails.SettlementAmount";
    private 	String	TransactionDetailsShareButton	=	"onlineBanking.CryptoWalet.TransactionDetails.ShareButton";
    private 	String	TransactionDetailsShareScreen	=	"onlineBanking.CryptoWalet.TransactionDetails.ShareScreen";
    private String Done = "onlineBanking.CryptoWalet.Done";
    private String TransactionDetailsToAccount = "onlineBanking.CryptoWalet.TransactionDetails.ToAccount";
    private String AgreeBtn = "onlineBanking.CryptoWalet.Agree";
    private String AgreeBtn1 = "onlineBanking.CryptoWalet.Agree";
    private String BitcoinTime="onlineBanking.CryptoWalet.BitcoinTime";
    private String AssetValue="onlineBanking.CryptoWalet.AssetValue";
    private String AvailablePhpBalance="onlineBanking.CryptoWalet.AvailablePHPBalance";
    private String CurrentRateExchangeIndication="onlineBanking.Cryptowalet.CurrenRateExchangeIndication";
    private String SellBTCBtn="onlineBanking.CryptoWalet.SelBTCBtn";
    private String BuyBTCBtn="onlineBanking.CryptoWalet.BuyBTCBtn";
    private String ErrorMsg="onlineBanking.CryptoWalet.ErrorMsg";
    private String KeyOTPTextbox = "convergent.otp.textboxOTP";
    private String TermsConditions="onlineBanking.CryptoWalet.TermsConditions";
    private String ConfirmationMsg="onlineBanking.CryptoWalet.ConfirmationBuyMsg";
    private String BTCCurrentPrice="onlineBanking.CryptoWalet.BTCCurrentPrice";
    private String Fee="onlineBanking.CryptoWalet.Fee";
    private String CheckBox="onlineBanking.CryptoWalet.CheckBoxTerms";
    private String RiskClosureCheckBox="onlineBanking.CryptoWalet.RiskDisclosureCheckBox";
//    private String Confirm="onlineBanking.CryptoWalet.Confirm";
//
//    private String Okay = "onlineBanking.CryptoWalet.Okay";

    public void verify_CryptoWallet() throws ApplicationException {
        Wait.forSeconds(3);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        verify.elementIsPresent(CryptoWalet);
    }

    public void click_cryptowallet() throws ApplicationException {
        Wait.forSeconds(2);
        //MobileElement el1 = (MobileElement) driver.findElementByAccessibilityId("Crypto Wallet");
        //el1.click();
        click.elementBy(CryptoWalet);
        Wait.forSeconds(5);
    }

    public void click_Bitcoin() throws ApplicationException  {
        Wait.waituntillElementVisibleMob(Bitcoin,3);
        if(verify.IfElementExistsboolean(AgreeBtn)) {
            click.elementBy(AgreeBtn);
            click.elementBy(AgreeBtn1);
        }else{
        click.elementBy(Bitcoin);
    }}
    public void verify_BitcoinPage()throws ApplicationException{
        Wait.forSeconds(2);
        verify.elementIsPresent(AssetValue);
        verify.elementIsPresent(BitcoinTime);
        verify.elementIsPresent(BuyBTCBtn);
        verify.elementIsPresent(SellBTCBtn);
    }
    public void click_BuyBTC()  throws ApplicationException {
        Wait.waituntillElementVisibleMob(BuyBTC,2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        click.elementBy(BuyBTC);
    }

    public void click_SellBTC() throws ApplicationException  {
        Wait.waituntillElementVisibleMob(SellBTC,2);
        click.elementBy(SellBTC);
    }

    public void selectAccount() throws ApplicationException {
        Wait.waituntillElementVisibleMob(Account,2);
        click.elementBy(Account);
    }

    public void enterAmount(String amount) throws ApplicationException  {
        Wait.waituntillElementVisibleMob(Amount,2);
//        click.elementBy(Amount);
        type.data(Amount,amount);
        click.elementBy(Done);
    }
    public void verify_BuyBTCPage()throws ApplicationException{
        Wait.forSeconds(2);
        verify.elementIsPresent(AvailablePhpBalance);
        verify.elementIsPresent(CurrentRateExchangeIndication);
        verify.elementIsPresent(TermsConditions);
    }
    public void verify_Errormsg()throws ApplicationException{
        Wait.forSeconds(2);
        verify.elementIsPresent(ErrorMsg);
    }
    public void verify_SellBTCPage()throws ApplicationException{
        Wait.forSeconds(2);
        verify.elementIsPresent(AvailablePhpBalance);
        verify.elementIsPresent(CurrentRateExchangeIndication);
        verify.elementIsPresent(TermsConditions);
    }
    public void enterAmount_AfterSwitching(String amount) throws ApplicationException  {
        Wait.forSeconds(2);
        MobileElement e = (MobileElement) driver.findElementByXPath("//android.view.ViewGroup/android.widget.ScrollView/androidx.appcompat.widget.LinearLayoutCompat/android.view.ViewGroup[1]/android.view.ViewGroup/android.view.ViewGroup");
        e.click();
        Wait.waituntillElementVisibleMob(Amount,2);
//        click.elementBy(Amount);
        type.data(Amount,amount);
        click.elementBy(Done);
    }

    public void checkboxes() throws ApplicationException {
       Wait.forSeconds(2);
        click.elementBy(CheckBox);
        click.elementBy(RiskClosureCheckBox);
    }

    public void click_ConfirmButton() throws ApplicationException  {
        click.elementBy(ConfirmButton);
    }
    public void Enter_OTP()throws ApplicationException{
        click.elementBy(KeyOTPTextbox);
        type.data(KeyOTPTextbox,PropertyReader.testDataOf("Cryptowalet_OTP"));
    }

    public void verify_ConfirmationScreen(String a) throws ApplicationException {

        Wait.forSeconds(2);
        if(a.equalsIgnoreCase("Buy BTC"))
        {
            verify.elementIsPresent(ConfirmationScreenTitle_BuyBTC);
        } else if(a.equalsIgnoreCase("Sell BTC")) {
            verify.elementIsPresent(ConfirmationScreenTitle_SellBTC);
        }

        Wait.forSeconds(2);
        if(a.equalsIgnoreCase("Buy BTC"))
        {
            verify.elementIsPresent(ConfirmationScreenText_BuyBTC);
        } else if(a.equalsIgnoreCase("Sell BTC")) {
            verify.elementIsPresent(ConfirmationScreenText_SellBTC);
        }

    }

    public void click_OkayBtn_ConfirmationScreen() throws ApplicationException {
        Wait.waituntillElementVisibleMob(ConfirmationScreenOkay,3);
        click.elementBy(ConfirmationScreenOkay);
    }

    public void verify_TransactionDetailsPage_BuyBTC() throws ApplicationException {
        Wait.forSeconds(2);
        verify.elementIsPresent(TransactionDetailsTitle);
        verify.elementIsPresent(TransactionDetailsReferenceNumber);
        verify.elementIsPresent(TransactionDetailsStatus);
        verify.elementIsPresent(TransactionDetailsSuccessful);
        verify.elementIsPresent(TransactionDetailsFromAccount);
        verify.elementIsPresent(TransactionDetailsFromAccountNumber);
        verify.elementIsPresent(TransactionDetailsExchangeRate);
        //verify.elementIsPresent(TransactionDetailsExchangeRateNumber);
        verify.elementIsPresent(TransactionDetailsBuyTitle);
        //verify.elementIsPresent(TransactionDetailsBuy);
        verify.elementIsPresent(TransactionDetailsSettlementAmountTitle);
        verify.elementIsPresent(TransactionDetailsSettlementAmount);

    }

    public void verify_TransactionDetailsPage_SellBTC() throws ApplicationException {
        Wait.forSeconds(2);
        verify.elementIsPresent(TransactionDetailsTitle);
        verify.elementIsPresent(TransactionDetailsReferenceNumber);
        verify.elementIsPresent(TransactionDetailsStatus);
        verify.elementIsPresent(TransactionDetailsSuccessful);
        verify.elementIsPresent(TransactionDetailsToAccount);
        verify.elementIsPresent(TransactionDetailsExchangeRate);
        //verify.elementIsPresent(TransactionDetailsExchangeRateNumber);
        verify.elementIsPresent(TransactionDetailsSellTitle);
        //verify.elementIsPresent(TransactionDetailsBuy);
        verify.elementIsPresent(TransactionDetailsSettlementAmountTitle);
        //verify.elementIsPresent(TransactionDetailsSettlementAmount);

    }

    public void Verify_ShareOption() throws ApplicationException  {
        click.elementBy(TransactionDetailsShareButton);
        verify.elementIsPresent(TransactionDetailsShareScreen);
    }

    public void click_BuyBTCButton() throws ApplicationException {
        click.elementBy(BuyBTCButton);
    }

    public void click_SellBTCButton() throws ApplicationException {
        click.elementBy(SellBTCButton);
    }
}



