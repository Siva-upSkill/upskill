package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import runners.ConvergentTestRunner;

public class GoRewardsPage extends Keywords {

    private String AccountsNextslide  = "onlineBanking.CC.AccountsNextslide";
    private String CreditCard = "onlineBanking.CC.CreditCard";
    private String Transaction_Controls = "onlineBanking.CC.Transaction_Controls";
    private String Card_Status = "onlineBanking.CC.Card_Status";
    private String lockunlock_status = "onlineBanking.CC.lockunlock_status";
    private String CardlockandUnlock_off = "onlineBanking.CC.CardlockandUnlock_off";
    private String CardlockandUnlock_on = "onlineBanking.CC.CardlockandUnlock_on";
    private String DashboardLink = "onlineBanking.HomePage.DashboardLink";
    private String Unlock = "onlineBanking.CC.Unlock";
    private String Lock = "onlineBanking.CC.Lock";
//    private String ManageCard = "onlineBanking.CC.ManageCard";
//    private String ManageCards = "onlineBanking.CC.ManageCards";

    private String Cardsettings="onlineBanking.CC.CardSettings";

    private String GORewardsGoldCreditCard = "onlineBanking.CC.GORewardsGoldCreditCard";
    private String GoRewardsPlatinumCredit = "onlineBanking.CC.GoRewardsPlatinumCredit";
    private String LockMyCard = "onlineBanking.CC.LockMyCard";
    private String MaybeLater = "onlineBanking.CC.MaybeLater";
    private String UnlockMyCard = "onlineBanking.CC.UnlockMyCard";
    private String CardUnlocked = "onlineBanking.ReportCard.CardIsUnlocked";
    private String CardIsLocked = "onlineBanking.ReportCard.CardIsLocked";
    private String GoldCreditCardHeader = "onlineBanking.CC.GoldCreditCardHeader";
    private String PlatinumCreditCardHeader = "onlineBanking.CC.PlatinumCreditCardHeader";
    private String AboutCard = "onlineBanking.CC.AboutCard";
    private String LockUnlock = "onlineBanking.CC.LockUnlock";
    private String AboutCardLink = "onlineBanking.CC.AboutCardLink";
    private String HideDetails = "onlineBanking.CC.HideDetails";
    private String Online = "onlineBanking.CC.Online";
    private String International = "onlineBanking.CC.International";
    private String Local = "onlineBanking.CC.Local";
    private String LimitAmount = "onlineBanking.CC.LimitAmount";
    private String SaveButton = "onlineBanking.CC.SaveButton";
    private String CancelButton = "onlineBanking.CC.CancelButton";
    private String EnableButton = "onlineBanking.CC.EnableButton";
    private String SpentLimit = "onlineBanking.CC.SpentLimit";
    private String Keykeepmeloggedinbtn="convergent.login.keepmeloggedinbtn";

    LoginPage login = new LoginPage();
    //SendMoney_Ownaccount Ownaccount = new SendMoney_Ownaccount();
    OTPPage otpPage = new OTPPage();
    ConvergentTestRunner Devicename=new ConvergentTestRunner();
    ReviewandTransferPage otherreviewpage = new ReviewandTransferPage();
    public static String status ;


    public void selectCard() throws Throwable {
        Wait.forSeconds(4);
        click.elementBy(CreditCard);
        }
    public void selectGORewardsGoldCreditCard() throws Throwable {
        Wait.forSeconds(5);
        AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.widget.TextView[@text=\"*3182\"]");
        element.click();
    }
    public void selectGoRewardsPlatinumCredit() throws Throwable {
//        Wait.forSeconds(4);
//        click.elementBy(GoRewardsPlatinumCredit);
        Wait.forSeconds(5);
        AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.widget.TextView[@text=\"*1314\"]");
        element.click();
    }

    public void clickTransactionControls() throws Throwable {
        click.elementBy(Transaction_Controls);
    }

    public void unlockCard() throws Throwable {
       Wait.forSeconds(10);
       verify.IfElementExists(Card_Status);
        WebElement element = driver.findElement(By.xpath("//div[@class='w-100']/br"));
        status=element.getText();
      try {
          if (status.equalsIgnoreCase("Card is unlocked")) {
              //click.elementBy(Transaction_Controls);
              verify.elementIsPresent(CardlockandUnlock_off);

          } else {
              //click.elementBy(DashboardLink);
              //click.elementBy(Transaction_Controls);
              click.elementBy(CardlockandUnlock_on);
              click.elementBy(Unlock);
              //login.enterOTP("111111");
              otpPage.enterOTP("111111");

              otherreviewpage.clickremittancesubmit();
             // Ownaccount.clickSubmit();
              Wait.forSeconds(3);
              verify.elementTextContains(Card_Status, "Card is unlocked");
          }
      } catch (Throwable throwable) {
          throwable.printStackTrace();
      }

    }

    public void lockAndUnlockCard() throws Throwable {
        Wait.forSeconds(10);
//        verify.IfElementExists(Card_Status);
        try {
             if(verify.IfElementExistsboolean(CardUnlocked))
             {
                 click.elementBy(CardlockandUnlock_off);
                 Wait.waituntillElementVisibleMob(LockMyCard,3);
                 verify.elementIsPresent(LockMyCard);
                 verify.elementIsPresent(MaybeLater);
                 click.elementBy(LockMyCard);
                 Wait.waituntillElementVisibleMob(CardIsLocked,3);
                 verify.elementTextContains(CardIsLocked, "Card is locked");
            }
             else
             {
                 click.elementBy(CardlockandUnlock_on);
                 Wait.waituntillElementVisibleMob(UnlockMyCard,3);
                 verify.elementIsPresent(UnlockMyCard);
                 verify.elementIsPresent(MaybeLater);
                 click.elementBy(UnlockMyCard);
                 otpPage.enterOTP("111111");
                 Wait.waituntillElementVisibleMob(CardUnlocked,3);
                 verify.elementTextContains(CardUnlocked, "Card is unlocked");
             }
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }

    }

    public void verifyCardStatus_ValidateFunctionality_Old() throws Throwable
    {
        Wait.forSeconds(12);
        //login.clickkeepmeloggedinbtn();
        verify.IfElementExists(Card_Status);
        WebElement element = driver.findElement(By.xpath("//small[@class='text-muted mt-1']"));
        status=element.getText();

        if(status.equalsIgnoreCase("Control is Enabled")){
            click.elementBy(Transaction_Controls);
            click.elementBy(CardlockandUnlock_off);
            click.elementBy(Lock);
            click.elementBy(CardlockandUnlock_on);
            click.elementBy(Unlock);
            Wait.forSeconds(6);
            click.elementBy(DashboardLink);
            click.elementBy(CreditCard);
            verify.elementTextContains(lockunlock_status,"Card is unlocked");
        }
        else if(status.equalsIgnoreCase("Control is Locked")) {
            click.elementBy(Transaction_Controls);
            click.elementBy(CardlockandUnlock_on);
            click.elementBy(Unlock);
            Wait.forSeconds(6);
            click.elementBy(DashboardLink);
            click.elementBy(CreditCard);
            verify.elementTextContains(lockunlock_status,"Card is unlocked");
        }
        else if(status.equalsIgnoreCase("Control is Unlocked")) {
            driver.findElement(By.cssSelector("div > div > div.header-foreground > div > div.left.part > a > svg")).click();
            click.elementBy(DashboardLink);
            click.elementBy(CreditCard);
            verify.elementTextContains(lockunlock_status,"Card is unlocked");
        }
    }
    public void verifyCardStatus_ValidateFunctionality() throws Throwable
    {
        try {
            if(verify.IfElementExistsboolean(CardUnlocked))
            {
                Wait.waituntillElementVisibleMob(Online,2);
                verify.elementIsPresent(Online);
                verify.elementIsPresent(International);
                verify.elementIsPresent(Local);
            }
            else
            {
                click.elementBy(Keykeepmeloggedinbtn);
                click.elementBy(CardlockandUnlock_on);
                Wait.waituntillElementVisibleMob(UnlockMyCard,3);
                verify.elementIsPresent(UnlockMyCard);
                verify.elementIsPresent(MaybeLater);
                click.elementBy(UnlockMyCard);
                otpPage.enterOTP("111111");
                Wait.waituntillElementVisibleMob(CardUnlocked,3);
                verify.elementTextContains(CardUnlocked, "Card is unlocked");
            }
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    public void verifyGoldCreditCardHeader(String header) throws Throwable {
        Wait.waituntillElementVisibleMob(GoldCreditCardHeader,3);
        verify.elementTextMatching(GoldCreditCardHeader, header);
    }
    public void verifyPlatinumCreditCardHeader(String header) throws Throwable {
        Wait.waituntillElementVisibleMob(PlatinumCreditCardHeader,4);
        verify.elementTextMatching(PlatinumCreditCardHeader, header);
    }
    public void verifyCardSettings() throws Throwable {
        Wait.waituntillElementVisibleMob(Cardsettings,3);
        verify.elementIsPresent(Cardsettings);
    }
    public void verify_ManagePageDetails() throws Throwable {
//        Wait.waituntillElementVisibleMob(AboutCard,4);
        Wait.forSeconds(4);
        verify.elementIsPresent(AboutCard);
        verify.elementIsPresent(LockUnlock);
       // verify.elementIsPresent(Transaction_Controls);
    }
    public void clickAboutCardLink() throws Throwable {
        if (Devicename.currentdevicename.equalsIgnoreCase("Samsung")) {
            Wait.forSeconds(4);
            click.elementBy(AboutCardLink);
//            actions.Touch.pressByCoordinates(954, 1164, 8);
        } else if (Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            Wait.forSeconds(4);
            click.elementBy(AboutCardLink);

        }


    }
    public void verifyHideDetailsLink() throws Throwable {
        Wait.forSeconds(5);
        swipe.swipeVertical(2, 0.6, .2, 2);
        verify.elementIsPresent(HideDetails);
    }
    public void clickHideDetailsLink() throws Throwable {
        click.elementBy(HideDetails);
    }
    public void verifyAfterHideDetailsPage() throws Throwable {
        Wait.waituntillElementVisibleMob(AboutCard,3);
        verify.elementIsPresent(AboutCard);
        verify.elementIsPresent(AboutCardLink);
    }
    public void verifyTransactionControlsOptions() throws Throwable {
        Wait.waituntillElementVisibleMob(Online,3);
        verify.elementIsPresent(Online);
        verify.elementIsPresent(International);
        verify.elementIsPresent(Local);
    }
    public void clickTransactionControls_Online() throws Throwable {
        click.elementBy(Online);
    }
    public void enterLimitAmount(String Amt) throws Throwable {
        Wait.forSeconds(1);
        //type.data(LimitAmount,Amt);
        MobileElement el1 = (MobileElement) driver.findElementById("com.unionbankph.online.qat:id/ub_text_amount_input");
        el1.clear();
        Wait.forSeconds(3);
        el1.sendKeys(Amt);

    }
    public void VerifySaveButtonEnabled() throws ApplicationException {
        Wait.waituntillElementVisibleMob(SaveButton,3);
        verify.elementIsEnabled(SaveButton);
    }
    public void clickSaveButton() throws Throwable {
        Wait.waituntillElementVisibleMob(SaveButton,3);
        click.elementBy(SaveButton);
    }
    public void verifyTransaction_Popups(String enable, String cancel) throws Throwable {
       Wait.waituntillElementVisibleMob(EnableButton,3);
        verify.elementTextMatching(EnableButton, enable);
        verify.elementTextMatching(CancelButton, cancel);
    }
    public void clickEnableButton() throws Throwable {
        click.elementBy(EnableButton);
    }
    public void verifyTransactionControlsSpentLimit() throws Throwable {
        Wait.waituntillElementVisibleMob(Online,3);
        verify.elementIsPresent(Online);

    }

}
