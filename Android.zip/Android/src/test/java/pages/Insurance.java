package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import org.openqa.selenium.JavascriptExecutor;
import runners.ConvergentTestRunner;


public class Insurance extends Keywords {

    private String ReferenceNumber  =  "onlineBanking.Insurance.ReferenceNumber";
    private String PurchasedOn  =  "onlineBanking.Insurance.PurchasedOn";
    private String Coverage  =  "onlineBanking.Insurance.Coverage";
    private String Status  =  "onlineBanking.Insurance.Status";
    private String FromAccount  =  "onlineBanking.Insurance.FromAccount";
    private String Amount  =  "onlineBanking.Insurance.Amount";
    private String ViewReminders  =  "onlineBanking.Insurance.ViewReminders";
    private String PurchaseSuccessfulTitle  =  "onlineBanking.Insurance.PurchaseSuccessfulTitle";

    private String CancelInsuranceBtn  =  "onlineBanking.Insurance.CancelInsuranceBtn";
    private String CancelPurchasePopUpTilte  =  "onlineBanking.Insurance.CancelPurchasePopUpTilte";
    private String CancelReason  =  "onlineBanking.Insurance.CancelReason";
    private String CancelPurchaseBtn  =  "onlineBanking.Insurance.CancelPurchaseBtn";
    private String InsuranceMarketplaceTitle  = "onlineBanking.Insurance.InsuranceMarketplaceTitle";



    private String LifeInsurance1  =  "onlineBanking.Insurance.LifeInsurance1";
    private String LifeInsurance2  =  "onlineBanking.Insurance.LifeInsurance2";
    private String LifeInsurance3  =  "onlineBanking.Insurance.LifeInsurance3";

    private String BackButton = "onlineBanking.Insurance.BackButton";

    private String PurchaseFor  =  "onlineBanking.Insurance.PurchaseFor";
    private String PurchaseFormTitle  =  "onlineBanking.Insurance.PurchaseFormTitle";
    private String HeresyourtransactionsummaryTitle  = "onlineBanking.Insurance.HeresyourtransactionsummaryTitle";
    private String TermsandConditions  =  "onlineBanking.Insurance.TermsandConditions";
    private String MyInsurancesTitle  =  "onlineBanking.Insurance.MyInsurancesTitle";
    private String LifeProductUnderMyInsurances  =  "onlineBanking.Insurance.LifeProductUnderMyInsurances";
    private String PurchaseDetailsTitle  =  "onlineBanking.Insurance.PurchaseDetailsTitle";
    private String PurchaseCancelledTitle  =  "onlineBanking.Insurance.PurchaseCancelledTitle";
    private String ContinueBrowsingBtn  =  "onlineBanking.Insurance.ContinueBrowsingBtn";
    private String ProductUnderMyInsurance1  =  "onlineBanking.Insurance.ProductUnderMyInsurance1";
    private String Awesome="onlineBanking.Insurance.Awesome";
    private String GotIt="onlineBanking.Insurance.GotIt";
    private String Accident  =  "onlineBanking.Insurance.Accident";
    private String Life  =  "onlineBanking.Insurance.Life";
    private String ViewMore  =  "onlineBanking.Insurance.ViewMore";
    private String AccidentInsurance1  =  "onlineBanking.Insurance.AccidentInsurance1";
    private String AccidentInsurance2  =  "onlineBanking.Insurance.AccidentInsurance2";
    private String AccidentInsurance3  =  "onlineBanking.Insurance.AccidentInsurance3";

    private String InsurancePurchaseSuccessful  = "onlineBanking.Insurance.InsurancePurchaseSuccessful";

    private String GetProtected = "onlineBanking.Insurance.GetProtected";
    private String ImpPopupLabel = "onlineBanking.UITF.ImpPopupLabel";
//    private String ProceedBtn = "onlineBanking.UITF.ProceedBtn";
    private String Inbox = "onlineBanking.Insurance.Inbox";
    private String Transactions = "onlineBanking.Insurance.Transactions";
    private String Share = "onlineBanking.Insurance.Share";
    private String PurchaseForFinal = "onlineBanking.Insurance.PurchaseForFinal";
    private String OKAY = "onlineBanking.Insurance.OKAY";
//    private String SelectAccount = "onlineBanking.Insurance.SelectAccount";
//    private String Account = "onlineBanking.Insurance.Account";
    private String ContineBtn = "onlineBanking.Insurance.ContinueBtn";

    private String Compare="onlineBanking.Insurance.Compare";
    private String keySelect = "onlineBanking.Insurance.SelectOption";
    private String SelectLifeProduct="onlineBanking.Insurance.SelectLifeProduct";
    private String CompareThisInsurance="onlineBanking.Insurance.CompareThisInsurance";
    private String CompareInsurances="onlineBanking.Insurance.CompareInsurance";
    private String BackBtn="onlineBanking.Insurance.BackBtn";
    private String FilterOption="onlineBanking.Insurance.Filter";
    private String Slider="onlineBanking.Insurance.Slider";
    private String ShowResults="onlineBanking.Insurance.ShowResults";

    ConvergentTestRunner Devicename=new ConvergentTestRunner();
    OTPPage otp = new OTPPage();

    public void click_viewInsuranceBtn() throws Throwable {
       Wait.forSeconds(6);
       swipe.swipeVertical(2, 0.6, .2, 2);
       swipe.swipeVertical(2, 0.6, .2, 2);
       swipe.swipeVertical(2, 0.6, .2, 2);
//        swipe.swipeVertical(2, 0.6, .2, 2);
//        swipe.swipeVertical(2, 0.6, .2, 2);
//        swipe.swipeVertical(2, 0.6, .2, 2);
//        swipe.swipeVertical(2, 0.6, .2, 2);
//        swipe.swipeVertical(2, 0.6, .2, 2);
//        swipe.swipeVertical(2, 0.6, .2, 2);
//        swipe.swipeVertical(2, 0.6, .2, 2);
//        verify.elementIsPresent(GetProtected);
        click.elementBy(GetProtected);

    }public void Verify_MarketPlacePage() throws Throwable {
        click.elementBy(Awesome);
        Wait.waituntillElementVisibleMob(GotIt,3);
        click.elementBy(GotIt);
        Wait.waituntillElementVisibleMob(Accident,3);
        verify.elementIsPresent(Accident);
        verify.elementIsPresent(Life);
        verify.elementIsPresent(ViewMore);
        click.elementBy(Accident);
        Wait.waituntillElementVisibleMob(AccidentInsurance1,3);
        verify.elementIsPresent(AccidentInsurance1);
        verify.elementIsPresent(AccidentInsurance2);
        verify.elementIsPresent(AccidentInsurance3);
        click.elementBy(BackButton);
        Wait.waituntillElementVisibleMob(Life,2);
        click.elementBy(Life);
        verify.elementIsPresent(LifeInsurance1);
        verify.elementIsPresent(LifeInsurance2);
        verify.elementIsPresent(LifeInsurance3);

    }

    public void verify_InlifePurchasedProduct() throws ApplicationException {
        Wait.forSeconds(2);
        verify.elementIsPresent(Accident);
        verify.elementIsPresent(Life);
        verify.elementIsPresent(ViewMore);
        click.elementBy(ViewMore);
        Wait.waituntillElementVisibleMob(MyInsurancesTitle,3);
        verify.elementIsPresent(MyInsurancesTitle);
        click.elementBy(LifeProductUnderMyInsurances);
        Wait.waituntillElementVisibleMob(PurchaseDetailsTitle,5);
        verify.elementIsPresent(PurchaseDetailsTitle);
        Wait.waituntillElementVisibleMob(ReferenceNumber,4);
        verify.elementIsPresent(ReferenceNumber);
        verify.elementIsPresent(PurchasedOn);
        swipe.swipeVertical(2, 0.6, .2, 2);
        verify.elementIsPresent(Status);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        verify.elementIsPresent(FromAccount);
        verify.elementIsPresent(Coverage);
        verify.elementIsPresent(Amount);
        verify.elementIsPresent(ViewReminders);
        verify.elementIsPresent(Share);
        click.elementBy(BackButton);

    }

    public void cancelPreviousAccident() throws Throwable{
//        click.elementBy(ProductUnderMyInsurance1);
        try {
            Wait.forSeconds(2);
            swipe.swipeVertical(2, 0.6, .2, 2);
            swipe.swipeVertical(2, 0.6, .2, 2);
            swipe.swipeVertical(2, 0.6, .2, 2);
            swipe.swipeVertical(2, 0.6, .2, 2);

            click.elementBy(ProductUnderMyInsurance1);
            Wait.forSeconds(2);
            swipe.swipeVertical(2, 0.6, .2, 2);
            swipe.swipeVertical(2, 0.6, .2, 2);
            swipe.swipeVertical(2, 0.6, .2, 2);
            swipe.swipeVertical(2, 0.6, .2, 2);
            if (verify.IfElementExistsboolean(CancelInsuranceBtn))
            {
                click.elementBy(CancelInsuranceBtn);
                Wait.waituntillElementVisibleMob(CancelPurchasePopUpTilte,3);
                verify.elementIsPresent(CancelPurchasePopUpTilte);
                click.elementBy(CancelReason);
                click.elementBy(CancelPurchaseBtn);
                Wait.waituntillElementVisibleMob(PurchaseCancelledTitle,3);
                verify.elementIsPresent(PurchaseCancelledTitle);
                verify.elementIsPresent(ContinueBrowsingBtn);
                click.elementBy(ContinueBrowsingBtn);
            }
            else {
                click.elementBy(BackButton);
                //verify.elementIsPresent(Accident);
            }
        }
        catch (ApplicationException e) {
            e.printStackTrace();
        }
    }

    public void purchase_AccidentProduct() throws Throwable
    {
        swipe.swipeVertical(2, 0.8, .2, 2);
        verify.elementIsPresent(Accident);
        Wait.waituntillElementVisibleMob(Accident,3);
        click.elementBy(Accident);
        click.elementBy(AccidentInsurance1);
        Wait.waituntillElementVisibleMob(PurchaseFor,3);
        click.elementBy(PurchaseFor);

        //for selecting tap to select account
        Wait.forSeconds(8);
        if(Devicename.currentdevicename.equalsIgnoreCase("Samsung")) {
            actions.Touch.pressByCoordinates(522, 982, 5);
        }
        else if(Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            actions.Touch.pressByCoordinates(522, 1011, 5);
        }

       //click.elementBy(SelectAccount);
        Wait.forSeconds(2);
        //for clicking account
        //click.elementBy(Account);

        if(Devicename.currentdevicename.equalsIgnoreCase("Samsung")) {
            actions.Touch.pressByCoordinates(530, 1878, 5);
        }
        else if(Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            actions.Touch.pressByCoordinates(525,1795 , 5);
        }

        Wait.forSeconds(2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        click.elementBy(ContineBtn);

        //verify.elementIsPresent(HeresyourtransactionsummaryTitle);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        Wait.waituntillElementVisibleMob(TermsandConditions,3);
        click.elementBy(TermsandConditions);
        click.elementBy(PurchaseForFinal);
        verify.IfElementExists(ImpPopupLabel);

        actions.Touch.pressByCoordinates(516, 1941, 5);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);

        actions.Touch.pressByCoordinates(516, 1941, 5);

        click.elementBy(OKAY);
        Wait.forSeconds(4);
        otp.enterOTP("111111");
        Wait.forSeconds(5);
    }

    public void verify_PurchaseSuccessTitle() throws Throwable {
        Wait.waituntillElementVisibleMob(PurchaseSuccessfulTitle,6);
        verify.elementIsPresent(PurchaseSuccessfulTitle);

    }

    public void clickComapre()throws Throwable{
        Wait.waituntillElementVisibleMob(Compare,2);
        click.elementBy(Compare);
    }
    public void clickSelect()throws Throwable{
        Wait.waituntillElementVisibleMob(keySelect,2);
        click.elementBy(keySelect);
        click.elementBy(Life);
    }
    public void SelectLifeProduct()throws Throwable{
        Wait.waituntillElementVisibleMob(SelectLifeProduct,2);
        click.elementBy(SelectLifeProduct);
        click.elementBy(CompareThisInsurance);
    }

    public void verifyCompareInsurancesHeader()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(CompareInsurances);
    }
    public void clickBackbtn()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(BackBtn);
    }
    public void clickFilter()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(FilterOption);
    }
    public void clickSlider()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(Slider);
        click.elementBy(ShowResults);
    }

    public void click_Transactions() throws Throwable {
        click.elementBy(Inbox);
        click.elementBy(Transactions);
    }


    public void verify_Details_PurchasedProduct() throws Throwable {
        //verify.elementIsPresent(InsuranceCancelled);
//        Wait.waituntillElementVisibleMob(InsurancePurchaseSuccessful,3);
        verify.elementIsPresent(InsurancePurchaseSuccessful);
        Wait.waituntillElementVisibleMob(InsurancePurchaseSuccessful,4);
        click.elementBy(InsurancePurchaseSuccessful);
        Wait.waituntillElementVisibleMob(ReferenceNumber,3);
        verify.elementIsPresent(ReferenceNumber);
        verify.elementIsPresent(PurchasedOn);
        swipe.swipeVertical(2, 0.6, .2, 2);
        swipe.swipeVertical(2, 0.6, .2, 2);

        verify.elementIsPresent(FromAccount);
        verify.elementIsPresent(Coverage);
        verify.elementIsPresent(Status);
        verify.elementIsPresent(Amount);
       // verify.elementIsPresent(ViewReminders);
    }

}