package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;

public class OTPPage extends Keywords {

    private String KeyOTPTextbox = "convergent.otp.textboxOTP";
    private String KeyOTPPageTitle = "convergent.otp.labelPageTitle";
    private String KeyOTPPagealertmsg="convergent.otp.labelAlertContent";
    private String KeyOTPPagebackbtn="convergent.otp.backbtn";
    private String KeyOTPPagereceivebtn="convergent.otp.receivecodesmscall";
    private String KeyOPTpageNotnow="convergent.otp.BtnNOTNOW";


    public void enterOTP(String validOTP) throws ApplicationException {
        Wait.forSeconds(1);
        type.data1(KeyOTPTextbox,validOTP);
//        type.sensitiveData(KeyOTPTextbox,validOTP);
    }
    public void verifyPageTitle(String expectedTitle) throws ApplicationException {
        //verify.elementTextMatching(KeyOTPPageTitle,expectedTitle);
        Wait.waituntillElementVisibleMob(KeyOTPPageTitle,7);
//        Wait.forSeconds(8);
        verify.elementIsPresent(KeyOTPPageTitle);
    }

    public void verifyOTPAlertMsg(String expectedmessage) throws ApplicationException {
        verify.elementTextMatching(KeyOTPPagealertmsg,expectedmessage);
    }

    public void verifyOTPPageElements(String receivebtnverbiage) throws ApplicationException {
        verify.IfElementExists(KeyOTPTextbox);
        verify.IfElementExists(KeyOTPPagebackbtn);
        verify.IfElementExists(KeyOTPPagereceivebtn);
        verify.elementTextMatching(KeyOTPPagereceivebtn,receivebtnverbiage);
    }

    public void clickNotnow() throws ApplicationException {
       try {

           if(verify.IfElementExistsboolean(KeyOPTpageNotnow)){
           click.elementBy(KeyOPTpageNotnow);}
       }
       catch(Exception e)
       {

       }
    }

}