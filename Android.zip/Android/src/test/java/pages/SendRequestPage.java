package pages;

import actions.Wait;
import com.cucumber.listener.Reporter;

import base.Keywords;
import driver.DriverManager;
import exceptions.ApplicationException;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.support.ui.FluentWait;
import xpath.Matching;


public class SendRequestPage extends Keywords {

    private String KeyOtherBanks = "convergent.send_request.linkOtherBanks";
    private String KeySendMoneyVia = "convergent.send_request.selectLinkOtherBanks";
    private String KeySelectFromList = "convergent.send_request.btnSelectFromList";
    private String KeySearch = "convergent.send_request.btnSelectReceipientSearch";
    private String KeySearchTextbox = "convergent.send_request.textboxSearchReceipient";
    private String KeyNext = "convergent.send_request.btnNext";
    private String KeyTransferAmount = "convergent.send_request.textboxTransferAmount";
    private String KeyTransferPurpose = "convergent.send_request.textboxTransferPurpose";
    private String KeyTransferFromAccountHidden = "convergent.send_request.labelTransferfromAccount";
    private String KeyTransfer = "convergent.send_request.btnTransfer";
    private String KeyProceedTransfer = "convergent.send_request.btnProceedTransfer";
    private String KeyGotoDashboard = "convergent.send_request.btnGotoDashboard";
    private String KeySendRequestpageEONAccountlink = "convergent.fundtransfer.linkEONAccount";
    private String KeySendRequestpagetitle = "convergent.send.labelPageTile";
    private String KeySendRequestpageOWNAccountlink = "convergent.fundtransfer.linkOwnAccount";
    private String KeySendRequestpageotherUBPAccountlink = "convergent.fundtransfer.linkOtherUnionBankAccount";
    private String KeySendRequestselectpurpose = "convergent.send_request.textboxTransferPurpose";
    private String KeySendMoneyPesoNet = "convergent.send_request.Pesonet";
    private String KeyInstaPaySendMoneyVia = "convergent.SendMoneyVia.btnInstaPay";

    private String KeyManageTransfers="convergent.send_request.Manage_Transfers";
    private String KeySendMoneyPDDTS="convergent.pddts.pddtspage.lblpddts";
    private String KeySendMoneyPDDTStext="convergent.pddts.pddtspage.lblpddtstext";
    private String KeyRemittancecenter="convergent.fundtransfer.linkRemittanceCenter";
    private String KeyGetstrated="convergent.Remittanccentertransferpage.btnGetstarted";
    private String KeyPalawanExpress="convergent.Remittanccentertransfersendnoneypage.btnPalawanExpress";
    private String KeyCebuanaLhuillie="convergent.Remittanccentertransfersendnoneypage.btnCebuanaLhuillier";
    private String KeyLBC="convergent.Remittanccentertransfersendnoneypage.btnLBC";
    private String KeyPerahub="convergent.Remittanccentertransfersendnoneypage.btnPerahub";
    private String KeyHistory="convergent.Remittanccentertransfersendnoneypage.btnHistory";
    private String KeyRequestTab = "convergent.send.linkRequestTab";
    private String tapToTryAgain = "convergent.RemittancecenterRecentTransaction.Taptotryagain";
    private String KeyInstapayLink="convergent.fundtransfer.InstapayLink";
    private String KeyPesonetLink="convergent.fundtransfer.pesonetLink";
    private String KeyPDDTSLink="convergent.fundtransfer.PDDTSLink";
    private String Search="convergent.Pesonet.clickactionsearchbtn";
    private String SearchTxtBox="convergent.Pesonet.searchtxtbox";
    private String emptyclosebtn="convergent.fundtransfer.emptyclosebtn";
    private String SelectFromContcts="convergent.TransferToPage.SelectFromContactc";



    private String hiddenFromAccountNumber, transactionRef;

    public void gotoRequestTab() throws ApplicationException {
        Wait.forSeconds(2);
        verify.elementIsPresent(KeySendRequestpageOWNAccountlink);
        verify.elementIsPresent(KeySendRequestpageotherUBPAccountlink);
        verify.elementIsPresent(KeyOtherBanks);
        verify.elementIsPresent(KeySendRequestpageEONAccountlink);
        verify.elementIsPresent(KeyRemittancecenter);
        click.elementBy(KeyRequestTab);
    }

    public void clickOtherBanks() throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyOtherBanks,4);
        click.elementBy(KeyOtherBanks);
        verify.elementIsPresent(KeyInstapayLink);
        verify.elementIsPresent(KeyPesonetLink);
        verify.elementIsPresent(KeyPDDTSLink);
    }

    public void clickOtherBanksIOS() throws ApplicationException {
        Wait.forSeconds(5);
        //click.elementBy(KeyOtherBanks);
        driver.findElementByAccessibilityId("Other Banks").click();
    }

    public void clickSendMoneyViaPesoNet() throws ApplicationException {
        if(DriverManager.OS.equalsIgnoreCase("ANDROID")) {
           // click.elementBy(KeySendMoneyVia, 1);
            Wait.forSeconds(2);
            MobileElement mobileElement = (MobileElement) driver.findElementByXPath("//android.view.ViewGroup/androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout[2]/android.widget.FrameLayout/android.view.ViewGroup");
            mobileElement.click();
        }
        else if(DriverManager.OS.equalsIgnoreCase("IOS"))  {
            Wait.forSeconds(8);
            //click.elementBy(KeySendMoneyPesoNet);
            actions.Touch.pressByCoordinates(400, 720, 5);
        }
    }

    public void clickSendMoneyViaInstaPay() throws ApplicationException {
        click.elementBy(KeySendMoneyVia);
        //  MobileElement mobileElement = (MobileElement) driver.findElementByXPath("//androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout[1]");
        //mobileElement.click();
    }

    public void clickSendMoneyViaInstaPayIOS() throws ApplicationException {
        //driver.findElementByAccessibilityId("Receive instantly for PHP 10").click();
        //actions.Touch.pressByCoordinates(147, 698, 5);
        actions.Touch.pressByCoordinates(350, 820, 5);
    }

    public void selectTransferFromAccount(String transferFromAccountNumber) throws ApplicationException {
        click.elementBy(xpathOf.textView(Matching.youDecide("transferFromAccountNumber")));
        ////click.elementBy(ResourceBase.androidTextViewXPATH(transferFromAccountNumber));
    }

    public void clickSelectFromList() throws ApplicationException {
        click.elementBy(KeySelectFromList);
        Wait.forSeconds(1);
        click.elementBy(Search);
        click.elementBy(SearchTxtBox);
        type.data(SearchTxtBox,"Lrp0EBCZuc");
        click.elementBy(emptyclosebtn);
        type.data(SearchTxtBox,"UNIONDIGITALBANK");
        click.elementBy(emptyclosebtn);
        type.data(SearchTxtBox,"881152294171");
    }

    public void selectAccount(String accountName) throws ApplicationException {
        click.elementBy(KeySearch);
        type.data(KeySearchTextbox, accountName);
        click.elementBy(xpathOf.textView(Matching.youDecide("accountName")));
        ////click.elementBy(ResourceBase.androidTextViewXPATH(accountName));
    }

    public void enterTransferAmount(String amount) throws ApplicationException {
        type.data(KeyTransferAmount, amount);
    }

    public void enterTransferPurpose(String purpose) throws ApplicationException {
        type.data(KeyTransferPurpose, purpose);
    }

    public void selectTransferPurpose() throws ApplicationException {
        click.elementBy(KeyTransferPurpose);
    }

    public void clickNext() throws ApplicationException {
        click.elementBy(KeyNext);
    }

    public void reviewBeforeTransfer(String fromAccount, String fromBank, String toAccount, String toBank, String transferAmount, String transferDate, String transferPurpose) throws ApplicationException {
        hiddenFromAccountNumber = get.elementBy(KeyTransferFromAccountHidden).getText();
        click.elementBy(hiddenFromAccountNumber);
        verify.IfElementExists(xpathOf.textView(Matching.youDecide("fromAccount")));
        verify.IfElementExists(xpathOf.textView(Matching.youDecide("fromBank")));
        verify.IfElementExists(xpathOf.textView(Matching.youDecide("toAccount")));
        verify.IfElementExists(xpathOf.textView(Matching.youDecide("toBank")));
        verify.IfElementExists(xpathOf.textView(Matching.youDecide("transferAmount")));
        verify.IfElementExists(xpathOf.textView(Matching.youDecide("transferDate")));
        verify.IfElementExists(xpathOf.textView(Matching.youDecide("transferPurpose")));

        //// ResourceBase.PERFORM.checkIfElementExists(ResourceBase.androidTextViewXPATH(fromAccount));
        ////ResourceBase.PERFORM.checkIfElementExists(ResourceBase.androidTextViewXPATH(fromBank));
        //// ResourceBase.PERFORM.checkIfElementExists(ResourceBase.androidTextViewXPATH(toAccount));
        //// ResourceBase.PERFORM.checkIfElementExists(ResourceBase.androidTextViewXPATH(toBank));
        ////  ResourceBase.PERFORM.checkIfElementExists(ResourceBase.androidTextViewXPATH(transferAmount));
        //// ResourceBase.PERFORM.checkIfElementExists(ResourceBase.androidTextViewXPATH(transferDate));
        //// ResourceBase.PERFORM.checkIfElementExists(ResourceBase.androidTextViewXPATH(transferPurpose));
    }

    public void clickTransfer() throws ApplicationException {
        click.elementBy(KeyTransfer);
        click.elementBy(KeyProceedTransfer);
    }

    public void reviewAfterTransfer(String fromAccount, String fromBank, String toAccount, String toBank, String transferAmount, String transferDate, String transferPurpose) throws ApplicationException {
        transactionRef = get.elementBy(KeyTransferFromAccountHidden).getText();
        Reporter.addStepLog("Transaction Reference Number is " + transactionRef);
        click.elementBy(xpathOf.textView(Matching.youDecide("hiddenFromAccountNumber")));
        verify.IfElementExists(xpathOf.textView(Matching.youDecide("fromAccount")));
        verify.IfElementExists(xpathOf.textView(Matching.youDecide("fromBank")));
        verify.IfElementExists(xpathOf.textView(Matching.youDecide("toAccount")));
        verify.IfElementExists(xpathOf.textView(Matching.youDecide("toBank")));
        verify.IfElementExists(xpathOf.textView(Matching.youDecide("transferAmount")));
        verify.IfElementExists(xpathOf.textView(Matching.youDecide("transferDate")));
        verify.IfElementExists(xpathOf.textView(Matching.youDecide("transferPurpose")));
        //// click.elementBy(ResourceBase.androidTextViewXPATH(hiddenFromAccountNumber));
        //// ResourceBase.PERFORM.checkIfElementExists(ResourceBase.androidTextViewXPATH(fromAccount));
        ////  ResourceBase.PERFORM.checkIfElementExists(ResourceBase.androidTextViewXPATH(fromBank));
        ////  ResourceBase.PERFORM.checkIfElementExists(ResourceBase.androidTextViewXPATH(toAccount));
        ////  ResourceBase.PERFORM.checkIfElementExists(ResourceBase.androidTextViewXPATH(toBank));
        //// ResourceBase.PERFORM.checkIfElementExists(ResourceBase.androidTextViewXPATH(transferAmount));
        //// ResourceBase.PERFORM.checkIfElementExists(ResourceBase.androidTextViewXPATH(transferDate));
        //// ResourceBase.PERFORM.checkIfElementExists(ResourceBase.androidTextViewXPATH(transferPurpose));
    }

    public void gotoDashboard() throws ApplicationException {
        click.elementBy(KeyGotoDashboard);
    }

    public void verifyTransactionSuccessfullMessage(String expectedText) throws ApplicationException {
        ///verify.IfElemenExists(androidTextViewXPATH(expectedText.trim()));
    }

    public void verifyEONAccountLink(String ilink) throws ApplicationException, InterruptedException {
        Wait.waituntillElementVisibleMob(KeySendRequestpageEONAccountlink,4);
        verify.elementTextMatching(KeySendRequestpageEONAccountlink, ilink);
    }

    public void clickEONAccountLink() throws ApplicationException, InterruptedException {
        WAIT.forSecondsUsingFluentWAIT(4,KeySendRequestpageEONAccountlink);
        click.elementBy(KeySendRequestpageEONAccountlink);
    }

    public void verifySendRequestTitle(String iexpectval) throws ApplicationException {
        verify.elementTextMatching(KeySendRequestpagetitle, iexpectval);

    }
    public void verifyOWNAccountLink(String ilink) throws ApplicationException, InterruptedException {
        Wait.forSeconds(2);
        verify.elementIsPresent(KeySendRequestpageOWNAccountlink);
        verify.elementIsPresent(KeySendRequestpageotherUBPAccountlink);
    }
    public void clickOWNAccountLink() throws ApplicationException, InterruptedException {
        click.elementBy(KeySendRequestpageOWNAccountlink);
    }

    public void verifyOWNAccountLinkNotDisplayed(String ilink) throws ApplicationException, InterruptedException {
        Wait.waituntillElementVisibleMob(KeySendRequestpageOWNAccountlink,4);
        verify.IfElementNotExists(KeySendRequestpageOWNAccountlink);
    }

    public void verifyOtherUBPAccountLink(String ilink) throws ApplicationException, InterruptedException {
        Wait.forSeconds(1);
        verify.elementIsPresent(KeySendRequestpageotherUBPAccountlink);

    }
    public void clickOtherUBPAccountLink() throws ApplicationException {
        click.elementBy(KeySendRequestpageotherUBPAccountlink);

    }
    public void verifyOtherBankAccountLink(String ilink) throws ApplicationException, InterruptedException {

        verify.elementTextMatching(KeyOtherBanks, ilink);
    }

    public void selectPurpose() throws ApplicationException {
        click.elementBy(KeySendRequestselectpurpose);
    }

    public void clickmanagetransfers() throws ApplicationException {
        click.elementBy(KeyManageTransfers);
    }

    public void verifypddtsisexist() throws ApplicationException {
        verify.elementIsPresent(KeySendMoneyPDDTS);
        verify.elementIsPresent(KeySendMoneyPDDTStext);
    }

    public void clickOtherBanksExist() throws ApplicationException {
        Wait.forSeconds(3);
        verify.elementIsPresent(KeyOtherBanks);

    }
    public void clickpddts() throws ApplicationException {
        //click.elementBy(KeySendMoneyPDDTS);
        Wait.forSeconds(4);
        MobileElement mobileElement = (MobileElement) driver.findElementByXPath("//android.widget.FrameLayout/android.view.ViewGroup/androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout[3]/android.widget.FrameLayout/android.view.ViewGroup");
        //MobileElement mobileElement = (MobileElement) driver.findElementByXPath("(//android.widget.ImageView)[3]");
        mobileElement.click();
        Wait.forSeconds(5);
    }

    public void verifyremittancecenterisexist() throws ApplicationException {
        verify.elementIsPresent(KeyRemittancecenter);

    }
    public void clickremittancecenter() throws ApplicationException {
        click.elementBy(KeyRemittancecenter);

    }
    public void clickGetstarted() throws ApplicationException {
        if(verify.IfElementExistsboolean(KeyGetstrated)) {

            click.elementBy(KeyGetstrated);
        }
    }

    public void verifyProviders()throws Throwable{
        Wait.forSeconds(1);
        verify.elementIsPresent(KeyCebuanaLhuillie);
        verify.elementIsPresent(KeyLBC);
        verify.elementIsPresent(KeyPerahub);
    }
    public void verifypalawanexpressisexist() throws ApplicationException {
        verify.elementIsPresent(KeyPalawanExpress);
    }
    public void clickpalawanexpress() throws ApplicationException {
        click.elementBy(KeyPalawanExpress);

    }
    public void clickCebuanaLhuillie() throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyCebuanaLhuillie,3);
        click.elementBy(KeyCebuanaLhuillie);

    }

    public void clickhistory() throws ApplicationException {
        //click.elementBy(tapToTryAgain);
        click.elementBy(KeyHistory);

    }
}
