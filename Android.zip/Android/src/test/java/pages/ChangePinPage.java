package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import io.appium.java_client.android.AndroidElement;
import runners.ConvergentTestRunner;


public class ChangePinPage extends Keywords {

    private HomePage home = new HomePage();
    private UITFPage uitfPage = new UITFPage();
    private SendRequestPage sendrequest = new SendRequestPage();

    private String PlayEverdayCard = "convergent.GreenPin.PlayEverdayCard";
    private String ManageCards = "convergent.GreenPin.ManageCards";
    private String CardImage = "convergent.GreenPin.CardImage";
    private String ChangePin = "convergent.GreenPin.ChangePin";
    private String EnterPin ="convergent.GreenPin.EnterPin";
    private String ConsecutiveNumericValuesErrMsg = "convergent.GreenPin.ConsecutiveNumericValuesErrMsg";
    private String OkayBtn = "convergent.GreenPin.OkayBtn";
    private String samePinErrMsg = "convergent.GreenPin.samePinErrMsg";
    private String PinDoesntMatchErrMsg = "convergent.GreenPin.PinDoesntMatchErrMsg";
    private String confirmBtn = "convergent.GreenPin.ConfirmBtn";
    private String ReminderTitle = "convergent.GreenPin.ReminderTitle";
    private String ReminderText = "convergent.GreenPin.ReminderText";
    private String InvalidOTPErrMsg = "convergent.GreenPin.InvalidOTPErrMsg";
    private String OTP = "convergent.GreenPin.OTP";
    private String PlayEverdayCard_SetPin = "convergent.GreenPin.PlayEverdayCard.SetPin";


    ConvergentTestRunner Devicename=new ConvergentTestRunner();


    public void clickPlayEverdayCard() throws ApplicationException {
        Wait.forSeconds(6);
        AndroidElement element = (AndroidElement) driver.findElementById("com.unionbankph.online.qat:id/text_type]");
        element.click();
    }

    public void clickPlayEverdayCard_SetPin()  throws ApplicationException
    {
        Boolean result = false;
        int i=1;
        while (result == false && i <=60 ) {
            try {
                if(i==1) {
                    //swipe.swipeVertical(2, .2, .8, 5);
                    click.elementBy(PlayEverdayCard_SetPin);
                }
                else {
                    swipe.swipeVertical(2, .8, .2, 5);
                    click.elementBy(PlayEverdayCard_SetPin);
                }

                result = true;
            }
            catch(Exception e){

            }
            i=i+1;
        }
    }

    public void clickManageCards() throws ApplicationException {
        Wait.waituntillElementVisibleMob(ManageCards,4);
        click.elementBy(ManageCards);
        Wait.waituntillElementVisibleMob(CardImage,3);
        click.elementBy(CardImage);
//        actions.Touch.pressByCoordinates(433, 631, 8);
    }

    public void clickChangePin() throws ApplicationException {
        Wait.waituntillElementVisibleMob(ChangePin,4);
        //swipe.swipeVertical(2, 0.6, .2, 2);
        //swipe.swipeVertical(2, 0.6, .2, 2);
        //actions.Touch.pressByCoordinates(195, 812, 8);
        click.elementBy(ChangePin);
    }

    public void enterPin(String Pin) throws ApplicationException {
        Wait.forSeconds(10);
        type.data(EnterPin,Pin);

    }

    public void verify_ConsecutiveNumericValue() throws ApplicationException {
        Wait.forSeconds(3);
        verify.elementIsPresent(ConsecutiveNumericValuesErrMsg);
        click.elementBy(OkayBtn);
    }

    public void verify_SamePinErrMsg() throws ApplicationException {
        Wait.forSeconds(3);
        verify.elementIsPresent(samePinErrMsg);
        click.elementBy(OkayBtn);
    }

    public void click_Confirm() throws ApplicationException {
        click.elementBy(confirmBtn);
    }

    public void verify_PinDoesntMatch() throws ApplicationException {
        Wait.forSeconds(3);
        verify.elementIsPresent(PinDoesntMatchErrMsg);
    }

    public void verify_Reminders() throws ApplicationException {
        verify.elementIsPresent(ReminderTitle);
        //verify.elementIsPresent(ReminderText);
    }

    public void enterOTP(String pin) throws ApplicationException {

        Wait.waituntillElementVisibleMob(OTP,3);
        type.data(OTP,pin);

    }

    public void verify_InvalidOTP() throws ApplicationException {
        Wait.forSeconds(3);
        verify.elementIsPresent(InvalidOTPErrMsg);
    }

    public void verifyOTP_Page() throws ApplicationException{
        Wait.forSeconds(3);
        verify.elementIsPresent(OTP);
    }
}