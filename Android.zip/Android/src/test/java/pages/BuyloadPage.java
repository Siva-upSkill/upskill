package pages;

import actions.Swipe;
import actions.Touch;
import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import helper.PropertyReader;
import org.openqa.selenium.By;

public class BuyloadPage extends Keywords {

	private String ManageContacts = "onlineBanking.BuyLoad.ManageContacts";
	private String MobileInlineErrormsg ="onlineBanking.BuyLoad.lbltinvalidmobilenumbererrormsg";
	private String MobileNumberStartsErrorMsg="onlineBanking.BuyLoad.MobiLeNumberStartsErrormsg";
	private String MobileNumberLessErrorMsg="onlineBanking.BuyLoad.lblMobileNumbershouldhave10digits";
	private String EditContactHeader="onlineBanking.BuyLoad.EditContactHeader";
	private String AddButton="onlineBanking.BuyLoad.Addnew";

	private String FirstNameTxtBox="convergent.participantNewContact.textboxName";

	private String KeyEditExistingManageReceipentink = "convergent.Managereceipent.Editexistingmanangerecipent";
	private String keyEdit="onlineBanking.BuyLoad.Edit";

	private String keyDelete="onlineBanking.BuyLoad.Delete";
	private String FirstNameTxtbox="onlineBanking.BuyLoad.EnterFirstName";
	private String MobileNumberTxtbox="onlineBanking.BuyLoad.EnterMobileNumber";
	private String FirstNameInlineErrorMsg ="onlineBanking.BuyLoad.InlineErroMsgEditContactScreen";
	private String AddContactBtn ="convergent.participantNewContact.AddContact";
	private String keyBtnNext ="onlineBanking.BuyLoad.Next";
//	private String MobileNumberInlineErrorMsg="onlineBanking.BuyLoad.InlineErroMsg1EditContactScreen";

	private String AccountName = "onlineBanking.BUYLOAD_MANAGECONTACTS.AccountName";
	private String AccountNumber = "onlineBanking.BUYLOAD_MANAGECONTACTS.AccountNumber";
	private String keybuyload = "onlineBanking.BuyLoad.LnkBuyload";
	private String keyselectcontact = "onlineBanking.BuyLoad.LnkSelectcontact";
	private String keymobilenumber = "onlineBanking.BuyLoad.Txtmobilenumber";
	private String keyselectfromlist = "onlineBanking.BuyLoad.Btnselectfromlist";
	private String keySearchcontact = "onlineBanking.BuyLoad.TxtSearchcontact";
	private String keySearchresult = "onlineBanking.BuyLoad.lblSearchresult";
	private String keypurchaseload = "onlineBanking.BuyLoad.Btnpurchaseload";
	private String keyDELETECONTACT="onlineBanking.BuyLoad.DELETECONTACT";
	private String KeyDeletePopUpMsg="onlineBanking.BuyLoad.VerifyDeleteMsg";
	private String KeyTapToSelectAccount="onlineBanking.BuyLoad.TapToSelectAccount";
	private String keyOTP = "onlineBanking.BuyLoad.TxtOTP";
	private String keysubmit = "onlineBanking.BuyLoad.btnsubmit";
	private String keypurchasesuccessful = "onlineBanking.BuyLoad.Lblpurchasesuccessful";
	private String keyFromAcoount_Purchasesuccessful = "onlineBanking.BuyLoad.LblFromAcoount_Purchasesuccessful";
	private String keyBuyLoad_To_Purchasesuccessful = "onlineBanking.BuyLoad.lblBuyLoad_To_Purchasesuccessful";
	private String keyamount_RecentTransfers = "onlineBanking.BuyLoad.lblamount_RecentTransfers";
	private String keylnkfavourites = "onlineBanking.BuyLoad.lnkfavourites";
	private String keyaccountnumber = "onlineBanking.BuyLoad.lblaccountnumber";
	private String keyerrormessage = "onlineBanking.BuyLoad.lblerrormessage";
	private String Keysubmit = "onlineBanking.BuyLoad.btnSubmit";
	private String KeyNewpurchase = "onlineBanking.BuyLoad.NewPurchase";
	private String KeyDashboard = "onlineBanking.BuyLoad.lbldashboard";
	private String KeyContactName="onlineBanking.BuyLoad.ContactsName";
	private String KeyInvalidotperrormsg = "onlineBanking.BuyLoad.lblInvalidotperrormsg";
	private String KeyBuyloadfromaccountedit = "onlineBanking.BuyLoad.btnfromaccountedit";
	private String KeyBuyloadmobilenumberedit = "onlineBanking.BuyLoad.btnmobilenumberedit";
	private String KeyBuyloadamountedit = "onlineBanking.BuyLoad.btnamountedit";
	private String KeyBuyloadcancelpurchase = "onlineBanking.BuyLoad.btncancelpurchase";
	private String Keymobilenumber = "onlineBanking.BuyLoad.txtmobilenumber";
	private String Keyinvaligmobilenumbererrormsg = "onlineBanking.BuyLoad.lbltinvalidmobilenumbererrormsg";
	private String KeyManageContacts = "onlineBanking.BuyLoad.lnkManageContacts";
	private String KeytxtSearch = "onlineBanking.BuyLoad.txtSearch";
	private String KeytxtSearchresult1 = "onlineBanking.BuyLoad.lblresult1";
	private String KeytxtSearchresult2 = "onlineBanking.BuyLoad.lblresult2";
	private String keybtnsearchicon = "onlineBanking.BuyLoad.btnSearchicon";
	private String keyAddmobilenumber = "onlineBanking.BuyLoad.txtAddmobilenumber";
	private String keyAddcontact = "onlineBanking.BuyLoad.btnAddcontact";
	private String keyAddname = "onlineBanking.BuyLoad.txtAddname";
	private String keybtnSave = "onlineBanking.BuyLoad.btnSave";
	private String keybtnEdit = "onlineBanking.BuyLoad.btnEdit";
	private String keybtnUpdate = "onlineBanking.BuyLoad.btnUpdate";
	private String keybtnDelete = "onlineBanking.BuyLoad.btnDelete";
	private String keybtnYes = "onlineBanking.BuyLoad.btnYes";
	private String keybtnNoenrolledcontactsfound = "onlineBanking.BuyLoad.lblNoenrolledcontactsfound";
	private String keybtnfavourite = "onlineBanking.BuyLoad.btnfavorite";
	private String keynameisrequired = "onlineBanking.BuyLoad.lblNameisrequired";
	private String keyMobileNumbershouldhave10digits = "onlineBanking.BuyLoad.lblMobileNumbershouldhave10digits";
	private String keyErrormessage = "onlineBanking.BuyLoad.Errormessage";
	private String keyFAQ = "onlineBanking.BuyLoad.btnFAQ";
	private String keyCanIbuyloadforothers = "onlineBanking.BuyLoad.lblCanIbuyloadforothers";
	private String keyWhatairtimedenominationsmayIload = "onlineBanking.BuyLoad.lblWhatairtimedenominationsmayIload";
	private String keysearchFAQ = "onlineBanking.BuyLoad.txtsearchFAQ";
	private String keysearchresult = "onlineBanking.BuyLoad.lblsearchresult";
	private String keyfromaccountnumber = "onlineBanking.BuyLoad.lblfromaccountnumber";
	private String keymobilenumbervalidate = "onlineBanking.BuyLoad.lblmobilenumber";
	private String keyamount = "onlineBanking.BuyLoad.lblamount";
	private String OkButton = "onlineBanking.FX.Ok";
	private String keyFromaccount_Buyload = "onlineBanking.Buyload.FromAccountNumber";
	private String DataOf_FromAccount_Buyload = PropertyReader.testDataOf("BL_FromAccountNumber");

	private String NewPurchase="onlineBanking.BuyLoad.NewPurchase";
	private String ProviderGlobe = "onlineBanking.BuyLoad.ProviderGlobe";
	private String ProviderSmart = "onlineBanking.BuyLoad.ProviderSmart";
	private String ProviderTM = "onlineBanking.BuyLoad.ProviderTM";
	private String ProviderTNT = "onlineBanking.BuyLoad.ProviderTNT";
	private String SelectDenomination = "onlineBanking.BuyLoad.SelectDenomination";
	private String Dataof_Denomination = PropertyReader.testDataOf("BL_Amount");
	private String ContactIcon = "onlineBanking.BuyLoad.ContactIcon";
	private String PurchaseFromAccount = "onlineBanking.BuyLoad.PurchaseFromAccount";
	private String SelectFromAccount = "onlineBanking.BuyLoad.SelectFromAccount";
	private String BuyLoadBtn = "onlineBanking.BuyLoad.BuyLoadBtn";
	private String PurchaseSuccessMessage = "onlineBanking.BuyLoad.PurchaseSuccessMessage";
	private String DenominationEdit = "onlineBanking.BuyLoad.DenominationEdit";
	private String NewDenomination = "onlineBanking.BuyLoad.SelectNewDenomination";
	private String UpdateBtn = "onlineBanking.BuyLoad.UpdateBtn";
	private String FromAccountEdit = "onlineBanking.BuyLoad.FromAccEdit";

	private String AccountUpdateOption = "onlineBanking.BuyLoad.AccountUpdateOption";
	private String SelectNewFromAccount = "onlineBanking.BuyLoad.SelectNewFromAccount";
    private String  BuyLoaad="onlineBanking.BuyLoad.BuyLoad";
	private String SelectFromList="onlineBanking.BuyLoad.SelectFromList";
	private String NewTransaction="onlineBanking.Swift.NewTransaction";


//	private GreenPinPage greenPinPage = new GreenPinPage();

	public void fromAccount_Buyload() throws Throwable {
		Wait.forSeconds(1);
		click.elementBy(keyFromaccount_Buyload, DataOf_FromAccount_Buyload);
	}

    public void clickBuyload()throws Throwable{
		Wait.waituntillElementVisibleMob(BuyLoaad,3);
		click.elementBy(BuyLoaad);
   }
	public void clickManageContacts() throws Throwable {
		verify.IfElementExists(ManageContacts);
		click.elementBy(ManageContacts);
	}

	public void clickAddButton()throws Throwable{
		Wait.waituntillElementVisibleMob(keyAddcontact,2);
		click.elementBy(keyAddcontact);
	}

	public void verifyEditContactHeader()throws Throwable{
		Wait.waituntillElementVisibleMob(EditContactHeader,2);
		verify.elementIsPresent(EditContactHeader);
	}

	public void clickselectcontact() throws Throwable {
//		click.elementBy(SelectFromList);
		Wait.forSeconds(3);
		click.elementBy(keyselectcontact);
	}

	public void verifyelementisexist() throws Throwable {
		verify.IfElementExists(keymobilenumber);

	}
	public void verifyMobileStartsErrorMsg()throws Throwable{
		Wait.forSeconds(2);
		click.elementBy(MobileNumberTxtbox);
		type.data(MobileNumberTxtbox,"09");
		verify.elementIsPresent(MobileNumberStartsErrorMsg);
	}
	public void EnterMobileNumber()throws Throwable{
		Wait.waituntillElementVisibleMob(MobileNumberTxtbox,2);
		type.data(MobileNumberTxtbox,"98799998");
	}
	public void verifyMobileLessErrorMsg()throws Throwable{
		Wait.forSeconds(2);
		verify.IfElementExists(MobileNumberLessErrorMsg);
	}

	public void clickNewTransaction()throws Throwable{
		Wait.forSeconds(2);
		click.elementBy(NewTransaction);

	}
	public void clickTaptoselectAccount()throws Throwable{
		click.elementBy(MobileNumberTxtbox);
		type.data(MobileNumberTxtbox,PropertyReader.testDataOf("BL_Phonenumber"));
		Wait.waituntillElementVisibleMob(KeyTapToSelectAccount,2);
		click.elementBy(KeyTapToSelectAccount);
		Wait.waituntillElementVisibleMob(SelectFromAccount,2);
		click.elementBy(SelectFromAccount);
		click.elementBy(keyBtnNext);
	}

	public void selectvaluefromthetext() throws Throwable {
		Wait.forSeconds(5);
//		String Datatoselectxpath = "(" + "//*[text()=" + "'" + PropertyReader.testDataOf("BL_Amount").trim() + "'" + "]/parent::button" + ")" + "[1]";
//		element = driver.findElement(By.xpath(Datatoselectxpath));
//		JavascriptExecutor executor = (JavascriptExecutor) driver;
//		executor.executeScript("arguments[0].click();", element);
//
	}

	public void clickSelectfromlist() throws Throwable {
		Wait.forSeconds(5);
		click.elementBy(keyselectfromlist);

	}

	public void enterSearchcontact() throws Throwable {
		Wait.forSeconds(5);
		type.data(keySearchcontact, PropertyReader.testDataOf("BL_ContactName").trim());
	}
	public void enterSearchcontactManageContacts()throws Throwable{
		Wait.waituntillElementVisibleMob(keySearchcontact,3);
		type.data(keySearchcontact, PropertyReader.testDataOf("BL_ContactName1"));
//		click.elementBy(KeyContactName);
		Touch.pressByCoordinates(987,1181,3);
		Wait.forSeconds(1);
	}

	public void verifyInlineErrormsgEditContactScreen()throws Throwable{
		Wait.forSeconds(2);
		verify.IfElementExists(FirstNameInlineErrorMsg);
		verify.IfElementExists(MobileInlineErrormsg);
	}

	public void enterMobileNumberStartsZero()throws Throwable{
		Wait.forSeconds(2);
		click.elementBy(MobileNumberTxtbox);
		type.data(MobileNumberTxtbox,"09");

	}
	public void enterEditContactDetails()throws Throwable{
		Wait.waituntillElementVisibleMob(FirstNameTxtbox,2);
		click.elementBy(FirstNameTxtbox);
		type.data(FirstNameTxtbox,"AutomationTest");
		Wait.forSeconds(1);
		click.elementBy(MobileNumberTxtbox);
		type.data(MobileNumberTxtbox,"9878988747");
		click.elementBy(keybtnSave);
	}
	public void enterSearchcontactLowBalance() throws Throwable {
		Wait.forSeconds(5);
		type.data(keySearchcontact, PropertyReader.testDataOf("BL_ContactNameLowBalance").trim());
	}

	public void enterMobilenumber() throws Throwable {
		click.elementBy(MobileNumberTxtbox);
		Wait.forSeconds(2);
		type.data(MobileNumberTxtbox,PropertyReader.testDataOf("BL_Phonenumber"));
	}

	public void enterLowBalancePhonenumber() throws Throwable {
		Wait.forSeconds(5);
		type.data(Keymobilenumber, PropertyReader.testDataOf("BL_PhonenumberLowBalance").trim());
	}

	public void enterInvalidPhonenumber() throws Throwable {
		Wait.forSeconds(5);
		type.data(Keymobilenumber, PropertyReader.testDataOf("BL_InvalidPhoneNumber").trim());
	}

	public void clickSearchresult() throws Throwable {
		click.elementBy(keySearchresult);
	}

	public void verifyOptions()throws Throwable{
		Wait.forSeconds(2);
		verify.IfElementExists(keyEdit);
		verify.IfElementExists(keyDelete);
	}

	public void clickPurchaseload() throws Throwable {
		Wait.forSeconds(2);
		click.elementBy(keypurchaseload);

	}

	public void EnterDetailsAddContactsScreen()throws Throwable{
		Wait.waituntillElementVisibleMob(FirstNameTxtbox,2);
		click.elementBy(FirstNameTxtbox);
		type.data(FirstNameTxtbox,"AutomationTester");
		Wait.forSeconds(2);
		click.elementBy(MobileNumberTxtbox);
		type.data(MobileNumberTxtbox,"9876567788");
		click.elementBy(AddContactBtn);
	}

	public void verifypurchasesuccessful() throws Throwable {
		if (verify.IfElementExistsboolean(keypurchasesuccessful)) {
			verify.IfElementExists(keypurchasesuccessful);
		} else {
			Wait.forSeconds(2);
			click.elementBy(OkButton);
			click.elementBy(keypurchaseload);
			Wait.forSeconds(3);
			String OTP = "111111";
			char[] ch = OTP.toCharArray();
//			greenPinPage.enter_Pin(String.valueOf(ch[0]), String.valueOf(ch[1]), String.valueOf(ch[2]),
//					String.valueOf(ch[3]), String.valueOf(ch[4]), String.valueOf(ch[5]));
			Wait.forSeconds(3000);
			verify.IfElementExists(keypurchasesuccessful);
		}
	}

	public void clickkeyaccountnumber() throws Throwable {
		click.elementBy(keyaccountnumber);
	}

	public void verifyInvalidPHNumber() throws Throwable {
		verify.elementTextMatching(keyerrormessage, PropertyReader.testDataOf("BL_InvalidErrorMessage").trim());

	}

	public void clickSubmit() throws Throwable {
		click.elementBy(Keysubmit);
		Wait.forSeconds(5);
	}

	public void clickNewpurchase() throws Throwable {
		click.elementBy(KeyNewpurchase);
		Wait.forSeconds(5);
	}

	public void verifySelectcontactisexist() throws Throwable {

		verify.elementIsPresent(keyselectcontact);

	}

	public void verifyKeyDashboardisexist() throws Throwable {

		verify.elementIsPresent(KeyDashboard);

	}

	public void clickBuyloadfromaccountedit() throws Throwable {
		click.elementBy(KeyBuyloadfromaccountedit);
		Wait.forSeconds(3);
	}

	public void clickBuyloadmobilenumberedit() throws Throwable {
		click.elementBy(KeyBuyloadmobilenumberedit);
		Wait.forSeconds(3);
	}

	public void clickBuyloadamountedit() throws Throwable {
		click.elementBy(KeyBuyloadamountedit);
		Wait.forSeconds(3);
	}

	public void clickBuyloadcancelpurchase() throws Throwable {
		click.elementBy(KeyBuyloadcancelpurchase);
		Wait.forSeconds(3);
	}


	public void entertheSearchname() throws Throwable {
		type.data(keySearchcontact, PropertyReader.testDataOf("BL_PhonenumberLowBalance"));
		Wait.forSeconds(3);
	}

	public void entertheSearchname1() throws Throwable {
		type.data(keySearchcontact, PropertyReader.testDataOf("BL_InvalidPhoneNumber"));
		Wait.forSeconds(3);
	}

	public void clickSearchicon() throws Throwable {
		Wait.forSeconds(3);
		click.elementBy(keybtnsearchicon);
		Wait.forSeconds(3);
	}

//	public void verifySearcresult() throws Throwable {
//		Wait.forSeconds(3);
//		verify.elementTextMatching(KeytxtSearchresult1, PropertyReader.testDataOf("BL_ContactNameLowBalance"));
//		verify.elementTextMatching(KeytxtSearchresult2, PropertyReader.testDataOf("BL_PhonenumberLowBalance"));
//	}
//
//	public void verifyTheSearchResultsInAddcontact() throws ApplicationException {
//		verify.elementTextMatching(KeytxtSearchresult1, PropertyReader.testDataOf("BL_DeleteContactName"));
//		verify.elementTextMatching(KeytxtSearchresult2, PropertyReader.testDataOf("BL_InvalidPhoneNumber"));
//	}
//
//	public void verifyTheSearchResultsInFavorites() throws ApplicationException {
//		verify.elementTextMatching(KeytxtSearchresult1, PropertyReader.testDataOf("BL_DeleteContactName1"));
//		verify.elementTextMatching(KeytxtSearchresult2, PropertyReader.testDataOf("BL_InvalidPhoneNumber"));
//	}
//
//	public void verifyTheSearchResultsInChangeContactName() throws ApplicationException {
//		verify.elementTextMatching(KeytxtSearchresult1, PropertyReader.testDataOf("BL_ChangeContactName"));
//		verify.elementTextMatching(KeytxtSearchresult2, PropertyReader.testDataOf("BL_InvalidPhoneNumber"));
//	}
//
//	public void verifyTheSearchResultsInChangeContactName_Favorite() throws ApplicationException {
//		verify.elementTextMatching(KeytxtSearchresult1, PropertyReader.testDataOf("BL_ChangeContactName1"));
//		verify.elementTextMatching(KeytxtSearchresult2, PropertyReader.testDataOf("BL_InvalidPhoneNumber"));
//	}

	public void clickAddcontact() throws Throwable {
		click.elementBy(keyAddcontact);
	}

//	public void enterContactNameandMobile() throws ApplicationException {
//		type.data(keyAddname, PropertyReader.testDataOf("BL_DeleteContactName"));
//		type.data(keyAddmobilenumber, PropertyReader.testDataOf("BL_InvalidPhoneNumber"));
//	}
//
//	public void enterBlankNameandMobile() throws ApplicationException {
//		type.data(keyAddname, PropertyReader.testDataOf("BL_BlankName"));
//		type.data(keyAddmobilenumber, PropertyReader.testDataOf("BL_PHNUmber"));
//	}
//
//	public void enterAlreadyaddedNameandMobile() throws ApplicationException {
//		type.data(keyAddname, PropertyReader.testDataOf("BL_AlreadyContactName"));
//		type.data(keyAddmobilenumber, PropertyReader.testDataOf("BL_AlreadyContactMobile"));
//	}
//
//	public void enterContactNameandMobile_favorites() throws ApplicationException {
//		type.data(keyAddname, PropertyReader.testDataOf("BL_DeleteContactName1"));
//		type.data(keyAddmobilenumber, PropertyReader.testDataOf("BL_InvalidPhoneNumber"));
//	}
//
//	public void changeContactNameandMobile() throws ApplicationException {
//		type.data(keyAddname, PropertyReader.testDataOf("BL_ChangeContactName"));
//		type.data(keyAddmobilenumber, PropertyReader.testDataOf("BL_InvalidPhoneNumber"));
//	}
//
//	public void changeContactNameandMobile_favorites() throws ApplicationException {
//		type.data(keyAddname, PropertyReader.testDataOf("BL_ChangeContactName1"));
//		type.data(keyAddmobilenumber, PropertyReader.testDataOf("BL_InvalidPhoneNumber"));
//	}
//
//	public void clickSave() throws Throwable {
//		click.elementBy(keybtnSave);
//	}

	public void clickEdit() throws Throwable {
		click.elementBy(keybtnEdit);
	}

	public void clickDelete() throws Throwable {
		click.elementBy(keybtnDelete);
		Wait.waituntillElementVisibleMob(keyDELETECONTACT,2);
		click.elementBy(keyDELETECONTACT);
	}

	public void verifyDeletepopup()throws Throwable{
		Wait.forSeconds(2);
		verify.elementIsPresent(KeyDeletePopUpMsg);
	}


//	public void clickSearchfirstresult() throws Throwable {
//		//driver.findElement(By.cssSelector("div > div > div.operations > div:nth-child(2) > a")).click();
//		driver.findElement(By.xpath("(//*[@class='ant-dropdown-trigger link ml-3'])[2]")).click();
//	}
//
//	public void verifySearcresultNoenrolledcontactsfound() throws Throwable {
//		Wait.forSeconds(3000);
//		verify.elementTextMatching(keybtnNoenrolledcontactsfound, PropertyReader.testDataOf("BL_NoContactFound").trim());
//
//	}
//
//	public void clickfavouritebutton() throws Throwable {
//		Wait.forSeconds(3000);
//		click.elementBy(keybtnfavourite);
//
//	}
//
//	public void verifyValidationinaddcontact() throws Throwable {
//		Wait.forSeconds(3);
//		verify.elementTextMatching(keynameisrequired, PropertyReader.testDataOf("BL_NameValidation").trim());
//		verify.elementTextMatching(keyMobileNumbershouldhave10digits, PropertyReader.testDataOf("BL_PhonenumberValidation").trim());
//		Wait.forSeconds(3);
//		//driver.findElement(By.cssSelector("div > div > div.ant-drawer-header > div > div > div.header-foreground > div > div.left.part > a > svg")).click();
//	}
//
//	public void verifyValidationinalreadyaddedcontact() throws Throwable {
//		Wait.forSeconds(3000);
//		verify.elementTextMatching(keyErrormessage, PropertyReader.testDataOf("BL_AlreadyaddedContactMessage").trim());
//	}
//
//	public void clickFAQ() throws Throwable {
//		click.elementBy(keyFAQ);
//	}
//
//	public void verifyFAQscreens() throws Throwable {
//		Wait.forSeconds(3000);
//		verify.elementIsPresent(keyCanIbuyloadforothers);
//		verify.elementIsPresent(keyWhatairtimedenominationsmayIload);
//	}
//
//	public void enterFAQsearch(String FAQsearch) throws ApplicationException {
//		type.data(keysearchFAQ, FAQsearch);
//	}
//
//	public void verifyFAQsearchresults() throws Throwable {
//		click.elementBy(keyCanIbuyloadforothers);
//		Wait.forSeconds(1000);
//		verify.elementTextContains(keysearchresult, "Yes, UnionBank Online allows you to buy load not only for yourself but for others too. Simply enter the mobile number of the intended recipient. You also have the option of saving this mobile number as one of your Favorites.");
//		//verify.elementIsPresent(keysearchresult);
//	}

//	public void verifySuccessfulscreenvalidations() throws Throwable {
//		Wait.forSeconds(3000);
//		if (Drivertype.equalsIgnoreCase("safari") && EnvironmentType.equalsIgnoreCase("mac")) {
//			verify.elementTextMatching_MacSafari(keyfromaccountnumber, PropertyReader.testDataOf("BL_Fromaccount").trim());
//			verify.elementTextMatching_MacSafari(keymobilenumbervalidate, PropertyReader.testDataOf("BL_Phonenumber").trim());
//			verify.elementTextMatching_MacSafari(keyamount, PropertyReader.testDataOf("BL_Successamt").trim());

//		} else {
//			verify.elementTextMatching(keyfromaccountnumber, PropertyReader.testDataOf("BL_Fromaccount").trim());
//			verify.elementTextMatching(keymobilenumbervalidate, PropertyReader.testDataOf("BL_Phonenumber").trim());
//			verify.elementTextMatching(keyamount, PropertyReader.testDataOf("BL_Successamt").trim());
//		}
//	}

//	public void verifyErrorForLowBalance() throws Throwable {
//		verify.elementIsPresent(keyerrormessage);
//	}
	public void ClickProviderGlobe() throws Throwable{
		Wait.forSeconds(2);
		click.elementBy(ProviderGlobe);

	}
	public void SelectDenomination() throws Throwable{
		Wait.forSeconds(4);
		click.elementBy(SelectDenomination);
		swipe.swipeVertical(2, 0.3, 0.8, 5);
	}
		public void ClickContactIcon() throws Throwable{
		Wait.forSeconds(3);
		click.elementBy(ContactIcon);
		type.data(ContactIcon,PropertyReader.testDataOf("BL_Phonenumber"));
		}

//		public void InvalidContactNumber()throws Throwable{
//		Wait.waituntillElementVisibleMob(ContactIcon,3);
//		click.elementBy(ContactIcon);
//		type.data(ContactIcon,PropertyReader.testDataOf("BL_Phonenumber1"));
//	}


	public void ClickPurchaseFromAccount() throws Throwable{
		Wait.waituntillElementVisibleMob(KeyTapToSelectAccount,2);
		click.elementBy(KeyTapToSelectAccount);
		Wait.waituntillElementVisibleMob(SelectFromAccount,2);
		click.elementBy(SelectFromAccount);
	}
	public void ClickBuyLoadBtn() throws Throwable{
		Wait.waituntillElementVisibleMob(BuyLoadBtn,2);
		click.elementBy(BuyLoadBtn);
	}
	public void VerifyPurchaseSuccessMessage() throws Throwable{
		Wait.forSeconds(3);
		verify.elementIsPresent(PurchaseSuccessMessage);
	}
	public void SelectProviderSmart() throws Throwable{
		Wait.forSeconds(2);
		click.elementBy(ProviderSmart);
	}
	public void SelectProviderTM() throws Throwable{
		Wait.waituntillElementVisibleMob(ProviderTM,2);
		click.elementBy(ProviderTM);
	}
	public void SelectProviderTNT() throws Throwable{
		Wait.waituntillElementVisibleMob(ProviderTNT,3);
		click.elementBy(ProviderTNT);
		}
	public void ClickEditOptionInDenomination() throws Throwable{
		Wait.waituntillElementVisibleMob(DenominationEdit,2);
		click.elementBy(DenominationEdit);
		Wait.waituntillElementVisibleMob(NewDenomination,3);
		click.elementBy(NewDenomination);
		Wait.forSeconds(1);
		click.elementBy(keyBtnNext);
	}
	public void ClickFromAccountEdit() throws Throwable{
		Wait.forSeconds(2);
		click.elementBy(FromAccountEdit);
	}
	public void ClickAccountUpdation() throws Throwable{
		Wait.forSeconds(2);
		click.elementBy(PurchaseFromAccount);
//		click.elementBy(AccountUpdateOption);
		click.elementBy(SelectNewFromAccount);
	}
}