package pages;

import actions.Swipe;
import actions.Wait;
import base.Keywords;
import helper.PropertyReader;

public class ELmsPage extends Keywords {


    private String SelectOrangeCard="onlineBanking.ELMS.SelectOrangeCard";
    private String SelectBlueCard="onlineBanking.ELMS.SelectBlueCard";
    private String AnnualMerchant="onlineBanking.ELMS.AnnualMerchant";
    private String AnnualFeeWaiver="onlineBanking.ELMS.AnnualFeeWaiver";
    private String Continue="onlineBanking.ELMS.Continue";
    private String FromAccount="onlineBanking.ELMS.FromAccount";
    private String ProductName="onlineBanking.ELMS.ProductName";
    private String RewardsPointsNeeded="onlineBanking.ELMS.RewardsPointsNeeded";
    private String BranchDropdown="onlineBanking.ELMS.SelectBranch";
    private String BranchName="onlineBanking.ELMS.BranchName";
    private String CashCredit="onlineBanking.ELMS.CashCredit";
    private String Petron="onlineBanking.ELMS.Petron";
    private String Rustans="onlineBanking.ELMS.Rustans";
    private String SMBranchName="onlineBanking.ELMS.BranchNameSMSTORE";
    private String Smstore="onlineBanking.ELMS.SMStore";
    private String BackButton="onlineBanking.ELMS.BackButton";
    private String SuccessInstruction="onlineBanking.ELMS.SuccessInstruction";
    private String RedeemOption = "onlineBanking.ELMS.RedeemOption";
    private String AmountTxtBox = "onlineBanking.ELMS.AmountTxtBox";
    private String ViewHistory="onlineBanking.ELMS.ViewHistory";
    private String IncrementInlineMessage = "onlineBanking.ELMS.IncrementInlineMessage";
    private String NextBtn = "onlineBanking.ELMS.NextBtn";
    private String RedeemButton = "onlineBanking.ELMS.ProceedWithRedeemButton";
    private String ReviewAndRedeemPage = "onlineBanking.ELMS.ReviewAndRedeemPage";
    private String SuccessMessage = "onlineBanking.ELMS.SuccessMessage";
    private String AccountDetailsPage="onlineBanking.ELMS.BackToAccountDetails";
    private String MinimumAmountErrorMessage = "onlineBanking.ELMS.MinimumAmountErrorMessage";
    private String EditBtn = "onlineBanking.ELMS.EditButton";
    private String CancelBtn = "onlineBanking.ELMS.CancelButton";
    private String CancelRedemptionBtn = "onlineBanking.ELMS.CancelRedemptionButton";


    public void SelectOrangeCard() throws Throwable {
        Wait.forSeconds(5);
       // click.elementBy(SelectCard,SelectCardData);
        click.elementBy(SelectOrangeCard);
    }
    public void SelectBlueCard()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(SelectBlueCard);
    }

    public void ClickRedeem() throws Throwable {
        Wait.forSeconds(3);
        verify.elementIsPresent(AccountDetailsPage);
        Wait.forSeconds(7);
        swipe.scrollDownToTextandClick("Redeem");

        //click.elementBy(RedeemOption);
    }
    public void clickRustans()throws Throwable{
        Wait.forSeconds(1);
        click.elementBy(Rustans);
    }
    public void clickBranchDropdown()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(BranchDropdown);
        click.elementBy(BranchName);
        click.elementBy(Continue);
    }
    public void clickSmStore()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(Smstore);
    }
    public void clickSMBranchName()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(BranchDropdown);
        click.elementBy(SMBranchName);
    }
     public void VerifyAnnualMerchant()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(AnnualMerchant);
     }
    public void verify_IncrementInlineMessage()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(IncrementInlineMessage);
    }
     public void verifyAnnualFeeWaiver()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(AnnualFeeWaiver);
     }
     public void  clickAnnualFee()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(AnnualMerchant);
        click.elementBy(CancelBtn);
        Wait.forSeconds(2);
        click.elementBy(BackButton);
     }
     public void clickAnnualFeeSupplementary()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(AnnualFeeWaiver);
        click.elementBy(Continue);
     }
     public void verifyHeaders()throws Throwable{
        Wait.forSeconds(1);
        verify.elementIsPresent(FromAccount);
        verify.elementIsPresent(ProductName);
        verify.elementIsPresent(RewardsPointsNeeded);

     }
    public void EnterAmount() throws Throwable {
        Wait.forSeconds(3);
        type.data(AmountTxtBox, PropertyReader.testDataOf("LMS_Amount"));
    }

    public void ClickNext() throws Throwable {
        Wait.forSeconds(2);
        click.elementBy(NextBtn);

    }
    public void SuccessInstruction()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(SuccessInstruction);
        click.elementBy(AccountDetailsPage);
    }
    public void clickViewHistory()throws Throwable{
        Wait.forSeconds(2);
        Swipe.swipe.swipeVertical(2,0.8,0.2,5);
        click.elementBy(ViewHistory);
    }

    public void VerifyNavigationToReviewPage() throws Throwable {
        Wait.forSeconds(3);
        verify.elementIsPresent(ReviewAndRedeemPage);
    }
    public void ClickRedeemBtn() throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(RedeemButton);

    }
    public void VerifySuccessMessage() throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(SuccessMessage);
    }
    public void ClickBackToAccountDetails() throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(AccountDetailsPage);
    }

    public void EnterInvalidAmount() throws Throwable{
        Wait.forSeconds(7);
        type.data(AmountTxtBox, PropertyReader.testDataOf("LMS_InvalidAmount"));

    }
    public void VerifyErrorMessage() throws Throwable{
        Wait.forSeconds(7);
        verify.elementIsPresent(MinimumAmountErrorMessage);

    }
    public void ClickEdit() throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(EditBtn);
    }
    public void EnterNewAmount() throws Throwable{
        Wait.forSeconds(2);
        type.data(AmountTxtBox, PropertyReader.testDataOf("LMS_NewAmount"));
    }
    public void ClickCancel() throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(CancelBtn);
    }
    public void ClickCancelRedemption() throws Throwable{
        Wait.forSeconds(3);
        click.elementBy(CancelRedemptionBtn);
    }

}


