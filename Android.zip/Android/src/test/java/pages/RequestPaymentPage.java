package pages;

import actions.Swipe;
import actions.Touch;
import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import helper.PropertyReader;
import helper.Tools;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import runners.ConvergentTestRunner;
import xpath.Matching;

import java.util.List;

public class RequestPaymentPage extends Keywords {

    String KeyPageTitle = "convergent.request_payment.labelPageTitle";
    String KeySendRequestPageTitle = "convergent.sendrequest.LabelSendRequestPageTitle";
    String KeyRequestPaymentPageTitle = "convergent.request_payment.labelRequestPaymentPageTitle";
    String KeySelectAccountPageTitle = "convergent.request_payment_depositto.labelselectaccountpageTitle";
    String KeyAddParticipantsPageTitle = "convergent.request_payment_addparticipant.labelAddParticipantsPageTitle";
    String KeyAddContactPageTitle = "convergent.request_payment_addparticipant.labelAddContactPageTitle";
    String KeyRequestTheAmountOfPageTitle = "convergent.requestTheAmountOf.RequestTheAmountOflabel";
    String KeyNext = "convergent.request_payment.btnNext";
    String KeyEnterMessage = "convergent.request_payment_message.textbox";
    String KeyErrorMessage = "convergent.request_payment.labelTotalError";
    String KeyAmountTextBox = "convergent.request_payment.textboxRequestAmountOf";
    String KeyAmountList = "convergent.request_payment.labelAmount";
    String KeySave = "convergent.request_payment_amount.btnSave";
    String KeySaveBtn ="convergent.request_payment_amount.SaveBtn";
    String KeySave1 = "convergent.request_payment_amount.SaveBtn";
    String KeySaveBtn1 = "convergent.request_payment_amount.btnSave";
    String KeySaveBtnbottom="convergent.request_payment_amount.btnSavebottom";
    String KeySelectAccount = "convergent.request_payment_depositto.selectaccount";
    String KeyTargetAccountColor = "convergent.request_payment_depositto.targetaccountcolor";
    String KeyBackBtn = "convergent.request_payment.btnClose";
    String KeyRequestFromTxtBox = "convergent.request_payment.textboxRequestFrom";
    String KeyRequestFromSecondTxtBox="convergent.request_payment.textboxsecondRequestFrom";
    String KeyMessageTextBox = "convergent.request_payment.textboxMessage";
    String KeyDepositToTextBox = "convergent.request_payment.textboxDepositTo";
    String KeyFieldRequestAmountOfTextBox = "convergent.request_payment_amount.textboxAmount";
    String KeyRequestAmountErrorMessage = "convergent.request_payment.labelRequestAmountErrorMessage";
    String KeyRequestAmountOfTextBox = "convergent.request_payment.textboxRequestAmountOf";
    String keyParticipantsTextBox = "convergent.request_payment.textboxParticipantField";
    String KeyAddToMyContacts = "convergent.request_payment.AddToMyContactsBtn";
    String keyAddNewContactName = "convergent.participantNewContact.textboxName";
    String KeyAddParticipantsNewlyAddedContactName = "convergent.request_payment.addparticipant_NewcontactName";
    String keyAddNewContactMobileNumber = "convergent.participantNewContact.textMobileNumber";
    String getKeyAddNewContactMobileNumberErrorMessage = "convergent.participantNewContact.labelInvalidMobileNumber";
    String KeyUnEvenlyBtn = "convergent.request_payment_amount.btnUnEvenly";
    String KeyRequestThePaymentOfSaveBtn = "convergent.request_payment_amount.btnSave";
    String KeyRequestThePaymentOfSaveBtn1 = "convergent.request_payment_amount.SaveBtn";
    String KeyUnEvenlylabel = "convergent.request_payment.labelUnEvenly";
    String KeyEachBtn = "convergent.request_payment_amount.btnEach";
    String KeyEachlabel = "convergent.request_payment.labelEach";
    String KeyEvenlylabel = "convergent.request_payment.labelEvenly";
    String KeyEvenlyBtn = "convergent.request_payment_amount.btnEvenly";
    String KeySplitOptionDescription = "convergent.request_payment.descriptionSplitOption";
    String KeySplitOptionDescriptionEvenly="convergent.request_payment.descriptionSplitOptionEvenly";
    String KeySplitOptionDescriptionUnEvenly="convergent.request_payment.descriptionSplitOptionUnEvenly";
    String KeySplitOptionDescriptionEach="convergent.request_payment.descriptionSplitOptionEach";
    String KeyEnterContactName = "convergent.request_payment_addparticipant.searchtextbox";
    String KeyCheckBox = "convergent.request_payment_addparticipant.checkboxFirstContact";
    String KeySecondContactCheckbox = "convergent.request_payment_addparticipant.checkboxSecondContact";
    String KeyAddBtn = "convergent.request_payment_addparticipant.btnAddContact";
    String KeyFavoriteSwitch = "convergent.participantNewContact.FavoutiteswitchIsDisabled";
    String KeySplitOptionEvenly = "convergent.request_payment_amount.btnEvenly";
    String KeySplitOptionUnEvenly = "convergent.request_payment_amount.btnUnEvenly";
    String KeySplitOptionEach = "convergent.request_payment_amount.btnEach";
    String KeyClose = "convergent.request_payment_amount.btnClose";
    String KeyDescription = "convergent.request_payment_amount.labelDescription";
    String KeyError = "convergent.request_payment_amount.labelAmountExceedsLimit";
    String KeyRequestAmountInvalidAmount = "convergent.request_payment_amount.labelInvalidAmount";
    String KeyAddNewContactSave = "convergent.participantNewContact.btnsave";
    String KeyCancelBtn = "convergent.review.btnCancelPayment";
    String KeyReviewAndRequestCancelYes = "convergent.reviewAndRequest_btnYes";
    String KeyReviewAndRequestCancelNo = "convergent.reviewAndRequest_btnNo";
    String KeyEditLink = "convergent.request_payment_reviewandrequest.Editbtn";
    String KeyDoneBtn = "convergent.request_payment_Nextbtn";
    String KeySuccessMessage = "convergent.request_payment_SuccessMsg";
    String KeySize ="convergent.request_payment.labelSize";
    String KeyRequestPaymentSplitedAmount1 = "convergent.request_payment.labelSplitedAmount1";
    String KeyRequestPaymentSplitedAmount2 = "convergent.request_payment.labelSplitedAmount2";
    String KeyRequesttheamountofUnevenlyAmounttextbox = "convergent.request_payment.RequesttheamountofUnevenlyAmounttextbox";
    String KeyRequesttheamountofUnevenlySaveBtn = "convergent.request_payment.RequesttheamountofUnevenlySaveBtn";
    String KeyReviewAndRequestAmount1 = "convergent.review_and_request.RequestFromAmount1";
    String KeyReviewAndRequestAmount2 = "convergent.review_and_request.RequestFromAmount2";
    String KeyReviewAndRequestAmount3 = "convergent.review_and_request.RequestFromAmount3";
    String KeyReviewAndRequestAmount4 = "convergent.review_and_request.RequestFromAmount4";
    String KeyUnevenlyTotalisnotSameAsRequested = "convergent.request_payment.labelUnevenlyTotalisnotSameAsRequired";
    String KeyReviewandRequestEditBtn="convergent.review_and_request.RequestFromEditBtn";
    String KeyDone = "convergent.request_payment.btnDone";
    String KeyReviewAndRequestPageTitle = "convergent.reviewAndRequest_labelreviewAndRequestPageTitle";
    String KeyAddParticipantClose = "convergent.request_payment.addparticipant.btnclose";
    String KeyBuyLoad = "convergent.home.btnBuyLoad";
    String KeyManageContacts = "convergent.BuyLaod.btnManageContacts";
    String KeyManageContactsSearchbtn = "convergent.ManageContacts.btnSearch";
    String KeyManageContactsSearchtextbox = "convergent.ManageContacts.Searchtextbox";
    String KeyManageContactsDotbtn = "convergent.ManageContacts.btndot";
    String KeyManageContactDeleteBtn = "convergent.ManageContacts.btnDelete";
    String KeyManageContactDeleteContactbtn = "convergent.DeleteContact.btnDeleteContact";
    String KeyDeleteContactSuccessOkbtn = "convergent.Success.btnOk";
    String KeyFirstRequestFormAmountEdit = "convergent.request_payment.FirstAmountRequestForm";
    String KeySecondRequestFormAmountEdit = "convergent.request_payment.SecondAmountRequestForm";
    String KeyRequestAmountOfAmountTextboxEdit = "convergent.requestAmountOf.txtAmountEdit";
    String KeyReviewAndRequestbtnRequest = "convergent.requestandRequest.btnRequest";
    String KeyUnevenlyRequestFromFirstAmount = "convergent.request_payment.UnevenlyRequestFromFirst";
    String KeyUnevenlyRequestFromSecondAmount = "convergent.request_payment.UnevenlyRequestFromSecond";
    String KeyCashDepositBackBtn="convergent.CashDeposit.btnclose";
    String keyAddNewContactNamesearchresult = "convergent.participantNewContact.textboxNamesearch";
    String KeySplitbills = "convergent.request.linkSpliBills";
    String KeyFieldSplitbillAmountOfTextBox="convergent.splitbills.txtportion";
    String KeySuccessMessage2 = "convergent.request_payment_SuccessMsg2";
    String keyYourPortion = "convergent.splitbills.yourPortion";
    String keyRequestPayment="convergent.request_payment.RequestPayment";
    String keySplitbill="convergent.request_payment.SplitBill";
    String keyDelete="convergent.request_payment.Delete";
    String keyHangOn="convergent.request_payment.HangOn";
    String keyPopupmsg="convergent.request_payment.Popupmsg";
    String keyCancel="convergent.request_payment.CANCEL";
    String keyYes="convergent.request_payment.YES";
    String keyGoToDashboard="convergent.request_payment.GoToDashboard";
    String keyNewTransaction="convergent.request_payment.NewTransaction";
    String keyRequestFrom="convergent.request_payment.RequestFrom";
    String keyTotalAmountRequested="convergent.request_payment.TotalAmountRequested";
    String keyMessage="convergent.request_payment.Message";
    String keyDeposit="convergent.request_payment.DepositTo";
    String keyEdit="convergent.request_payment.EDIT";

    ConvergentTestRunner Devicename=new ConvergentTestRunner();
    private int i=1;
    private String amountEleList;
    private String itext;
    private String Name;
    public static String participantname;
    public static String participantnumber;


    public void verifyPageTitle(String expectedTitle) throws ApplicationException {
        Wait.forSeconds(2);
//        Wait.waituntillElementVisibleMob(KeyPageTitle,2);
        verify.elementTextMatching(KeyPageTitle, expectedTitle);
//        verify.elementIsPresent(KeyPageTitle);
    }
    public void verifyHeaderOptions()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(keyRequestFrom);
        verify.elementIsPresent(keyTotalAmountRequested);
        verify.elementIsPresent(keyMessage);
        verify.elementIsPresent(keyDeposit);
        verify.elementIsPresent(keyEdit);
    }
    public void clickCrosssymbol()throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(keyDelete);
    }
    public void verifyPopupmsg()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(keyHangOn);
        verify.elementIsPresent(keyPopupmsg);
    }
    public void verifyCOancelptions()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(keyCancel);
        verify.elementIsPresent(keyYes);
    }
    public void verifyDashboardOptions()throws Throwable{
        Wait.forSeconds(2);
        verify.elementIsPresent(keyNewTransaction);
        verify.elementIsPresent(keyGoToDashboard);
    }
    public void verifyPageTitleIOS(String expectedTitle) throws ApplicationException {
        verify.elementTextMatching(KeyPageTitle, expectedTitle);
    }

    public void verifyRequestPaymentPageTitleIOS(String expectedTitle) throws ApplicationException {
        verify.elementTextMatching(KeyRequestPaymentPageTitle, expectedTitle);
    }

    public void verifySendRequestPageTitleIOS(String expectedTitle) throws ApplicationException {
        verify.elementTextMatching(KeySendRequestPageTitle, expectedTitle);
    }

    public void verifyReviewAndRequestPageTitleIOS(String expectedTitle) throws ApplicationException {
        verify.elementTextMatching(KeyReviewAndRequestPageTitle, expectedTitle);
    }

    public void verifySelectAccountPageTitleIOS(String expectedTitle) throws ApplicationException {
        verify.elementTextMatching(KeySelectAccountPageTitle, expectedTitle);
    }

    public void verifyAddParticipantsPageTitleIOS(String expectedTitle) throws ApplicationException {
        verify.elementTextMatching(KeyAddParticipantsPageTitle, expectedTitle);
    }

    public void verifyAddContactPageTitleIOS(String expectedTitle) throws ApplicationException {
        verify.elementTextMatching(KeyAddContactPageTitle, expectedTitle);
    }

    public void verifyRequestTheAmountOfPageTitleIOS(String expectedTitle) throws ApplicationException {
        verify.elementTextMatching(KeyRequestTheAmountOfPageTitle, expectedTitle);
    }

    public void verifySuccessMessage(String expectedTitle) throws ApplicationException {
        try {
            verify.elementTextMatching(KeySuccessMessage, expectedTitle);
        }
        catch(Exception e){
            verify.elementTextMatching(KeySuccessMessage2, expectedTitle);
        }
    }

    public void clickBackBtn() throws ApplicationException {
        click.elementBy(KeyBackBtn);
    }

    public void clickCashDepositBackBtnIOS() throws ApplicationException {
        click.elementBy(KeyCashDepositBackBtn);
    }

    public void clickBackBtnIOS() throws ApplicationException {
        click.elementBy(KeyBackBtn);
    }

    public void clickEditLink() throws ApplicationException {
        click.elementBy(KeyEditLink);
    }

    public void clickCancelBtn() throws ApplicationException {
        click.elementBy(KeyCancelBtn);
    }

    public void clickCancelYesBtnIOS() throws ApplicationException {
        click.elementBy(KeyReviewAndRequestCancelYes);
    }

    public void clickSave() throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeySave,4);
        click.elementBy(KeySave);
    }

    public void clickSaveBtn() throws ApplicationException {
        click.elementBy(KeySaveBtn);
    }
    public void clickSaveBtnbottom() throws ApplicationException {
        click.elementBy(KeySaveBtnbottom);
    }

    public void verifyIfNextButtonDisabled() throws ApplicationException {
        verify.elementIsDisabled(KeyNext);
        verify.elementIsPresent(KeyNext);
    }

    public void verifyIfNextButtonIsPresent() throws ApplicationException {
        verify.elementIsPresent(KeyNext);
    }

    public void verifyAmountError(String errorMessage) throws ApplicationException {
        verify.elementTextMatching(KeyErrorMessage, errorMessage);
    }

    public void clickNext() throws ApplicationException {
        click.elementBy(KeyNext);
    }

    public void clickMessage() throws Throwable {
        //click.elementBy(By.xpath("//android.widget.FrameLayout[@content-desc='payment_request_form_message']"));
        click.elementBy(KeyMessageTextBox);
    }

    public void clickMessageIOS() throws Throwable {
        click.elementBy(KeyMessageTextBox);
    }

    public void clickAmount() throws Throwable {
        click.elementBy(KeyAmountTextBox);
    }

    public void clickRequestFrom() throws Throwable {
        //click.elementBy(By.xpath("//android.widget.FrameLayout[@content-desc='payment_request_form_participants']"));
        click.elementBy(KeyRequestFromTxtBox);
    }

    public void clickRequestFromsecondIOS() throws Throwable {
        //click.elementBy(By.xpath("//android.widget.FrameLayout[@content-desc='payment_request_form_participants']"));
        click.elementBy(KeyRequestFromSecondTxtBox);
    }

    public void clickDepositTo() throws Throwable {
        //click.elementBy(By.xpath("//android.widget.FrameLayout[@content-desc='payment_request_form_deposit_to']"));
        swipe.swipeVertical(2, 0.7, 0.5,1);
        click.elementBy(KeyDepositToTextBox);
        //swipe.scrollDownToTextandClick("payment_request_form_deposit_to");
        Wait.forSeconds(5);
        selectAccountFromDepositTo();
    }

    public void clickDepositToViewTargetAccount() throws Throwable {
        click.elementBy(KeyDepositToTextBox);
    }

    public void verifyTargetAccountColor() throws Throwable {
        verify.elementIsPresent(KeyTargetAccountColor);
    }

    public void verifyTargetAccountColorIOS() throws Throwable {
        verify.elementIsPresent(KeySelectAccount);
    }

    public void checkIfParticipentAmountIsClickable(int numberofLineItems) throws ApplicationException {

        List<MobileElement> amountEleList = (List<MobileElement>) get.elementBy(KeyAmountList);
        for (int i = 1; i <= numberofLineItems; i++) {
            Assert.assertEquals("false", amountEleList.get(i).getAttribute("clickable"));
        }
    }



    public void checkIfParticipentAmountIsClickableIOS(int numberofLineItems) throws ApplicationException {
        /*List<MobileElement> amountEleList = (List<MobileElement>) get.elementBy(KeyFirstRequestFormAmountEdit);
        for (int i = 1; i <= numberofLineItems; i++) {
            Assert.assertEquals("false", amountEleList.get(i).getAttribute("clickable"));
        }
        Assert.assertEquals("false", el1.isEnabled());
        */
        // MobileElement isEditable = (MobileElement) verify.elementIsDisabled(KeyFirstRequestFormAmountEdit);

        MobileElement el1 = (MobileElement) driver.findElementByXPath("(//XCUIElementTypeStaticText[@name=\"PHP 2.50\"])[1]");
        Assert.assertEquals("true", el1.getAttribute("enabled"));

        // MobileElement element = (MobileElement) driver.findElementByAccessibilityId("PHP 2.50");
        // boolean isEnabled = element.isEnabled();
        // Assert.assertEquals("true", isEnabled);

    }

    public void clickRequestFromAfterSelectAmount() throws ApplicationException {
        click.elementBy(xpathOf.textView(Matching.youDecide(( "Tap to add participant*" ))));
        //click.elementBy(ResourceBase.androidTextViewXPATH("Tap to add participant*"));

    }

    public void checkIfAmountEvenlySplit(String amount, String splitAmount, int numberofLineItems) throws ApplicationException {
        List<MobileElement> amountEleList = (List<MobileElement>) get.elementBy(KeyAmountList);
        Assert.assertEquals(numberofLineItems, amountEleList.size() - 2);
        Assert.assertEquals(amount, amountEleList.get(0).getText());
        Assert.assertEquals(amount.replace("PHP", "").trim(), amountEleList.get(amountEleList.size() - 1).getText());

        for (int i = 1; i <= numberofLineItems; i++) {
            Assert.assertEquals(splitAmount, amountEleList.get(i).getText());
            Assert.assertEquals("false", amountEleList.get(i).getAttribute("clickable"));
        }

    }

    public void clickRequestAmountOf() throws ApplicationException {
        //click.elementBy(By.xpath("//android.widget.FrameLayout[@content-desc='payment_request_form_amount']"));
        click.elementBy(KeyRequestAmountOfTextBox);

    }

    public void clickRequestAmountOfIOS() throws ApplicationException {
        //click.elementBy(By.xpath("//android.widget.FrameLayout[@content-desc='payment_request_form_amount']"));
        click.elementBy(KeyRequestAmountOfTextBox);
    }

    public void enterAmount(String amount) throws ApplicationException {
        Wait.forSeconds(5);
        if(Devicename.currentdevicename.equalsIgnoreCase("Samsung")) {
            click.elementBy(KeyFieldRequestAmountOfTextBox);
            type.data1(KeyFieldRequestAmountOfTextBox, amount);
        }
        else if(Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")) {
            click.elementBy(KeyFieldRequestAmountOfTextBox);
           type.data1(KeyFieldRequestAmountOfTextBox, amount);
        }
        Wait.forSeconds(3);
    }

    public void enterAmountIOS(String amount) throws ApplicationException {
        type.data(KeyFieldRequestAmountOfTextBox, amount);
    }

    public void enterRequestFromAmount(String amount) throws ApplicationException {
        get.elementBy(KeyAmountList).clear();
        type.data1(KeyAmountList, amount);
        clickSave();
    }

    public void enterRequestFromAmountIOS(String amount) throws ApplicationException {
        get.elementBy(KeyRequestAmountOfAmountTextboxEdit).clear();
        type.data1(KeyRequestAmountOfAmountTextboxEdit, amount);
        clickSave();
    }

    public void clearAmount() throws ApplicationException {
        get.elementBy(KeyFieldRequestAmountOfTextBox).clear();
    }

    public void verifyRequestAmountErrorMessage(String errorMessage) throws ApplicationException {
        verify.elementTextMatching(KeyRequestAmountErrorMessage, errorMessage);
    }

    public void verifyRequestAmountErrorMessageIOS(String errorMessage) throws ApplicationException {
        verify.elementTextMatching(KeyRequestAmountErrorMessage, errorMessage);
    }

    public void clickparticipants() throws ApplicationException {
        click.elementBy(keyParticipantsTextBox);
    }

    public void clickAddToMyContacts() throws ApplicationException {
        click.elementBy(KeyAddToMyContacts);
    }

    public void enteraddtonewcontactName(String name) throws ApplicationException {
        click.elementBy(keyAddNewContactName);
        type.data(keyAddNewContactName, Tools.RANDOMTEXT("String",10));
    }

    public void enteraddtonewMobileNumber(String mobilenumber) throws ApplicationException {
        click.elementBy(keyAddNewContactMobileNumber);
        type.data1(keyAddNewContactMobileNumber, mobilenumber);
    }

    public void verifyaddtocontactMobilenumberErrorMessage(String ErrorMessage) throws ApplicationException {
        verify.elementTextMatching(getKeyAddNewContactMobileNumberErrorMessage, ErrorMessage);
    }

    public void clickUnEvenlyBtn() throws ApplicationException {
        click.elementBy(KeyUnEvenlyBtn);
    }

    public void clickRequestTheAmountOfSaveBtn() throws ApplicationException {
        click.elementBy(KeyRequestThePaymentOfSaveBtn);
    }

    public void verifyUnEvenlylabel(String arg0) throws ApplicationException {
        verify.elementTextMatching(KeyUnEvenlylabel, arg0);
    }

    public void clickEachBtn() throws ApplicationException {
        click.elementBy(KeyEachBtn);
    }

    public void verifyEachlabel(String arg0) throws ApplicationException {
        verify.elementTextMatching(KeyEachlabel, arg0);
    }

    public void clickEvenlyBtn() throws ApplicationException {
        Wait.waituntillElementVisibleMob(KeyEvenlyBtn,3);
        click.elementBy(KeyEvenlyBtn);
    }

    public void verifyEvenlylabel(String arg0) throws ApplicationException {
        verify.elementTextMatching(KeyEvenlylabel, arg0);
    }

    public void verifyDescriptionForEvenlySplit(String arg0) throws ApplicationException {
        verify.elementTextMatching(KeySplitOptionDescription, arg0);
    }

    public void verifyDescriptionForEvenlySplitIOS(String arg0) throws ApplicationException {
        verify.elementTextMatching(KeySplitOptionDescriptionEvenly, arg0);
    }

    public void verifyDescriptionForUnEvenlySplit(String arg0) throws ApplicationException {
        verify.elementTextMatching(KeySplitOptionDescription, arg0);
    }

    public void verifyDescriptionForUnEvenlySplitIOS(String arg0) throws ApplicationException {
        verify.elementTextMatching(KeySplitOptionDescriptionUnEvenly, arg0);
    }

    public void verifyDescriptionForEachSplit(String arg0) throws ApplicationException {
        verify.elementTextMatching(KeySplitOptionDescription, arg0);
    }

    public void verifyDescriptionForEachSplitIOS(String arg0) throws ApplicationException {
        verify.elementTextMatching(KeySplitOptionDescriptionEach, arg0);
    }

    public void enterContactName(String name) throws Throwable {
        type.data(KeyEnterContactName, name);
    }

    public void clickCheckBox() throws Throwable {
        Wait.waituntillElementVisibleMob(KeyCheckBox,3);
        click.elementBy(KeyCheckBox);
    }

    public void clickAddButton() throws Throwable {
       click.elementBy(KeyAddBtn);
    }

    public void selectParticipant() throws Throwable {
        clickCheckBox();
        clickAddButton();
    }

    public void selectFirstParticipantIOS() throws Throwable {
        clickFirstContactCheckBoxIOS();
        clickAddButton();
    }

    public void selectSecondParticipantIOS() throws Throwable {
        clickSecondContactCheckBoxIOS();
        clickAddButton();
    }

    public void clickFirstContactCheckBoxIOS() throws Throwable {
        Wait.forSeconds(5);
        //driver.findElementByAccessibilityId("queen").click();
        //click.elementBy(KeySecondContactCheckbox);
        driver.findElementByXPath("//XCUIElementTypeTable/XCUIElementTypeCell").click();
    }

    public void clickSecondContactCheckBoxIOS() throws Throwable {
        Wait.forSeconds(5);
        // click.elementBy(KeySecondContactCheckbox);
        driver.findElementByXPath("//XCUIElementTypeTable/XCUIElementTypeCell").click();
    }

    public void enterMessage(String msg) throws Throwable {
        if(Devicename.currentdevicename.equalsIgnoreCase("Samsung"))
        {
            type.data(KeyEnterMessage, msg);
        }
        else if(Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30"))
        {
            type.data(KeyEnterMessage, msg);
        }
    }

    public void enterMessageIOS(String msg) throws Throwable {
        type.data(KeyEnterMessage, msg);
    }

    public void enterMessageDetails(String msg) throws Throwable {
        Wait.forSeconds(5);
        swipe.swipeVertical(2, 0.8, 0.2,5);
        clickMessage();
        enterMessage(msg);
        clickSave();
    }

    public void clickDoneBtn() throws Throwable {
        click.elementBy(KeyDoneBtn);
    }

    public void selectAccountFromDepositTo() throws Throwable {
        click.elementBy(KeySelectAccount);

    }

    public void selectSplitOptionAsEvenly() throws ApplicationException {
        click.elementBy(KeySplitOptionEvenly);

    }

    public void selectSplitOptionsAsUnEvenly() throws ApplicationException {
        click.elementBy(KeySplitOptionUnEvenly);
    }

    public void selectSplitOptionsAsEach() throws ApplicationException {
        click.elementBy(KeySplitOptionEach);
    }


    public void clickClose() throws ApplicationException {
        click.elementBy(KeyClose);
    }

    public void verifyDescription(String expectedDescription) throws ApplicationException {
        verify.elementTextMatching(KeyDescription, expectedDescription);
    }

    public void verifyAddNewContactSaveButtonIsDisabled() throws ApplicationException {
        verify.elementIsDisabled(KeyAddNewContactSave);
    }

    public void verifyAddNewContactSaveButtonIsEnabled() throws ApplicationException {
        verify.elementIsEnabled(KeyAddNewContactSave);
    }

    public void clickAddNewContactSaveBtn() throws ApplicationException {
        click.elementBy(KeyAddNewContactSave);
    }

    public void verifyError(String expectedError) throws ApplicationException {
        verify.elementTextMatching(KeyError, expectedError);
    }

    public void verifyInvalidAmount(String expectedError) throws ApplicationException {
        verify.elementTextMatching(KeyRequestAmountInvalidAmount, expectedError);
    }

    public void verifyErrorIOS(String expectedError) throws ApplicationException {
        verify.elementTextMatching(KeyRequestAmountInvalidAmount, expectedError);
    }

    public void verifyAmount(String amount) throws ApplicationException {
        verify.elementTextMatching(KeyAmountTextBox, amount);
    }

    public void verifySaveButtonIsDisabled() throws ApplicationException {
        verify.elementIsDisabled(KeySaveBtn);
    }

    public void verifySaveButtonIsDisabledIOS() throws ApplicationException {
        verify.elementIsDisabled(KeyRequestThePaymentOfSaveBtn);
    }


    public void verifyrequestpaymentsplitedamount (String amount1, String amount2) throws ApplicationException {
        verify.elementTextMatching(KeyRequestPaymentSplitedAmount1,amount1);
        verify.elementTextMatching(KeyRequestPaymentSplitedAmount2,amount2);
    }

    public void enterRequesttheamountofUnevenlyAmount1(String amount1) throws ApplicationException
    {
        Wait.forSeconds(5);
        if((Devicename.currentdevicename.equalsIgnoreCase("Samsung")))
        {
            click.elementBy(KeyRequesttheamountofUnevenlyAmounttextbox);
            type.data1(KeyRequesttheamountofUnevenlyAmounttextbox,amount1);
        }
        else if((Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")))
        {
            click.elementBy(KeyRequesttheamountofUnevenlyAmounttextbox);
            type.data1(KeyRequesttheamountofUnevenlyAmounttextbox,amount1);
        }

        Wait.forSeconds(5);
        click.elementBy(KeyRequesttheamountofUnevenlySaveBtn);
    }

    public void enterRequesttheamountofUnevenlyAmount2(String amount2) throws ApplicationException {
        Wait.forSeconds(6);
        if((Devicename.currentdevicename.equalsIgnoreCase("Samsung")))
        {
            click.elementBy(KeyRequesttheamountofUnevenlyAmounttextbox);
            type.data1(KeyRequesttheamountofUnevenlyAmounttextbox,amount2);
        }
        else if((Devicename.currentdevicename.equalsIgnoreCase("HUAWEIMATE30")))
        {
            click.elementBy(KeyRequesttheamountofUnevenlyAmounttextbox);
            type.data1(KeyRequesttheamountofUnevenlyAmounttextbox,amount2);
        }

        Wait.waituntillElementVisibleMob(KeyRequesttheamountofUnevenlySaveBtn,4);
        click.elementBy(KeyRequesttheamountofUnevenlySaveBtn);
    }

    public void verifyReviewAndRequestAmount1(String amount1)throws ApplicationException{

        try {
            verify.elementTextMatching(KeyReviewAndRequestAmount1, amount1);
        }
        catch(Exception e) {
            verify.elementTextMatching(KeyReviewAndRequestAmount1,amount1);
        }

    }

    public void verifyReviewAndRequestAmount2(String amount2)throws ApplicationException{
        verify.elementTextMatching(KeyReviewAndRequestAmount2,amount2);
    }

    public void verifyReviewAndRequestAmount3(String amount1)throws ApplicationException{
        verify.elementTextMatching(KeyReviewAndRequestAmount3,amount1);
    }

    public void verifyReviewAndRequestAmount4(String amount2)throws ApplicationException{
        verify.elementTextMatching(KeyReviewAndRequestAmount4,amount2);
    }

    public void verifyRequestPaymentUnevenlyTotalnotSameAsRequestedErrorMessage(String errorMessage)throws ApplicationException {
        verify.elementTextMatching(KeyUnevenlyTotalisnotSameAsRequested, errorMessage);
    }

    public void isDisabledRequestPaymentNextBtn()throws ApplicationException{
        verify.elementIsDisabled(KeyNext);
    }

    public void clickReviewandRequestEditBtn()throws ApplicationException{
        click.elementBy(KeyReviewandRequestEditBtn);
    }

    public void clickDone() throws ApplicationException {
        click.elementBy(KeyDone);
    }

    public void verifyIfFavoriteButtonIsDisabled() throws ApplicationException {
        verify.elementIsPresent(KeyFavoriteSwitch);
    }

    public void clickRequestBtn() throws Throwable {
        click.elementBy(KeyAddNewContactSave);
    }

    public void clickRequestandRequestRequestBtn() throws Throwable {
        click.elementBy(KeyReviewAndRequestbtnRequest);
    }

    public void verifyMessageLength() throws Throwable {

        itext = get.elementBy(KeyEnterMessage).getText();
        if (itext.length() == 150) {
            verify.elementIsPresent(KeyEnterMessage);
        } else {
            new ApplicationException("input message is not more than 150 characters");
        }
    }

    public void verifyMessageLengthIOS() throws Throwable {

        itext = get.elementBy(KeyEnterMessage).getText();
        if (itext.length() == 150) {
            verify.elementIsPresent(KeyEnterMessage);
        } else {
            new ApplicationException("input message is not more than 150 characters");
        }
    }

    public void verifyAddContactName() throws Throwable {
        Name = PropertyReader.testDataOf("Name");
        itext = get.elementBy(keyAddNewContactNamesearchresult).getText();
        if (itext.length() == Name.length()) {
            verify.elementIsPresent(keyAddNewContactNamesearchresult);
        } else {
            new ApplicationException("newly added contact not found");
        }
    }

    public void verifyAddContactNameIOS() throws Throwable {
        Name = PropertyReader.testDataOf("Name");
        itext = get.elementBy(KeyAddParticipantsNewlyAddedContactName).getText();
        if (itext.length() == Name.length()) {
            verify.elementIsPresent(KeyAddParticipantsNewlyAddedContactName);
        } else {
            new ApplicationException("newly added contact not found");
        }
    }


    public void clickAddParticipantCloseBtn() throws Throwable {
        click.elementBy(KeyAddParticipantClose);
    }

    public void clickBuyLoadBtn() throws Throwable {
        click.elementBy(KeyBuyLoad);
    }

    public void clickManageContactsBtn() throws Throwable {
        click.elementBy(KeyManageContacts);
    }

    public void clickManageContactSearchBtn() throws Throwable {
        click.elementBy(KeyManageContactsSearchbtn);
    }

    public void enterManageContactSearchtextbox() throws Throwable {
        type.data(KeyManageContactsSearchtextbox, (PropertyReader.testDataOf("Name")));
    }

    public void clickManageContactdotBtn() throws Throwable {
        click.elementBy(KeyManageContactsDotbtn);
        click.elementBy(KeyManageContactDeleteBtn);
        click.elementBy(KeyManageContactDeleteContactbtn);
        click.elementBy(KeyDeleteContactSuccessOkbtn);
    }

    public void deleteNewlyAddedContactIOS() throws Throwable {
        clickAddParticipantCloseBtn();
        clickBackBtnIOS();
        clickBuyLoadBtn();
        clickManageContactsBtn();
        clickManageContactSearchBtn();
        enterManageContactSearchtextbox();
        clickManageContactdotBtn();
    }

    public void clickFirstRequestFormAmountEdit() throws Throwable {
        click.elementBy(KeyFirstRequestFormAmountEdit);
    }

    public void clickSecondRequestFormAmountEdit() throws Throwable {
        click.elementBy(KeySecondRequestFormAmountEdit);
    }

    public void clickUnevenlyRequestFromFirstAmount() throws Throwable {
        //driver.findElementByAccessibilityId("queen").click();
        click.elementBy(KeyUnevenlyRequestFromFirstAmount);
    }

    public void clickUnevenlyRequestFromSecondAmount() throws Throwable {
        click.elementBy(KeyUnevenlyRequestFromSecondAmount);
    }


    public void verifyparticipantamouneeditpage() throws ApplicationException {
        //type.data(KeyRequesttheamountofUnevenlyAmounttextbox,amount1);
        //click.elementBy(KeyRequesttheamountofUnevenlySaveBtn);

        verify.elementIsPresent(KeyRequesttheamountofUnevenlyAmounttextbox);

    }


    public void clickSplitBills() throws ApplicationException {
        click.elementBy(KeySplitbills);
    }

    public void enterAmountinportion(String amount) throws ApplicationException {
        Wait.waituntillElementVisibleMob(keyYourPortion,2);
        click.elementBy(keyYourPortion);
        Wait.waituntillElementVisibleMob(KeyFieldSplitbillAmountOfTextBox,2);
        click.elementBy(KeyFieldSplitbillAmountOfTextBox);
        type.data1(KeyFieldSplitbillAmountOfTextBox, amount);
        Wait.waituntillElementVisibleMob(KeySave,2);
        click.elementBy(KeySave);
    }

}