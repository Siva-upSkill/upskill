package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import gherkin.lexer.Th;
import helper.PropertyReader;
import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;


public class CreditLimitSettings_Page extends Keywords {

private String CreditcardAccount="onlineBanking.CreditLimitSettings.CreditcardAccount";
private String Cardsettings="onlineBanking.CreditLimitSettings.CardSettings";
private String  Supplementary="onlineBanking.CreditLimitSettings.Supplementary";
private String CreditLimit="onlineBanking.CreditLimitSettings.CreditLimit";
private String EditBtn="onlineBanking.CreditLimitSettings.EditButton";
private String SaveBtn="onlineBanking.CreditLimitSettings.SaveButton";
private String IncrementErrormsg="onlineBanking.CreditLimitSettings.IncrementErrormsg";
private String MaximumErrormsg="onlineBanking.CreditLimitSettings.Maximumerrormsg";
private String MinimumErrorMsg="onlineBanking.CreditLimitSettings.MinimumErrormsg";
private String  Backbtn="onlineBanking.CreditLimitSettings.BackButton";
private String SucessMsg="onlineBanking.CreditLimitSettings.SuccessMsg";
private String SavenewCredit="onlineBanking.CreditLimitSettings.SaveNewcredit";
private String GoDashboard="onlineBanking.CreditLimitSettings.GoBackDashboard";
private String EnterAmount="  onlineBanking.CreditLimitSettings.EnterAmount";
private String DontSave="onlineBanking.CreditLimitSettings.Don'tSaveNewcredit";


    public void click_CreditCardAccount() throws Throwable {
        Wait.forSeconds(10);
        AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.widget.TextView[@text=\"*7975\"]");
        element.click();
    }

   public void click_CardSettings() throws Throwable{
      Wait.waituntillElementVisibleMob(Cardsettings,2);
      click.elementBy(Cardsettings);
   }
   public void click_Supplementary() throws Throwable{
        Wait.waituntillElementVisibleMob(Supplementary,3);
        click.elementBy(Supplementary);
        click.elementBy(CreditLimit);}

   public void click_Editbtn()throws Throwable{
        Wait.waituntillElementVisibleMob(EditBtn,2);
        click.elementBy(EditBtn);
        type.data(EditBtn, PropertyReader.testDataOf("EditAmount"));

   }

   public void EnterAmount() throws Throwable{
        Wait.waituntillElementVisibleMob(EnterAmount,3);
        type.data(EnterAmount,PropertyReader.testDataOf("LimitAmount"));
    }

    public void  Enter_NonIncrementsAmount()throws Throwable{
        Wait.waituntillElementVisibleMob(EditBtn,2);
        click.elementBy(EditBtn);
        type.data(EnterAmount,PropertyReader.testDataOf("Increment_Data"));
        verify.elementIsPresent(IncrementErrormsg);

    }

    public void verify_IncrementErrormsg()throws Throwable{
        Wait.waituntillElementVisibleMob(EditBtn,2);
        click.elementBy(EditBtn);
        type.data(EnterAmount,PropertyReader.testDataOf("Increment_Data"));
        verify.elementIsPresent(IncrementErrormsg);
    }

    public void verify_MaximumErrorMsg()throws Throwable{
        Wait.waituntillElementVisibleMob(EditBtn,2);
        click.elementBy(EditBtn);
        type.data(EditBtn,PropertyReader.testDataOf("Maximum_Amount"));
        verify.elementIsPresent(MaximumErrormsg);
    }
 public void verify_MinimumErrorMsg() throws Throwable, ApplicationException {
        Wait.waituntillElementVisibleMob(EditBtn,2);
        click.elementBy(EditBtn);
        type.data(EditBtn,PropertyReader.testDataOf("Minimum_Amount"));
        verify.elementIsPresent(MinimumErrorMsg);
    }

    public void verify_SaveBtn()throws Throwable{
        Wait.waituntillElementVisibleMob(SaveBtn,2);
        verify.elementIsDisabled(SaveBtn);
    }
    public void click_Backbtn()throws Throwable{
        Wait.waituntillElementVisibleMob(Backbtn,2);
        click.elementBy(Backbtn);
    }

    public void click_SavenewCredit()throws Throwable{
        Wait.waituntillElementVisibleMob(SavenewCredit,2);
        click.elementBy(SavenewCredit);
    }

    public void click_DontSave()throws Throwable{
        Wait.waituntillElementVisibleMob(DontSave,2);
        click.elementBy(DontSave);
    }
    public void click_Savebtn()throws Throwable{
        Wait.waituntillElementVisibleMob(SaveBtn,2);
        click.elementBy(SaveBtn);
    }

    public void verify_Sucessmsg()throws Throwable{
        Wait.waituntillElementVisibleMob(SucessMsg,2);
        verify.elementIsPresent(SucessMsg);
    }

    public void click_Dashboard()throws Throwable {
        Wait.waituntillElementVisibleMob(GoDashboard,2);
        click.elementBy(GoDashboard);
    }
}
