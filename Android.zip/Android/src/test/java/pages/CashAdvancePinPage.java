package pages;

import actions.Wait;
import base.Keywords;
import exceptions.ApplicationException;
import helper.PropertyReader;
import io.appium.java_client.android.AndroidElement;

import static helper.PropertyReader.testDataOf;

public class CashAdvancePinPage extends Keywords {

    private String SetCardAccount  = "onlineBanking.CashAdvancePin.SetCardAccount";
    private String SetCardAccountData = testDataOf("Set_SetcardData");
    private String ResetCardAccount  = "onlineBanking.CashAdvancePin.ResetCardAccount";
    private String ResetCardAccountData = testDataOf("Reset_ResetcardData");
    private String SetCashAdvancePin  = "onlineBanking.CashAdvancePin.SetCashAdvancePin";
    private String ReminderMessage  ="onlineBanking.CashAdvancePin.ReminderMessage";
    private String ManageCards = "onlineBanking.CC.ManageCards";
    private String ResetpinOption = "onlineBanking.GreenPin.SetPin.ResetPinOption";
    private String PlayEverDayCardData1 = testDataOf("CP_ChangepinCardData1");
    private String PlayEverDayCard2 = "onlineBanking.GreenPin.PlayEverDayCard2";
    private String PlayEverDayCardData2 = testDataOf("CP_ChangepinCardData2");

    private String EnterPin  = "onlineBanking.CashAdvancePin.EnterPin";
    private String OTPPin1 = "onlineBanking.GreenPin.OTPPin1";
    private String OTPPin2 = "onlineBanking.GreenPin.OTPPin2";
    private String OTPPin3 = "onlineBanking.GreenPin.OTPPin3";
    private String OTPPin4 = "onlineBanking.GreenPin.OTPPin4";
    private String OTPPin5 = "onlineBanking.GreenPin.OTPPin5";
    private String OTPPin6 = "onlineBanking.GreenPin.OTPPin6";
    private String PinValidationErrorMessage  = "onlineBanking.CashAdvancePin.doesntMatchPreviousPINInput";
    private String SetPin = "onlineBanking.GreenPin.SetPin";

    private String InvalidOTPMessage  = "onlineBanking.CashAdvancePin.InvalidOTPMessage";
    private String SixDigitPin  = "onlineBanking.CashAdvancePin.SixDigitPin";
    private String SixDigitCreditPin  = "onlineBanking.CashAdvancePin.SixDigitCreditPin";
    private String ClearPin  = "onlineBanking.CashAdvancePin.ClearPin";
    private String ResetCashAdvancePin  = "onlineBanking.CashAdvancePin.ResetCashAdvancePin";

    public void click_CardAccount() throws Throwable {
        Wait.forSeconds(3);
        AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.view.ViewGroup[@resource-id=\"com.unionbankph.online.qat:id/container\"]");
        element.click();

    }
    public void click_ResetCardAccount() throws Throwable {
        Wait.forSeconds(4);
        AndroidElement element = (AndroidElement) driver.findElementByXPath("//android.view.ViewGroup[@resource-id=\"com.unionbankph.online.qat:id/container\"]");
        element.click();
    }

    public void verifySetCashAdvancedPin()throws Throwable {
        Wait.waituntillElementVisibleMob(SetCashAdvancePin,5);
//        Wait.forSeconds(5);
        verify.elementTextMatching(SetCashAdvancePin, PropertyReader.testDataOf("Set_SetCashAdvanceLabel").trim());
    }
    public void verifyInvalidOTPMessage()throws Throwable {
//        Wait.forSeconds(3);
        Wait.waituntillElementVisibleMob(InvalidOTPMessage,5);
        verify.elementTextMatching(InvalidOTPMessage, PropertyReader.testDataOf("Set_InvalidOTPMessage").trim());
    }
    public void SetOTP() throws ApplicationException {
        Wait.waituntillElementVisibleMob(EnterPin,4);
//        Wait.forSeconds(4);
        type.data1(EnterPin,"130495");

    }
    public void SetOTP1() throws ApplicationException {
//        Wait.forSeconds(4);
       Wait.waituntillElementVisibleMob(EnterPin,5);
       type.data1(EnterPin,"998875");
//        Wait.forSeconds(2);
    }
    public void SetOTP2() throws ApplicationException {
//        Wait.forSeconds(8);
      Wait.waituntillElementVisibleMob(EnterPin,6);
      type.data1(EnterPin,"664805");
//        Wait.forSeconds(8);
    }
    public void enterConsecutiveSixDigits() throws Throwable {
        Wait.waituntillElementVisibleMob(EnterPin,5);
//        Wait.forSeconds(3);
        type.data1(EnterPin,PropertyReader.testDataOf("CP_ConsecutiveDigitPin"));

    }
    public void enterSameDigitsPin() throws Throwable {
//        Wait.forSeconds(3);
        Wait.waituntillElementVisibleMob(EnterPin,5);
        type.data1(EnterPin,PropertyReader.testDataOf("CP_SameDigitPin"));

    }

    public void click_PlayEveryDayCard2() throws Throwable {
        Wait.forSeconds(4);
       click.elementBy(PlayEverDayCard2, PlayEverDayCardData2);
    }

    public void ValidDigitsPin() throws Throwable {
//        Wait.forSeconds(3);
        Wait.waituntillElementVisibleMob(EnterPin,5);
        type.data1(EnterPin,PropertyReader.testDataOf("CP_ValidDigitPin"));

    }
    public void consecutiveErrMsg() throws Throwable {
//        Wait.forSeconds(3);
        Wait.waituntillElementVisibleMob(PinValidationErrorMessage,6);
        verify.elementTextMatching(PinValidationErrorMessage, PropertyReader.testDataOf("Set_ConsecutiveErrorMessage").trim());
    }
    public void samePinErrMgs() throws Throwable {
//        Wait.forSeconds(3);
       Wait.waituntillElementVisibleMob(PinValidationErrorMessage,4);
        verify.elementTextMatching(PinValidationErrorMessage, PropertyReader.testDataOf("Set_SameDigitErrorMessage").trim());
    }

    public void PinDoesntMatchErrMsg() throws Throwable {
//        Wait.forSeconds(3);
       Wait.waituntillElementVisibleMob(PinValidationErrorMessage,4);
        verify.elementTextMatching(PinValidationErrorMessage, PropertyReader.testDataOf("Set_DoesnotMatchErrorMessage").trim());
    }
    public void verifySixDigitPin()throws Throwable {
//        Wait.forSeconds(3);
        Wait.waituntillElementVisibleMob(SixDigitPin,4);
        verify.elementTextMatching(SixDigitPin, PropertyReader.testDataOf("Set_SetCashLabelDescription").trim());
    }
    public void verifySixDigitCreditPin()throws Throwable {
//        Wait.forSeconds(3);
        Wait.waituntillElementVisibleMob(SixDigitCreditPin,4);
        verify.elementTextMatching(SixDigitCreditPin, PropertyReader.testDataOf("Reset_ResetcashLabelDescription").trim());
    }
    public void verifyReminders() throws Throwable {
//        Wait.forSeconds(2);
       Wait.waituntillElementVisibleMob(ReminderMessage,4);
        verify.elementIsPresent(ReminderMessage);
    }
    public void click_SetCardPin() throws Throwable {
//        Wait.forSeconds(2);
        Wait.waituntillElementVisibleMob(SetCashAdvancePin,4);
        click.elementBy(SetCashAdvancePin);
    }
    public void click_ResetCardPin() throws Throwable {
//        Wait.forSeconds(2);
       Wait.waituntillElementVisibleMob(ResetCashAdvancePin,4);
        click.elementBy(ResetCashAdvancePin);
    }
    public void click_ClearPin() throws Throwable {
//        Wait.forSeconds(2);
       Wait.waituntillElementVisibleMob(ClearPin,4);
        verify.elementIsPresent(ClearPin);
        click.elementBy(ClearPin);
    }
    public void verifyResetCashAdvancedPin()throws Throwable {
//        Wait.forSeconds(8);
        Wait.waituntillElementVisibleMob(ResetCashAdvancePin,4);
        verify.elementTextMatching(ResetCashAdvancePin, PropertyReader.testDataOf("Reset_ResetCashAdvancePin").trim());
    }
    public void click_ManageCards() throws Throwable {
        Wait.forSeconds(4);
        click.elementBy(ManageCards);
    }
    public void click_SetPin() throws Throwable {
        Wait.forSeconds(2);
       click.elementBy(SetPin);
    }
//    public void verifyOTPpageisdisplayed() throws Throwable {
//        Wait.forSeconds(3000);
//        //click.elementBy(keyOTPfield);
//        verify.elementIsPresent(keyOTPfield);
//    }
    public void ClickResetPin() throws Throwable{
        Wait.forSeconds(2);
        click.elementBy(ResetpinOption);
    }


}
