public class testCase1 {
    public static void main(String[] args) {
        String v=" 13,266.48";
        v=v.trim();
        System.out.println(v);
    }
}
